#!/usr/bin/env python3
"""Offline source-integrity and exact-algebra replay; not a formal proof checker."""
import argparse
import hashlib
import io
import json
import os
from pathlib import Path, PurePosixPath
import re
import stat
import subprocess
import sys
import tempfile
from zipfile import ZipFile

sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parent
PACKAGE = 'ym-finite-positive-mixed-acg-axis-rigidity-20261019'
DEP = 'ym-finite-positive-acg-axis-rigidity-20261019'
DEP_SHA = '273ea8168a922477bb33208b7d7ef7b4b256f3ba962421d563a35153b5f92c08'
PRIMARY = 'mixed-acg-axis-next-20261019'
AUDIT = 'mixed-axis-audit-20261019'
PRIMARY_SHA = 'ebca4d967e7a70cac865f8afd2d94dbf50d745757e7c8da898775bf60261c918'
AUDIT_SHA = 'fb91eaf4f007450c384908b90f7ef407e4cc69559401084f1ae9703f0697e099'
HISTORICAL_SHA = '3a921036dd6a15e02df86e7191a4d6c18ec4f7a1595a88bc8be7fc45ff9d7d6b'
CHECK_OUTPUTS = {
    PRIMARY: '8bca398241f5ad6fd9766ce78e571a321a5f7dfcfcdd1488214b7f9e19342658',
    AUDIT: 'fe1054bcbd0ed998b4f022dd0ab39e68105992f17b855b3ab5018c88dfc35cb5',
}
CHECK_COUNTS = {PRIMARY: 55, AUDIT: 36}


def require(condition, message):
    if not condition:
        raise RuntimeError(message)


def sha(data):
    return hashlib.sha256(data).hexdigest()


def safe_name(name):
    p = PurePosixPath(name)
    require(bool(name) and not p.is_absolute() and '\\' not in name and name == p.as_posix()
            and '..' not in p.parts and bool(p.parts), 'Unsafe payload path: ' + name)
    return name


def parse_manifest(data):
    entries = {}
    for line in data.decode().splitlines():
        digest, name = line.split('  ', 1)
        safe_name(name)
        require(re.fullmatch('[0-9a-f]{64}', digest) is not None, 'Invalid digest: ' + name)
        require(name not in entries and name != 'SHA256SUMS', 'Duplicate or self-referential manifest: ' + name)
        entries[name] = digest
    require(bool(entries), 'Empty manifest')
    return entries


def verify_tree(root=None):
    root = ROOT if root is None else Path(root)
    require(not (root / 'SHA256SUMS').is_symlink(), 'Symlink in payload manifest')
    entries = parse_manifest((root / 'SHA256SUMS').read_bytes())
    found = set()
    for p in root.rglob('*'):
        require(not p.is_symlink(), 'Symlink in payload: ' + str(p))
        if p.is_file():
            found.add(p.relative_to(root).as_posix())
        else:
            require(p.is_dir(), 'Nonregular payload: ' + str(p))
    require(found == set(entries) | {'SHA256SUMS'}, 'Manifest file-set mismatch')
    for name, digest in entries.items():
        require(sha((root / name).read_bytes()) == digest, 'Integrity mismatch: ' + name)
    return len(entries)


def verify_zip(data, prefix, digest):
    require(sha(data) == digest, 'Dependency archive identity mismatch: ' + prefix)
    contents = {}
    with ZipFile(io.BytesIO(data)) as z:
        for entry in z.infolist():
            name = safe_name(entry.filename)
            require(not entry.is_dir() and name.startswith(prefix + '/'), 'Unexpected archive path: ' + name)
            require(name not in contents, 'Duplicate ZIP entry: ' + name)
            require(not stat.S_ISLNK(entry.external_attr >> 16), 'Symlink ZIP entry: ' + name)
            contents[name] = z.read(entry)
    manifest = parse_manifest(contents[prefix + '/SHA256SUMS'])
    require(set(contents) == {prefix + '/' + name for name in manifest} | {prefix + '/SHA256SUMS'},
            'Dependency manifest file-set mismatch: ' + prefix)
    for name, digest in manifest.items():
        require(sha(contents[prefix + '/' + name]) == digest, 'Dependency integrity mismatch: ' + name)
    return contents


def dependency_contents(root=None):
    root = ROOT if root is None else Path(root)
    return verify_zip((root / 'dependencies' / (DEP + '.zip')).read_bytes(), DEP, DEP_SHA)


def dependency_index(contents):
    """Read nested archives in memory only; inherit pins from their verified parent."""
    index = dict(contents)
    for name, data in sorted(contents.items()):
        if name.endswith('.zip'):
            with ZipFile(io.BytesIO(data)) as z:
                names = z.namelist()
                require(bool(names), 'Empty nested dependency')
                prefix = PurePosixPath(safe_name(names[0])).parts[0]
            nested = verify_zip(data, prefix, sha(data))
            for member, value in dependency_index(nested).items():
                key = name + '!/' + member
                require(key not in index, 'Duplicate nested identity')
                index[key] = value
    return index


def source_bytes(original_path, index, root=None):
    root = ROOT if root is None else Path(root)
    p = Path(original_path)
    require(str(p).startswith('/workspace/shared/'), 'Unexpected original source path: ' + str(p))
    tail = p.relative_to('/workspace/shared').as_posix()
    safe_name(tail)
    if p.parent.name in (PRIMARY, AUDIT):
        return (root / tail).read_bytes()
    if tail == 'finite-axis-rp-next-20261019/NEXT_CANDIDATE.md':
        return (root / 'provenance-inputs' / tail).read_bytes()
    matches = [value for name, value in index.items() if name.endswith('/' + tail)]
    require(bool(matches), 'Unresolved pinned source: ' + str(p))
    require(all(value == matches[0] for value in matches), 'Ambiguous pinned source: ' + str(p))
    return matches[0]


def verify_sources(contents, root=None):
    root = ROOT if root is None else Path(root)
    require(sha((root / PRIMARY / 'RESULT.md').read_bytes()) == PRIMARY_SHA, 'Accepted primary hash mismatch')
    require(sha((root / AUDIT / 'AUDIT.md').read_bytes()) == AUDIT_SHA, 'Accepted audit hash mismatch')
    require(sha((root / 'provenance-inputs/finite-axis-rp-next-20261019/NEXT_CANDIDATE.md').read_bytes()) == HISTORICAL_SHA,
            'Historical provenance hash mismatch')
    index = dependency_index(contents)
    primary_sources = json.loads((root / PRIMARY / 'SOURCE_MANIFEST.json').read_text())
    audit_sources = json.loads((root / AUDIT / 'SOURCE_MANIFEST.json').read_text())['sources']
    pinned = []
    for entry in primary_sources + audit_sources:
        data = source_bytes(entry['path'], index, root)
        require(len(data) == entry['bytes'] and sha(data) == entry['sha256'], 'Pinned source mismatch: ' + entry['path'])
        pinned.append({'original_path': entry['path'], 'sha256': sha(data)})
    for entry in json.loads((root / PRIMARY / 'ARTIFACT_MANIFEST.json').read_text())['artifacts']:
        name = safe_name(entry['path'])
        data = (root / PRIMARY / name).read_bytes()
        require(len(data) == entry['bytes'] and sha(data) == entry['sha256'], 'Original artifact mismatch: ' + name)
    final = json.loads((root / PRIMARY / 'FINAL_HASH_RECONCILIATION.json').read_text())
    require(final['status'] == 'passed' and final['result_and_independent_audit_reconciled'] is True
            and final['remote_changes'] is False, 'Final reconciliation status mismatch')
    expected_paths = {f'/workspace/shared/{PRIMARY}/RESULT.md', f'/workspace/shared/{PRIMARY}/ARTIFACT_MANIFEST.json',
                      f'/workspace/shared/{AUDIT}/AUDIT.md', f'/workspace/shared/{AUDIT}/FINAL_RECONCILIATION.json'}
    require({entry['path'] for entry in final['records']} == expected_paths and len(final['records']) == 4,
            'Final reconciliation record set mismatch')
    for entry in final['records']:
        data = source_bytes(entry['path'], index, root)
        require(entry['bytes'] == len(data) and entry['sha256'] == sha(data), 'Final reconciliation target mismatch')
    audit_final = json.loads((root / AUDIT / 'FINAL_RECONCILIATION.json').read_text())
    require(audit_final['status'] == 'PASS' and audit_final['independent_exact_checks'] == 36,
            'Audit final reconciliation status mismatch')
    for key, expected in [('reviewed_result', PRIMARY_SHA), ('independent_audit', AUDIT_SHA)]:
        entry = audit_final[key]
        data = source_bytes(entry['path'], index, root)
        require(entry['bytes'] == len(data) and entry['sha256'] == expected == sha(data), 'Audit final target mismatch')
    exact = (root / PRIMARY / 'exact-checks.json').read_bytes()
    require(sha(exact) == CHECK_OUTPUTS[PRIMARY] and json.loads(exact)['count'] == 55, 'Saved exact output mismatch')
    for filename in ['regression-validation.json', 'regression-validation-optimized.json']:
        report = json.loads((root / PRIMARY / filename).read_text())
        require(report == {'status': 'passed', 'ordinary_optimized_identical': True,
                          'corrupted_residue_rejected_in_both_modes': True,
                          'corrupted_negative_gamma_rejected_in_both_modes': True,
                          'exact_output_sha256': CHECK_OUTPUTS[PRIMARY], 'exact_check_count': 55},
                'Saved primary regression mismatch')
    audit_report = json.loads((root / AUDIT / 'REGRESSION_REPORT.json').read_text())
    require(audit_report['status'] == 'PASS' and len(audit_report['runs']) == 2, 'Saved audit regression mismatch')
    require({entry['harness'] for entry in audit_report['runs']} == {'ordinary_harness', 'optimized_harness'},
            'Saved audit harness set mismatch')
    for entry in audit_report['runs']:
        report = entry['result']
        require(report['status'] == 'PASS' and report['exact_count'] == 36
                and report['exact_output_sha256'] == CHECK_OUTPUTS[AUDIT]
                and report['runs'] == [{'false_oblate_residue': 'REJECTED', 'mode': mode, 'valid': 'PASS'}
                                       for mode in ['ordinary', 'optimized']], 'Saved audit run mismatch')
    provenance = json.loads((root / 'PROVENANCE.json').read_text())
    require(provenance['primary_sha256'] == PRIMARY_SHA and provenance['audit_sha256'] == AUDIT_SHA,
            'Provenance accepted hash mismatch')
    require(provenance['remote_changes'] is False, 'Provenance remote status mismatch')
    actual_originals = set()
    for item in provenance['originals']:
        name = safe_name(item['package_path'])
        require(name not in actual_originals, 'Duplicate provenance original')
        actual_originals.add(name)
        data = (root / name).read_bytes()
        require(sha(data) == item['sha256'] and len(data) == item['bytes'], 'Provenance original mismatch')
    expected_originals = {p.relative_to(root).as_posix() for folder in [PRIMARY, AUDIT, 'provenance-inputs']
                          for p in (root / folder).rglob('*') if p.is_file()}
    require(actual_originals == expected_originals, 'Provenance original file-set mismatch')
    require(provenance['dependency']['sha256'] == DEP_SHA
            and provenance['dependency']['bytes'] == len((root / 'dependencies' / (DEP + '.zip')).read_bytes()),
            'Provenance dependency pin mismatch')
    return {'primary_sha256': PRIMARY_SHA, 'audit_sha256': AUDIT_SHA, 'source_pins_verified': pinned,
            'historical_candidate': 'PRESERVED_AS_PROVENANCE_ONLY', 'automated_proof_check': False}


def write_contents(contents, directory):
    for name, data in contents.items():
        safe_name(name)
        path = directory / name
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_bytes(data)


def run(command, env, cwd):
    return subprocess.run(command, capture_output=True, env=env, cwd=cwd)


def current_checks(env):
    reports = []
    for folder in [PRIMARY, AUDIT]:
        controls = [('--corrupt-residue', 'upper residue: nonzero exact residual'),
                    ('--corrupt-negative-gamma', 'negative gamma endpoint: nonzero exact residual')] if folder == PRIMARY else [
                    ('--flip-oblate-residue', 'oblate_coincident_upper_residue: expected zero')]
        script = ROOT / folder / 'check_exact_identities.py'
        runner = script.with_name('verify_regression_modes.py')
        outputs, regressions = [], []
        for options in ([], ['-O']):
            command = [sys.executable, *options, str(script)]
            result = run(command, env, ROOT)
            require(result.returncode == 0, 'Exact check failed: ' + folder + '\n' + result.stderr.decode())
            require(sha(result.stdout) == CHECK_OUTPUTS[folder], 'Exact output mismatch: ' + folder)
            parsed = json.loads(result.stdout)
            require(parsed['count'] == CHECK_COUNTS[folder], 'Exact check count mismatch')
            outputs.append(result.stdout)
            for flag, marker in controls:
                bad = run(command + [flag], env, ROOT)
                require(bad.returncode != 0 and marker in bad.stderr.decode(), 'Corruption wrongly accepted: ' + folder + ' ' + flag)
            regression = run([sys.executable, *options, str(runner)], env, ROOT)
            require(regression.returncode == 0, 'Original regression runner failed: ' + folder + '\n' + regression.stderr.decode())
            regressions.append(regression.stdout)
        require(outputs[0] == outputs[1], 'Normal/optimized exact outputs differ')
        require(regressions[0] == regressions[1], 'Normal/optimized original runner outputs differ')
        reports.append({'source': folder, 'exact_checks': CHECK_COUNTS[folder], 'output_sha256': CHECK_OUTPUTS[folder],
                        'normal_and_optimized': 'PASS', 'corruptions_both_modes': [flag for flag, _ in controls],
                        'corruption_result': 'EXPECTED_REJECTION', 'original_runner_both_modes': 'PASS',
                        'runner_output_sha256': sha(regressions[0])})
    return reports


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--integrity-only', action='store_true')
    parser.add_argument('--with-dependency-replay', action='store_true')
    args = parser.parse_args()
    require(not (args.integrity_only and args.with_dependency_replay), 'Choose one replay mode')
    files = verify_tree()
    contents = dependency_contents()
    report = {'status': 'PASS', 'integrity_files': files, 'sources': verify_sources(contents)}
    env = dict(os.environ, PYTHONDONTWRITEBYTECODE='1', PYTHONHASHSEED='0')
    env.pop('PYTHONOPTIMIZE', None)
    with tempfile.TemporaryDirectory(prefix='mixed-axis-dependency-') as directory:
        work = Path(directory)
        write_contents(contents, work)
        options = ['-O'] if sys.flags.optimize else []
        replay_flag = '--with-dependency-replay' if args.with_dependency_replay else '--integrity-only'
        dep_result = run([sys.executable, *options, str(work / DEP / 'reproduce.py'), replay_flag], env, work)
        require(dep_result.returncode == 0, 'Inherited dependency replay failed:\n' + dep_result.stderr.decode())
        dependency = json.loads(dep_result.stdout)
        require(dependency.get('status') == 'PASS', 'Inherited replay did not pass')
        report['dependency'] = {'archive_sha256': DEP_SHA, 'mode': replay_flag, 'result': dependency,
                                'output_sha256': sha(dep_result.stdout)}
    if not args.integrity_only:
        import sympy
        require(sympy.__version__ == '1.14.0', 'SymPy 1.14.0 required')
        report.update({'python': sys.version.split()[0], 'sympy': sympy.__version__,
                       'new_exact_check_total': 91, 'checks': current_checks(env)})
    report['claim_boundary'] = ('Finite positive mixed prolate/oblate ACG axis mixtures; under reflection invariance, '
                               'mirror RP forces every anisotropically active axis normal or tangent. Arbitrary positive '
                               'Borel parameter measures on (-1,1) are covered; zero atoms are isotropic, +/-1 atoms excluded. '
                               'Uniform continuous axis averaging is an isotropic counterexample to unrestricted representation-level '
                               'necessity; arbitrary nonconstant continuous classification remains unresolved. Scalar Gaussian '
                               'covariance only; no interacting Yang-Mills or mass-gap claim.')
    print(json.dumps(report, indent=2, sort_keys=True))


if __name__ == '__main__':
    main()
