#!/usr/bin/env python3
"""Exact regression checks; explicit failures survive python -O."""
import argparse
import json
import sympy as S


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--corrupt-residue", action="store_true")
    parser.add_argument("--corrupt-negative-gamma", action="store_true")
    args = parser.parse_args()
    checks = []

    def check(name, expression):
        reduced = S.factor(S.cancel(S.together(expression)))
        if reduced != 0:
            reduced = S.simplify(reduced)
        if reduced != 0:
            raise RuntimeError(f"{name}: nonzero exact residual {reduced}")
        checks.append(name)

    lam, eta, t, y = S.symbols("lambda eta t y", real=True)
    A, C = 1+lam, 1-lam
    D = A*A-4*lam*t*t
    G = A/D
    P = C*(A*A+4*lam*t*t)/D**2
    check("differentiated generating function", 2*lam*S.diff(G,lam)+G-P)
    check("all-sign ACG decomposition", A*P/2+C*G/2-C*A**3/D**2)
    check("ACG beta substitution", (C/A)/(1+(C*C/A**2-1)*t*t)**2-C*A**3/D**2)
    check("positive-lambda denominator lower identity", D-C*C-4*lam*(1-t*t))
    check("negative-lambda denominator lower identity", D-A*A+4*lam*t*t)
    j = S.symbols("j", integer=True, nonnegative=True)
    check("all-degree mixture coefficient", (1+A*j)/(2*j+1)-A/2-C/(2*(2*j+1)))
    check("outer mixture weights", A/2+C/2-1)
    for degree in range(13):
        coefficient = S.diff(G,lam,degree).subs(lam,0)/S.factorial(degree)
        check(f"even generating coefficient {degree}", coefficient-S.chebyshevu(2*degree,t))

    X, Y, q, tau, ap = S.symbols("X Y q tau ap", positive=True)
    L = (1+eta)*X+(1-eta)*Y
    swap = (1-eta)*X+(1+eta)*Y
    check("negative-eta denominator square", L**2+4*eta*(Y*Y-X*X)-swap**2)
    check("negative-eta projection remainder", L**2+4*eta*tau*ap**2-(swap**2+4*eta*tau*(ap**2-q)-4*eta*(Y*Y-X*X-tau*q)))
    yy = (X-Y)/(X+Y)
    h0 = 2/(X*(X+Y))
    Gey = (1+eta*yy)/((1+eta*yy)**2-4*eta*yy*t*t)
    check("physical T closed form", h0*Gey-2*L/(X*(L**2+4*eta*(Y*Y-X*X)*t*t)))
    s = S.symbols("s", positive=True)
    d = 1+eta+(1-eta)*s
    gamma = 4*eta*(s*s-1)/d**2
    check("homogeneous reduction", (2*L/(X*(L*L+4*eta*(Y*Y-X*X)*t*t))).subs(Y,s*X)-2/d/(X*X+gamma*X*X*t*t))
    check("gamma derivative", S.diff(gamma,eta)-4*(s*s-1)*(1+s+(s-1)*eta)/d**3)
    target_negative = -(s*s-1)/(s*s)
    if args.corrupt_negative_gamma:
        target_negative = -target_negative
    check("negative gamma endpoint", gamma.subs(eta,-1)-target_negative)
    check("positive gamma endpoint", gamma.subs(eta,1)-(s*s-1))
    check("zero gamma", gamma.subs(eta,0))
    check("d lower bound", d-2-(s-1)*(1-eta))
    check("d upper bound", 2*s-d-(s-1)*(1+eta))
    check("gamma greater than minus one square", d*d+4*eta*(s*s-1)-(1+s+(s-1)*eta)**2)
    check("opposite-eta gamma duality", gamma.subs(eta,-eta)+gamma/(1+gamma))

    gg, K, alpha, beta, u = S.symbols("gamma K alpha beta u", real=True)
    Ag = 1+gg*alpha**2
    Dg = K*Ag+gg*beta**2
    x = -gg*alpha*beta/Ag
    y2 = Dg/Ag**2
    circle = (K*alpha**2-beta**2)/(alpha*beta)
    check("quadratic discriminant", Ag*(K+gg*beta**2)-(gg*alpha*beta)**2-Dg)
    check("negative-gamma discriminant bound identity", Dg-K*(1+gg)-gg*(K*alpha**2+beta**2-K))
    check("negative-gamma quadratic coefficient bound identity", Ag-(1+gg)-gg*(alpha**2-1))
    check("pole real equation", Ag*(x*x-y2)+2*gg*alpha*beta*x+K+gg*beta*beta)
    check("pole imaginary equation", 2*Ag*x+2*gg*alpha*beta)
    check("pole circle", x*x+y2-K-circle*x)
    check("pole monotonicity", S.diff(x,gg)+alpha*beta/Ag**2)
    check("quadratic factorization", Ag*((u-x)**2+y2)-(u*u+K+gg*(alpha*u+beta)**2))
    r1, r2 = S.symbols("r1 r2", nonzero=True, real=True)
    check("circle coincidence factorization", K/r1-r1-K/r2+r2+(r1-r2)*(r1*r2+K)/(r1*r2))

    dd, AA, yp, xp = S.symbols("d A yp xp", positive=True)
    residue = -S.I/(dd*AA*yp)
    if args.corrupt_residue:
        residue = -residue
    check("upper residue", 2/(dd*AA*2*S.I*yp)-residue)
    check("partial fractions", 2/(dd*AA*((u-xp)**2+yp**2))-(-S.I/(dd*AA*yp)/(u-xp-S.I*yp)+S.I/(dd*AA*yp)/(u-xp+S.I*yp)))

    xx, yy, qq, cc = S.symbols("x y q c", real=True)
    U = xx+S.I*yy
    W = (U-S.I*qq)/(U+S.I*qq)
    WD = xx*xx+(yy+qq)**2
    check("Cayley real imaginary formula", W-(xx*xx+yy*yy-qq*qq-2*S.I*qq*xx)/WD)
    check("Cayley circle ray", W-xx*(cc-2*S.I*qq)/WD-(xx*xx+yy*yy-qq*qq-cc*xx)/WD)
    Wconj = (xx-S.I*yy-S.I*qq)/(xx-S.I*yy+S.I*qq)
    check("Cayley conjugate inversion", Wconj-1/S.conjugate(W))
    check("Cayley upper inside unit disk", W*S.conjugate(W)-1+4*yy*qq/WD)

    # Opposite gamma signs and orthogonal projected slopes, exactly coincident poles.
    same_pole = (S.Integer(12)+35*S.I)/37
    for label, ev, bv, target_g, target_res in (
        ("prolate", S.Rational(1,2), -1/S.sqrt(2), S.Rational(24,25), -2*S.I/7),
        ("oblate", -S.Rational(1,2), 1/S.sqrt(2), -S.Rational(24,49), -2*S.I/5),
    ):
        gv = gamma.subs({eta:ev,s:2})
        dv = d.subs({eta:ev,s:2})
        av = 1/S.sqrt(2)
        Agv = 1+gv*av**2
        Dgv = 1+gv*(av**2+bv**2)
        xv = -gv*av*bv/Agv
        yv = S.sqrt(Dgv)/Agv
        check(f"coincident {label} gamma", gv-target_g)
        check(f"coincident {label} pole", xv+S.I*yv-same_pole)
        check(f"coincident {label} residue", -S.I/(dv*S.sqrt(Dgv))-target_res)

    abs_lam = S.symbols("abs_lambda", positive=True)
    check("effective measure unit mass either sign", (1+lam)/2+(1-lam)/(4*S.sqrt(abs_lam))*2*S.sqrt(abs_lam)-1)
    b, kappa, h = S.symbols("b kappa h", positive=True)
    check("real scaling", kappa**2/(b+kappa**2*(u*u+K+tau*h*h))-1/(b/kappa**2+u*u+K+tau*h*h))
    print(json.dumps({"status":"passed", "count":len(checks), "checks":checks}, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
