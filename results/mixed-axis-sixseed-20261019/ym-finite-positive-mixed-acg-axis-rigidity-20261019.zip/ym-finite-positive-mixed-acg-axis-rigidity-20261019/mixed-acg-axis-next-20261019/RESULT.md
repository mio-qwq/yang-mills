# Finite positive mixed prolate/oblate ACG axes: an oblique axis forbids mirror RP

19 October 2026. Local scalar Gaussian covariance research only. No remote changes, merge, release, or publication.

## 1. Precise theorem

Let a_1,...,a_N be finitely many unoriented unit axes in R^4. Let c_0>=0, c_j>0, and c_0+sum_j c_j=1. Each P_j is a positive probability Borel measure supported in a compact subset of (-1,1), with P_j({0})=0. The support may contain both signs and may accumulate at zero. Define

    beta(lambda)=((1-lambda)/(1+lambda))^2,
    rho_(lambda,a)(v)=sqrt(beta(lambda))
          /[1+(beta(lambda)-1)(a.v)^2]^2,
    rho(v)=c_0+sum_j c_j integral rho_(lambda,a_j)(v) P_j(d lambda),
    F_b(p)=integral_(S^3) rho(v)/[b+|p|^2+tau(p.v)^2] d sigma(v),

where d sigma is probability surface measure, b>0, and tau>0. Assume rho is invariant under the reflection R_n with unit normal n.

**Theorem.** If F_b is reflection positive at n, every active axis a_j is parallel or perpendicular to n. Equivalently, even one active axis with 0<|a_j.n|<1 forces failure of reflection positivity, for every b,tau>0 and every positive coefficient on that axis, regardless of the nonnegative isotropic background.

More precisely, for any unit m perpendicular to n such that some (a_j.n)(a_j.m) is nonzero, every sufficiently large finite tangential frequency kappa m has a strictly negative compact-positive-time Hankel form. A finite tangential wave packet produces a real C_c^infinity spacetime witness supported strictly inside the positive half-space.

An atom at lambda=0 is harmless: it is exactly isotropic and may be extracted into c_0, followed by renormalizing each remaining nonzero axis measure. Thus the equivalent general formulation allows P_j({0})>0 and calls an axis active precisely when it carries positive mass at lambda!=0. Purely isotropic summands impose no axis restriction.

This extends the accepted finite-positive-prolate theorem to all ordinary ACG anisotropies beta>0, beta!=1, with arbitrary positive compact-inner parameter measures. It is a necessity theorem, not a sufficiency theorem. It excludes signed mixtures, infinitely many axes, and arbitrary angular densities. It makes no interacting Yang-Mills, mass-gap, or main-problem claim.

## 2. Direct all-sign harmonic identity

No analytic continuation in lambda is needed. Fix -1<lambda<1 and write A=1+lambda>0, C=1-lambda>0. With U_l the Chebyshev polynomials of the second kind,

    G_lambda(t)=sum_(j>=0) lambda^j U_(2j)(t)
       =A/[A^2-4lambda t^2],
    P_lambda(t)=sum_(j>=0)(2j+1)lambda^j U_(2j)(t)
       =C[A^2+4lambda t^2]/[A^2-4lambda t^2]^2.

These series and the differentiated series converge absolutely and uniformly on t in [-1,1], since |U_(2j)(t)|<=2j+1 and |lambda|<1. Their real denominators are strictly positive: for lambda>=0 the minimum is (1-lambda)^2, and for lambda<0 it is (1+lambda)^2.

The exact algebraic identity

    rho_(lambda,a)(v)
       =(A/2)P_lambda(a.v)+(C/2)G_lambda(a.v)
       =C A^3/[A^2-4lambda(a.v)^2]^2
       =sum_(j>=0)[1+(1+lambda)j]lambda^j U_(2j)(a.v)       (1)

holds for both signs. Every positive harmonic degree has spherical mean zero, so rho is normalized. Its positivity and smoothness follow directly from the ACG formula. Negative lambda produces alternating harmonic coefficients; neither positivity of those coefficients nor positivity of P_lambda is asserted.

For real p!=0 put q=|p|^2, e=p/sqrt(q), X=sqrt(b+q), Y=sqrt(b+(1+tau)q),

    y=(X-Y)/(X+Y), h_0=2/[X(X+Y)].

Here -1<y<0. The accepted zonal convolution identity on S^3 is

    integral U_l(a.v)U_m(e.v) d sigma(v)
       =1_(l=m) U_l(a.e)/(l+1).

The generating expansion of the angular denominator is h_0 sum_j y^j U_(2j)(e.v). Absolute uniform convergence of both factors justifies integration term by term. Thus

    F_(lambda,a)(p)=h_0 sum_(j>=0)
       [1+(1+lambda)j](lambda y)^j U_(2j)(a.e)/(2j+1).

Define T_(eta,a)(p)=h_0 G_(eta y)(a.e) for every -1<eta<1. The coefficient identity

    [1+(1+lambda)j]/(2j+1)
       =(1+lambda)/2+(1-lambda)/[2(2j+1)]

and integral_0^1 r^(2j) dr=1/(2j+1) yield

    F_(lambda,a)=(1+lambda)T_(lambda,a)/2
         +(1-lambda)/2 integral_0^1 T_(lambda r^2,a) dr.    (2)

The r integration is justified by the same absolute uniform bounds, uniformly over 0<=r<=1. Both outer weights are strictly positive and sum to one. For lambda<0 the effective parameter eta=lambda r^2 is negative. Also T_(eta,a)>0 on real momenta, because G_z(t)>0 for real -1<z<1 and |t|<=1. This last fact does not claim that the auxiliary angular expression P_eta is nonnegative for negative eta, or that the accepted normal-axis RP theorem extends to negative eta.

At p=0 all T and F equal 1/b, so (2) extends continuously. At b=0 the same proof works directly for real p!=0, with y=(1-s)/(1+s), s=sqrt(1+tau). Alternatively dominated convergence in the original positive angular integral gives that limit. No complex b->0 limit is used.

## 3. Physical real-momentum denominator and positive effective measure

Algebra in the generating function gives

    T_(eta,a)(p)=2[(1+eta)+(1-eta)Y/X]
      /{[(1+eta)X+(1-eta)Y]^2+4eta tau(a.p)^2}.             (3)

Both X and Y in this formula are the positive real square roots. For eta>=0 the denominator is positive. For eta<0, since (a.p)^2<=q and Y^2-X^2=tau q, it is bounded below by

    [(1+eta)X+(1-eta)Y]^2+4eta tau q
       =[(1-eta)X+(1+eta)Y]^2>0.                         (4)

This establishes the negative-parameter identity on the physical real-momentum branch before taking the homogeneous reduction. There is no inferred alternate complex square-root branch.

For any positive P on a compact subset of (-1,1), with P({0})=0, define the effective measure M by its integral against bounded Borel phi:

    integral phi(eta) M(d eta)
      =integral [(1+lambda)phi(lambda)/2
          +(1-lambda)/2 integral_0^1 phi(lambda r^2) dr] P(d lambda).  (5)

It is a positive probability measure. Its support lies in the union of the intervals joining the original parameter support to zero. It has no atom at zero and carries nonzero mass at eta!=0. In explicit measure notation, away from zero,

    M(d eta)=(1+eta)P(d eta)/2
       +[1/(4sqrt(|eta|))]
          integral_(lambda eta>0, |lambda|>=|eta|)
               (1-lambda)/sqrt(|lambda|) P(d lambda) d eta.         (6)

For eta<0 the inner domain is lambda<=eta<0; for eta>0 it is lambda>=eta>0. Formula (6) follows by eta=lambda r^2 with the positive absolute Jacobian. The displayed density is finite for each eta!=0 and integrable at zero by Tonelli, even when original parameters accumulate there. For an original atom at zero, (5) gives its entire mass at eta=0; this is the isotropic mass already removed in Section 1.

Equations (2) and (5) give F_(P,a)=integral T_(eta,a) M(d eta). All these exchanges are justified on real momenta by positivity or absolute uniform convergence on the compact inner support.

## 4. Homogeneous reduction and uniform quadratic positivity

For b=0 and real p!=0, put

    s=sqrt(1+tau), d(eta)=1+eta+(1-eta)s,
    gamma(eta)=4eta tau/d(eta)^2.

Cancelling X=sqrt(q) and Y=s sqrt(q) in (3) gives exactly

    T_(eta,a)(p)=(2/d)/[|p|^2+gamma(a.p)^2].                (7)

Its rational continuation is therefore the continuation of the physical real-momentum germ. On the whole enclosing interval -1<=eta<=1,

    2<=d<=2s,
    gamma'(eta)=4tau[1+s+(s-1)eta]/d^3>0,
    gamma(-1)=-tau/(1+tau), gamma(0)=0, gamma(1)=tau.       (8)

For actual nondegenerate parameters the range is the open interval (-tau/(1+tau),tau), so gamma>-1. The closed interval is used only for harmless uniform bounds and enclosing pole arcs; no degenerate ACG density at lambda=+/-1 is introduced.

Fix a real tangent k!=0, set K=|k|^2, alpha=a.n, beta=a.k, and p=u n+k. Write

    A_gamma=1+gamma alpha^2,
    D_gamma=K A_gamma+gamma beta^2
           =K+gamma(K alpha^2+beta^2).

Since alpha^2+beta^2/K<=1,

    1/(1+tau)<=A_gamma<=1+tau,
    D_gamma>=K/(1+tau)>0.                                (9)

For gamma>=0 the second bound follows from D_gamma>=K. For gamma<0 it follows by multiplying K alpha^2+beta^2<=K by the negative gamma. The slice is

    (2/d)/[A_gamma u^2+2gamma alpha beta u+K+gamma beta^2],

whose upper pole w=x+i y and residue are

    x=-gamma alpha beta/A_gamma,
    y=sqrt(D_gamma)/A_gamma>0,
    R_upper=-i/[d A_gamma y]=-i/[d sqrt(D_gamma)].          (10)

In particular y>=sqrt(K)/(1+tau)^(3/2) uniformly and

    |R_upper|<=sqrt(1+tau)/(2sqrt(K)).

The lower pole is conjugate and its residue has phase +i. Both signs of gamma give the same strictly negative imaginary phase for every upper residue. Positive prolate and oblate contributions cannot cancel along any shared upper-pole curve.

## 5. Mixed-sign pole circles and all coincidences

If alpha beta=0 all poles are imaginary. Otherwise, eliminating gamma from (10) gives

    |w|^2=K+c x, y^2=K+c x-x^2,
    c=(K alpha^2-beta^2)/(alpha beta),
    dx/dgamma=-alpha beta/(1+gamma alpha^2)^2.             (11)

Right upper poles occur exactly when gamma alpha beta<0. For either the positive or the negative gamma branch, the corresponding right arc starts at i sqrt(K) when gamma=0 and has strictly increasing x as |gamma| increases. Its other endpoint lies strictly in the upper-right quadrant, by (9). An arbitrary actual parameter support can be enlarged to this full initial arc without changing the continuation comparison needed below.

Different c circles have no intersection in the open right half-plane: subtraction of their equations gives (c_1-c_2)x=0. If r=beta/alpha, then c=K/r-r and

    c(r_1)=c(r_2) iff r_1=r_2 or r_1 r_2=-K.              (12)

Unlike the purely prolate proof, the reciprocal-ratio exception r_1 r_2=-K CAN now place both upper arcs in the right half-plane, because their gamma signs can be opposite. This is not an obstruction: both are initial portions of the same upper-right circle branch, starting at i sqrt(K), and are nested. Their same-phase residues add. It would be incorrect to discard this coincidence by the one-sign argument from the accepted prolate proof.

An exact stress test illustrates the potentially dangerous coincidence. Take K=1, tau=3, eta_+=1/2, eta_-=-1/2, and projected pairs (alpha,beta)=(1,-1)/sqrt(2) and (1,1)/sqrt(2). Then gamma_+=24/25 and gamma_-=-24/49. Both upper poles are (12+35i)/37, while their residues are respectively -2i/7 and -2i/5. Positive mixtures reinforce this pole. In general gamma(-eta)=-gamma(eta)/(1+gamma(eta)); the exact script checks this identity as well as the displayed coincidence.

Here is a global connectedness proof that covers these coincidences automatically. Set q=sqrt(K) and

    W(u)=(u-iq)/(u+iq).

It maps H={Re u>0} bijectively to {Im W<0}. If u=x+i y then

    Im W=-2qx/[x^2+(y+q)^2],
    Re W=(|u|^2-K)/[x^2+(y+q)^2].

On (11), W=x(c-2iq)/[x^2+(y+q)^2]. Thus every right circle branch maps to one fixed ray. Every upper arc maps to an initial radial segment 0<|W|<=R with R<1; continuity and injectivity give exactly the whole segment. The lower conjugate arc maps to the terminal segment |W|>=1/R on the same ray, because

    W(conjugate(u))=1/conjugate(W(u)).

Collapse coincident rays using the largest R. There are finitely many such rays, and the lower unit semicircle is unobstructed. Every point outside the slits can move radially to that semicircle: on an occupied ray its allowable radial interval is R<|W|<1/R; other rays have no obstacle. Movement along the semicircle joins all the points. Therefore H minus the enlarged finite pole-arc union Gamma is connected. Parameter gaps, atoms, and accumulation at eta=0 do not alter this argument.

## 6. Nonzero positive Cauchy measure obstructs Stieltjes continuation

Reflection invariance permits replacing each axis summand by the equally weighted pair a and R_n a without changing rho. This remains a finite positive representation with the same parameter measures. Reflection changes alpha to -alpha and preserves beta. For each nonzero eta, an axis with alpha beta!=0 and its reflected partner therefore place exactly one upper pole in the right half-plane. Since an active effective measure has positive mass away from zero, the resulting right upper pole measure is nonzero whenever any axis is detected by k.

Use partial fractions in (10). The upper-right contributions are

    -i integral 1/(u-w) nu_+(d w),

where nu_+ is a finite positive measure obtained by pushing forward the effective measures with weight 1/[d sqrt(D_gamma)]. The lower-right terms similarly are +i times a positive Cauchy measure nu_- supported below the real axis. Poles in the left half-plane, imaginary-axis poles, and the isotropic term are holomorphic in H. Uniform bounds (9)-(10) ensure that all pushforward measures are finite and compactly supported, possibly with boundary mass at +/-i sqrt(K), which is outside H. In the actual zero-atom-free formulation there is no such boundary atom.

Suppose the real homogeneous even slice f_0(u)=F_0(u n+k) had a positive Stieltjes representation S(u^2). Then h(u)=S(u^2) is holomorphic throughout H. The rational-integral continuation of f_0 is holomorphic on H\Gamma and agrees with h on the positive real axis. Connectedness from Section 5 and the identity theorem identify them on all of H\Gamma.

Cauchy transforms of finite compact measures are locally integrable in the plane, by Fubini and local integrability of |u-w|^(-1). The finite union Gamma of circular arcs has planar area zero. Thus f_0=h almost everywhere in H, and their distributional d-bar derivatives agree. But

    d-bar_u[1/(u-w)]=pi delta_w,
    d-bar f_0=-i pi nu_+ + i pi nu_- in H.                 (13)

On the upper-right quadrant the second measure is absent and the first is nonzero and positive. This contradicts holomorphicity. It proves a genuine obstruction to continuation of the physical real-momentum germ, rather than merely the existence of a formal nonreal pole. No parameter density, jump regularity, or generic tangent direction is required.

## 7. Transfer to every b>0 and actual compact spacetime tests

Set k=m unit. The remaining argument depends only on normalized positive rho and its mirror invariance, and hence is exactly the accepted finite-axis transfer. For delta>=0 define

    G_delta(u^2)=F_delta(u n+m),
    H_delta(T)=(1/(2pi)) integral_R exp(iuT)G_delta(u^2) du.

The original angular integral gives

    0<G_delta(u^2)<=1/(delta+1+u^2),
    0<=G_0(u^2)-G_delta(u^2)<=delta/(1+u^2)^2,
    |H_delta(T)|<=exp[-sqrt((delta+1)/(1+tau))|T|]
                       /(2sqrt(delta+1)).                         (14)

The last inequality follows by inverting the original angular quadratic: with a_v=1+tau(v.n)^2, c_v=tau(v.n)(v.m), and Delta_v=a_v(delta+1)+tau(v.m)^2, its kernel is

    exp[-sqrt(Delta_v)|T|/a_v] exp[-i c_v T/a_v]/(2sqrt(Delta_v)).

Reflection invariance makes H_delta real and even. It is bounded and continuous. The accepted bounded-Hankel necessity lemma applies: nonnegativity of every compact positive-time Hankel form implies G_delta is Stieltjes. For clarity, positive Hankel matrices define a Hilbert space whose shifts are symmetric contractions; boundedness of the kernel and iterated Cauchy-Schwarz prove contraction and preservation of null vectors. The shift identity T_a=T_(a/2)^2 and continuity make a positive strongly continuous contraction semigroup. Its spectral measure represents H_delta(T) as a positive Laplace transform. The exponential bound forces support away from zero, and Fourier inversion gives the Stieltjes representation. Kernel continuity and decay exclude contact and constant remainders. The complete argument is retained in the pinned diagonal-RP source.

Section 6 therefore supplies a real h in C_c^infinity((0,infinity)) and epsilon_h>0 with Q_0(h)=-epsilon_h<0. Since integral_R (1+u^2)^(-2)du=pi/2, (14) gives

    ||H_delta-H_0||_infinity<=delta/4,
    |Q_delta(h)-Q_0(h)|<=delta ||h||_1^2/4.                         (15)

The exact real scaling identity is

    kappa^2 F_b(kappa u n+kappa m)=F_(b/kappa^2)(u n+m).

For every kappa^2>b||h||_1^2/(4epsilon_h), the original frequency kappa m consequently has a negative form using h_kappa(t)=kappa h(kappa t):

    Q_(b,kappa m)(h_kappa)=kappa^(-1)Q_(b/kappa^2)(h)<0.             (16)

This proves all sufficiently large finite frequencies. The threshold and test are existential; no explicit numerical witness is claimed.

For b>0 the fixed-k form is continuous in real k and globally bounded. For nonzero chi in C_c^infinity(R^3), the compact tangential packet R^(-3/2)chi(x/R)exp(i kappa m.x) has Fourier mass concentrating at kappa m. Multiplying by h_kappa gives a negative full spacetime form for some finite R. Its real or imaginary part is a real negative witness, since the reflected kernel is real symmetric. Its time support stays strictly positive. Origin-supported contact additions cannot repair a form whose reflected test supports are strictly separated.

## 8. Consequences and exact scope

1. Choosing m along the nonzero tangent projection of any oblique active axis proves the theorem. Conversely normal or tangent axes are not detected by this obstruction.
2. If the density is invariant and RP at every coordinate mirror, every active axis must be a coordinate axis. If it is also invariant and RP at every diagonal mirror with normal (e_i+/-e_j)/sqrt(2), no active anisotropic axis can remain. Within this finite positive mixed-ACG class, only the constant density survives all these mirrors.
3. The theorem still does not give sufficiency for normal/tangent collections, and does not claim one-mirror RP for an oblate axis parallel to the mirror. The previously accepted prolate normal-axis RP result and coordinate-repair results have their own narrower hypotheses.
4. Finite axis support is essential to this proof: it supplies a zero-area pole set and a connected finite-slit complement. The active-oblique-axis necessity is actually false for unrestricted continuous axis measures. Fix any lambda!=0 and average rho_(lambda,a)(v) uniformly over a in S^3. Rotational invariance and normalization give the constant density 1, which is RP at every mirror, even though almost every axis is oblique to any chosen mirror. Thus no verbatim infinite-axis generalization is claimed. The broader classification of arbitrary angular densities is not settled here.
5. The new work is the direct negative-lambda harmonic identity, its positive effective measure, the full-sign quadratic bound, and the correction of the reciprocal-ratio coincident-circle case. All conclusions concern scalar Gaussian two-point covariances.

## 9. Optional noncompact parameter extension

The same proof permits each P_j to be any probability Borel measure on (-1,1), without atoms at +/-1, provided an active axis has positive mass at lambda!=0. Extract any zero atom as in Section 1. This does not enlarge the finite axis set. The resulting rho is a normalized nonnegative L1 angular density by Tonelli, although it need not be bounded or smooth.

To justify this separately, for fixed real p and b>=0 with b+|p|^2>0, y stays in (-1,0]. The function G_(eta y)(t) is positive and uniformly bounded for eta in [-1,1], |t|<=1; its denominator has lower bound (1-|y|)^2. Thus T_(eta,a) is uniformly bounded for all effective eta in [-1,1]. The identity (2) holds pointwise at every original lambda in (-1,1), so integration is justified by Tonelli, or by compact truncation and dominated convergence. The probability measure (5) remains finite. Equations (8)-(10) and the enclosing full arcs are uniformly controlled on [-1,1], and their endpoints retain strictly positive y. Sections 5-7 therefore apply unchanged.

Actual atoms at lambda=+/-1 are excluded: the displayed ACG density is degenerate there. Compact-inner measures remain the main theorem and guarantee smooth angular densities.

## 10. Dependencies and verification

Read and used, with byte lengths and SHA256 hashes in SOURCE_MANIFEST.json:

- /workspace/shared/infinite-angular-candidates-20261019/RESULT.md: all-degree zonal generating and convolution formulas; its accepted RP theorem remains prolate-only.
- /workspace/shared/finite-axis-rp-next-20261019/RESULT.md and NEXT_CANDIDATE.md: accepted finite-prolate obstruction and the precisely pending extension.
- /workspace/shared/finite-axis-rp-audit-20261019/AUDIT.md: the accepted Cayley connectedness and distributional Cauchy-measure method.
- /workspace/shared/diagonal-rp-next-20261019/RESULT.md: complete bounded-Hankel necessity argument, real-frequency transfer, and legal compact witnesses.

The proof is analytic. check_exact_identities.py verifies exact algebraic identities; verify_regression_modes.py checks ordinary/optimized agreement and rejects deliberate residue and negative-endpoint corruptions. The saved regression reports record actual outputs. They do not replace the convergence, measure, topology, or Hankel arguments above. Independent audit and final-hash reconciliation are maintained separately by the coordinating review.

## Completed exact regression record

All 55 exact identities passed. Ordinary and optimized checker outputs agree. A deliberately reversed upper residue and a deliberately reversed negative-gamma endpoint are each rejected in both interpreter modes. Both ordinary and optimized harness runs passed. The successful exact-output SHA256 is

    8bca398241f5ad6fd9766ce78e571a321a5f7dfcfcdd1488214b7f9e19342658

Reproduce from this directory with:

    python check_exact_identities.py
    python verify_regression_modes.py
    python -O verify_regression_modes.py

The independent audit at /workspace/shared/mixed-axis-audit-20261019/AUDIT.md passes the mixed-sign identity, positive measure, all coincidence cases, connectedness, finite-b transfer, and the optional noncompact parameter extension. It separately passed 36 exact identities and an oblate-residue corruption control. Its final-hash reconciliation records which exact final result bytes were reviewed.
