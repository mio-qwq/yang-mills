#!/usr/bin/env python3
"""Check ordinary/optimized agreement and two fail-closed corruptions."""
import hashlib
import json
from pathlib import Path
import subprocess
import sys

HERE = Path(__file__).resolve().parent
SCRIPT = HERE / "check_exact_identities.py"


def run(optimized=False, corrupt=None):
    command = [sys.executable]
    if optimized:
        command.append("-O")
    command.append(str(SCRIPT))
    if corrupt:
        command.append(corrupt)
    return subprocess.run(command, capture_output=True, text=True, check=False)


ordinary, optimized = run(), run(True)
if ordinary.returncode != 0 or optimized.returncode != 0:
    raise RuntimeError(f"Clean regression failed: {ordinary.stderr}\n{optimized.stderr}")
if ordinary.stdout != optimized.stdout:
    raise RuntimeError("Ordinary and optimized output differ")
for corruption, failure in (
    ("--corrupt-residue", "upper residue: nonzero exact residual"),
    ("--corrupt-negative-gamma", "negative gamma endpoint: nonzero exact residual"),
):
    for optimized_mode in (False, True):
        bad = run(optimized_mode, corruption)
        if bad.returncode == 0 or failure not in bad.stderr:
            raise RuntimeError(f"Corruption not rejected: {corruption}, optimized={optimized_mode}")
print(json.dumps({
    "status":"passed",
    "ordinary_optimized_identical":True,
    "corrupted_residue_rejected_in_both_modes":True,
    "corrupted_negative_gamma_rejected_in_both_modes":True,
    "exact_output_sha256":hashlib.sha256(ordinary.stdout.encode()).hexdigest(),
    "exact_check_count":json.loads(ordinary.stdout)["count"],
}, indent=2, sort_keys=True))
