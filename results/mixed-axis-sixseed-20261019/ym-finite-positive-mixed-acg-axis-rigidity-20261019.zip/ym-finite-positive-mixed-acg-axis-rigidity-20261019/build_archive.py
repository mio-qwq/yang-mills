#!/usr/bin/env python3
"""Build the byte-reproducible source archive from a verified package tree."""
import argparse
from pathlib import Path
import stat
import sys
from zipfile import ZipFile, ZipInfo, ZIP_DEFLATED
sys.dont_write_bytecode = True
import reproduce as R


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('output', type=Path)
    args = parser.parse_args()
    output = args.output.resolve()
    R.require(not output.is_relative_to(R.ROOT.resolve()), 'Output must be outside the source package')
    R.verify_tree()
    with ZipFile(output, 'w', compression=ZIP_DEFLATED, compresslevel=9) as archive:
        for p in sorted(R.ROOT.rglob('*')):
            if p.is_file():
                entry = ZipInfo(R.PACKAGE + '/' + p.relative_to(R.ROOT).as_posix(), date_time=(1980,1,1,0,0,0))
                entry.create_system = 3
                entry.external_attr = (stat.S_IFREG | 0o644) << 16
                entry.compress_type = ZIP_DEFLATED
                archive.writestr(entry, p.read_bytes(), compress_type=ZIP_DEFLATED, compresslevel=9)
    print(R.sha(output.read_bytes()) + '  ' + output.name)


if __name__ == '__main__':
    main()
