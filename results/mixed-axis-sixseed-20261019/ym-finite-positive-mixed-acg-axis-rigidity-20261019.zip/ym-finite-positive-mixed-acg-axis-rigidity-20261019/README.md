# Finite positive mixed prolate/oblate ACG-axis rigidity

Accepted local scalar Gaussian covariance research, 19 October 2026.
No repository changes, merge, release, or external publication are part of this checkpoint.

## Accepted result and exact boundary

For a reflection-invariant finite positive mixture of ACG angular densities, with a
nonnegative isotropic background, reflection positivity at a mirror forces every
anisotropically active axis to be normal or tangent to that mirror. The accepted
extension covers both prolate and oblate parameters, including their positive
mixtures. Even one oblique active axis forces failure for every b,tau>0, with real
compact smooth positive-time spacetime witnesses at every sufficiently large finite
tangential frequency. No explicit witness or threshold is computed.

The main statement has compact-inner parameter support. The independently reconciled
extension permits arbitrary positive probability Borel parameter measures on (-1,1).
An atom at lambda=0 is exactly isotropic and may be extracted into the background.
Actual atoms at lambda=+/-1 are excluded because those ACG densities are degenerate.
The axis set remains finite. Normal/tangent necessity is not sufficiency, and oblate
normal-axis RP is not established by this result.

Uniformly averaging a fixed nonzero ACG parameter over continuous axes yields the
constant isotropic density, which is RP at every mirror despite the oblique axes in
that representation. This is a counterexample to unrestricted representation-level
axis necessity. The arbitrary nonconstant continuous-axis case and the broader
classification of angular densities remain unresolved. Signed mixtures are excluded.
This is a scalar Gaussian covariance theorem, not an interacting Yang-Mills or
mass-gap result.

Read:
- mixed-acg-axis-next-20261019/RESULT.md
- mixed-axis-audit-20261019/AUDIT.md, including Final-result reconciliation
- mixed-axis-audit-20261019/FINAL_RECONCILIATION.json
- mixed-acg-axis-next-20261019/FINAL_HASH_RECONCILIATION.json

Exact accepted primary SHA256:
ebca4d967e7a70cac865f8afd2d94dbf50d745757e7c8da898775bf60261c918

Exact independent audit SHA256:
fb91eaf4f007450c384908b90f7ef407e4cc69559401084f1ae9703f0697e099

## Source preservation and dependency closure

All original source bytes are unchanged. The accepted predecessor archive appears
once under dependencies, retaining its exact historical bytes and nested dependencies.
No extracted dependency copies are stored beside it. Its historical prolate-only
scope and excluded candidate remain unchanged; this archive supplies the subsequent
accepted mixed-sign extension.

The old NEXT_CANDIDATE.md is included under provenance-inputs solely because the
accepted primary pins it as historical motivation. It is superseded provenance, not
a separate accepted theorem. All direct source pins resolve within this archive or
its nested predecessors. PROVENANCE.json records their original paths; replay never
reads from those absolute paths or needs the original /workspace/shared tree.

## Offline replay

Requirements: Python 3.12 and preinstalled SymPy 1.14.0. Python/SymPy distributions
are not vendored; all research inputs are. Replay needs no network.

From this directory:

    PYTHONDONTWRITEBYTECODE=1 python reproduce.py --integrity-only
    PYTHONDONTWRITEBYTECODE=1 python reproduce.py --with-dependency-replay
    PYTHONDONTWRITEBYTECODE=1 python -O reproduce.py --with-dependency-replay
    PYTHONDONTWRITEBYTECODE=1 python test_package.py
    PYTHONDONTWRITEBYTECODE=1 python -O test_package.py

The primary suite verifies 55 exact identities; the independent suite verifies 36.
Both checkers and their original harnesses run in ordinary and optimized modes.
Deliberately reversed upper-residue, negative-gamma-endpoint and oblate-residue
signs must fail in both modes. Full dependency replay also executes inherited tests.
These are exact algebra and packaging regressions, not formal verification of the
analytic, convergence, measure, topology or compact-witness proof arguments.

The package has 24 negative controls for changed, missing, extra and symlink payloads;
independently pinned accepted sources and dependency archives after manifest refresh;
source and reconciliation corruption; saved audit reports and provenance corruption;
and unsafe, duplicate and symlink archive or manifest entries. These integrity
checks detect corruption; they are not a cryptographic signature or hostile-code sandbox.

## Deterministic build

    python build_archive.py /path/to/output.zip

Sorted member names, fixed 1980-01-01 timestamps, regular-file 0644 permissions and
DEFLATE level 9 make repeated same-environment builds byte-identical. The builder
verifies the file manifest first. External YM-prefixed checkpoint metadata records
clean extraction, full normal/optimized replay, corruption tests, and deterministic
rebuild checks without a recursive archive-hash dependency.
