#!/usr/bin/env python3
"""Fail-closed source package corruption controls, including under python -O."""
import io
import json
from pathlib import Path
import shutil
import stat
import sys
import tempfile
import warnings
from zipfile import ZipFile, ZipInfo
sys.dont_write_bytecode = True
import reproduce as R
ROOT = Path(__file__).resolve().parent


def refresh_manifest(root):
    entries = [R.sha(p.read_bytes()) + '  ' + p.relative_to(root).as_posix()
               for p in sorted(root.rglob('*')) if p.is_file() and p.name != 'SHA256SUMS']
    (root / 'SHA256SUMS').write_text('\n'.join(entries) + '\n')


def reject(name, action, marker, reports):
    try:
        action()
    except Exception as error:
        R.require(marker in str(error), 'Wrong rejection for ' + name + ': ' + str(error))
        reports.append({'case': name, 'status': 'EXPECTED_REJECTION'})
    else:
        raise RuntimeError('Corruption incorrectly accepted: ' + name)


def main():
    R.verify_tree()
    contents = R.dependency_contents()
    R.verify_sources(contents)
    reports = []
    with tempfile.TemporaryDirectory(prefix='mixed-axis-package-test-') as directory:
        work = Path(directory)
        def case(name, mutate, verify, marker, rehash=False):
            root = work / name
            shutil.copytree(ROOT, root)
            mutate(root)
            if rehash:
                refresh_manifest(root)
            reject(name, lambda: verify(root), marker, reports)
        def append(root, name):
            p = root / name
            p.write_bytes(p.read_bytes() + b'corrupt\n')
        def edit_json(root, name, mutation):
            p = root / name
            data = json.loads(p.read_text())
            mutation(data)
            p.write_text(json.dumps(data))
        sources = lambda root: R.verify_sources(contents, root)
        case('changed_payload', lambda r: append(r, R.PRIMARY + '/RESULT.md'), R.verify_tree, 'Integrity mismatch')
        case('missing_payload', lambda r: (r / 'requirements.txt').unlink(), R.verify_tree, 'file-set mismatch')
        case('unexpected_payload', lambda r: (r / 'unexpected.txt').write_text('extra'), R.verify_tree, 'file-set mismatch')
        case('symlink_payload', lambda r: (r / 'unexpected-link').symlink_to(r / 'README.md'), R.verify_tree, 'Symlink in payload')
        case('repinned_accepted_primary', lambda r: append(r, R.PRIMARY + '/RESULT.md'), sources, 'Accepted primary hash mismatch', True)
        case('repinned_accepted_audit', lambda r: append(r, R.AUDIT + '/AUDIT.md'), sources, 'Accepted audit hash mismatch', True)
        case('repinned_historical_source', lambda r: append(r, 'provenance-inputs/finite-axis-rp-next-20261019/NEXT_CANDIDATE.md'),
             sources, 'Historical provenance hash mismatch', True)
        case('repinned_dependency_archive', lambda r: append(r, 'dependencies/' + R.DEP + '.zip'),
             R.dependency_contents, 'Dependency archive identity mismatch', True)
        case('corrupt_source_pin', lambda r: edit_json(r, R.PRIMARY + '/SOURCE_MANIFEST.json',
             lambda d: d[0].update(sha256='0'*64)), sources, 'Pinned source mismatch', True)
        case('corrupt_primary_receipt', lambda r: edit_json(r, R.PRIMARY + '/FINAL_HASH_RECONCILIATION.json',
             lambda d: d['records'][0].update(sha256='0'*64)), sources, 'Final reconciliation target mismatch', True)
        case('corrupt_audit_receipt', lambda r: edit_json(r, R.AUDIT + '/FINAL_RECONCILIATION.json',
             lambda d: d['reviewed_result'].update(sha256='0'*64)), sources, 'Final reconciliation target mismatch', True)
        case('corrupt_audit_regression', lambda r: edit_json(r, R.AUDIT + '/REGRESSION_REPORT.json',
             lambda d: d['runs'][0]['result'].update(exact_count=35)), sources, 'Saved audit run mismatch', True)
        case('corrupt_provenance_primary', lambda r: edit_json(r, 'PROVENANCE.json',
             lambda d: d.update(primary_sha256='0'*64)), sources, 'Provenance accepted hash mismatch', True)
        case('corrupt_provenance_dependency', lambda r: edit_json(r, 'PROVENANCE.json',
             lambda d: d['dependency'].update(sha256='0'*64)), sources, 'Provenance dependency pin mismatch', True)
        case('missing_provenance_original', lambda r: edit_json(r, 'PROVENANCE.json',
             lambda d: d['originals'].pop()), sources, 'Provenance original file-set mismatch', True)
    reject('manifest_parent_path', lambda: R.parse_manifest(('0'*64 + '  ../escape\n').encode()), 'Unsafe payload path', reports)
    reject('manifest_absolute_path', lambda: R.parse_manifest(('0'*64 + '  /escape\n').encode()), 'Unsafe payload path', reports)
    reject('manifest_backslash_path', lambda: R.parse_manifest(('0'*64 + '  folder\\file\n').encode()), 'Unsafe payload path', reports)
    reject('manifest_duplicate', lambda: R.parse_manifest(('0'*64 + '  file\n').encode()*2), 'Duplicate or self-referential', reports)
    reject('manifest_self_reference', lambda: R.parse_manifest(('0'*64 + '  SHA256SUMS\n').encode()), 'Duplicate or self-referential', reports)
    def bad_zip(names, symlink=False):
        stream = io.BytesIO()
        with warnings.catch_warnings():
            warnings.simplefilter('ignore', UserWarning)
            with ZipFile(stream, 'w') as z:
                for name in names:
                    entry = ZipInfo(name)
                    entry.create_system = 3
                    entry.external_attr = ((stat.S_IFLNK if symlink else stat.S_IFREG) | 0o644) << 16
                    z.writestr(entry, b'data')
        data = stream.getvalue()
        return lambda: R.verify_zip(data, 'payload', R.sha(data))
    reject('zip_parent_path', bad_zip(['payload/../escape']), 'Unsafe payload path', reports)
    reject('zip_absolute_path', bad_zip(['/payload/file']), 'Unsafe payload path', reports)
    reject('zip_duplicate', bad_zip(['payload/file', 'payload/file']), 'Duplicate ZIP entry', reports)
    reject('zip_symlink', bad_zip(['payload/link'], symlink=True), 'Symlink ZIP entry', reports)
    print(json.dumps({'status': 'PASS', 'negative_control_count': len(reports), 'cases': reports}, indent=2, sort_keys=True))


if __name__ == '__main__':
    main()
