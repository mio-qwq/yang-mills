#!/usr/bin/env python3
"""Exact algebra checks; all verification uses explicit failures, never assert."""
import json
import sys
import sympy as S

eta, tau, q = S.symbols('eta tau q', real=True)
s = S.symbols('s', positive=True)
K = S.symbols('K', positive=True)
a, beta, gamma = S.symbols('a beta gamma', real=True)
x, y = S.symbols('x y', real=True)
r1, r2 = S.symbols('r1 r2', nonzero=True, real=True)
X, Y = S.symbols('X Y', positive=True)
t, lam = S.symbols('t lam', real=True)
I = S.I
checks = []

def check(name, expression):
    value = S.factor(S.simplify(expression))
    if value != 0:
        raise RuntimeError(f'{name}: expected zero, got {value}')
    checks.append(name)

d = 1+eta+(1-eta)*s
g = 4*eta*(s*s-1)/d**2
check('d_left_endpoint', d.subs(eta,-1)-2*s)
check('d_right_endpoint', d.subs(eta,1)-2)
check('gamma_left_endpoint', g.subs(eta,-1)+(s*s-1)/s**2)
check('gamma_origin', g.subs(eta,0))
check('gamma_right_endpoint', g.subs(eta,1)-(s*s-1))
check('gamma_derivative', S.diff(g,eta)-4*(s*s-1)*(1+s+(s-1)*eta)/d**3)
check('negative_parameter_involution', g.subs(eta,-eta)+g/(1+g))
check('opposite_d_square_relation', d.subs(eta,-eta)**2-d**2-4*eta*(s*s-1))
L=(1+eta)*X+(1-eta)*Y
Lrev=(1-eta)*X+(1+eta)*Y
expr=S.expand(L**2+4*eta*tau*q-Lrev**2)
check('finite_b_negative_parameter_denominator', expr.subs(Y**2,X**2+tau*q))
G=(1+lam)/((1+lam)**2-4*lam*t**2)
B=((1-lam)/(1+lam))**2
rho=((1-lam)/(1+lam))/(1+(B-1)*t**2)**2
check('ACG_harmonic_differentiation', G+(1+lam)*lam*S.diff(G,lam)-rho)
j=S.symbols('j', integer=True, nonnegative=True)
check('positive_decomposition_coefficient', (1+(1+lam)*j)/(2*j+1)-(1+lam)/2-(1-lam)/(2*(2*j+1)))
check('positive_decomposition_total_mass', (1+lam)/2+(1-lam)/2-1)
A=1+gamma*a*a
D=K+gamma*(K*a*a+beta*beta)
C=K+gamma*beta*beta
xc=-gamma*a*beta/A
yc=S.sqrt(D)/A
check('quadratic_discriminant', A*C-(gamma*a*beta)**2-D)
check('upper_pole_quadratic', A*(xc+I*yc)**2+2*gamma*a*beta*(xc+I*yc)+C)
check('upper_residue_phase', (2/d)/(2*A*(xc+I*yc)+2*gamma*a*beta)+I/(d*S.sqrt(D)))
check('lower_residue_phase', (2/d)/(2*A*(xc-I*yc)+2*gamma*a*beta)-I/(d*S.sqrt(D)))
check('pole_real_monotonicity', S.diff(xc,gamma)+a*beta/A**2)
c=(K*a*a-beta*beta)/(a*beta)
check('pole_circle', xc**2+yc**2-K-c*xc)
check('circle_equal_slope_factorization', (K/r1-r1)-(K/r2-r2)-(r2-r1)*(K+r1*r2)/(r1*r2))
check('circle_opposite_slopes', (K/r1-r1)-(K/r2-r2).subs(r2,-K/r1))
projection=a*a+beta*beta/K
check('negative_gamma_discriminant_lower_bound_identity', D-K*((1+gamma)+(-gamma)*(1-projection)))
check('negative_gamma_A_lower_bound_identity', A-((1+gamma)+(-gamma)*(1-a*a)))
qq=S.symbols('qq', positive=True)
W=(x+I*y-I*qq)/(x+I*y+I*qq)
den=x*x+(y+qq)**2
check('Cayley_real_part', S.re(W)-(x*x+y*y-qq*qq)/den)
check('Cayley_imaginary_part', S.im(W)+2*qq*x/den)
check('Cayley_modulus_one_minus', 1-S.simplify(W*S.conjugate(W))-4*qq*y/den)
Wconj=(x-I*y-I*qq)/(x-I*y+I*qq)
check('Cayley_conjugate_reciprocal', Wconj-1/S.conjugate(W))
check('Cayley_circle_ray', S.simplify(S.expand_complex(W)*den-x*(c-2*I*qq)).subs(y*y,qq*qq+c*x-x*x))
# Homogeneous formula reduction with X=sqrt(q), Y=s sqrt(q).
T=2*L/(X*(L*L+4*eta*(s*s-1)*beta*beta))
check('homogeneous_real_reduction', T.subs({X:S.sqrt(q),Y:s*S.sqrt(q)})-(2/d)/(q+g*beta*beta))
# Adversarial coincidence: same upper pole, opposite parameter signs.
sp=S.Rational(2); ep=S.Rational(1,2); em=-ep
for label,e,expected_g,expected_d in [('prolate',ep,S.Rational(24,25),S.Rational(5,2)),('oblate',em,-S.Rational(24,49),S.Rational(7,2))]:
    check(f'{label}_exact_gamma',g.subs({s:sp,eta:e})-expected_g)
    check(f'{label}_exact_d',d.subs({s:sp,eta:e})-expected_d)
    av=1/S.sqrt(2)
    bv=-1/S.sqrt(2) if label=='prolate' else 1/S.sqrt(2)
    subs={K:1,a:av,beta:bv,gamma:expected_g}
    check(f'{label}_coincident_upper_pole',(xc+I*yc).subs(subs)-(12+35*I)/37)
    expected_residue=-2*I/7 if label=='prolate' else -2*I/5
    if '--flip-oblate-residue' in sys.argv and label=='oblate':
        expected_residue=-expected_residue
    actual=-I/(expected_d*S.sqrt(D.subs(subs)))
    check(f'{label}_coincident_upper_residue',actual-expected_residue)

print(json.dumps({'status':'PASS','count':len(checks),'checks':checks},sort_keys=True))
