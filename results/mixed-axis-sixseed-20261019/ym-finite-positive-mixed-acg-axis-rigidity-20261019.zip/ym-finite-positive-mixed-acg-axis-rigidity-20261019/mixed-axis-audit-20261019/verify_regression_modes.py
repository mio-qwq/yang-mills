#!/usr/bin/env python3
"""Run both interpreter modes and a deliberate false-oblate-residue mutation."""
import hashlib
import json
from pathlib import Path
import subprocess
import sys

root=Path(__file__).resolve().parent
script=root/'check_exact_identities.py'
outputs=[]
records=[]
for flags in ([],['-O']):
    valid=subprocess.run([sys.executable,*flags,str(script)],capture_output=True,text=True)
    if valid.returncode:
        raise RuntimeError(f'valid run failed {flags}: {valid.stderr}')
    outputs.append(valid.stdout)
    tampered=subprocess.run([sys.executable,*flags,str(script),'--flip-oblate-residue'],capture_output=True,text=True)
    if not tampered.returncode or 'oblate_coincident_upper_residue' not in tampered.stderr:
        raise RuntimeError(f'false oblate residue was not specifically rejected: {flags}')
    records.append({'mode':'optimized' if flags else 'ordinary','valid':'PASS','false_oblate_residue':'REJECTED'})
if outputs[0]!=outputs[1]:
    raise RuntimeError('ordinary and optimized exact outputs disagree')
result={'status':'PASS','exact_count':json.loads(outputs[0])['count'],'exact_output_sha256':hashlib.sha256(outputs[0].encode()).hexdigest(),'runs':records}
print(json.dumps(result,sort_keys=True))
