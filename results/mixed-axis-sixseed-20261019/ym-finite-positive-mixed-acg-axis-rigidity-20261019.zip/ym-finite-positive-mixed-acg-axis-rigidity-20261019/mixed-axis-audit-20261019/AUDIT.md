# Independent audit: mixed prolate/oblate finite-axis obstruction

19 October 2026. Local mathematical work only. No external write, PR merge, release, or publication.

## Verdict

The finite positive ACG-axis reflection-positivity obstruction extends to arbitrary mixed prolate and oblate parameters. Positive prolate/oblate contributions cannot cancel the off-axis pole measures, even when opposite projected axis slopes create exactly coincident pole curves.

One correction is essential when extending the old proof: equal circles with opposite slopes can now contribute to the SAME right half-plane. The earlier prolate-only exclusion of that case must not be reused. Their contributions nevertheless add with the same residue phase, and the Cayley-ray connectedness proof still applies.

## Exact theorem

Let n be a unit vector in R^4, let a_1,...,a_N be finitely many unit axes, let c_0>=0 and c_j>0 with c_0+sum c_j=1, and let P_j be arbitrary probability Borel measures on (-1,1). Define

    B(lambda)=((1-lambda)/(1+lambda))^2,
    rho_(lambda,a)(v)=sqrt(B(lambda))
        /[1+(B(lambda)-1)(a.v)^2]^2,
    rho(v)=c_0+sum_j c_j integral rho_(lambda,a_j)(v) P_j(d lambda),
    F_b(p)=integral_(S^3) rho(v)/[b+|p|^2+tau(p.v)^2] d sigma(v),

where d sigma is probability surface measure and b,tau>0. Assume rho is invariant under the reflection with normal n. Call a_j anisotropically active if P_j((-1,1)\{0})>0.

If F_b is reflection positive at n, every anisotropically active a_j is either parallel or perpendicular to n. Equivalently, one active oblique axis forces failure for every b,tau>0, for every positive weight on that axis, and with any nonnegative isotropic background.

More precisely, for any unit tangent m such that some active a_j satisfies (a_j.n)(a_j.m)!=0, every sufficiently large finite tangential frequency kappa m has a negative smooth compact positive-time Hankel test. A finite tangential wave packet gives a real C_c^infinity spacetime witness supported strictly in the positive half-space.

Atoms at lambda=0 are isotropic and can be absorbed into c_0. The endpoints lambda=+/-1 are excluded from the angular density definition. Their use below only encloses the homogeneous pole curves by harmless compact parameter intervals.

This remains a necessity theorem, not a sufficiency theorem for normal/tangent axis configurations. It concerns the stated finite-axis scalar covariance class; it makes no arbitrary-axis-distribution, interacting Yang-Mills, or mass-gap claim.

## 1. The positive elementary decomposition is valid for both signs

The accepted harmonic derivation extends directly from 0<=lambda<1 to |lambda|<1. For t in [-1,1],

    G_lambda(t)=sum_(j>=0) lambda^j U_(2j)(t)
               =(1+lambda)/[(1+lambda)^2-4lambda t^2],
    rho_(lambda,a)(v)=sum_(j>=0)
         [1+(1+lambda)j]lambda^j U_(2j)(a.v).

Absolute uniform convergence follows from |U_(2j)(t)|<=2j+1 and |lambda|<1. Negative lambda changes harmonic coefficient signs, but does not affect the convergence or convolution identities. Using the accepted S^3 convolution identity and

    [1+(1+lambda)j]/(2j+1)
       =(1+lambda)/2+(1-lambda)/[2(2j+1)],
    1/(2j+1)=integral_0^1 r^(2j) dr,

gives, on real momenta,

    F_(lambda,a)=(1+lambda)T_(lambda,a)/2
          +(1-lambda)/2 integral_0^1 T_(lambda r^2,a) dr.       (1)

Both outer coefficients are strictly positive for -1<lambda<1. There is no square root of a negative parameter in this formula.

The clean effective measure definition is a positive pushforward: for every Borel set E,

    M_j(E)=integral [ (1+lambda)1_E(lambda)/2
        +(1-lambda)/2 integral_0^1 1_E(lambda r^2) dr ] P_j(d lambda).

Then M_j is a probability measure on [-1,1], and

    M_j((0,1))=P_j((0,1)),
    M_j((-1,0))=P_j((-1,0)),
    M_j({0})=P_j({0}).

In particular, an anisotropically active original axis still has positive effective mass away from eta=0. These identities hold for arbitrary Borel measures, including atoms and parameter distributions approaching either endpoint.

There is also a direct denominator check, independent of the harmonic signs. For real p, write q=|p|^2, X=sqrt(b+q), Y=sqrt(b+(1+tau)q), and

    L_eta=(1+eta)X+(1-eta)Y,
    T_(eta,a)(p)=2L_eta/[X(L_eta^2+4eta tau(a.p)^2)].          (2)

For eta>=0 the denominator in parentheses is positive. For eta<0, since (a.p)^2<=q,

    L_eta^2+4eta tau(a.p)^2 >= L_eta^2+4eta tau q
       =[(1-eta)X+(1+eta)Y]^2 >0.                            (3)

Thus the real-momentum formula remains positive and regular throughout -1<eta<1. One may also extend (1) by real analyticity in lambda, but that alternative is unnecessary.

## 2. Homogeneous blocks and uniform ellipticity

At b=0 and real p!=0, set

    s=sqrt(1+tau),
    d=1+eta+(1-eta)s,
    gamma=4eta tau/d^2.

The real positive square roots cancel in (2), giving the physical rational germ

    T_(eta,a)(p)=(2/d)/[|p|^2+gamma(a.p)^2].                 (4)

For the full enclosing interval -1<=eta<=1,

    2<=d<=2s,
    gamma' =4tau[1+s+(s-1)eta]/d^3 >0,
    gamma(-1)=-tau/(1+tau), gamma(0)=0, gamma(1)=tau.       (5)

The lower endpoint is strictly greater than -1. Consequently every quadratic in (4) is positive definite, uniformly over eta, with eigenvalues between 1/(1+tau) and 1+tau.

Fix nonzero tangent k and abbreviate

    K=|k|^2, alpha=a.n, beta=a.k,
    A=1+gamma alpha^2,
    D=K+gamma(K alpha^2+beta^2).

Because n and k/sqrt(K) are orthonormal,

    B=alpha^2+beta^2/K<=1.

For gamma<0 this gives D=K(1+gamma B)>=K(1+gamma)>=K/(1+tau); for gamma>=0 it gives D>=K. Likewise,

    1/(1+tau)<=A<=1+tau,
    D>=K/(1+tau)>0.                                        (6)

The upper pole and upper residue of the normal-frequency slice are therefore

    w=x+iy,
    x=-gamma alpha beta/A,
    y=sqrt(D)/A>0,
    R_+=-i/[d A y]=-i/[d sqrt(D)].                          (7)

In particular R_+ is always strictly negative imaginary, including for oblate gamma<0. The sign does NOT depend on the sign of gamma, alpha beta, or the direction of parameter traversal.

The useful full-interval bounds are

    y>=sqrt(K)/(1+tau),
    |R_+|<=sqrt(1+tau)/(2sqrt(K)).                           (8)

For y, use A<=1+tau,D>=K when gamma>=0, and A<=1,D>=K/(1+tau) when gamma<0. Compactness also bounds every pole location. Thus all pushforward pole measures are finite, even for arbitrary endpoint-approaching parameter measures.

## 3. Coincident circles: the mixed-sign case must be retained

For alpha beta!=0, elimination of gamma still gives

    |w|^2=K+c x,
    c=(K alpha^2-beta^2)/(alpha beta).                       (9)

Also dx/dgamma=-alpha beta/A^2, so each fixed-sign parameter branch is injective. Its upper pole is in the right half-plane exactly when gamma alpha beta<0.

With r=beta/alpha,

    c=K/r-r,
    c(r_1)=c(r_2) iff r_1=r_2 or r_1 r_2=-K.                (10)

In the prolate-only proof the second alternative had opposite half-plane locations. In the mixed-sign setting opposite gamma signs can reverse this conclusion: opposite slopes CAN produce the same right-hand pole curve. They cause no cancellation, because (7) has the same phase for all upper poles.

An exact example makes the issue concrete. Take K=1, tau=3, eta_+=1/2, eta_-=-1/2, and projected axes

    (alpha_+,beta_+)=(1,-1)/sqrt(2),
    (alpha_-,beta_-)=(1,1)/sqrt(2).

Then

    d_+=5/2, d_-=7/2,
    gamma_+=24/25, gamma_-=-24/49,
    w_+=w_-=(12+35i)/37,
    R_(+,+)=-2i/7, R_(-,+)=-2i/5.

Thus the poles coincide EXACTLY and positive weights reinforce their residues. The general algebraic relation behind this example is

    gamma(-eta)=-gamma(eta)/(1+gamma(eta)),
    d(-eta)^2=d(eta)^2+4eta tau.                            (11)

For two orthogonal axes lying in the (n,k) plane and parameters eta,-eta, the two homogeneous slice quadratics differ by a positive scalar. No positive mixing can cancel their common poles.

Different c circles intersect only at x=0,y=+/-sqrt(K), since subtracting their equations gives (c_1-c_2)x=0. Thus no crossing of distinct circles occurs in the open right half-plane.

## 4. The Cayley-ray topology remains valid

Let H={Re u>0}, q=sqrt(K), and

    W(u)=(u-iq)/(u+iq).

This maps H conformally onto {Im W<0}. On a pole circle,

    Re W=(|u|^2-K)/[x^2+(y+q)^2],
    Im W=-2qx/[x^2+(y+q)^2],
    W(u)=x(c-2iq)/[x^2+(y+q)^2].                           (12)

Every upper-right arc maps to a ray segment beginning at zero. Since y>0, its modulus is strictly less than one. Injectivity and continuity make its image exactly 0<|W|<=R_j<1. This statement holds whether the original eta branch runs from 0 toward 1 or from 0 toward -1.

When multiple circles coincide, INCLUDING the opposite-slope, opposite-gamma case, all upper-right segments on that circle are initial portions of the same ray. Keep the largest R_j. Their lower conjugates map to terminal segments |W|>=1/R_j>1 on the same ray, because W(conjugate u)=1/conjugate(W(u)).

There are finitely many rays. The lower unit semicircle is unobstructed. Every point off the radial slits can be moved radially to that semicircle: on an occupied ray its admissible radii are precisely R_max<|W|<1/R_max, and on any other ray there is no obstruction. Thus H with all upper and lower enclosing arcs removed is path connected.

This argument does not need generic tangential momentum, separate curve parameterizations, or noncoincidence. Arbitrary gaps and atoms in the parameter measures are handled by the same larger enclosing arcs.

## 5. Positive mixed-sign pole measures cannot cancel

Reflection invariance permits replacing each density term by half itself and half its reflected-axis term. This keeps rho unchanged and the representation finite and positive. Reflection sends alpha to -alpha while preserving beta. For every eta!=0 on a detected oblique axis, exactly one member of that reflected pair has its upper pole in the open upper-right quadrant.

Partial fractions and (7) show that the homogeneous slice in H is a sum of holomorphic terms and

    -i integral 1/(u-w) nu_+(dw)
       +i integral 1/(u-w) nu_-(dw),                        (13)

where nu_+ and nu_- are finite positive measures on the upper-right and lower-right pole sets, respectively. By anisotropic activity and reflection pairing, nu_+ is nonzero. Coincident upper curves simply add positive measures; there is no oriented-arc Jacobian in this pushforward formulation. This is why reversing the eta direction cannot introduce a cancellation sign.

If the real even homogeneous slice had a Stieltjes representation S(u^2), then S(u^2) would be holomorphic on H. It agrees with (13) on the positive real axis, and therefore on the entire connected slit complement by Section 4 and the identity theorem.

Finite Cauchy transforms are locally integrable in two real dimensions. The finite collection of analytic pole arcs has planar area zero. Hence (13) would agree almost everywhere in H with the holomorphic S(u^2), so its distributional d-bar derivative would vanish. Instead,

    d-bar f_0=-i pi nu_+ +i pi nu_-,                        (14)

which is a nonzero measure on the upper-right quadrant because nu_+ is nonzero and nu_- is supported below the real axis. This is a contradiction.

Thus positive prolate/oblate curve cancellation is impossible in this finite-axis class. The conclusion follows from fixed-phase residues and connectedness, not from merely displaying a formal pole or assuming a jump density.

## 6. Transfer to finite positive b and compact tests

All transfer steps of the accepted finite-axis result depend only on the original normalized positive angular density and mirror invariance, not on the sign of lambda. They therefore apply unchanged.

For unit tangent m, delta>=0, G_delta(u^2)=F_delta(u n+m), and its inverse normal Fourier transform H_delta,

    0<G_delta(u^2)<=1/(delta+1+u^2),
    |H_delta(T)|<=exp[-sqrt((delta+1)/(1+tau))|T|]
                     /(2sqrt(delta+1)),
    ||H_delta-H_0||_infinity<=delta/4.                      (15)

The accepted bounded-Hankel necessity lemma turns positivity of all compact positive-time tests into a Stieltjes representation. The contradiction in Section 5 thus gives a real h in C_c^infinity((0,infinity)) with Q_0(h)=-epsilon_h<0. The uniform bound yields

    |Q_delta(h)-Q_0(h)|<=delta||h||_1^2/4.

The exact real-momentum scaling

    kappa^2 F_b(kappa u n+kappa m)=F_(b/kappa^2)(u n+m)

therefore gives a negative finite-frequency Hankel test for every

    kappa^2>b||h||_1^2/(4epsilon_h).

The accepted finite tangential wave-packet argument then supplies a real smooth compact spacetime witness supported strictly in the positive half-space. These are existence claims for the witness and threshold, not computed numerical values. No complex b->0 continuation, Fourier delta test, or boundary-supported distribution is used.

## 7. Consequences and limits

For this finite positive ACG-axis class with arbitrary parameters in (-1,1), simultaneous reflection positivity and reflection invariance at all coordinate mirrors force every anisotropically active axis to be a coordinate axis. Requiring the diagonal mirrors with normals (e_i+/-e_j)/sqrt(2) then excludes every active anisotropic axis. Only the isotropic density remains within this class.

Finiteness of the axis set is crucial to the present proof: it supplies finitely many slit rays and a pole support of planar area zero. The active-oblique-axis necessity is in fact false for unrestricted continuous axis distributions: uniformly averaging rho_(lambda,a) over a at any fixed nonzero lambda yields rho=1 by rotational invariance and normalization. This isotropic covariance is RP at every mirror, since its radial expression is a positive average of resolvents 1/[b+(1+tau t^2)|p|^2]. Thus no verbatim continuous-axis extension is possible. The broader classification of arbitrary smooth angular densities is not resolved here.

## Sources and reproducibility

Direct mathematical dependencies inspected:

- finite-axis-rp-next-20261019/RESULT.md: accepted prolate theorem, compact-test transfer.
- finite-axis-rp-audit-20261019/AUDIT.md: accepted distributional and Cayley-ray audit.
- diagonal-rp-next-20261019/RESULT.md: physical T formula and bounded-Hankel necessity lemma.
- infinite-angular-candidates-20261019/RESULT.md: harmonic generating functions and S^3 convolution derivation.

SOURCE_MANIFEST.json pins the exact input bytes. check_exact_identities.py is independent audit code written for this task; verify_regression_modes.py checks ordinary and optimized execution and rejects a deliberately flipped oblate upper-residue sign. Those checks supplement the analytic proof; they do not replace its topology, measure, or compact-test steps.

## Exact regression outcome

All 36 exact identities passed. Ordinary and optimized interpreter execution produced identical output. The deliberate oblate-upper-residue sign reversal was rejected in both modes. The harness itself also passed under ordinary and optimized execution. The successful exact-output SHA256 is:

    fe1054bcbd0ed998b4f022dd0ab39e68105992f17b855b3ab5018c88dfc35cb5

REGRESSION_REPORT.json records the completed runs. Reproduce with:

    python check_exact_identities.py
    python verify_regression_modes.py
    python -O verify_regression_modes.py

## Final-result reconciliation

The completed main result was read in full and independently reconciled against this audit:

    /workspace/shared/mixed-acg-axis-next-20261019/RESULT.md
    Bytes: 22105
    SHA256: ebca4d967e7a70cac865f8afd2d94dbf50d745757e7c8da898775bf60261c918

Verdict: PASS. No correction to these exact result bytes is needed. The direct all-sign harmonic identity, positive effective measures including atoms, negative-gamma uniform positivity, opposite-slope coincident curves, connected Cayley slit complement, distributional noncancellation, finite-b compact witnesses, coordinate/diagonal consequence, and optional noncompact parameter extension all pass.

The final revision correctly adds the exact coincident-pole example and identifies the continuous-axis counterexample rather than suggesting that the same active-axis necessity might extend verbatim. Its reported 55-check main regression record is separate from this audit's independently executed 36-check suite.
