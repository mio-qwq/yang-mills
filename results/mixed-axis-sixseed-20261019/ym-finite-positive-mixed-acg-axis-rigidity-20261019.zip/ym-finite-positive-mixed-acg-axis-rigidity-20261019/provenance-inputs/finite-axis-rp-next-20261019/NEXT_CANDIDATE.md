# Recovery candidate only: extend the axial identity to oblate parameters

This is a future research candidate, not part of RESULT.md and not an accepted extension of its theorem. The audited result remains finite positive prolate ACG mixtures. No remote action is proposed here.

## Target

Determine whether the finite-axis obstruction also covers ordinary oblate ACG densities, beta>1, by deriving the accepted axial decomposition for -1<lambda<0. Do not generalize the final theorem until that identity, its effective positive measure, and the enlarged pole-domain argument have been independently checked.

## Exact observations worth checking next

With beta=((1-lambda)/(1+lambda))^2, negative lambda corresponds to beta>1. The formal axial decomposition

    F_(lambda,a)=(1+lambda)T_(lambda,a)/2
                +(1-lambda)/2 integral_0^1 T_(lambda r^2,a) dr

would still have strictly positive weights. The pushforward eta=lambda r^2 would now be a positive measure on negative eta. The decomposition is already accepted for positive lambda, but its negative-lambda continuation has not been included in the present proof.

For -1<=eta<=1 the homogeneous coefficient

    gamma=4eta tau/[1+eta+(1-eta)sqrt(1+tau)]^2

is increasing and ranges from -tau/(1+tau) to tau. It therefore stays above -1. On a tangent slice, beta_projection^2<=K(1-alpha^2), so for gamma<0

    K(1+gamma alpha^2)+gamma beta_projection^2>=K(1+gamma)>0.

Thus the formal upper pole remains nonreal, and its residue still has phase -i with a positive coefficient. The same pole-circle equation holds. The reciprocal-ratio equal-circle exception r_1 r_2=-K can now put prolate and oblate arcs in the same half-plane, since gamma changes sign; nevertheless their residues would add rather than cancel. The Cayley radial connectedness mechanism appears unchanged.

## Possible derivation route and required stopping condition

Prove real analyticity in lambda on (-1,1) of both sides of the axial identity at fixed real momentum and b>0, then justify identity continuation from the positive interval. For eta<0, the physical denominator can potentially be controlled using

    d(eta)^2+4eta tau=[1+s+(s-1)eta]^2>0,
    s=sqrt(1+tau),

together with (a.p)^2<=|p|^2 and the positive physical square roots. One must check all parameter integrals and the b=0 nonzero-momentum limit explicitly, rather than merely substituting negative lambda into the final displayed formula.

Only after that derivation and an independent audit should the theorem be extended. If the continuation fails, retain the present prolate theorem unchanged and report the exact obstruction. Infinitely many axes and arbitrary angular densities remain outside this candidate.
