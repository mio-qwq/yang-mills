# Independent audit: two-sided taper and interior beta resonance

19 October 2026. Local scalar covariance research only. No remote edits or publication.

## Verdict

**Accepted.** The explicit normalized density

    g(beta)=6(beta-1/9)(1/4-beta)/(5/36)^3,  1/9<=beta<=1/4,

extended by zero outside its support, fails coordinate reflection positivity after equal four-axis averaging. The specified witness is

    X=2401/7599,  r=X/(1+X)=2401/10000,  sqrt(r)=49/100.

The proof establishes the exact bound

    lim_{s up to b} sqrt(b-s) w(K,s)
       < -1/(24 pi sqrt(b tau)).

Both singular parameter operations are resolved at finite cut before taking their limits. The physical residue has the sign asserted by the source. The logarithmic domination is valid. All rational and logarithmic estimates were independently checked. The negative spectral interval has the stated legal compact-test consequence. The smooth-beta approximation argument is also valid.

This is an obstruction for this explicit taper, its sufficiently close mixtures, the displayed sufficiently late smooth approximations, and the separately proved nonzero-edge class. It does not exclude every tapered or other positive beta mixture.

Audited source:

    /workspace/shared/parameter-mixed-rp-20261019/RESULT.md
    SHA256 b45a3c24ceb63d04e8724073f3388b9f52c56887510119495344f69b0cac466b

The preceding accepted fixed-beta `RESULT.md` and `ROOT_REVIEW.md` were also read in full. The companion `AUDIT.md` records the separate uniform-mixture audit and the complete transfer to compact reflected tests.

## 1. Independent derivation of the finite-cut direct ratio

Use `t=sqrt(beta)`, `lambda=(1-t)/(1+t)`, `A=1+lambda`, `C=1-lambda`, `v=sqrt(b-s)>0`, and `m=i sqrt(d)`, where `d=(1+tau)s-b>0`.

The accepted tangential-axis formula and `h0=2/[v(v+m)]` give

    A T_lambda,e2/h0
      = A(A v+C m)(v+m)/[(A v+C m)^2+4lambda tau K].

Because `C/A=t` and `4lambda/A^2=1-t^2`, this is precisely

    (v+m)(v+m t)/[(v+m t)^2+(1-t^2)tau K].

Its denominator is

    D_s(t)=v^2+tau K+2iv sqrt(d)t-(d+tau K)t^2.

The displayed factorization is exact:

    D_s(t)=-(d+tau K)(t-z_+)(t-z_-),
    z_+/-=[iv sqrt(d) +/- sqrt(tau K(v^2+d+tau K))]/(d+tau K).

Both poles have strictly positive imaginary part `v sqrt(d)/(d+tau K)`. Their real parts have opposite signs and their separation is nonzero. Thus no pole lies on the real t-integration path for any finite cut point in question.

Multiplying by `2t g(t^2)` correctly accounts for `d beta=2t dt`. The numerator is a polynomial of degree at most six, the denominator is quadratic with distinct roots, and subtracting the two simple-pole residues leaves a polynomial. The source's exact polynomial-plus-logarithms antiderivative is therefore valid.

## 2. Physical logarithm branch and residue sign

For real t and either pole, `t-z_j` lies strictly in the lower half-plane. The principal logarithm is analytic along each integration segment, so its endpoint difference is the actual ordinary finite-cut integral of `1/(t-z_j)`.

As `s` tends upward to b, the poles tend to `+q0` and `-q0`, where `q0=49/100` lies strictly inside `(1/3,1/2)`. The positive-pole difference tends to

    Log(1/2-q0-i0)-Log(1/3-q0-i0)
       = log((1/2-q0)/(q0-1/3)) + i pi.

The sign is **plus** i pi: the second argument approaches a negative real number from below and has principal argument tending to `-pi`. Both endpoint arguments for the negative pole approach positive real numbers, so that difference has no imaginary jump.

At the endpoint, the full transformed integrand becomes

    2(1-r)t^2 g(t^2)/(t^2-r).

Its positive-pole residue is exactly

    R_+=(1-r)q0 g(r)>0.

The quotient polynomial, residues, and endpoint logarithms all have finite limits: the two poles stay distinct and neither approaches an integration endpoint. Consequently the exact finite-cut integral tends to

    D(X)+i pi(1-r)sqrt(r)g(r),

where D is the real principal-value integral only as an after-the-fact identification. No dominated-convergence assertion is made across the unresolved simple beta pole.

This imaginary residue is retained in `F/h0`. It does not affect the leading imaginary part of F because `sqrt(b-s)h0` tends to the purely negative-imaginary number `-2i/sqrt(b tau)`. A finite imaginary component of the bracket contributes to the leading real part of F instead.

## 3. Rigorous domination after the exact R-antiderivative

The accepted exact finite-cut R integral is used before beta integration or the endpoint limit. Its only potentially vanishing logarithm argument is

    f_v(beta)=1-alpha(v) h_v(beta),
    h_v(beta)=sqrt(lambda(beta))(sqrt(d)+iv)/sqrt(d+v^2).

Here `s=b-v^2`, so `alpha(v)=sqrt(1+K/(b-v^2))+sqrt(K/(b-v^2))` is smooth in `v^2` near zero. Therefore, uniformly on the compact beta support,

    Re f_v(beta)=f_0(beta)+O(v^2),
    c v <= |Im f_v(beta)| <= C v.

The limiting real function is `f_0(beta)=1-alpha(0)sqrt(lambda(beta))`. Its zero is exactly beta=r. Its derivative there is nonzero because

    lambda'(beta)=-1/[sqrt(beta)(1+sqrt(beta))^2]<0.

Thus `|f_0(beta)|` is comparable to `|beta-r|` in a fixed neighborhood of r. These facts imply the two-sided bound in the source. For example, the imaginary lower bound gives `v<=|f_v|/c`; together with the real-part estimate, it gives

    |f_0| <= |f_v|+C v^2 <= (1+C v/c)|f_v|.

The simple-zero comparison then bounds `|beta-r|+v` by a constant times `|f_v|`. The reverse bound follows directly from the real and imaginary estimates.

The other logarithm arguments stay uniformly away from zero. Their coefficients, including the reciprocal of `h(alpha+alpha^(-1))`, remain bounded. Principal arguments are bounded by pi. On the support, the absolute finite-cut normalized R integral is consequently bounded almost everywhere by

    M(1+|log|beta-r||).

This is integrable and g is bounded. Dominated convergence is therefore legal **after** the exact R integration. The single beta point r can be discarded for this purpose. The imaginary boundary constants for beta<r are included automatically in the complex limit.

The regular direct terms and the other-axis integrals converge uniformly. Combining them with the exact direct-beta integral proves a finite complex limit of the entire bracket `F/h0`, and establishes the source's endpoint formula without a singular interchange.

## 4. Direct-term constants and elementary logarithm bound

Independent polynomial division of

    2(1-r)t^2 g(t^2)/(t^2-r)

gives the exact polynomial integral and logarithmic coefficient

    polynomial part = -5537314770471/976562500000,
    coefficient = 103989335713263/97656250000000 > 0.

The coefficient equals the positive physical residue from Section 2. The logarithm's combined endpoint argument is

    ((1/2-q0)(q0+1/3))/((1/2+q0)(q0-1/3))=247/4653<1/16.

The strict bound `log 2>2/3` follows from the positive series `log 2=2 atanh(1/3)`. Thus the logarithm is strictly smaller than `-8/3`, and direct exact arithmetic gives

    D(X)<-207759093070617/24414062500000<-17/2,

with the stated difference `-239561820617/24414062500000` from `-17/2`.

## 5. All other-term bounds

Every displayed bound in Section 5 of the source is valid:

- Direct integration gives `E_g[2/sqrt(beta)]=2976/625`.
- The regular direct ratio increases with beta, so its maximum is its beta=1/4 value `5066/12533`.
- The N integrand decreases with X. At X=0 its primitive is `R/(1+lambda R^2)`, giving `C N_lambda(X)<=C/A=sqrt(beta)<=1/2`.
- The positive series for Z gives `Z<=1+lambda/[3(1-lambda)]`, hence `2CZ<=14/9` on `lambda in [1/3,1/2]`.
- Direct rational comparisons verify `u_min>99/100`, `u_max<11/10`, and `(21/10)^2(1-r)<27/8`.
- Since `u^2-1=(beta-r)/(r-1)`, the absolute-log identity yields the source's bound `C I<(25/99)log[(27/8)/|beta-r|]` almost everywhere. This expression is positive throughout the support.

Under `beta=a+H t`, the probability density becomes `6t(1-t)`. Splitting its logarithmic potential at t=z and integrating the polynomial factors on both sides independently gives exactly

    L(z)=-z^2(3-2z)log z-(1-z)^2(1+2z)log(1-z)
           +2z(1-z)+5/6.

At `z=11609/12500`, `h=1-z=891/12500` lies between `1/16` and `3/40`. The four upper bounds in the source follow as follows:

1. `z^2(3-2z)<=1` and `-log z<=h/(1-h)<3/37`.
2. `h^2(1+2z)<27/1600` and `-log h<log16<3`, giving `81/1600`. For a purely rational justification of the last logarithm bound, the Taylor sum of `e^3` through degree 4 is `131/8>16`.
3. `2zh<2h<3/20`.
4. The remaining constant is `5/6`.

Their exact sum is `198031/177600<9/8`. Also the Taylor sum for `exp(13/4)` through degree 6 is exactly `72428881/2949120>243/10`. Therefore the mean r-logarithm is strictly smaller than `875/792`.

The full other-term sum is exactly

    2976/625+5066/12533+1/2+14/9+875/792
      =51654162611/6203835000<25/3.

Consequently `Bbar<-17/2+25/3=-1/6`, and division by `4 pi sqrt(b tau)` gives the claimed `-1/24` spectral coefficient.

## 6. Legal tests and smooth beta bumps

The taper is nonnegative, normalized, and supported away from beta=0 and beta=1. The angular density is therefore strictly positive, smooth, W4-invariant, and subject to all normal-kernel bounds in the accepted compact-test theorem. The finite-cut formulas have ordinary continuous boundary values for each s strictly below b. The strict endpoint limit produces a negative spectral interval, not merely a negative endpoint distribution.

The previous fixed-k Hankel-to-Stieltjes necessity theorem applies without change. Negative ordinary spectral density contradicts its necessary upper-half-plane sign. Smooth time bumps and a finite compact tangential wave packet then supply an admissible compact smooth negative RP test. W4 symmetry transfers the conclusion to every coordinate mirror.

Each stated `g_n` is C-infinity after extension by zero because the exponential is flat at both endpoints. Dominated convergence gives `Z_n->1` and `g_n->g` in L1. Choose the strictly upper-half-plane point where the tapered covariance has positive imaginary part, obtained from a negative ordinary boundary interval by continuity. At that fixed point the physical-sheet covariance is uniformly bounded and continuous in beta. Hence its beta average is a continuous linear functional in the L1 norm, and the positive imaginary sign persists for all sufficiently large n.

This proves the claimed existence of failing smooth beta bumps. It also proves a genuine relative L1-open neighborhood of the normalized tapered density, on the fixed compact parameter support, with the same failure. It makes no assertion of a computable n and no universal assertion about all tapered mixtures.

## 7. Independent exact regression checks

`check_tapered_identities.py` passes 47 independent checks of the finite-cut ratio, pole factorization and half-plane signs, endpoint residue, polynomial division, logarithm argument and coefficient, all rational estimates, and the Beta(2,2) logarithmic-potential formula.

Run both:

    python check_tapered_identities.py
    python -O check_tapered_identities.py
    python verify_tapered_modes.py
    python -O verify_tapered_modes.py

The `--negative-control` option deliberately reverses the physical-residue sign and must fail in both modes. Explicit exceptions, rather than Python assertions, enforce all checks. Both ordinary and optimized runs passed with identical output, SHA256 `ad1121d0315e5d49774066afff91bf9fe55332336d6d76ec3a4243f5fe707f55`; both deliberately reversed-residue controls failed for the intended reason. Saved JSON output and `tapered-regression-validation.json` record the completed runs.

The singular-limit arguments and compact-test consequence are analytic arguments verified in Sections 1-3 and 6; they do not rest on finite regression checks.
