# Independent audit: continuous parameter mixtures of the W4 axial family

19 October 2026. Local scalar Gaussian covariance analysis only. No remote edits or publication.

## Verdict

**Accepted.** The uniform probability mixture with density `36/5` on `beta in [1/9, 1/4]` fails coordinate reflection positivity. At the specified frequency

    X = K/b = 251001/748999,

the exact endpoint coefficient obeys

    lim_{s up to b} sqrt(b-s) w_mix(K,s)
      < -53/(480 pi sqrt(b tau)) < 0.

The resulting ordinary negative spectral interval yields a genuine compact smooth negative reflected test. The same conclusion holds at every coordinate mirror by W4 symmetry.

The broader statement is also accepted: for a continuous probability density on a compact interval strictly inside `(0,1)`, a positive value at its maximal beta edge produces a negative logarithmic divergence of the averaged endpoint bracket. This argument does **not** exclude all mixtures whose density vanishes at that edge. It does not settle interacting Yang–Mills theory or a mass gap.

There is no mathematical correction required. The source now incorporates the clarification identified during this audit: the uniformly bounded expressions in the endpoint argument are the **normalized brackets `F_beta/h0`**, including their exact normalized r-integrals. The raw covariance itself is not uniformly bounded as `s` approaches `b`.

## 1. Sources and scope of the independent check

Audited source:

    /workspace/shared/parameter-mixed-rp-20261019/UNIFORM_BETA_CERTIFICATE.md
    SHA256 87743d7f472a49a35f72cf7d85888b51254b9c4a247a575181270d93b2959bef

The initial version had SHA256 `2a5d3856847ffd4cf582845d30ac65045ca1a434995605a47ccf9a89f7fd7fe3`; the intervening revision only clarified normalized brackets and fixed-X uniformity as requested by this audit.

Accepted fixed-beta source and its root review were read in full:

    /workspace/shared/w4-angular-symmetrization-20261019/RESULT.md
    SHA256 568ad3e93ea51ead59d9730b23f8803a1e361294af3fa222364b86fe4dedc189

    /workspace/shared/w4-angular-symmetrization-20261019/ROOT_REVIEW.md
    SHA256 aa59294faf43fa31df69fcb0054fcfe606180a7e42e8625e58d78f415fbb192d

The fixed-beta endpoint identity is checked against the parameter transformations below. The new beta integration, every displayed rational/logarithmic bound, the limit ordering, the general edge asymptotic, and the transfer to legal compact tests are independently verified here.

## 2. The mixed angular density meets the required hypotheses

For each beta, the axial ACG density is

    rho_beta,j(v) = sqrt(beta)/[1+(beta-1)v_j^2]^2.

Its normalization is the standard polar-coordinate Gaussian identity: use the positive quadratic form with eigenvalues `(beta,1,1,1)` and integrate the radial variable in four dimensions. Multiplication by the square root of its determinant gives precisely the displayed probability density with respect to probability surface measure on S3.

The uniform beta density is normalized because

    (36/5)(1/4-1/9) = 1.

The denominator of every axial density is bounded below by `beta >= 1/9`. All angular derivatives are therefore uniformly bounded over this compact parameter interval. Differentiating under the beta integral proves that the mixed angular density is smooth. It is strictly positive, normalized, and invariant under coordinate sign changes and permutations. These statements remain valid for any nonnegative normalized integrable beta density supported in a compact interval inside `(0,1)`.

## 3. Coordinate transformations and the exact resonant integral

Write `t = sqrt(beta)`, `lambda = (1-t)/(1+t)`, `A=1+lambda`, and `C=1-lambda`. Direct rational simplification gives

    Xc(beta) = C^2/(4lambda) = beta/(1-beta),
    AC/(C^2-4lambda X) = sqrt(beta)/[(1+X)beta-X],
    AC/(A^2+4lambda X) = sqrt(beta)/[1+(1-beta)X],
    2A/C = 2/sqrt(beta).

On the stated beta interval, `lambda in [1/3,1/2]` and `max Xc=1/3`.

For `q=sqrt(X/(1+X))>1/2`, changing variables from beta to t gives the exact resonant mean

    D(X) = (36/5)(1-q^2)
           [1/3 + q log(((q-1/2)(q+1/3))/((q+1/2)(q-1/3)))].

Indeed the transformed integrand is `2t^2/(t^2-q^2)`, and

    d/dt [2t + q log((q-t)/(q+t))] = 2t^2/(t^2-q^2).

Every logarithm in this computation has a positive real argument because `1/3 <= t <= 1/2 < q`. No principal value, hidden branch choice, or beta pole is involved.

At `q=501/1000`, exact arithmetic yields

    X = 251001/748999,
    X-1/3 = 4004/2246997 > 0,
    logarithm argument = 2503/503503 < 1/200,
    (36/5)(1-q^2) = 6740991/1250000 > 5.

The elementary exponential bound used in the certificate is valid. For `n>=3`, successive factorial-tail terms have ratio at most `1/4`, so

    e <= 5/2 + (1/6)/(1-1/4) = 49/18 < 11/4,
    (11/4)^5 = 161051/1024 < 200.

Consequently `e^5<200` and the displayed logarithm is strictly smaller than `-5`. The bracket is negative, so replacing its positive prefactor by the smaller value 5 gives an upper bound, with the correct inequality direction:

    D(X) < 5[1/3 - 5(501/1000)] = -1303/120.

## 4. Verification of every remaining term bound

All bounds below apply to the same fixed witness X.

1. Since `0<sqrt(beta)<=1/2` and `X>0`,

       AC/(A^2+4lambda X) <= 1/2.

2. Since `sqrt(beta)>=1/3`,

       2A/C <= 6.

3. The N integrand is positive and at most one: its numerator is at most one and its denominator is at least one. Thus

       C N_lambda(X) <= C <= 2/3.

4. Since `1-lambda r^2 >= C` throughout the unit interval,

       Z_lambda = integral_0^1 1/(1-lambda r^2) dr <= 1/C,
       2 C Z_lambda <= 2.

5. Put `u=sqrt((1-beta)(1+X))`. Positive-root algebra transforms the exact r-logarithm to

       C I_lambda(X) = sqrt(beta)/(2u) log((u+1)/(u-1)).

   Here `u>1` because `X>max Xc`. The function `f(u)=log((u+1)/(u-1))/u` has derivative

       f'(u) = -log((u+1)/(u-1))/u^2 - 2/[u(u^2-1)] < 0.

   Thus this term decreases with X for each beta. At `X=1/3` and `beta<1/4`,

       1 < u <= sqrt(32/27) < 2,
       sqrt(beta)/(2u) <= 1/4,
       u^2-1 = (4/3)(1/4-beta).

   Since `(u+1)^2<9`, the claimed majorant follows:

       C I_lambda(X) <= (1/4) log(27/[4(1/4-beta)]).

   At beta exactly `1/4` the majorant is infinite, while the original term at the chosen X is finite. This is harmless: the upper endpoint is a measure-zero point and the majorant is integrable. With interval length `L=5/36`, its uniform mean is exactly

       (1/4)[1+log((27/4)/L)] = (1/4)[1+log(243/5)].

   The positive Taylor polynomial of `e^4` through degree 7 is

       sum_{n=0}^7 4^n/n! = 16319/315 > 243/5.

   Hence this mean is strictly smaller than `5/4`.

The sum of the five other-term bounds is

    1/2 + 6 + 2/3 + 2 + 5/4 = 125/12.

Combining it with D gives exactly

    Bbar(X) < -1303/120 + 125/12 = -53/120.

The conversion from bracket to spectral coefficient divides this result by `4 pi sqrt(b tau)`, yielding the stated `-53/480` constant.

## 5. The endpoint interchange is legal in the stated order

Fix X strictly above `max_beta Xc(beta)`. The accepted exact finite-cut formula for the selected tangential axis is

    integral_0^1 [T_{lambda r^2,e2}/h0] dr
      = [atanh(alpha h)+atanh(delta h)]/[h(alpha+delta)],

where

    h = sqrt(lambda)(sqrt(d)+i sqrt(epsilon))/sqrt(d+epsilon),
    alpha = sqrt(1+K/s)+sqrt(K/s),  delta=1/alpha,
    epsilon=b-s,  d=(1+tau)s-b.

This formula is evaluated while `epsilon>0`, before taking the endpoint. There is no pole on the r-integration path in that regime. Its branch convention is fixed by the principal logarithms continued from these displayed arguments.

For beta in the compact interval, `lambda` lies in a compact subinterval of `(0,1)`. At the endpoint, `alpha sqrt(lambda)>1` by a uniform positive margin because X exceeds the largest threshold. Also `delta sqrt(lambda)<1` by a uniform positive margin. Consequently the logarithm arguments stay uniformly away from zero. The term `1-alpha h` approaches the negative real axis from below; its logarithm tends to the correct boundary value with imaginary part `-pi`. This is a continuous one-sided boundary extension on the entire compact beta interval, not an arbitrary principal-value replacement.

The selected direct term has a limiting denominator `C^2-4lambda X` uniformly bounded away from zero. The other two-axis terms and the normal-axis r-integrals have no endpoint resonance, with uniform denominator bounds because `lambda` remains below one. Therefore the **full normalized bracket** `F_beta/h0` has a uniformly bounded, continuous endpoint extension in beta. Dominated convergence applies to this bracket.

The factor `h0` is independent of beta and satisfies

    sqrt(b-s) h0 -> -2i/sqrt(b tau).

Taking the imaginary part after multiplying this factor yields

    lim_{s up to b} sqrt(b-s) w_mix(K,s)
       = Bbar(X)/(4 pi sqrt(b tau)).

This proves the required averaged endpoint identity. It does **not** interchange an unresolved r-pole with the endpoint limit, and it does **not** claim a bound uniform as X approaches the maximal threshold. For the broader theorem below, the limits are sequential: first fix `delta>0`, then take `s up to b`; only afterward analyze the resulting bracket as `delta down to 0`.

## 6. General continuous edge-positive mixtures

Let `g>=0` be continuous and normalized on `[beta0,beta1]` with `0<beta0<beta1<1`. Put

    X0=beta1/(1-beta1),  X=X0+delta,
    y=beta1-beta,  a_delta=1+X,  c=1-beta1,
    h(y)=g(beta1-y)sqrt(beta1-y).

The complete resonant contribution is exactly

    -integral_0^(beta1-beta0) h(y)/(a_delta y+c delta) dy.

For constant numerator `h(0)`, direct integration gives

    -(h(0)/a_delta)
      [log(a_delta(beta1-beta0)+c delta)-log(c delta)].

Dividing this expression by `log(delta)` and letting delta decrease to zero yields

    h(0)/(1+X0) = g(beta1)sqrt(beta1)(1-beta1).

Continuity is enough to control the remaining numerator. Given any positive eta, choose a fixed small edge width on which `|h(y)-h(0)|<eta`. The integral of that difference on the edge, divided by `|log(delta)|`, has limsup at most `eta/(1+X0)`. The complement is uniformly bounded because its denominator stays bounded below. Letting eta tend to zero proves that the remainder is `o(|log(delta)|)`. An `O(1)` remainder is not justified by continuity alone and is correctly not claimed.

All other non-logarithmic terms stay bounded on the compact beta interval for `X` near X0. For the exact r-logarithm,

    u^2-1 = (1+X)(beta1-beta)+(1-beta1)delta.

Its numerator `(u+1)^2` remains bounded, and its coefficient `sqrt(beta)/(2u)` also remains bounded. It is dominated, off the endpoint, by an integrable constant plus a constant times `|log(beta1-beta)|`. Multiplication by the bounded continuous density g preserves integrability. Therefore the averaged exact r-logarithm remains bounded as delta decreases to zero and cannot cancel the negative resonant divergence.

It follows that

    Bbar(X0+delta)/log(delta)
      -> g(beta1)sqrt(beta1)(1-beta1).

If `g(beta1)>0`, the right side is positive, while `log(delta)` tends to negative infinity, so `Bbar` tends to negative infinity. A sufficiently small but strictly positive delta gives the already justified negative endpoint coefficient and hence coordinate RP failure.

If g vanishes sufficiently rapidly at the maximal beta edge, the resonant inverse-edge integral can be finite. Its finite value may or may not dominate the other terms. Neither the edge asymptotic nor this audit decides that sign. In particular, no general obstruction for all tapered mixtures follows.

## 7. Negative boundary sign gives a legal compact smooth test

The fixed-beta compact-test proof transfers without an extra spectral-measure assumption. Its hypotheses are consequences only of a positive normalized, reflection-invariant angular density, all preserved by the beta mixture.

For real momenta,

    0<F_mix(u,k)<=1/(b+u^2+|k|^2).

Each slice is even and integrable in u. Its normal inverse transform H_k is continuous, real, and even. Inverting each angular resolvent gives the same explicit kernel and bound as in the accepted result:

    |H_k(T)| <= exp(-sqrt((b+|k|^2)/(1+tau))|T|)/(2sqrt(b+|k|^2)).

This estimate and continuity hold after angular and beta averaging. They imply continuity in k of every compact-time Hankel quadratic form.

If the fixed-k kernel were Hankel-positive on positive times, its formal positive shifts would be symmetric contractions. The contraction step in the accepted proof is sound: bounded shifted squared norms together with Cauchy–Schwarz give `b_j^2<=b_0 b_(2j)`; iteration forces `b_1<=b_0`, including null vectors. The shifts are positive because each is the square of a half-shift. Kernel continuity gives a strongly continuous positive self-adjoint contraction semigroup.

Continuity at zero yields a vector e0, and the spectral theorem then represents H_k as a Laplace transform of a finite positive measure. The exponential bound forces that measure to have a strictly positive lower mass threshold. Fourier inversion therefore gives a Stieltjes representation for the actual covariance slice, whose imaginary part in the upper z half-plane is nonpositive. No signed spectral measure was assumed and no contact contribution was inserted.

The axial formulas provide a holomorphic upper-half-plane continuation of the mixture. For compact z subsets there are uniform denominator bounds over compact beta and r parameter sets, so averaging preserves holomorphy. The exact finite-cut formulas give ordinary continuous boundary values near every interior point of the negative interval established above. At such a point, `w_mix<0` means `Im F_mix>0`, and boundary continuity gives the same positive sign at a nearby point strictly in the upper half-plane. This contradicts the necessary Stieltjes sign.

Thus at the selected tangential k there is a finite positive-time Hankel matrix with a strictly negative quadratic form. Approximate its time point masses by smooth compact bumps supported strictly above zero; continuity preserves strict negativity. Finally use the compact smooth tangential wave packets

    g_L(x)=L^(-3/2) chi(x/L) exp(i k.x),

with a nonzero compact smooth chi. Their squared Fourier transforms concentrate at k. Boundedness and continuity of the time quadratic form imply that some finite L already has a negative full reflected form. The product test is in `Cc-infinity` and is supported strictly in the positive half-space. If a real test is required, one of its real or imaginary parts is negative.

This proves existence of a legal compact smooth witness. It does not supply explicit bump centers or coefficients. Neither a Fourier delta nor an endpoint distribution is used as an admissible test. Coordinate permutations transport the failure to every coordinate mirror.

## 8. Reproducible exact checks

`check_exact_identities.py` passes 39 checks of the beta/lambda transformations, exact resonant primitive, witness arithmetic, both elementary exponential estimates, logarithmic majorant algebra and mean, summed coefficient, and the general edge denominator and coefficient. All checks use exact SymPy expressions and explicit exceptions rather than Python assertions.

Run:

    python check_exact_identities.py
    python -O check_exact_identities.py
    python verify_regression_modes.py
    python -O verify_regression_modes.py

The regression-mode verifier additionally corrupts the resonant primitive's logarithm coefficient. Both ordinary and optimized executions rejected that corruption for the intended reason. Normal and optimized successful outputs were byte-for-byte identical, with SHA256 `2ed9a43b7271dfd907c0d7e2582b08d72ea9502af9dc92d5164b4097e08d055f`. Saved JSON reports record the results.

These algebraic tests support the analytic proof; finite symbolic tests alone do not prove the dominated-convergence, edge-asymptotic, or compact-test arguments, which are supplied above.
