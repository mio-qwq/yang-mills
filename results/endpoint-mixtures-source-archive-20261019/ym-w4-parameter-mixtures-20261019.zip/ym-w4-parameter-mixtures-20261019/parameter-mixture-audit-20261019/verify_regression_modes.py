#!/usr/bin/env python3
"""Check ordinary/optimized agreement and deliberate-corruption rejection."""
import hashlib
import json
from pathlib import Path
import subprocess
import sys


script = Path(__file__).with_name("check_exact_identities.py")
records = []
positive_outputs = []
for optimized in (False, True):
    for negative in (False, True):
        command = [sys.executable]
        if optimized:
            command.append("-O")
        command.append(str(script))
        if negative:
            command.append("--negative-control")
        run = subprocess.run(command, text=True, capture_output=True)
        payload = json.loads(run.stdout)
        if negative:
            if run.returncode == 0 or payload.get("result") != "FAIL":
                raise RuntimeError("A deliberate corruption was not rejected")
            if "resonant-beta-integral-primitive" not in payload.get("error", ""):
                raise RuntimeError("The negative control failed for an unrelated reason")
        else:
            if run.returncode != 0 or payload.get("result") != "PASS":
                raise RuntimeError(f"A correct run failed: {run.stdout}\n{run.stderr}")
            positive_outputs.append(run.stdout)
        records.append({"optimized": optimized, "negative_control": negative, "exit_code": run.returncode, "result": payload["result"]})

if positive_outputs[0] != positive_outputs[1]:
    raise RuntimeError("Ordinary and optimized positive outputs differ")
print(json.dumps({"result": "PASS", "runs": records, "positive_output_sha256": hashlib.sha256(positive_outputs[0].encode()).hexdigest()}, indent=2))
