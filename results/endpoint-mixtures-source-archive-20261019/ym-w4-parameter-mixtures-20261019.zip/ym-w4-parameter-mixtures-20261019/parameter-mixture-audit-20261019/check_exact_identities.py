#!/usr/bin/env python3
"""Exact regression checks for the uniform-beta endpoint certificate.

These finite checks accompany, and do not replace, the analytic audit.
Explicit failures remain active under python -O.
"""
import argparse
import json
import sys

import sympy as sp


parser = argparse.ArgumentParser()
parser.add_argument("--negative-control", action="store_true")
args = parser.parse_args()
checks = []


def equal(name, lhs, rhs):
    difference = sp.simplify(lhs - rhs)
    if difference != 0:
        raise ValueError(f"{name}: nonzero exact difference {difference}")
    checks.append(name)


def positive(name, value):
    value = sp.simplify(value)
    if value.is_positive is not True:
        raise ValueError(f"{name}: not an exact strictly positive quantity: {value}")
    checks.append(name)


try:
    t, X = sp.symbols("t X", positive=True)
    lam = (1 - t) / (1 + t)
    A, C = 1 + lam, 1 - lam
    equal("beta-to-threshold", C**2 / (4 * lam), t**2 / (1 - t**2))
    equal("direct-resonant-term", A*C / (C**2 - 4*lam*X), t / ((1+X)*t**2-X))
    equal("direct-normal-term", A*C / (A**2 + 4*lam*X), t / (1+(1-t**2)*X))
    equal("two-unused-axes", 2*A/C, 2/t)

    a, b = sp.Rational(1, 9), sp.Rational(1, 4)
    L, density = b-a, sp.Rational(36, 5)
    equal("uniform-beta-normalization", density*L, 1)
    equal("lambda-at-lower-beta", lam.subs(t, sp.Rational(1, 3)), sp.Rational(1, 2))
    equal("lambda-at-upper-beta", lam.subs(t, sp.Rational(1, 2)), sp.Rational(1, 3))

    q = sp.symbols("q", positive=True)
    primitive = 2*t + (2 if args.negative_control else 1)*q*sp.log((q-t)/(q+t))
    equal("resonant-beta-integral-primitive", sp.diff(primitive, t), 2*t**2/(t**2-q**2))
    equal("resonant-beta-integral-prefactor", 1/(1+q**2/(1-q**2)), 1-q**2)
    equal("resonant-beta-integral-constant", 2*(sp.Rational(1, 2)-sp.Rational(1, 3)), sp.Rational(1, 3))

    q0 = sp.Rational(501, 1000)
    X0 = q0**2/(1-q0**2)
    equal("witness-frequency", X0, sp.Rational(251001, 748999))
    equal("witness-threshold-gap", X0-sp.Rational(1, 3), sp.Rational(4004, 2246997))
    positive("witness-above-maximal-threshold", X0-sp.Rational(1, 3))
    ratio = (q0-sp.Rational(1, 2))*(q0+sp.Rational(1, 3))/((q0+sp.Rational(1, 2))*(q0-sp.Rational(1, 3)))
    equal("exact-logarithm-argument", ratio, sp.Rational(2503, 503503))
    positive("logarithm-argument-positive", ratio)
    positive("logarithm-argument-below-one-over-200", sp.Rational(1, 200)-ratio)

    e_upper = sp.Rational(5, 2) + sp.Rational(1, 6)/(1-sp.Rational(1, 4))
    equal("geometric-exponential-tail-bound", e_upper, sp.Rational(49, 18))
    positive("e-upper-bound-below-eleven-fourths", sp.Rational(11, 4)-e_upper)
    positive("eleven-fourths-fifth-power-below-200", 200-sp.Rational(11, 4)**5)
    prefactor = density*(1-q0**2)
    equal("resonant-prefactor-exact", prefactor, sp.Rational(6740991, 1250000))
    positive("resonant-prefactor-above-five", prefactor-5)
    negative_bracket = sp.Rational(1, 3)-5*q0
    positive("bracket-is-negative", -negative_bracket)
    equal("direct-term-upper-bound", 5*negative_bracket, -sp.Rational(1303, 120))

    u = sp.symbols("u", positive=True)
    X_of_u = u**2/(1-t**2)-1
    equal("r-logarithm-positive-root-ratio-squared", (2*sp.sqrt(lam)*sp.sqrt(1+X_of_u)/A)**2, u**2)
    equal("r-logarithm-prefactor-squared", (C/(4*sp.sqrt(lam)*sp.sqrt(1+X_of_u)))**2, (t/(2*u))**2)
    f = sp.log((u+1)/(u-1))/u
    equal("r-logarithm-monotonicity-derivative", sp.diff(f, u), -sp.log((u+1)/(u-1))/u**2-2/(u*(u**2-1)))
    beta = sp.symbols("beta", positive=True)
    equal("threshold-log-denominator", (1-beta)*sp.Rational(4, 3)-1, sp.Rational(4, 3)*(sp.Rational(1, 4)-beta))
    positive("threshold-u-is-less-than-two", 4-sp.Rational(32, 27))

    y, M = sp.symbols("y M", positive=True)
    log_primitive = y*(1+sp.log(M/y))
    equal("integrable-log-primitive", sp.diff(log_primitive, y), sp.log(M/y))
    equal("integrable-log-lower-boundary", sp.limit(log_primitive, y, 0, dir="+"), 0)
    equal("mean-logarithm-argument", sp.Rational(27, 4)/L, sp.Rational(243, 5))
    partial_e4 = sum(sp.Integer(4)**n/sp.factorial(n) for n in range(8))
    equal("e-to-four-partial-sum", partial_e4, sp.Rational(16319, 315))
    positive("e-to-four-partial-sum-above-target", partial_e4-sp.Rational(243, 5))

    rest = sp.Rational(1, 2)+6+sp.Rational(2, 3)+2+sp.Rational(5, 4)
    equal("sum-of-other-term-bounds", rest, sp.Rational(125, 12))
    total = -sp.Rational(1303, 120)+rest
    equal("total-endpoint-bracket-bound", total, -sp.Rational(53, 120))
    equal("spectral-coefficient-bound", total/4, -sp.Rational(53, 480))

    beta1, delta = sp.symbols("beta1 delta", positive=True)
    Xedge = beta1/(1-beta1)+delta
    equal("general-edge-denominator", (1+Xedge)*(beta1-y)-Xedge, -((1+Xedge)*y+(1-beta1)*delta))
    equal("general-edge-logarithmic-coefficient", 1/(1+beta1/(1-beta1)), 1-beta1)
    equal("general-edge-r-log-denominator", (1-(beta1-y))*(1+Xedge)-1, (1+Xedge)*y+(1-beta1)*delta)

except Exception as error:
    print(json.dumps({"result": "FAIL", "completed_checks": checks, "error": str(error)}, indent=2))
    sys.exit(1)

print(json.dumps({"result": "PASS", "check_count": len(checks), "checks": checks}, indent=2))
