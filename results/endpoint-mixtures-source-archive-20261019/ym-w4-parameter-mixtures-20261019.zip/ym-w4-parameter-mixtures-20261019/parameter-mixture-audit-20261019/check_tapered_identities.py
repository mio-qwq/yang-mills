#!/usr/bin/env python3
"""Independent exact checks for the two-sided taper, including its residue."""
import argparse
import json
import sys
import sympy as sp

parser = argparse.ArgumentParser()
parser.add_argument("--negative-control", action="store_true")
args = parser.parse_args()
checks = []


def equal(name, lhs, rhs):
    difference = sp.simplify(lhs-rhs)
    if difference != 0:
        raise ValueError(f"{name}: nonzero exact difference {difference}")
    checks.append(name)


def positive(name, value):
    value = sp.simplify(value)
    if value.is_positive is not True:
        raise ValueError(f"{name}: not exactly positive: {value}")
    checks.append(name)


try:
    t, v, w, L = sp.symbols("t v w L", positive=True)
    m = sp.I*w
    lam = (1-t)/(1+t)
    A, C = 1+lam, 1-lam
    finite_ratio = (v+m)*(v+m*t)/((v+m*t)**2+(1-t**2)*L)
    equal("finite-cut-direct-ratio", A*(A*v+C*m)*(v+m)/((A*v+C*m)**2+4*lam*L), finite_ratio)
    denominator = v**2+L+2*sp.I*v*w*t-(w**2+L)*t**2
    equal("finite-cut-denominator", (v+m*t)**2+(1-t**2)*L, denominator)
    radical = sp.sqrt(L*(v**2+w**2+L))
    zp, zm = (sp.I*v*w+radical)/(w**2+L), (sp.I*v*w-radical)/(w**2+L)
    equal("finite-cut-root-factorization", -(w**2+L)*(t-zp)*(t-zm), denominator)
    equal("positive-pole-imaginary-part", sp.im(zp), v*w/(w**2+L))
    equal("negative-pole-imaginary-part", sp.im(zm), v*w/(w**2+L))
    positive("both-poles-have-positive-imaginary-part", v*w/(w**2+L))

    beta = sp.symbols("beta")
    a, c = sp.Rational(1, 9), sp.Rational(1, 4)
    H = c-a
    g = 6*(beta-a)*(c-beta)/H**3
    equal("taper-normalization", sp.integrate(g, (beta, a, c)), 1)
    equal("taper-lower-edge-zero", g.subs(beta, a), 0)
    equal("taper-upper-edge-zero", g.subs(beta, c), 0)
    q, r = sp.Rational(49, 100), sp.Rational(2401, 10000)
    X = r/(1-r)
    equal("taper-witness-frequency", X, sp.Rational(2401, 7599))
    equal("taper-witness-square", q**2, r)
    positive("pole-inside-lower-endpoint", q-sp.Rational(1, 3))
    positive("pole-inside-upper-endpoint", sp.Rational(1, 2)-q)

    # Set d=w^2 and tau K=d X. The finite numerator includes d beta=2t dt.
    Ps = 2*t*g.subs(beta, t**2)*(v+m)*(v+m*t)
    ratio0 = (Ps/denominator).subs({L:w**2*X, v:0})
    endpoint = 2*(1-r)*t**2*g.subs(beta, t**2)/(t**2-r)
    equal("finite-to-endpoint-rational-function", ratio0, endpoint)
    residue = sp.simplify(sp.limit((t-q)*endpoint, t, q))
    expected_residue = (1-r)*q*g.subs(beta, r)
    equal("positive-root-physical-residue", residue, (-1 if args.negative_control else 1)*expected_residue)
    positive("physical-residue-strictly-positive", residue)

    numerator = sp.expand(2*(1-r)*t**2*g.subs(beta, t**2))
    quotient, remainder = sp.div(numerator, t**2-r, t)
    polynomial_part = sp.integrate(quotient, (t, sp.Rational(1, 3), sp.Rational(1, 2)))
    equal("direct-polynomial-part", polynomial_part, -sp.Rational(5537314770471, 976562500000))
    equal("direct-logarithm-coefficient", remainder/(2*q), sp.Rational(103989335713263, 97656250000000))
    equal("direct-logarithm-coefficient-is-residue", remainder/(2*q), residue)
    logarg = (sp.Rational(1, 2)-q)*(q+sp.Rational(1, 3))/((sp.Rational(1, 2)+q)*(q-sp.Rational(1, 3)))
    equal("direct-logarithm-argument", logarg, sp.Rational(247, 4653))
    positive("direct-logarithm-argument-below-one-sixteenth", sp.Rational(1, 16)-logarg)
    direct_bound = polynomial_part+residue*(-sp.Rational(8, 3))
    equal("direct-rational-upper-bound", direct_bound, -sp.Rational(207759093070617, 24414062500000))
    equal("direct-margin-below-minus-seventeen-halves", direct_bound+sp.Rational(17, 2), -sp.Rational(239561820617, 24414062500000))

    equal("mean-two-over-square-root-beta", sp.integrate(4*g.subs(beta, t**2), (t, sp.Rational(1, 3), sp.Rational(1, 2))), sp.Rational(2976, 625))
    equal("normal-direct-pointwise-maximum", sp.sqrt(c)/(1+(1-c)*X), sp.Rational(5066, 12533))
    eta, R = sp.symbols("eta R", positive=True)
    equal("N-at-zero-antiderivative", sp.diff(R/(1+eta*R**2), R), (1-eta*R**2)/(1+eta*R**2)**2)
    equal("Z-upper-bound", (1-eta)*(1+eta/(3*(1-eta))), 1-sp.Rational(2, 3)*eta)
    positive("u-min-exceeds-ninety-nine-hundredths", (1-c)/(1-r)-sp.Rational(99, 100)**2)
    positive("u-max-below-eleven-tenths", sp.Rational(11, 10)**2-(1-a)/(1-r))
    positive("logarithm-numerator-bound", sp.Rational(27, 8)-sp.Rational(21, 10)**2*(1-r))
    equal("logarithm-prefactor-bound", sp.Rational(1, 2)/(2*sp.Rational(99, 100)), sp.Rational(25, 99))

    z, y = sp.symbols("z y", positive=True)
    def negative_log_moment(poly, upper):
        value = 0
        for (power,), coefficient in sp.Poly(sp.expand(poly), y).terms():
            value += coefficient*upper**(power+1)*(sp.Rational(1, (power+1)**2)-sp.log(upper)/(power+1))
        return value
    L_integral = negative_log_moment(6*(z-y)*(1-z+y), z)+negative_log_moment(6*(z+y)*(1-z-y), 1-z)
    L_formula = -z**2*(3-2*z)*sp.log(z)-(1-z)**2*(1+2*z)*sp.log(1-z)+2*z*(1-z)+sp.Rational(5, 6)
    equal("beta-two-two-log-potential", L_integral, L_formula)
    z0 = (r-a)/H
    h0 = 1-z0
    equal("rescaled-pole-location", z0, sp.Rational(11609, 12500))
    equal("rescaled-pole-upper-gap", h0, sp.Rational(891, 12500))
    positive("upper-gap-above-one-sixteenth", h0-sp.Rational(1, 16))
    positive("upper-gap-below-three-fortieths", sp.Rational(3, 40)-h0)
    positive("e-cubed-exceeds-sixteen", sum(sp.Integer(3)**n/sp.factorial(n) for n in range(5))-16)
    L_bound = sp.Rational(3, 37)+sp.Rational(81, 1600)+sp.Rational(3, 20)+sp.Rational(5, 6)
    equal("log-potential-rational-bound", L_bound, sp.Rational(198031, 177600))
    positive("log-potential-bound-below-nine-eighths", sp.Rational(9, 8)-L_bound)
    equal("scaled-logarithm-constant", sp.Rational(27, 8)/H, sp.Rational(243, 10))
    exponential_partial = sum(sp.Rational(13, 4)**n/sp.factorial(n) for n in range(7))
    equal("exponential-partial-sum", exponential_partial, sp.Rational(72428881, 2949120))
    positive("exponential-partial-sum-above-target", exponential_partial-sp.Rational(243, 10))
    equal("mean-r-logarithm-upper-bound", sp.Rational(25, 99)*(sp.Rational(13, 4)+sp.Rational(9, 8)), sp.Rational(875, 792))
    other = sp.Rational(2976, 625)+sp.Rational(5066, 12533)+sp.Rational(1, 2)+sp.Rational(14, 9)+sp.Rational(875, 792)
    equal("other-terms-exact-sum", other, sp.Rational(51654162611, 6203835000))
    positive("other-terms-below-twenty-five-thirds", sp.Rational(25, 3)-other)
    equal("negative-final-bracket", -sp.Rational(17, 2)+sp.Rational(25, 3), -sp.Rational(1, 6))
    equal("negative-final-spectral-constant", (-sp.Rational(17, 2)+sp.Rational(25, 3))/4, -sp.Rational(1, 24))

except Exception as error:
    print(json.dumps({"result":"FAIL", "completed_checks":checks, "error":str(error)}, indent=2))
    sys.exit(1)

print(json.dumps({"result":"PASS", "check_count":len(checks), "checks":checks}, indent=2))
