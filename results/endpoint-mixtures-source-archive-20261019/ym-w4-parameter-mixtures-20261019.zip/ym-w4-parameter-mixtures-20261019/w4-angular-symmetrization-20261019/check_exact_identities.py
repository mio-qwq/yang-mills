#!/usr/bin/env python3
"""Exact algebra regression checks; the analytic sign proof is in RESULT.md."""
import argparse
import json
import sympy as S

parser = argparse.ArgumentParser()
parser.add_argument('--negative-control', action='store_true')
args = parser.parse_args()
l, r, h, alpha, X, t, b, tau = S.symbols('lambda r h alpha X t b tau', positive=True)
A, C = 1+l, 1-l
checks = []
def check(name, expression):
    diff = S.factor(S.cancel(expression))
    if diff != 0:
        raise RuntimeError(f'FAIL {name}: exact difference {diff}')
    checks.append(name)

delta=1/alpha
numerator=1-h*h*r*r
if args.negative_control:
    numerator += h*h*r*r
check('finite_cut_partial_fractions', numerator/((1-alpha**2*h*h*r*r)*(1-delta**2*h*h*r*r)) - alpha/(alpha+delta)/(1-alpha**2*h*h*r*r) - delta/(alpha+delta)/(1-delta**2*h*h*r*r))
check('finite_cut_denominator', (1-alpha**2*h*h*r*r)*(1-delta**2*h*h*r*r) - ((1-h*h*r*r)**2-(alpha-delta)**2*h*h*r*r))
Xc=C*C/(4*l)
Xt=A*A*(1+t)**2/(4*l)-1
check('positive_threshold_offset', 4*l*(Xt-Xc)-A*A*t*(2+t))
check('rational_coefficient', A*C/(4*l*(Xt-Xc))-C/(A*t*(2+t)))
check('lower_bound_subtraction', C/(3*A*t)-C/(A*S.sqrt(t)) - C/(A*t)*(S.Rational(1,3)-S.sqrt(t)))
L=S.Rational(1,3); aa=S.Rational(101,100); dd=S.Rational(100,303)
XX=S.factor((aa-dd)**2/(4*L))
check('sample_ad_equals_lambda', aa*dd-L)
check('sample_X', XX-S.Rational(424483609,1224120000))
check('sample_threshold_difference', XX-S.Rational(1,3)-S.Rational(5481203,408040000))
check('sample_denominator_factorization', (1-L)**2-4*L*XX-(1-aa**2)*(1-dd**2))
check('sample_endpoint_bound', S.Rational(1,4)*(-S.Rational(40000,1809)+S.Rational(7,6)+S.Rational(9,2))+S.Rational(29749,7236))
check('sample_second_log_argument', (1+dd)/(1-dd)-S.Rational(403,203))
check('sample_first_log_argument', (aa+1)/(aa-1)-201)
# Check the finite-cut normalized numerator/denominator conversion symbolically.
v, m, eta, k=S.symbols('v m eta k')
# v=sqrt(a), m=sqrt(c), m^2-v^2=tau*q; substitute tau*q accordingly.
# T/h0=G with tangential projection squared k/q, q=(m²-v²)/tau.
y=(v-m)/(v+m)
G=(1+eta*y)/((1+eta*y)**2-4*eta*y*k*tau/(m*m-v*v))
h0=2/(v*(v+m))
T=2*((1+eta)+(1-eta)*m/v)/(((1+eta)*v+(1-eta)*m)**2+4*eta*tau*k)
check('tangential_closed_formula', h0*G-T)
# No floating-point calls are used.
print(json.dumps({'status':'PASS','exact_checks':len(checks),'checks':checks}, indent=2))
