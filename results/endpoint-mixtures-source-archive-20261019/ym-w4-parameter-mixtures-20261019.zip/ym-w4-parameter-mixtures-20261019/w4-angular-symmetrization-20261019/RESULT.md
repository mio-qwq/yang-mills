# W4 symmetrization of the accepted axial family fails coordinate reflection positivity

19 October 2026. Exact local scalar-covariance analysis. No repository, PR, release, or frozen artifact was changed.

## Result

Fix b>0, τ>0 and 0<β<1. Let dσ be probability surface measure on S³ and

    ρW(v) = (1/4) Σ_{j=1}^4 √β/[1+(β−1)v_j²]²,
    FW(p) = ∫S³ ρW(v)/[b+|p|²+τ(p·v)²] dσ(v).

Then FW is NOT reflection positive at any coordinate mirror. In particular the W4 average of the accepted one-mirror positive axial family does not extend that family to a coordinate-mirror positive W4 example. This rejects this particular symmetrization, not arbitrary smooth W4-invariant densities. The failure holds for every nonconstant member 0<β<1, not only for one sample. At β=1 the density is constant and the known positive radial case is recovered.

The certificate is an ordinary negative normal spectral density on a nonempty open interval just below the endpoint x=K+b, at an explicitly chosen tangential frequency k=√K e₂ for the mirror normal to e₁. The sign persists in an open neighborhood of that tangential frequency, so it is not an exceptional, measure-zero fiber.

Only scalar Gaussian two-point reflection positivity is under consideration. No claim about interacting Yang–Mills theory or a mass-gap construction is made.

## 1. Exact axial decomposition

Set

    λ=(1−√β)/(1+√β),   A=1+λ,   C=1−λ,    0<λ<1.

Use the already accepted identity separately for each axis a:

    Fa = (A/2) Tλ,a + (C/2) ∫₀¹ Tλr²,a dr,
    Tη,a(p) = h₀(q) Gηy((a·p)/√q),
    Gζ(t) = (1+ζ)/[(1+ζ)²−4ζt²],
    q=|p|²,  a₀(q)=b+q,  c(q)=b+(1+τ)q,
    y=(√a₀−√c)/(√a₀+√c),
    h₀(q)=2/[√a₀(√a₀+√c)].

Both roots are continued from positive real q using their principal roots. In particular their product is not replaced by a principal square root of the product.

Take the mirror e₁, p=u e₁+√K e₂, z=u², q=z+K, and put X=K/b. The axis e₁ is normal, e₂ is the selected tangential axis, and e₃,e₄ have a·p=0.

For an axis tangential to the mirror with a·k=k_a, direct algebra gives

    Tη,a = 2[(1+η)+(1−η)√c/√a₀]
      / {[(1+η)√a₀+(1−η)√c]²+4ητ k_a²}.             (1)

The normal-axis formula is the accepted one,

    Tη,e₁ = 2[(1+η)+(1−η)√c/√a₀]
      / {[(1+η)√c+(1−η)√a₀]²−4ητ K}.              (2)

For Im q>0 each positive linear combination of the two roots lies in the first quadrant. Its square has strictly positive imaginary part. Thus neither denominator (1) nor (2) vanishes there. These formulas provide the unambiguous upper-half-plane continuation of the real-momentum covariance.

## 2. Exact finite-cut integral: the parameter-pole issue is resolved before taking the limit

Let

    b/(1+τ)<s<b,   q=−s+i0,
    ε=b−s>0,   d=(1+τ)s−b>0,
    h=√λ(√d+i√ε)/√(d+ε),
    α=√(1+K/s)+√(K/s),   δ=1/α.

Then h²=−λy and h is in the first quadrant. For the selected tangential axis e₂,

    ∫₀¹ [Tλr²,e₂/h₀] dr
      = [atanh(αh)+atanh(δh)]/[h(α+δ)].            (3)

Here atanh w=[Log(1+w)−Log(1−w)]/2, with principal logarithms at the displayed first-quadrant arguments. Formula (3) is an exact expression for every point in the open cut, not a principal-value substitution under a limiting integral.

To check it directly,

    Tλr²,e₂/h₀
      = (1−h²r²)/[(1−α²h²r²)(1−δ²h²r²)]
      = [α/(α+δ)]/(1−α²h²r²)
          + [δ/(α+δ)]/(1−δ²h²r²).

Integration gives (3). No pole lies on the integration path because h has strictly positive imaginary part.

Define the endpoint threshold

    Xc=C²/(4λ).

For X>Xc, α√λ>1 and δ√λ<1 at s=b. Consequently (3) has the finite boundary limit

    I(X) + iπ/[4√λ√(1+X)],

where

    I(X)=1/[4√λ√(1+X)]
       · log[(A+2√λ√(1+X))/(2√λ√(1+X)−A)] > 0.     (4)

The same real number is the principal value

    I(X)=PV ∫₀¹ (1−λr²)
          /[(1−λr²)²−4λXr²] dr.

The exact finite-cut formula establishes which boundary value to use and includes the imaginary contribution from the interior parameter resonance. That contribution cannot be discarded from the full covariance, but it does not contribute to the leading imaginary part after multiplication by h₀, whose leading endpoint value is purely negative imaginary.

## 3. Exact endpoint spectral coefficient

Also define

    Z=atanh(√λ)/√λ,
    N(X)=∫₀¹ (1−λr²)/[(1+λr²)²+4λXr²] dr.

For X≥0,

    0<N(X)≤1.

The other endpoint ratios have no interior parameter resonance:

    Tη,e₁/h₀ → (1−η)/[(1+η)²+4ηX],
    Tη,e₃/h₀ = Tη,e₄/h₀ → 1/(1−η).

Their parameter integrals converge uniformly because 0≤η≤λ<1 and the denominators stay bounded away from zero. Therefore, writing

    B(X)=A{C/[A²+4λX]+C/[C²−4λX]+2/C}
            +C{N(X)+I(X)+2Z},                    (5)

we have

    Re[FW/h₀] → B(X)/8.

Moreover FW/h₀ has a finite complex limit, by (3). Since

    √ε h₀(−b+ε+i0) → −2i/√(bτ),

the ordinary normal spectral density on this cut,

    wW(K,s)=−(1/π) Im FW(z=−K−s+i0),

satisfies the exact endpoint limit

    lim_{s↑b} √(b−s) wW(K,s) = B(X)/[4π√(bτ)].     (6)

Thus B(X)<0 proves a negative open interval. Equation (4) also shows why the parameter integral cannot cancel the obstruction: as X↓Xc from above, its divergence is logarithmic, whereas C/[C²−4λX] diverges negatively like −1/(X−Xc).

## 4. All nonconstant β are rejected by the endpoint asymptotic

At fixed λ∈(0,1), the terms N(X), 2Z, 2/C, and C/[A²+4λX] remain bounded as X↓Xc from above. The exceptional rational term is exactly

    AC/[C²−4λX] = −AC/[4λ(X−Xc)].

Equation (4) gives I(X)=O(log(1/(X−Xc))) in this same limit. Therefore

    B(X)=−AC/[4λ(X−Xc)] + O(log(1/(X−Xc))) → −∞.    (7)

For every 0<λ<1, choose any X>Xc sufficiently near Xc that B(X)<0. By (6), some ε₀∈(0,b−b/(1+τ)) then satisfies

    wW(K,s)<0 whenever b−ε₀<s<b,    K=bX.

Equivalently the ordinary normal spectral density is strictly negative throughout

    K+b−ε₀ < x < K+b.

This is an analytic negative spectral interval, obtained from an exact boundary limit. It uses neither numerical signs nor an exchange of the endpoint limit with the resonant parameter integral. The optional appendix supplies an explicit elementary choice of X for every β if one wants to avoid even the phrase “sufficiently near.”

## 5. Explicit rational/logarithmic certificate at β=1/4

For the especially simple accepted example β=1/4, set

    λ=1/3,   A=4/3,   C=2/3,
    a=101/100,   d=100/303,    ad=λ,
    X=(a−d)²/(4λ)=424483609/1224120000 > Xc=1/3,
    K=bX.

The selected tangential axis's leading rational contribution to Fa/h₀ is

    (A/2) C/[C²−4λX]
      = (4/9)/[(1−a²)(1−d²)]
      < −40000/1809.

Indeed 1−a²=−201/10000 and 0<1−d²<1. Its parameter-integral contribution is (C/2)I(X), where

    I(X)=[atanh_PV(a)+atanh(d)]/(a+d)
        =[log(201)+log(403/203)]/[2(a+d)] < 7/2.

The strict elementary bounds used here are log 201<6, log(403/203)<log 2<1, and a+d>1. For example e⁶>201 follows already by summing the first seven nonnegative Taylor terms of e⁶; e>2 is immediate from its first three terms. Thus the complete selected-axis endpoint real coefficient is less than

    −40000/1809 + 7/6.

For each of the other three axes the endpoint harmonic ratio obeys

    G_{−η}(t)=(1−η)/[(1−η)²+4ηt²]≤1/(1−η)≤1/C=3/2,

because its endpoint t² is nonnegative. The positive axial-mixture weights sum to one, so each complete axial coefficient is at most 3/2. Consequently

    lim Re[FW/h₀]
      < (1/4)[−40000/1809+7/6+9/2]
      = −29749/7236 < 0.                           (8)

It follows that

    lim_{s↑b} √(b−s) wW(K,s)
      < −29749/[3618π√(bτ)] < 0.                  (9)

Thus, for these exact rational parameters and any b,τ>0, there is a nonempty negative interval immediately below x=K+b. The certificate involves only rational inequalities, elementary logarithm bounds, and the audited exact boundary formula.

## 6. Why negative cut sign implies a legal negative RP test

This section checks the regularity and localization hypotheses behind the necessary Stieltjes condition. It does not assume the existence or finite variation of a signed spectral measure for the symmetrized covariance.

### 6.1 Bounded continuous normal kernels

For real momenta, positivity and normalization of ρW give

    0<FW(u,k)<=1/(b+u^2+|k|^2).

Each normal slice is even and L1 in u. Its inverse Fourier transform H_k(T) is bounded, continuous, real and even. One can also invert each angular resolvent directly. For v in S3 set

    a_v=1+tau v1^2,
    c_v=tau v1(k.v_tan),
    d_v=b+K+tau(k.v_tan)^2,
    Delta_v=a_v d_v-c_v^2=a_v(b+K)+tau(k.v_tan)^2,
    m_v=sqrt(Delta_v)/a_v.

The inverse transform is

    exp(-m_v|T|) exp(-i c_v T/a_v)/(2sqrt(Delta_v)).

Since m_v>=sqrt((b+K)/(1+tau)), averaging gives the locally uniform estimate

    |H_k(T)| <= exp(-sqrt((b+K)/(1+tau))|T|)/(2sqrt(b+K)).

In particular H_k is integrable in T, tends to zero, and varies continuously with k, locally uniformly in bounded T intervals. Invariance under v1 sign reversal makes it real and even.

### 6.2 Full RP implies fixed-k Hankel positivity

For product tests f(t,x)=h(t)g(x),

    Q(f)=(2pi)^(-3) integral |g_hat(k)|^2 Q_k(h) dk,
    Q_k(h)=integral integral conjugate(h(t)) H_k(t+s)h(s) dt ds.

For every h in Cc-infinity((0,infinity)), Q_k(h) is continuous in k by the preceding bounds. If Q_k(h)<0 at one k0, choose a compact smooth tangential wave packet

    g_L(x)=L^(-3/2)chi(x/L)exp(i k0.x),  chi in Cc-infinity(R3).

Its normalized squared Fourier transform concentrates at k0 as L increases. Boundedness and continuity show Q(h g_L)<0 for some finite L. Thus full RP forces Q_k(h)>=0 at every fixed k, including the selected k=sqrt(K)e2. This does not infer pointwise positivity from a merely almost-everywhere statement without continuity.

Approximating finitely many positive-time point masses by smooth bumps shows that full RP forces every matrix [H_k(t_i+t_j)] to be positive semidefinite.

### 6.3 A bounded Hankel-positive kernel has the needed Stieltjes continuation

For completeness, here is a short bounded-kernel proof. Make formal vectors e_t, t>0, with inner products H_k(t+s). Positive shifts T_a e_t=e_(t+a) are symmetric. For a finite vector xi let b_j=||T_a^j xi||^2. If xi=sum_i c_i e_(t_i), then b_j=sum_(i,l) conjugate(c_i)c_l H_k(t_i+t_l+2ja), so b_j<=sup|H_k| (sum_i |c_i|)^2 uniformly in j. Symmetry and Cauchy-Schwarz give

    b_j^2<=b_0 b_(2j).

Iteration gives b_1<=b_0; the same inequality handles null vectors. Therefore the shifts descend to self-adjoint contractions on the Hilbert completion. Moreover T_a=T_(a/2)^2 makes them positive. Kernel continuity supplies strong continuity, so T_a=exp(-aH) for a nonnegative self-adjoint generator H.

Continuity at zero makes e_t a Cauchy family as t decreases to zero:

    ||e_t-e_s||^2=H_k(2t)+H_k(2s)-2H_k(t+s) -> 0.

Let its limit be e_0. The spectral theorem yields the finite positive measure sigma_k for which

    H_k(T)=integral_[0,infinity) exp(-mT) sigma_k(dm), T>=0.

The exponential estimate in 6.1 forces sigma_k to be supported in m>=sqrt((b+K)/(1+tau)); in particular there is no zero-mass atom. Fourier inversion, justified by this lower bound and finite sigma_k, gives

    F_k(z)=integral 2m/(m^2+z) sigma_k(dm).

For real z=u^2>0 this agrees with the original slice. It is holomorphic on the upper z half-plane and has Im F_k(z)<=0 there. The original bound z F_k(z)<=1 also implies, by monotone convergence, that the pushed Stieltjes measure has total mass at most one. There is no contact addition: the actual inverse transform is continuous on the entire real T axis and agrees with the Laplace representation there.

### 6.4 Contradiction and compact tests

Section 1 supplies a holomorphic physical continuation in the upper z half-plane that agrees with the original germ for z>0. Identity of analytic continuations forces it to equal the Stieltjes function if RP held. But the endpoint formula (6) yields Im F_k(z+i0)>0 at an ordinary interior point of the negative axis. Boundary continuity makes Im F_k positive at some nearby point strictly in the upper half-plane, contradicting the Stieltjes sign.

Therefore the fixed-k Hankel kernel is not positive semidefinite. A finite matrix has a strictly negative quadratic form at some positive times. Replace its time deltas by sufficiently narrow smooth compact bumps, whose supports stay strictly above zero; continuity preserves the negative sign. Then use the finite-L tangential wave packet of 6.2. The resulting f is a genuine Cc-infinity function supported in x1>0 and has Q(f)<0. If a real test is desired, the real and imaginary parts split the real symmetric reflected form, so at least one is negative.

This is an existence proof of a legal witness, not a claim to have computed its times or coefficients. Neither a single Fourier delta nor an endpoint distribution is being presented as a legal test. Contact distributions at the spacetime origin vanish on these strictly separated reflected supports and cannot repair the failure.

W4 invariance transports the same failure to all coordinate mirrors. Since coordinate positivity already fails, no diagonal-mirror audit is needed to reject this proposed family. This rejects the naive equal average of these four axial densities only. It does not exclude other smooth infinite-angular W4-invariant densities and does not settle the general W4 coordinate/diagonal-mirror question.

## Appendix: optional explicit frequency choice for every 0<β<1

The following exact construction avoids an unspecified choice of how near Xc to work. Define the positive dimensionless constants

    D=C/A + 2A/C + C + 2CZ,
    t=min{1/36, C/(12AD)},
    X=A²(1+t)²/(4λ)−1,
    K=bX.                                         (7)

Then X>Xc>0. For this X,

    4λ(X−Xc)=A²t(2+t),
    I(X)=log((2+t)/t)/[2A(1+t)].

Put H=−B(X). Formula (5) gives

    H=C/[At(2+t)] − AC/[A²+4λX] −2A/C
           − C I(X) − C N(X) −2CZ.

Because AC/[A²+4λX]≤C/A and N(X)≤1,

    H ≥ C/[At(2+t)] − C log((2+t)/t)/[2A(1+t)] − D.

For 0<t≤1, log((2+t)/t)≤log(3/t)≤2/√t. The last elementary inequality follows, for example, from log x≤√x for x≥1 and √3<2. Since t≤1/36,

    H ≥ C/(3At) − C/(A√t) −D
      ≥ C/(6At) −D
      ≥ D > 0.                                    (8)

The last step uses t≤C/(12AD). Hence the explicit choice (7) gives

    B(X)≤−D<0,
    lim_{s↑b} √(b−s) wW(K,s)≤−D/[4π√(bτ)]<0.      (9)

In particular there is ε₀>0, with ε₀<b−b/(1+τ), such that throughout the nonempty interval

    K+b−ε₀ < x < K+b,    x=K+s,

one has the stronger inequality

    wW(K,x−K)<−D/[8π√(bτ)√(K+b−x)]<0.             (10)

This is an analytic negative spectral interval: its existence and sign follow from the exact limit and strict bound (9), without a numerical sign check. Its endpoint K+b and the frequency K are specified by (7); any sufficiently small ε₀ satisfying the ordinary definition of the limit in (9) works. Formula (3), together with the other elementary axis terms, also supplies the exact density at each interior point of that interval.

## Verification and scope

- The exact parameter antiderivative (3), the rational certificate, and the compact-test necessity argument in Section 6 were independently audited in w4-rp-obstruction-audit-20261019/AUDIT.md.
- A symbolic regression script in this directory verifies the factorization, endpoint parameterization, and comparison algebra using exact SymPy expressions. It uses explicit failures and works under python -O.
- All signs in the argument are proved analytically. No floating-point sign assertion, finite angular truncation, or assumed positivity under rotation averaging is used.
- The starting accepted one-mirror theorem remains untouched and is not contradicted: only its selected axis is guaranteed positive before averaging, and the differently oriented summands need not be positive at the common coordinate mirror.

Reproduce the exact regression checks:

    python check_exact_identities.py
    python verify_regression_modes.py
    python -O verify_regression_modes.py

Both deliberately corrupted controls must fail:

    python check_exact_identities.py --negative-control
    python -O check_exact_identities.py --negative-control
