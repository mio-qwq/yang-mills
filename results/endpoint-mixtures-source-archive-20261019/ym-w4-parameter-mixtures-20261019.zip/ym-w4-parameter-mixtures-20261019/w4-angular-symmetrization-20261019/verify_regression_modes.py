#!/usr/bin/env python3
"""Check positive/negative controls under ordinary and optimized Python."""
from pathlib import Path
import json
import subprocess
import sys
script=Path(__file__).with_name('check_exact_identities.py')
results=[]
outputs=[]
for flags in ([], ['-O']):
    good=subprocess.run([sys.executable,*flags,str(script)],text=True,capture_output=True)
    if good.returncode != 0:
        raise RuntimeError(f'Good run failed under {flags}: {good.stderr}')
    data=json.loads(good.stdout)
    if data.get('status')!='PASS' or data.get('exact_checks')!=13:
        raise RuntimeError('Unexpected positive report')
    outputs.append(good.stdout)
    bad=subprocess.run([sys.executable,*flags,str(script),'--negative-control'],text=True,capture_output=True)
    marker='FAIL finite_cut_partial_fractions: exact difference'
    if bad.returncode==0 or marker not in bad.stderr:
        raise RuntimeError(f'Negative control did not fail as intended under {flags}')
    results.append({'mode':'optimized' if flags else 'ordinary','positive':'PASS','negative_control':'EXPECTED_EXACT_MISMATCH'})
if outputs[0]!=outputs[1]:
    raise RuntimeError('Normal and optimized positive reports differ')
print(json.dumps({'status':'PASS','modes':results,'positive_reports_identical':True},indent=2))
