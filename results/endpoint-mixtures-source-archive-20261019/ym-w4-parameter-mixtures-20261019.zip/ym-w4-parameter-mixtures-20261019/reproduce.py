#!/usr/bin/env python3
"""Exact local replay, with optimization-resistant integrity and negative controls."""
from pathlib import Path
from zipfile import ZipFile
import argparse,hashlib,json,os,subprocess,sys,tempfile
ROOT=Path(__file__).resolve().parent

def require(ok,why):
 if not ok:raise RuntimeError(why)
def sha(data):return hashlib.sha256(data).hexdigest()
def integrity():
 count=0
 for line in (ROOT/'SHA256SUMS').read_text().splitlines():
  digest,name=line.split('  ',1);path=ROOT/name
  require(path.resolve().is_relative_to(ROOT),'Unsafe manifest path')
  require(path.is_file() and sha(path.read_bytes())==digest,'Integrity mismatch: '+name);count+=1
 return count

def main():
 parser=argparse.ArgumentParser();parser.add_argument('--integrity-only',action='store_true');args=parser.parse_args()
 count=integrity()
 if args.integrity_only:print(json.dumps({'status':'PASS','integrity_files':count},sort_keys=True));return
 import sympy
 env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',PYTHONHASHSEED='0');env.pop('PYTHONOPTIMIZE',None)
 tasks=[
 ('w4-angular-symmetrization-20261019/check_exact_identities.py','exact-checks.json','FAIL finite_cut_partial_fractions'),
 ('w4-rp-obstruction-audit-20261019/check_audit_identities.py','exact-checks.json','FAIL normalized exact partial fractions'),
 ('parameter-mixed-rp-20261019/check_exact_identities.py','exact-checks.json','FAIL direct_integral_log_coefficient'),
 ('parameter-mixture-audit-20261019/check_exact_identities.py','exact-checks.json','resonant-beta-integral-primitive'),
 ('parameter-mixture-audit-20261019/check_tapered_identities.py','tapered-exact-checks.json','positive-root-physical-residue')]
 results=[]
 for script,certificate,negative_marker in tasks:
  path=ROOT/script;expected=path.with_name(certificate).read_bytes();outputs=[]
  for flags in ([],['-O']):
   cmd=[sys.executable,*flags,str(path)]
   good=subprocess.run(cmd,capture_output=True,env=env)
   require(good.returncode==0,script+' positive replay failed: '+good.stderr.decode());require(good.stdout==expected,script+' certificate mismatch');outputs.append(good.stdout)
   bad=subprocess.run([*cmd,'--negative-control'],capture_output=True,env=env)
   require(bad.returncode!=0 and negative_marker in (bad.stdout+bad.stderr).decode(),script+' wrong negative-control outcome')
  require(outputs[0]==outputs[1],script+' optimization changes output')
  data=json.loads(outputs[0]);results.append({'script':script,'positive_sha256':sha(outputs[0]),'exact_checks':data.get('exact_checks',data.get('check_count',data.get('count'))),'normal':'PASS','optimized':'PASS','negative_controls':'EXPECTED_REJECTION_BOTH_MODES'})
 dep=ROOT/'dependencies/ym-positive-infinite-angular-20261019.zip'
 require(sha(dep.read_bytes())=='476a47359f8ff24bef53709d7e0cefa7dfa5e27001c9e4f5326f3d2e1ffe303b','Prior archive identity mismatch')
 with tempfile.TemporaryDirectory(prefix='ym-dependency-') as td:
  work=Path(td)
  with ZipFile(dep) as z:
   require(all((work/x.filename).resolve().is_relative_to(work) for x in z.infolist()),'Unsafe archive path');z.extractall(work)
  scripts=list(work.rglob('verify_regression_modes.py'));require(len(scripts)==1,'Unexpected prior archive layout')
  reports=[]
  for flags in ([],['-O']):
   run=subprocess.run([sys.executable,*flags,str(scripts[0])],capture_output=True,env=env)
   require(run.returncode==0,'Prior axial-family check failed: '+run.stderr.decode());reports.append(run.stdout)
  require(reports[0]==reports[1],'Prior axial-family mode mismatch')
 print(json.dumps({'status':'PASS','integrity_files':count,'python':sys.version.split()[0],'sympy':sympy.__version__,'new_exact_check_total':sum(r['exact_checks'] for r in results),'checks':results,'prior_axial_family_archive_sha256':sha(dep.read_bytes()),'prior_axial_family_normal_optimized_and_negative_controls':'PASS','claim_boundary':'Specified scalar angular covariance families only; no Yang-Mills conclusion.'},indent=2,sort_keys=True))
if __name__=='__main__':main()
