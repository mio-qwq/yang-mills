# W4 angular averaging and parameter-mixture obstructions

Local source checkpoint, 19 October 2026. No repository write, PR, merge, release, or publication was performed.

## Accepted scope

The equal four-axis average of the accepted axial ACG family fails coordinate reflection positivity for every 0 < beta < 1. The uniform beta mixture on [1/9,1/4], the stated edge-positive class, and the explicit two-sided taper also fail. The tapered argument resolves its interior beta pole at finite cut. The included W4 and mixture audits supply the necessary Stieltjes sign and compact smooth test localization.

These are restricted scalar Gaussian covariance results. They do not exclude every W4 density or every parameter mixture and make no interacting Yang–Mills or mass-gap claim.

## Reproduce

Requires Python 3.10+ and SymPy 1.14.0. Install dependencies only in your own chosen environment. All replay writes occur in disposable temporary directories.

    python reproduce.py
    python -O reproduce.py
    python -O reproduce.py --integrity-only

Each full invocation reruns every new checker normally and with optimization, verifies exact accepted output bytes, and requires the intentional algebra/residue corruptions to fail. It also extracts the exact prior accepted axial-family source archive and runs its normal/optimized and negative-control checks. Finite symbolic checks are regressions; the analytic proofs and independent mathematical audits remain necessary.

## Reading order

1. dependencies/ym-positive-infinite-angular-20261019.zip: pinned previously archived positive axial family.
2. w4-angular-symmetrization-20261019/RESULT.md and w4-rp-obstruction-audit-20261019/AUDIT.md: fixed-beta obstruction and legal-test implication.
3. parameter-mixed-rp-20261019/UNIFORM_BETA_CERTIFICATE.md and parameter-mixture-audit-20261019/AUDIT.md: uniform and edge-positive mixtures.
4. parameter-mixed-rp-20261019/RESULT.md and parameter-mixture-audit-20261019/TAPERED_AUDIT.md: tapered witness and smooth approximations.

All selected input files are exact copies. Original absolute source references in those historical documents are mapped by PROVENANCE.json and the directory names here. Earlier root-review notes keep their chronology; the final independent audit verdicts control acceptance. Identical optimized JSON copies were removed; every omitted duplicate is regenerated. SHA256SUMS covers every payload file except itself. External archive SHA-256 protects SHA256SUMS.

## Recovery

Verify the external ZIP SHA-256; extract into a new directory; run reproduce.py. A mismatch is a blocker, never a reason to edit the retained reference certificate. Open research remains the search for genuinely different W4 constructions or a wider rigorous obstruction. This checkpoint does not authorize further numerical searches or remote actions.
