#!/usr/bin/env python3
"""Exact regressions only; complete analytic proof is RESULT.md."""
import argparse
import json
import math
import sympy as S

parser = argparse.ArgumentParser()
parser.add_argument('--negative-control', action='store_true')
args = parser.parse_args()
checks = []
def eq(name, expr):
    diff = S.factor(S.cancel(S.simplify(expr)))
    if diff != 0:
        raise RuntimeError(f'FAIL {name}: exact difference {diff}')
    checks.append(name)
def pos(name, expr):
    value = S.simplify(expr)
    if value.is_positive is not True:
        raise RuntimeError(f'FAIL {name}: not exactly positive: {value}')
    checks.append(name)

beta,t,v,m,kappa=S.symbols('beta t v m kappa', positive=True)
a,c=S.Rational(1,9),S.Rational(1,4)
H=c-a
g=6*(beta-a)*(c-beta)/H**3
q=S.Rational(49,100); r=q*q; X=r/(1-r)
eq('density_normalization',S.integrate(g,(beta,a,c))-1)
eq('selected_frequency',X-S.Rational(2401,7599))
lambda_t=(1-t)/(1+t); A=1+lambda_t; C=1-lambda_t
y=(v-m)/(v+m)
G=(1+lambda_t*y)/((1+lambda_t*y)**2-4*lambda_t*y*kappa/(m*m-v*v))
finite=(v+m)*(v+m*t)/((v+m*t)**2+(1-t*t)*kappa)
eq('finite_cut_direct_ratio',A*G-finite)
D=S.symbols('d',positive=True)
zp=(S.I*v*S.sqrt(D)+S.sqrt(kappa*(v*v+D+kappa)))/(D+kappa)
zm=(S.I*v*S.sqrt(D)-S.sqrt(kappa*(v*v+D+kappa)))/(D+kappa)
Ds=v*v+kappa+2*S.I*v*S.sqrt(D)*t-(D+kappa)*t*t
eq('finite_cut_root_factorization',Ds+(D+kappa)*(t-zp)*(t-zm))
eq('direct_beta_conversion',A*C/(C*C-4*lambda_t*X)-t/((1+X)*t*t-X))
eq('normal_beta_conversion',A*C/(A*A+4*lambda_t*X)-t/(1+(1-t*t)*X))
poly=2*t*t*(t*t-a)*(c-t*t)
quot,rem=S.div(poly,t*t-r,t)
eq('quotient_reconstruction',quot*(t*t-r)+rem-poly)
polyint=S.integrate(quot,(t,S.Rational(1,3),S.Rational(1,2)))
logcoef=rem/(2*q)
constant=S.factor(6/H**3*(1-r)*polyint)
coefficient=S.factor(6/H**3*(1-r)*logcoef)
if args.negative_control:
    coefficient += 1
expected_constant=-S.Rational(5537314770471,976562500000)
expected_coefficient=S.Rational(103989335713263,97656250000000)
eq('direct_integral_constant',constant-expected_constant)
eq('direct_integral_log_coefficient',coefficient-expected_coefficient)
arg=((S.Rational(1,2)-q)/(S.Rational(1,2)+q))/((q-S.Rational(1,3))/(q+S.Rational(1,3)))
eq('direct_log_argument',arg-S.Rational(247,4653))
pos('direct_log_argument_bound',S.Rational(1,16)-arg)
Du=constant-S.Rational(8,3)*coefficient
eq('direct_rational_upper_bound',Du+S.Rational(207759093070617,24414062500000))
pos('direct_below_minus_17_over_2',-S.Rational(17,2)-Du)
eq('inverse_sqrt_mean',S.integrate(g*2/S.sqrt(beta),(beta,a,c))-S.Rational(2976,625))
eq('normal_term_bound',S.Rational(1,2)/(1+S.Rational(3,4)*X)-S.Rational(5066,12533))
lambda_sym=S.symbols('lambda',positive=True)
eq('N_zero_primitive',S.diff(t/(1+lambda_sym*t*t),t)-(1-lambda_sym*t*t)/(1+lambda_sym*t*t)**2)
eq('Z_bound_simplification',(1-lambda_sym)*(1+lambda_sym/(3*(1-lambda_sym)))-(1-2*lambda_sym/3))
pos('u_min_bound',S.Rational(7500,7599)-S.Rational(99,100)**2)
pos('u_max_bound',S.Rational(11,10)**2-S.Rational(80000,68391))
pos('log_argument_constant_bound',S.Rational(27,8)-S.Rational(21,10)**2*(1-r))
z=(r-a)/H; h=1-z
eq('rescaled_resonance',z-S.Rational(11609,12500))
eq('rescaled_edge_distance',h-S.Rational(891,12500))
pos('h_lower',h-S.Rational(1,16));pos('h_upper',S.Rational(3,40)-h)
Lbound=S.Rational(3,37)+S.Rational(81,1600)+S.Rational(3,20)+S.Rational(5,6)
eq('log_distance_bound_sum',Lbound-S.Rational(198031,177600))
pos('log_distance_bound_below_9_over_8',S.Rational(9,8)-Lbound)
exp3=sum(S.Rational(3)**j/S.factorial(j) for j in range(5))
pos('exp3_taylor_exceeds_16',exp3-16)
exp134=sum(S.Rational(13,4)**j/S.factorial(j) for j in range(7))
eq('exp_13_over_4_partial_sum',exp134-S.Rational(72428881,2949120))
pos('exp_13_over_4_exceeds_243_over_10',exp134-S.Rational(243,10))
eq('log_term_bound',S.Rational(25,99)*(S.Rational(13,4)+S.Rational(9,8))-S.Rational(875,792))
rest=S.Rational(2976,625)+S.Rational(5066,12533)+S.Rational(1,2)+S.Rational(14,9)+S.Rational(875,792)
eq('remaining_terms_sum',rest-S.Rational(51654162611,6203835000))
pos('remaining_terms_below_25_over_3',S.Rational(25,3)-rest)
eq('endpoint_coefficient_margin',-S.Rational(17,2)+S.Rational(25,3)+S.Rational(1,6))
# Independent exact integration of the weighted log-distance kernel by differentiation.
zz,uu=S.symbols('z u',positive=True)
L=-S.integrate(6*(zz-uu)*(1-zz+uu)*S.log(uu),(uu,0,zz))-S.integrate(6*(zz+uu)*(1-zz-uu)*S.log(uu),(uu,0,1-zz))
Lformula=-zz**2*(3-2*zz)*S.log(zz)-(1-zz)**2*(1+2*zz)*S.log(1-zz)+2*zz*(1-zz)+S.Rational(5,6)
eq('weighted_log_distance_integral',L-Lformula)
# Uniform-beta certificate checks.
qu=S.Rational(501,1000); Xu=qu*qu/(1-qu*qu)
eq('uniform_frequency',Xu-S.Rational(251001,748999))
argu=(qu-S.Rational(1,2))*(qu+S.Rational(1,3))/((qu+S.Rational(1,2))*(qu-S.Rational(1,3)))
eq('uniform_log_argument',argu-S.Rational(2503,503503))
pos('uniform_argument_below_one_over_200',S.Rational(1,200)-argu)
pos('uniform_multiplier_above_five',S.Rational(36,5)*(1-qu*qu)-5)
pos('e_upper_power_five_bound',200-S.Rational(11,4)**5)
eq('uniform_direct_bound',5*(S.Rational(1,3)-5*qu)+S.Rational(1303,120))
exp4=sum(S.Rational(4)**j/S.factorial(j) for j in range(8))
eq('exp4_taylor_sum',exp4-S.Rational(16319,315))
pos('exp4_exceeds_uniform_log_target',exp4-S.Rational(243,5))
eq('uniform_final_bound',-S.Rational(1303,120)+S.Rational(1,2)+6+S.Rational(2,3)+2+S.Rational(5,4)+S.Rational(53,120))
print(json.dumps({'status':'PASS','exact_checks':len(checks),'checks':checks},indent=2))
