# Continuous parameter mixing, including a two-sided taper, does not rescue this W4 family

19 October 2026. Local scalar Gaussian covariance research only. No repository edits, merges, releases, or publication.

## Main result

Let b,tau>0 and define

    a=1/9, c=1/4, H=c-a=5/36,
    g(beta)=6(beta-a)(c-beta)/H^3,   a<=beta<=c,
    g(beta)=0 otherwise.

This is an explicit continuous probability density with simple zeros at both ends of its nontrivial compact support. Define the parameter-mixed, equal-four-axis angular density

    rho(v)=integral_a^c g(beta) (1/4) sum_{j=1}^4
       sqrt(beta)/[1+(beta-1)v_j^2]^2 d beta.

Then rho is positive, normalized, smooth, and W4-invariant, but its covariance

    F(p)=integral_{S^3} rho(v)/[b+|p|^2+tau(p.v)^2] d sigma(v)

fails reflection positivity at every coordinate mirror.

Unlike a nonvanishing parameter edge, this taper removes the divergent endpoint coefficient. Failure is instead certified at an interior parameter resonance. For the mirror e1, choose tangential frequency k=sqrt(K)e2 with

    X=K/b=2401/7599,
    r=X/(1+X)=2401/10000,
    sqrt(r)=49/100.

The ordinary normal spectral density w(K,s)=-(1/pi) Im F(u^2=-K-s+i0) satisfies the exact bound

    lim_{s up to b} sqrt(b-s) w(K,s)
      < -1/[24 pi sqrt(b tau)] < 0.                 (A)

Thus it is negative on a nonempty ordinary open interval immediately below normal squared energy K+b. The bounded normal-kernel / positive-Hankel-to-Stieltjes argument in the preceding audited W4 result converts this into a genuine compact smooth negative reflection-positivity test. The proof below resolves both parameter singularities before any limit; no singular integral interchange is assumed.

A separate, simpler uniform-beta certificate and the general nonzero-edge-density lemma are frozen in UNIFORM_BETA_CERTIFICATE.md. The present result is stronger because g vanishes at both support endpoints. It also implies existence of C-infinity compactly supported beta mixing densities with the same failure (Section 7).

## 1. Endpoint coefficient and notation

Use the accepted fixed-beta exact decomposition. For each beta set

    lambda=(1-sqrt(beta))/(1+sqrt(beta)), A=1+lambda, C=1-lambda,
    N_lambda(X)=integral_0^1 (1-lambda t^2)/[(1+lambda t^2)^2+4lambda X t^2] dt,
    Z_lambda=atanh(sqrt(lambda))/sqrt(lambda).

The two regular direct terms and the singular selected-tangential-axis direct term become

    A C/[A^2+4lambda X] = sqrt(beta)/[1+(1-beta)X],
    2A/C=2/sqrt(beta),
    A C/[C^2-4lambda X] = sqrt(beta)/[(1+X)beta-X].

Let Bbar(X) denote the complete mixture endpoint real coefficient, in the normalization

    lim Re(F/h0)=Bbar(X)/8,
    h0=2/[sqrt(b+q)(sqrt(b+q)+sqrt(b+(1+tau)q))], q=u^2+K.

The calculation below establishes, rather than assumes, the formula

    Bbar(X)=D(X)+integral_a^c g(beta) [
        sqrt(beta)/[1+(1-beta)X]+2/sqrt(beta)
        +C N_lambda(X)+2 C Z_lambda+C I_lambda(X)] d beta,       (1)

where

    D(X)=PV integral_a^c g(beta) sqrt(beta)/[(1+X)beta-X] d beta,
    C I_lambda(X)=sqrt(beta)/(2u) log|(u+1)/(u-1)|,
    u=sqrt((1-beta)(1+X)).                                      (2)

The PV notation in (1) is only an after-the-fact identification of a real part of an exact finite-cut integral. It is not a limiting prescription inserted into the original mixture.

## 2. Resolve the direct beta resonance at finite cut

Fix s strictly between b/(1+tau) and b, and define

    v=sqrt(b-s)>0, d=(1+tau)s-b>0, m=i sqrt(d).

Use t=sqrt(beta), with t in [1/3,1/2]. The selected tangential-axis direct ratio has the exact finite-cut formula

    A T_lambda,e2/h0
      =(v+m)(v+m t)/[(v+m t)^2+(1-t^2)tau K].                  (3)

The denominator is

    D_s(t)=v^2+tau K+2iv sqrt(d)t-(d+tau K)t^2
          =-(d+tau K)(t-z_+)(t-z_-),

    z_+/-=[iv sqrt(d) +/- sqrt(tau K(v^2+d+tau K))]/(d+tau K).

Both roots lie strictly in the upper half plane. Let

    P_s(t)=2t g(t^2)(v+m)(v+m t),
    R_+/-=P_s(z_+/-)/D_s'(z_+/-),
    Q_s(t)=P_s(t)/D_s(t)-R_+/(t-z_+)-R_-/(t-z_-).

Since g(t^2) is a polynomial, Q_s is a polynomial. Polynomial division gives the exact ordinary integral

    J_s=integral_(1/3)^(1/2) Q_s(t) dt
       +sum_{j=+,-} R_j [Log(1/2-z_j)-Log(1/3-z_j)].            (4)

The logarithms are principal: their arguments stay in the lower half plane for every finite s, so no branch cut crosses the integration path. Formula (4) is an explicit algebraic/logarithmic antiderivative, including the physical residue contribution.

As s increases to b, z_+ tends to q0=49/100 and z_- tends to -q0. All polynomial coefficients and residues have finite limits, since the roots remain distinct. Because 1/3<q0<1/2, the positive-root logarithm contributes +i pi. In particular

    J_s -> D(X)+i pi (1-r)sqrt(r)g(r).                          (5)

The residue is strictly positive. It is retained in the full ratio. It does not enter the leading imaginary spectral coefficient, because sqrt(b-s)h0 tends to the purely negative-imaginary number -2i/sqrt(b tau).

The real part of (4) at the limit is exactly the PV in (1). This proves its meaning without dominating an unresolved simple pole or exchanging its boundary limit with the original beta integral.

## 3. Resolve the r-mixture logarithm and justify beta integration

The fixed-beta covariance also contains C integral_0^1 T_(lambda R^2),e2 dR. The earlier audited finite-cut antiderivative is

    integral_0^1 T_(lambda R^2),e2/h0 dR
      =[atanh(alpha h)+atanh(alpha^(-1)h)]/[h(alpha+alpha^(-1))],
    h=sqrt(lambda)(sqrt(d)+iv)/sqrt(d+v^2),
    alpha=sqrt(1+K/s)+sqrt(K/s).

Each atanh is defined by [Log(1+z)-Log(1-z)]/2 at its displayed first-quadrant argument. This formula is evaluated for finite s first. The real endpoint expression is exactly I in (2), on both sides of beta=r. For beta<r, the first atanh also contributes its positive imaginary boundary constant; that contribution is retained in the finite complex mixture limit.

Here is a direct domination argument for the beta limit. On the fixed compact beta interval all coefficients are bounded. Only 1-alpha h can approach zero. At v=0 it has one simple zero at beta=r. Its real part differs from the v=0 value by O(v^2), uniformly in beta, and the magnitude of its imaginary part is bounded above and below by positive constants times v. The derivative of its limiting real part at r is nonzero. Consequently, on a fixed neighborhood of r and for sufficiently small v,

    c1 (|beta-r|+v) <= |1-alpha h| <= c2 (|beta-r|+v)

for constants c1,c2>0; away from r it is uniformly bounded away from zero. The other logarithm arguments are also uniformly separated from zero. Principal arguments are bounded by pi. Therefore the absolute finite-cut expression is bounded, for almost every beta, by

    M [1+|log|beta-r||].                                       (6)

This is integrable on [a,c], and g is bounded. Dominated convergence applies after the exact R-antiderivative. The regular axes and N,Z terms converge uniformly. Equations (4)-(6) therefore establish a finite complex limit of F/h0 and all of (1)-(2).

## 4. Exact negative direct term

For this polynomial g, substitute t=sqrt(beta) into the real part of (4). Equivalently divide the degree-six polynomial

    2t^2(t^2-a)(c-t^2)

by t^2-q0^2, integrate the polynomial quotient, and use the two endpoint logarithms already fixed by (4). The exact result is

    D(X)=-5537314770471/976562500000
          +(103989335713263/97656250000000) log(247/4653).       (7)

The log argument satisfies 247/4653<1/16. Moreover log 2>2/3, for example from log 2=2 atanh(1/3)>2/3. Thus

    log(247/4653)<-4log 2<-8/3.

Exact rational comparison gives

    D(X)<-207759093070617/24414062500000 < -17/2.               (8)

The difference from -17/2 is -239561820617/24414062500000.

## 5. Exact upper bound on all positive terms

First, direct polynomial integration gives

    integral_a^c g(beta) 2/sqrt(beta) d beta=2976/625.

The remaining non-logarithmic terms obey the pointwise bounds

    sqrt(beta)/[1+(1-beta)X] <=5066/12533,
    C N_lambda(X)<=C N_lambda(0)=C/A=sqrt(beta)<=1/2,
    2 C Z_lambda<=14/9.

For N_lambda(0)=1/A, use the primitive t/(1+lambda t^2). For Z use

    Z=sum_{j>=0} lambda^j/(2j+1)
       <=1+lambda/[3(1-lambda)],
    C Z<=1-2lambda/3<=7/9.

For the logarithmic term, u_min>99/100 and u_max<11/10 on the beta interval, so

    sqrt(beta)/(2u)<25/99,
    (u+1)^2(1-r)<27/8,
    C I_lambda(X)<(25/99)log[(27/8)/|beta-r|].                 (9)

Put z=(r-a)/H=11609/12500 and h=1-z=891/12500. Rescaling beta=a+H t gives

    E_g log[(27/8)/|beta-r|]=log(243/10)+L(z),
    L(z)=-z^2(3-2z)log z-(1-z)^2(1+2z)log(1-z)
           +2z(1-z)+5/6.

Because 1/16<h<3/40, -log z<=h/(1-h), and log16<3,

    L(z)<3/37+81/1600+3/20+5/6
         =198031/177600 <9/8.

Also log(243/10)<13/4: the positive Taylor sum of exp(13/4) through degree 6 is 72428881/2949120>243/10. Therefore (9) integrates to

    E_g[C I_lambda(X)] < (25/99)(13/4+9/8)=875/792.

All terms other than D consequently have total less than

    2976/625+5066/12533+1/2+14/9+875/792
       =51654162611/6203835000 <25/3.                          (10)

Combining (8) and (10) proves Bbar(X)<-17/2+25/3=-1/6.

## 6. Spectral and RP consequence

The finite complex ratio limit proved above, together with

    sqrt(b-s)h0 -> -2i/sqrt(b tau),

gives

    lim sqrt(b-s)w(K,s)=Bbar(X)/[4pi sqrt(b tau)]
       <-1/[24pi sqrt(b tau)].

For every finite s sufficiently close to b, all exact finite-cut expressions are ordinary boundary values with nonzero logarithm arguments and no parameter path pole. Their beta integrals are continuous there. The strict limit therefore produces an ordinary negative spectral interval.

The positive angular density still gives the real-momentum bound 0<F(p)<=1/(b+|p|^2), bounded continuous exponentially decaying normal kernels, and continuous dependence on tangential frequency. The necessity and compact-test argument already fully proved in /workspace/shared/w4-angular-symmetrization-20261019/RESULT.md, Section 6, applies unchanged to this normalized positive mixture. In particular negative cut sign contradicts a necessary positive Stieltjes representation. Smooth time bumps and a finite tangential wave packet yield a legal compact test; contact additions cannot repair the sign. W4 symmetry transports the failure to each coordinate mirror.

## 7. True smooth beta bumps are also excluded in a nonempty family

The displayed g is continuous on the real line and vanishes linearly at its support edges. The angular density rho is nevertheless already C-infinity, since beta lies in a compact subinterval of (0,1) and differentiation in v is uniformly bounded there.

If a C-infinity beta mixing density is required, define

    g_n(beta)=Z_n^(-1) g(beta)
       exp(-1/[n(beta-a)(c-beta)]) on (a,c), and zero outside,
    Z_n=integral_a^c g(beta) exp(-1/[n(beta-a)(c-beta)]) d beta.

Each g_n is C-infinity on the real line, positive inside its support, and flat at both ends. For all sufficiently large n its W4 mixture also fails coordinate RP. This is an existence result, with no explicit n claimed.

A simple proof avoids every endpoint-functional continuity issue: the strict negative boundary value already proved for g implies Im F_g>0 at a nearby point strictly in the upper normal-squared-frequency half plane. At that fixed point the exact physical-sheet axial covariances are uniformly bounded and continuous in beta on [a,c]. Since g_n tends to g in L1 by dominated convergence and Z_n tends to 1, F_(g_n) tends to F_g there. Its imaginary part remains positive for all sufficiently large n, contradicting the necessary Stieltjes sign. Thus edge flattening of arbitrary finite order, or C-infinity flattening itself, is not a general recovery mechanism.

## Scope and genuine recovery condition

These results reject explicit uniform and doubly tapered parameter mixtures, a whole neighborhood of the tapered example, and all continuous compact mixing densities that remain positive at their largest-beta edge. They do not prove that every positive mixture supported away from beta=1 fails. A different broad or specially shaped mixing measure might still satisfy every necessary spectral sign, and would require a complete physical-sheet spectral audit rather than edge asymptotics alone.

This is a scalar Gaussian two-point result. It neither constructs nor rules out an interacting Yang-Mills theory or a mass gap. The earlier accepted one-mirror axial family remains untouched.

## Exact regression verification

The accompanying check_exact_identities.py passes 43 exact SymPy identities and rational comparisons. verify_regression_modes.py verifies matching ordinary and optimized output and requires a deliberately corrupted logarithm coefficient to fail in both modes. The successful-output SHA256 is 33ec3b284111c489ecc544418199ccbf0ab84ddff1c49a496f4874db1f11ce3f. These finite regressions support the algebra; they do not replace the analytic boundary-limit or sign proof above.

Reproduce with:

    python check_exact_identities.py
    python verify_regression_modes.py
    python -O verify_regression_modes.py
