# Uniform beta mixing still fails coordinate reflection positivity

19 October 2026. Local scalar Gaussian covariance research only. No remote edits or publication.

## Explicit result

Let b,tau>0 and let the ACG parameter beta have probability density 36/5 on [1/9,1/4]. Average the corresponding axial ACG densities equally over the four coordinate axes, then average over beta. The resulting positive, normalized, smooth W4-invariant angular density is not coordinate reflection positive.

An exact witness frequency is

    X=K/b=251001/748999,   sqrt(X/(1+X))=501/1000.

For the coordinate mirror e1 and tangential frequency sqrt(K)e2, the ordinary spectral density w_mix on q=-s+i0 obeys

    lim_{s up to b} sqrt(b-s) w_mix(K,s)
       < -53/[480 pi sqrt(b tau)] < 0.

Consequently a nonempty negative spectral interval exists immediately below normal squared energy K+b. The regularity/localization argument in the preceding W4 result then supplies a genuine compact smooth negative RP test. No Fourier delta or endpoint distribution is used as a test.

## Endpoint notation inherited from the audited fixed-beta result

Set lambda=(1-sqrt(beta))/(1+sqrt(beta)), A=1+lambda, C=1-lambda, and

    N_lambda(X)=integral_0^1 (1-lambda r^2)/[(1+lambda r^2)^2+4lambda X r^2] dr,
    Z_lambda=atanh(sqrt(lambda))/sqrt(lambda).

For X above Xc(beta)=beta/(1-beta), the audited exact r-antiderivative gives

    B_beta(X)=A C/[A^2+4lambda X] + A C/[C^2-4lambda X]
              +2 A/C + C N_lambda(X) + C I_lambda(X) +2 C Z_lambda,

    I_lambda(X)=1/[4sqrt(lambda)sqrt(1+X)]
       log[(A+2sqrt(lambda)sqrt(1+X))/(2sqrt(lambda)sqrt(1+X)-A)].

For a probability beta mixture, write Bbar(X)=E[B_beta(X)]. At fixed X>max Xc(beta), all finite-cut r-integrals are evaluated by that exact logarithmic antiderivative before taking s up to b. On the compact beta interval the logarithm arguments remain uniformly away from zero at this fixed X. The normalized finite-cut brackets F_beta/h0, not the raw covariances, and their endpoint limits are then uniformly bounded and continuous in beta at this fixed X; ordinary dominated convergence is legal. No uniformity is asserted as X subsequently approaches the threshold. Thus

    lim sqrt(b-s) w_mix(K,s)=Bbar(X)/[4pi sqrt(b tau)].

This is not an interchange across an unresolved parameter pole.

## Exact resonant-term integration

Put r=X/(1+X), q=sqrt(r)>1/2. In beta coordinates,

    A C/[C^2-4lambda X] = sqrt(beta)/[(1+X)beta-X].

Its uniform-beta mean is exactly

    D(X)=(36/5)(1-q^2)
       [1/3 + q log(((q-1/2)(q+1/3))/((q+1/2)(q-1/3)))].

This follows by setting t=sqrt(beta) and using the elementary primitive

    integral 2t^2/(t^2-q^2) dt
       =2t+q log((q-t)/(q+t)),    1/3<=t<=1/2<q.

At q=501/1000, the logarithm argument is 2503/503503<1/200. Since e<11/4 and (11/4)^5<200, its logarithm is <-5. Also (36/5)(1-q^2)>5. Hence

    D(X)<5[1/3-5(501/1000)]=-1303/120.

The elementary e<11/4 bound follows from e=1+1+1/2+sum_{n>=3}1/n!, with the remaining sum <=(1/6)sum_{j>=0}(1/4)^j=2/9.

## Uniform bound on every other term

For beta in [1/9,1/4], lambda in [1/3,1/2]:

    A C/[A^2+4lambda X]=sqrt(beta)/[1+(1-beta)X]<=1/2,
    2 A/C=2/sqrt(beta)<=6,
    C N_lambda(X)<=C<=2/3,
    2 C Z_lambda<=2.

For the last inequality use Z=integral_0^1 dr/(1-lambda r^2)<=1/C.

Write u=sqrt((1-beta)(1+X)). Then

    C I_lambda(X)=sqrt(beta)/(2u) log((u+1)/(u-1)).

For X>=1/3 this decreases with X, so bound it at X=1/3. There 1<=u<2, sqrt(beta)/(2u)<=1/4 and u^2-1=(4/3)(1/4-beta), giving

    C I_lambda(X) <= (1/4) log(27/[4(1/4-beta)]).

This integrable bound has uniform-beta mean

    (1/4)[1+log(243/5)] <5/4.

For the last strict inequality e^4>243/5 follows from summing its positive Taylor terms through degree 7 (the rational sum is 16319/315>243/5).

Therefore

    Bbar(X)< -1303/120+1/2+6+2/3+2+5/4
             = -53/120.

## Broader edge-positive statement and its exact limitation

Let the beta mixing density g be continuous on [beta0,beta1] contained in (0,1), nonnegative and normalized. If g(beta1)>0, then with X0=beta1/(1-beta1),

    Bbar(X0+delta)/log(delta)
      -> g(beta1) sqrt(beta1)(1-beta1)>0 as delta down to 0.

Thus Bbar tends to -infinity. The singular direct term is

    -g(beta)sqrt(beta)/[(1+X)(beta1-beta)+(1-beta1)delta].

All other non-logarithmic terms remain bounded. The exact-r logarithm is bounded after beta integration by an integrable constant plus |log(beta1-beta)|. For fixed delta>0, the endpoint limit is justified uniformly as above. Continuity gives the displayed logarithmic coefficient; an O(1) remainder is not asserted without a stronger modulus of continuity on g.

If g vanishes sufficiently rapidly at beta1, the inverse-edge integral can be finite and this divergent-edge argument alone does not determine the sign. No claim excluding all positive parameter mixtures is made here.
