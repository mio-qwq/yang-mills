#!/usr/bin/env python3
"""Run good and intentionally corrupted checks in ordinary/optimized modes."""
import hashlib
import json
from pathlib import Path
import subprocess
import sys
script=Path(__file__).with_name('check_exact_identities.py')
outputs=[]
for flags in ([],['-O']):
    cmd=[sys.executable,*flags,str(script)]
    good=subprocess.run(cmd,capture_output=True,text=True)
    if good.returncode != 0:
        raise RuntimeError(f'Good checks failed: {cmd}\n{good.stderr}')
    outputs.append(good.stdout)
    bad=subprocess.run([*cmd,'--negative-control'],capture_output=True,text=True)
    if bad.returncode == 0 or 'FAIL direct_integral_log_coefficient' not in bad.stderr:
        raise RuntimeError(f'Negative control did not fail as intended: {cmd}\n{bad.stderr}')
if outputs[0] != outputs[1]:
    raise RuntimeError('Ordinary and optimized successful outputs differ')
print(json.dumps({'status':'PASS','ordinary_and_optimized_match':True,'both_negative_controls_failed':True,'checks':json.loads(outputs[0])['exact_checks'],'output_sha256':hashlib.sha256(outputs[0].encode()).hexdigest()},indent=2))
