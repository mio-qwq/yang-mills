# Root review, 19 October 2026

Scope: positive scalar Gaussian angular covariance mixtures only. No interacting Yang–Mills conclusion, no general exclusion of all parameter measures.

I independently derived the edge-positive mixture obstruction: in lambda coordinates, Xc(lambda) is strictly decreasing. Taking X just above Xc at the smallest support lambda turns the direct rational term into a negative logarithmic divergence after mixing with a nonzero edge density. The remaining already-integrated logarithmic term stays integrable. The boundary limit must be taken for each fixed positive threshold gap.

I read the uniform and tapered certificates. For the tapered certificate I independently divided 2 t^2 g(t^2)(1-q^2) by t^2-q^2 at q=49/100 and recovered exactly the stated polynomial integral -5537314770471/976562500000 and log coefficient 103989335713263/97656250000000. The total positive-term rational bound is 51654162611/6203835000, strictly below 25/3.

The finite-cut direct integral retains its complex residue before the limit. The normalized exact-R integral has only a logarithmic singularity with an integrable beta majorant. Raw covariances themselves are not uniformly bounded at the endpoint. The smooth-bump extension uses continuity at a fixed strictly upper-half-plane point and does not assume continuity of an endpoint principal-value functional in L1.

Independent reviewer is checking the remaining analytic and arithmetic details. Final acceptance and frozen manifest should refer to that audit; this note alone is not a completion receipt. No repository change or publication was performed by this review.
