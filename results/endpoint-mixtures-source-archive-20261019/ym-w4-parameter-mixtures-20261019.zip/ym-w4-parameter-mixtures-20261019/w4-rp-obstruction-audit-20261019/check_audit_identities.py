#!/usr/bin/env python3
"""Exact independent algebra checks; explicit failures remain active with python -O."""
import argparse
import json
from fractions import Fraction as Q
import sympy as s

parser=argparse.ArgumentParser()
parser.add_argument('--negative-control', action='store_true')
args=parser.parse_args()
checks=[]

def identity(name, lhs, rhs):
    difference=s.factor(lhs-rhs)
    if difference != 0:
        raise SystemExit('FAIL '+name+': '+str(difference))
    checks.append(name)

def condition(name, value):
    if not value:
        raise SystemExit('FAIL '+name)
    checks.append(name)

eta,r,h,alpha=s.symbols('eta r h alpha', nonzero=True)
delta=1/alpha
x=(alpha-delta)**2/4
D=(1-h*h*r*r)**2-4*h*h*x*r*r
identity('cut denominator factorization',D,(1-alpha**2*h*h*r*r)*(1-delta**2*h*h*r*r))
right=(alpha/(alpha+delta))/(1-alpha**2*h*h*r*r)+(delta/(alpha+delta))/(1-delta**2*h*h*r*r)
if args.negative_control:
    right=right+1
identity('normalized exact partial fractions',(1-h*h*r*r)/D,right)
antiderivative=(s.atanh(alpha*h*r)+s.atanh(delta*h*r))/(h*(alpha+delta))
identity('atanh antiderivative',s.diff(antiderivative,r),(1-h*h*r*r)/D)

R,S,tau,K=s.symbols('R S tau K', nonzero=True)
A=1+eta; C=1-eta
q=(S*S-R*R)/tau
y=(R-S)/(R+S)
h0=2/(R*(R+S))
def G(t_squared):
    return (1+eta*y)/((1+eta*y)**2-4*eta*y*t_squared)
identity('transverse continuation',h0*G(K/q),2*(A+C*S/R)/((A*R+C*S)**2+4*eta*tau*K))
identity('axial continuation',h0*G((q-K)/q),2*(A+C*S/R)/((A*S+C*R)**2-4*eta*tau*K))
identity('unused-axis continuation',h0*G(0),2/(R*(A*R+C*S)))

lam,X,dX=s.symbols('lam X dX', nonzero=True)
A=1+lam; C=1-lam
Xc=C*C/(4*lam)
identity('endpoint threshold identity',1+Xc,A*A/(4*lam))
identity('simple pole coefficient',A*C/(2*(C*C-4*lam*(Xc+dX))),-A*C/(8*lam*dX))
identity('other-axis endpoint denominator',C*C+4*lam*(1+X),A*A+4*lam*X)
identity('mixture weights sum one',A/2+C/2,1)

l=Q(1,3); a=Q(101,100); d=Q(100,303)
X=(a-d)**2/(4*l)
condition('certificate product',a*d==l)
condition('certificate exact X',X==Q(424483609,1224120000))
condition('certificate exact threshold gap',X-Q(1,3)==Q(5481203,408040000))
condition('certificate positive gap',X>Q(1,3))
condition('certificate denominator identity',(1-a*a)*(1-d*d)==(1-l)**2-4*l*X)
top=Q(4,9)/((1-a*a)*(1-d*d))
condition('top term strict rational bound',top<-Q(40000,1809))
condition('atanh log ratio first',(a+1)/(a-1)==201)
condition('atanh log ratio second',(1+d)/(1-d)==Q(403,203))
condition('atanh denominator bound',a+d>1)
from math import factorial
exp6_lower=sum((Q(6)**j/Q(factorial(j)) for j in range(7)),Q(0))
condition('log 201 less than 6 via rational Taylor bound',exp6_lower==Q(1223,5) and exp6_lower>201)
condition('log second ratio less than 1',Q(403,203)<2)
bound=-Q(40000,1809)+Q(7,6)+Q(9,2)
condition('exact negative total bound',bound==-Q(29749,1809) and bound<0)
print(json.dumps({'status':'PASS','checks':checks,'count':len(checks),'X':str(X),'X_minus_Xc':str(X-Q(1,3)),'Bsum_strict_upper_bound':str(bound)},indent=2))
