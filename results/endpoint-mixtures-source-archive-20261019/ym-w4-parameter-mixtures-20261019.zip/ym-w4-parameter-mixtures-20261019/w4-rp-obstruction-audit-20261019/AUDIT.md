# Independent audit: W4 symmetrization destroys coordinate reflection positivity

19 October 2026. Local mathematical audit. No repository, PR, release, or frozen result was changed.

## Verdict and scope

The proposed obstruction is valid for every b>0, tau>0 and 0<beta<1. Let

    rho_bar(v) = (1/4) sum_(j=1)^4 sqrt(beta)/[1+(beta-1)v_j^2]^2,
    F_bar(p) = integral_(S^3) rho_bar(v)/[b+|p|^2+tau(p.v)^2] d sigma(v).

Although rho_bar is positive, normalized, smooth, and invariant under all coordinate permutations and sign changes, its covariance fails reflection positivity at every coordinate mirror. In particular the equal W4 orbit average of the accepted one-mirror-positive axial family does not furnish a coordinate-RP example.

The proof below fixes mirror e1, takes tangential momentum k=sqrt(K)e2, and exhibits a negative ordinary normal spectral density on an open interval. The analytic parameter integral is evaluated exactly before taking the endpoint limit: no interchange across an interior parameter pole is used. The negative density is then converted, by a fully justified necessary Stieltjes condition and localization, into existence of a legal smooth compact positive-half-space negative test.

This only excludes this symmetrized family. It is not a classification of all smooth W4-invariant densities, nor a gauge-theory, continuum reconstruction, or Yang-Mills mass-gap conclusion. The cases beta>1, b=0, and tau=0 are not included. At beta=1 the density is constant and the obstruction disappears.

Source family: the accepted local result `infinite-angular-candidates-20261019/RESULT.md`. This audit independently checks the new symmetrization argument.

## 1. Normalization and common notation

Put

    lambda=(1-sqrt(beta))/(1+sqrt(beta)),
    A=1+lambda, C=1-lambda, 0<lambda<1,
    X=K/b, Xc=C^2/(4lambda).

For an axial direction n, the accepted exact mixture is

    F_n=(A/2)T_(lambda,n)+(C/2) integral_0^1 T_(lambda r^2,n) dr,
    T_(eta,n)=h0 G_(eta y)((p.n)/sqrt(q)),
    G_w(t)=(1+w)/[(1+w)^2-4wt^2],
    q=u^2+K,
    a=b+q, c=b+(1+tau)q,
    y=(sqrt(a)-sqrt(c))/(sqrt(a)+sqrt(c)),
    h0=2/[sqrt(a)(sqrt(a)+sqrt(c))].

The principal square roots are kept separately. The outer A,C always refer to lambda, not eta. The outer weights are positive and sum to one.

For real p this follows from absolutely convergent harmonic expansions. It consequently fixes the analytic germ used below; the closed formulas continue that same germ.

## 2. Physical-sheet continuation for the three axis types

Write A_eta=1+eta, C_eta=1-eta. For p=u e1+sqrt(K)e2,

    T_(eta,e1) = 2[A_eta+C_eta sqrt(c)/sqrt(a)]
      /{[A_eta sqrt(c)+C_eta sqrt(a)]^2-4eta tau K},

    T_(eta,e2) = 2[A_eta+C_eta sqrt(c)/sqrt(a)]
      /{[A_eta sqrt(a)+C_eta sqrt(c)]^2+4eta tau K},

    T_(eta,e3)=T_(eta,e4)
      =2/{sqrt(a)[A_eta sqrt(a)+C_eta sqrt(c)]}.

If Im q>0, both principal roots have strictly positive real and imaginary parts. A positive linear combination therefore lies in the first quadrant, and its square has strictly positive imaginary part. None of the displayed denominators can vanish there. The same statement holds in the lower half-plane by conjugation. For eta in the compact interval [0,lambda], the formulas and their integrals are locally uniformly holomorphic in the upper half-plane.

Thus there is no physical-sheet off-axis singularity that could prevent comparison with a putative Stieltjes continuation. Real-axis atoms or additional real cuts elsewhere are irrelevant to the local negative-cut obstruction, and no assertion that they are absent is needed.

## 3. Exact finite-cut parameter integral

On the upper rim q=-s+i0, where b/(1+tau)<s<b, write

    epsilon=b-s>0,
    d=(1+tau)s-b>0,
    x_s=K/s,
    alpha=sqrt(1+x_s)+sqrt(x_s),
    delta=sqrt(1+x_s)-sqrt(x_s)=1/alpha,
    h=sqrt(lambda)(sqrt(d)+i sqrt(epsilon))/sqrt(d+epsilon).

Then h is strictly in the first quadrant, h^2=-lambda y, and for the transverse e2 axis,

    T_(lambda r^2,e2)/h0
      =(1-h^2 r^2)/[(1-h^2 r^2)^2-4h^2 x_s r^2].

The exact factorization and partial fractions are

    (1-h^2r^2)^2-4h^2 x_s r^2
      =(1-alpha^2 h^2r^2)(1-delta^2 h^2r^2),

    (1-h^2r^2)/[(1-alpha^2 h^2r^2)(1-delta^2 h^2r^2)]
      =alpha/(alpha+delta) * 1/(1-alpha^2 h^2r^2)
       +delta/(alpha+delta) * 1/(1-delta^2 h^2r^2).

There is no pole on 0<=r<=1 because h is strictly in the first quadrant. Integrating the two elementary factors gives the exact formula

    integral_0^1 [T_(lambda r^2,e2)/h0] dr
      =[atanh(alpha h)+atanh(delta h)]/[h(alpha+delta)].             (1)

Here atanh(z) means [Log(1+z)-Log(1-z)]/2 using principal logarithms. For z in the upper half-plane this is the continuation from z=0 in the upper half-plane, with derivative 1/(1-z^2). In particular the antiderivative along r z starts at zero and has no unaccounted logarithm constant.

Formula (1) is valid at every interior cut point, before taking epsilon to zero. This is the key repair to an otherwise unjustified direct endpoint substitution inside the r integral.

## 4. Endpoint limit and exact real part

Fix X>Xc first. Only after fixing this strictly positive gap let epsilon decrease to zero. Then

    h -> sqrt(lambda) from the upper half-plane,
    alpha -> alpha_X=sqrt(1+X)+sqrt(X),
    delta -> delta_X=1/alpha_X,
    sqrt(lambda) alpha_X>1,
    0<sqrt(lambda) delta_X<1.

The principal logarithms give

    atanh(a+i0)=(1/2)log((a+1)/(a-1))+i pi/2,   a>1.

Consequently (1) tends to

    I(X) + i pi/[4 sqrt(lambda) sqrt(1+X)],                         (2)

where

    I(X) = PV integral_0^1 (1-lambda r^2)
                  /[(1-lambda r^2)^2-4lambda Xr^2] dr
         = [4 sqrt(lambda) sqrt(1+X)]^(-1)
             log[(A+2sqrt(lambda)sqrt(1+X))
                   /(2sqrt(lambda)sqrt(1+X)-A)].                  (3)

The PV in (3) is merely a name for the real part already derived from the exact antiderivative. No distributional interchange is used. The equality to the PV integral also follows directly by the real partial fractions above and the elementary PV antiderivative.

The top eta=lambda term has the ordinary endpoint limit

    T_(lambda,e2)/h0 -> C/(C^2-4lambda X).

Therefore the real part of the complete e2-axis normalized limit is

    B2(X)=AC/[2(C^2-4lambda X)] +(C/2)I(X)
         =-AC/[8lambda(X-Xc)]+(C/2)I(X).                           (4)

As X decreases to Xc from above,

    I(X)=(1/(2A))log(A^2/[lambda(X-Xc)])+O((X-Xc)log(1/(X-Xc))).

Thus B2 has a negative simple-pole divergence that dominates its positive logarithm. This is a sequential argument: choose a finite X>Xc for which the coefficient is negative, then choose an interior cut point s sufficiently close to b. No estimate uniform in both small variables is assumed.

## 5. Other axes are uniformly bounded and positive

At q=-b the limiting squared zonal arguments are 1+X for e1 and zero for e3,e4. For real t and 0<=eta<=lambda,

    G_(-eta)(t)=(1-eta)/[(1-eta)^2+4eta t^2],
    0<G_(-eta)(t)<=1/(1-eta)<=1/C.

The limits are nonsingular, so ordinary dominated convergence in the parameter integral applies to these three axes. Let their complete normalized limits be B1(X), B0, B0. The positive mixture weights sum to one, giving

    0<B1(X)<=1/C, 0<B0<=1/C.

In particular all three terms remain bounded as X decreases to Xc. Explicitly,

    B1=(A/2) C/(A^2+4lambda X)
        +(C/2) integral_0^1 (1-lambda r^2)
          /[(1+lambda r^2)^2+4lambda r^2 X] dr,

    B0=A/(2C)+[C/(2sqrt(lambda))]atanh(sqrt(lambda)).

Hence

    Bsum(X)=B1(X)+B2(X)+2B0 -> -infinity  as X decreases to Xc+.

For every fixed 0<lambda<1 there is a finite X>Xc for which Bsum(X)<0.

## 6. Negative ordinary cut density

Since

    sqrt(epsilon) h0 -> -2i/sqrt(b tau),

and the normalized transverse mixture has the finite complex limit (2),

    lim_(s->b-) sqrt(b-s) [-Im F_bar(q=-s+i0;K)/pi]
       =Bsum(X)/[2pi sqrt(b tau)].                                (5)

The imaginary part in (2) affects only a lower-order term in (5). It cannot compensate the negative leading coefficient. Fixing X with Bsum(X)<0 proves strict negativity for all s in a sufficiently short open interval immediately below b. Every such point is an ordinary interior cut point with a finite, continuous boundary value.

The normal variable is z=u^2=q-K. Thus the same sign occurs at z=-(K+s)+i0, at positive normal squared energy K+s>0. In particular it cannot be dismissed as an unphysical negative-energy test.

## 7. A compact exact certificate at beta=1/4

Take

    lambda=1/3, A=4/3, C=2/3,
    a_*=101/100, d_*=100/303, a_*d_*=lambda,
    X=(a_*-d_*)^2/(4lambda)=424483609/1224120000,
    X-Xc=5481203/408040000>0.

Then sqrt(lambda)alpha_X=a_*, sqrt(lambda)delta_X=d_*. The top term in B2 obeys

    (4/9)/[(1-a_*^2)(1-d_*^2)] < -40000/1809.

Furthermore

    I(X)=[atanh_PV(a_*)+atanh(d_*)]/(a_*+d_*),
    atanh_PV(a_*)=(1/2)log(201)<3,
    atanh(d_*)=(1/2)log(403/203)<1/2,
    a_*+d_*>1.

Therefore I(X)<7/2, and its contribution (C/2)I(X) is less than 7/6. Each of the other three axes is at most 3/2. Hence

    Bsum(X)<-40000/1809+7/6+9/2=-29749/1809<0.                     (6)

No decimal computation is required. For the logarithm bounds, e^6 exceeds its sixth-order Taylor partial sum 1223/5>201, while 403/203<2<e. These are exact strict inequalities with positive Taylor remainders.

This certificate holds for every b>0 and tau>0, with K=bX. The size of the final s interval may depend on b and tau, as allowed.

## 8. Why negative cut sign implies a legal negative RP test

This section checks the regularity and localization hypotheses behind the necessary Stieltjes condition. It does not assume the existence or finite variation of a signed spectral measure for the symmetrized covariance.

### 8.1 Bounded continuous normal kernels

For real momenta, positivity and normalization of rho_bar give

    0<F_bar(u,k)<=1/(b+u^2+|k|^2).

Each normal slice is even and L1 in u. Its inverse Fourier transform H_k(T) is bounded, continuous, real and even. One can also invert each angular resolvent directly. For v in S3 set

    a_v=1+tau v1^2,
    c_v=tau v1(k.v_tan),
    d_v=b+K+tau(k.v_tan)^2,
    Delta_v=a_v d_v-c_v^2=a_v(b+K)+tau(k.v_tan)^2,
    m_v=sqrt(Delta_v)/a_v.

The inverse transform is

    exp(-m_v|T|) exp(-i c_v T/a_v)/(2sqrt(Delta_v)).

Since m_v>=sqrt((b+K)/(1+tau)), averaging gives the locally uniform estimate

    |H_k(T)| <= exp(-sqrt((b+K)/(1+tau))|T|)/(2sqrt(b+K)).

In particular H_k is integrable in T, tends to zero, and varies continuously with k, locally uniformly in bounded T intervals. Invariance under v1 sign reversal makes it real and even.

### 8.2 Full RP implies fixed-k Hankel positivity

For product tests f(t,x)=h(t)g(x),

    Q(f)=(2pi)^(-3) integral |g_hat(k)|^2 Q_k(h) dk,
    Q_k(h)=integral integral conjugate(h(t)) H_k(t+s)h(s) dt ds.

For every h in Cc-infinity((0,infinity)), Q_k(h) is continuous in k by the preceding bounds. If Q_k(h)<0 at one k0, choose a compact smooth tangential wave packet

    g_L(x)=L^(-3/2)chi(x/L)exp(i k0.x),  chi in Cc-infinity(R3).

Its normalized squared Fourier transform concentrates at k0 as L increases. Boundedness and continuity show Q(h g_L)<0 for some finite L. Thus full RP forces Q_k(h)>=0 at every fixed k, including the selected k=sqrt(K)e2. This does not infer pointwise positivity from a merely almost-everywhere statement without continuity.

Approximating finitely many positive-time point masses by smooth bumps shows that full RP forces every matrix [H_k(t_i+t_j)] to be positive semidefinite.

### 8.3 A bounded Hankel-positive kernel has the needed Stieltjes continuation

For completeness, here is a short bounded-kernel proof. Make formal vectors e_t, t>0, with inner products H_k(t+s). Positive shifts T_a e_t=e_(t+a) are symmetric. For a finite vector xi let b_j=||T_a^j xi||^2. If xi=sum_i c_i e_(t_i), then b_j=sum_(i,l) conjugate(c_i)c_l H_k(t_i+t_l+2ja), so b_j<=sup|H_k| (sum_i |c_i|)^2 uniformly in j. Symmetry and Cauchy-Schwarz give

    b_j^2<=b_0 b_(2j).

Iteration gives b_1<=b_0; the same inequality handles null vectors. Therefore the shifts descend to self-adjoint contractions on the Hilbert completion. Moreover T_a=T_(a/2)^2 makes them positive. Kernel continuity supplies strong continuity, so T_a=exp(-aH) for a nonnegative self-adjoint generator H.

Continuity at zero makes e_t a Cauchy family as t decreases to zero:

    ||e_t-e_s||^2=H_k(2t)+H_k(2s)-2H_k(t+s) -> 0.

Let its limit be e_0. The spectral theorem yields the finite positive measure sigma_k for which

    H_k(T)=integral_[0,infinity) exp(-mT) sigma_k(dm), T>=0.

The exponential estimate in 8.1 forces sigma_k to be supported in m>=sqrt((b+K)/(1+tau)); in particular there is no zero-mass atom. Fourier inversion, justified by this lower bound and finite sigma_k, gives

    F_k(z)=integral 2m/(m^2+z) sigma_k(dm).

For real z=u^2>0 this agrees with the original slice. It is holomorphic on the upper z half-plane and has Im F_k(z)<=0 there. The original bound z F_k(z)<=1 also implies, by monotone convergence, that the pushed Stieltjes measure has total mass at most one. There is no contact addition: the actual inverse transform is continuous on the entire real T axis and agrees with the Laplace representation there.

### 8.4 Contradiction and compact tests

Section 2 supplies a holomorphic physical continuation in the upper z half-plane that agrees with the original germ for z>0. Identity of analytic continuations forces it to equal the Stieltjes function if RP held. But (5) yields Im F_k(z+i0)>0 at an ordinary interior point of the negative axis. Boundary continuity makes Im F_k positive at some nearby point strictly in the upper half-plane, contradicting the Stieltjes sign.

Therefore the fixed-k Hankel kernel is not positive semidefinite. A finite matrix has a strictly negative quadratic form at some positive times. Replace its time deltas by sufficiently narrow smooth compact bumps, whose supports stay strictly above zero; continuity preserves the negative sign. Then use the finite-L tangential wave packet of 8.2. The resulting f is a genuine Cc-infinity function supported in x1>0 and has Q(f)<0. If a real test is desired, the real and imaginary parts split the real symmetric reflected form, so at least one is negative.

This is an existence proof of a legal witness, not a claim to have computed its times or coefficients. Neither a single Fourier delta nor an endpoint distribution is being presented as a legal test. Contact distributions at the spacetime origin vanish on these strictly separated reflected supports and cannot repair the failure.

## 9. Final audit checklist

- The normalized angular mixture and the physical analytic germ are the accepted ones.
- The transverse continuation has no hidden upper-half-plane singularity.
- The eta integral is evaluated exactly at finite epsilon, with branches specified.
- The interior-parameter-pole limit has its finite imaginary term included.
- Only the real normalized limit controls the leading cut density.
- The simple-pole versus logarithm comparison is sequential, not an unproved joint asymptotic.
- The other three axis contributions are uniformly bounded and positive.
- An exact rational beta=1/4 coefficient certificate is independently verified.
- Slice continuity, boundedness, exponential decay, pointwise localization, and the positive spectral necessity are checked.
- Failure yields a legal smooth compact test; coordinate symmetry transports it to all four coordinate mirrors.
- No conclusion about diagonal RP separately, arbitrary W4 densities, or Yang-Mills theory is inferred.

The accompanying `check_audit_identities.py` checks exact algebra and the rational certificate. Its negative control and optimized-Python regression use explicit failures rather than assert statements. These finite checks complement, rather than replace, the analytic argument above.
