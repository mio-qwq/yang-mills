#!/usr/bin/env python3
"""Build a deterministic archive from the verified text-only inventory."""
from pathlib import Path
import hashlib,sys,zipfile
ROOT=Path(__file__).resolve().parent
from verify_bundle import check_integrity
check_integrity(ROOT)
target=Path(sys.argv[1]).resolve() if len(sys.argv)>1 else ROOT.with_suffix('.zip')
if target==ROOT or ROOT in target.parents: raise RuntimeError('Archive must be outside the source directory')
with zipfile.ZipFile(target,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for p in sorted(ROOT.rglob('*')):
        if not p.is_file():continue
        name=p.relative_to(ROOT).as_posix()
        info=zipfile.ZipInfo(name,(2026,10,19,16,7,0));info.create_system=3
        info.external_attr=0o100644<<16;info.compress_type=zipfile.ZIP_DEFLATED
        z.writestr(info,p.read_bytes(),compress_type=zipfile.ZIP_DEFLATED,compresslevel=9)
print(hashlib.sha256(target.read_bytes()).hexdigest())
