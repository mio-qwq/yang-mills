#!/usr/bin/env python3
from itertools import product, combinations
from pathlib import Path
import json

cases=[];adjacency=0
for d in (2,3,4):
  for W in range(1,6):
    L=2*W+1
    for t in (-3,-2,0,1,4):
      by_min={pair:0 for pair in combinations(range(d),2)}
      by_tail={pair:0 for pair in combinations(range(d),2)}
      for k in range(t-2,t+3):
        for v in range(-W,W+1):
          if (k+v)%2:continue
          for z in product(range(-W,W+1),repeat=d-2):
            x=((k+v)//2,(v-k)//2)+z
            for i,j in combinations(range(d),2):
              ei=tuple(int(a==i) for a in range(d));ej=tuple(int(a==j) for a in range(d))
              add=lambda a,b:tuple(x+y for x,y in zip(a,b))
              p=[x,add(x,ei),add(add(x,ei),ej),add(x,ej)]
              if not all(abs(y[0]+y[1])<=W and all(abs(y[a])<=W for a in range(2,d)) for y in p):continue
              # Positively oriented physical edges, independent of loop traversal.
              es=[(x,add(x,ei)),(x,add(x,ej)),(add(x,ei),add(add(x,ei),ej)),(add(x,ej),add(add(x,ei),ej))]
              h=lambda y:y[0]-y[1]
              mins=[min(h(a),h(b)) for a,b in es]
              tails=[h(a) for a,b in es]
              assert max(mins)-min(mins)<=1
              # Two-level blocks put the audited boundary between levels t-1 and t.
              assert max((q-t)//2 for q in tails)-min((q-t)//2 for q in tails)<=1
              adjacency+=1
              if min(mins)<t<=max(mins):by_min[(i,j)]+=1
              if min(tails)<t<=max(tails):by_tail[(i,j)]+=1
      expected_min_01=(W-1+int((t-W)%2==0))*L**(d-2)
      expected_tail_01=(2*W-1)*L**(d-2)
      assert by_min[(0,1)]==expected_min_01,(d,W,t,by_min)
      assert by_tail[(0,1)]==expected_tail_01,(d,W,t,by_tail)
      for j in range(2,d):
        expected=2*W*W*L**(d-3)
        for i in (0,1):assert by_min[(i,j)]==by_tail[(i,j)]==expected
      for i,j in combinations(range(2,d),2):assert by_min[(i,j)]==by_tail[(i,j)]==0
      expected_min=expected_min_01+(4*(d-2)*W*W*L**(d-3) if d>2 else 0)
      expected_tail=expected_tail_01+(4*(d-2)*W*W*L**(d-3) if d>2 else 0)
      assert sum(by_min.values())==expected_min
      assert sum(by_tail.values())==expected_tail
      cases.append({'d':d,'W':W,'boundary_t':t,'minimum_height_count':expected_min,'two_level_tail_count':expected_tail})
report={'status':'pass','cases':len(cases),'plaquette_adjacency_checks':adjacency,'dimensions':[2,3,4],'widths':[1,2,3,4,5],'offsets':[-3,-2,0,1,4],'all_cases':cases}
Path(__file__).with_name('diagonal_count_results.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({k:v for k,v in report.items() if k!='all_cases'},indent=2))
