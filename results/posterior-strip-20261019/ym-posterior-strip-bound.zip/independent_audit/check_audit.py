#!/usr/bin/env python3
"""Exact finite-state constants and independent lattice-locality checks.
These tests supplement the proof; they do not numerically integrate Wilson theory.
"""
from fractions import Fraction as F
from itertools import product, combinations
from random import Random
import json
from pathlib import Path

rng=Random(202610191600)

def normalize(a):
    s=sum(a)
    assert s>0
    return [x/s for x in a]

def tv(p,q):return sum(abs(x-y) for x,y in zip(p,q))/2

def push(p,Q):return [sum(p[y]*Q[y][x] for y in range(len(p))) for x in range(len(Q[0]))]

# The elementary sharp ratio lemma is checked algebraically at its extremizers.
ratio_sharp=0
for s in range(1,51):
    q=[F(1,s+1),F(s,s+1)]
    p=q[::-1]
    assert tv(p,q)==F(s-1,s+1)
    if s>1:
        ratios=[p[i]/q[i] for i in range(2)]
        assert max(ratios)/min(ratios)==s*s
    ratio_sharp+=1

chains=0
kernels=0
collar_exponent=0
for case in range(160):
    N=rng.randint(1,5)
    ns=[rng.randint(2,4) for _ in range(N+1)]
    hs=[]
    for n in ns:
        exponents=[rng.randint(-160,160) for _ in range(n)]
        collar_exponent=max(collar_exponent,*map(abs,exponents))
        hs.append([F(2)**j for j in exponents])
    ks=[]; taus=[]
    for i in range(N):
        maxk=rng.randint(1,9)
        k=[[F(rng.randint(1,maxk)) for y in range(ns[i+1])] for x in range(ns[i])]
        ks.append(k)
        lo=min(map(min,k)); hi=max(map(max,k))
        taus.append((hi-lo)/(hi+lo))
    ls=[hs[0]]; Qs=[]
    for i,k in enumerate(ks):
        denominators=[sum(ls[i][x]*k[x][y] for x in range(ns[i])) for y in range(ns[i+1])]
        Q=[[ls[i][x]*k[x][y]/denominators[y] for x in range(ns[i])] for y in range(ns[i+1])]
        actual=max(tv(p,q) for p in Q for q in Q)
        assert actual<=taus[i]
        Qs.append(Q)
        ls.append([hs[i+1][y]*denominators[y] for y in range(ns[i+1])])
        kernels+=1
    # Hard terminal choices are allowed, including mutually singular laws.
    mu=[F(i==0) for i in range(ns[N])]
    nu=[F(i==ns[N]-1) for i in range(ns[N])]
    contraction=F(1)
    for i in reversed(range(N)):
        mu=push(mu,Qs[i]); nu=push(nu,Qs[i]); contraction*=taus[i]
        assert tv(mu,nu)<=contraction
        # Common-prefix extension preserves exactly the x_i-marginal TV.
        prefixP={():F(1)}
        prefixQ={():F(1)}
        # Enumerate only short prefixes to control test size.
        if i<=2:
            pp=[]; qq=[]
            for path in product(*(range(ns[j]) for j in range(i+1))):
                common=F(1)
                for j in range(i):common*=Qs[j][path[j+1]][path[j]]
                pp.append(mu[path[i]]*common);qq.append(nu[path[i]]*common)
            assert sum(pp)==sum(qq)==1
            assert tv(pp,qq)==tv(mu,nu)
            # Complex unit-circle test; squared expectation bound is exact.
            re=im=F(0)
            for index,(p,q) in enumerate(zip(pp,qq)):
                a=(index%5)-2;b=((index//5)%3)+1
                u=F(a*a-b*b,a*a+b*b);v=F(2*a*b,a*a+b*b)
                assert u*u+v*v==1
                re+=(p-q)*u;im+=(p-q)*v
            assert re*re+im*im<=4*contraction*contraction
    chains+=1

# Link ownership by minimum endpoint normal height is nearest-neighbor
# for every coordinate or integer signed-diagonal normal.
geometry_cases=0;plaquette_checks=0;diagonal_collar_checks=0
for d in (2,3,4):
    normals=[]
    for i in range(d):
        a=[0]*d;a[i]=1;normals.append(tuple(a))
    for i,j in combinations(range(d),2):
        for s in (-1,1):
            a=[0]*d;a[i]=1;a[j]=s;normals.append(tuple(a))
    unit=[tuple(int(i==j) for i in range(d)) for j in range(d)]
    add=lambda x,y:tuple(a+b for a,b in zip(x,y))
    for normal in normals:
        height=lambda x:sum(a*b for a,b in zip(normal,x))
        for x in product(range(-2,3),repeat=d):
            for i,j in combinations(range(d),2):
                p=[x,add(x,unit[i]),add(add(x,unit[i]),unit[j]),add(x,unit[j])]
                edges=[(p[k],p[(k+1)%4]) for k in range(4)]
                levels=[min(height(u),height(v)) for u,v in edges]
                assert max(levels)-min(levels)<=1
                plaquette_checks+=1
                if sum(abs(a) for a in normal)==2 and min(map(height,p))<0<max(map(height,p)):
                    plus_edges=[(u,v) for u,v in edges if min(height(u),height(v))>=0]
                    assert len(plus_edges)==2
                    assert all(min(height(u),height(v))==0 for u,v in plus_edges)
                    diagonal_collar_checks+=1
        geometry_cases+=1

# Coordinate temporal plaquette count equals the transverse edge count exactly.
coordinate_count_cases=0
for D in (1,2,3):
    for L in product(range(1,5),repeat=D):
        V=list(product(*(range(n+1) for n in L)))
        edge_count=sum(1 for x in V for j in range(D) if x[j]<L[j])
        formula=sum(L[j]*__import__('math').prod(L[k]+1 for k in range(D) if k!=j) for j in range(D))
        assert edge_count==formula
        coordinate_count_cases+=1

# Common-collar assumption cannot be dropped: zero interactions imply tau=0,
# but distinct initial factors leave nonzero discrepancy at the left endpoint.
p=normalize([F(9),F(1)]);q=normalize([F(1),F(9)])
assert tv(p,q)==F(4,5)

report={"status":"pass","sharp_ratio_extremizers":ratio_sharp,"exact_rational_chains":chains,"reverse_kernels_checked":kernels,"one_block_weight_power_of_two_exponents_up_to":collar_exponent,"normal_geometry_cases":geometry_cases,"plaquette_locality_checks":plaquette_checks,"diagonal_gaussian_collar_checks":diagonal_collar_checks,"coordinate_edge_count_cases":coordinate_count_cases,"distinct_collar_zero_interaction_counterexample_tv":"4/5","scope":"Proof supplements only; no Wilson integration, no width-uniform estimate, no all-cut full-dimensional exhaustion."}
Path(__file__).with_name('check_results.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
