# Independent audit: fixed-width posterior strip contraction

19 October 2026. Independent local mathematical audit. No repository writes, merges, or releases.

## Verdict

The author's reverse-Markov argument is correct under an **exact shared-prefix factorization**. It gives a pointwise-in-the-conditioning-field bound, so the Gaussian posterior tilt causes no loss. The clean constant is

    epsilon(r,N) = product_{i=r}^{N-1} tanh(B_i),
    |P_W F - Q_W F| <= 2 ||F||_infinity epsilon(r,N),
    D_rho(F) <= 4 ||F||_infinity^2 epsilon(r,N)^2.

Here B_i bounds the absolute cross-block interaction, F is measurable in blocks 0 through r, and the two laws have exactly the same initial and intermediate factors through block N. They may differ arbitrarily in the law imposed at block N by their remote tails.

This verifies a fixed-transverse-geometry, finite-beta theorem, **not** a width-uniform theorem or the all-cut four-dimensional common-exhaustion hypothesis. The reflected halves must agree throughout the buffer, including all lateral boundaries and all retained plaquettes. Identical geometry near the test alone does not suffice.

## 1. Exact probability theorem

Let X_0,...,X_N be standard Borel spaces with reference probability measures nu_i. For each fixed W, suppose the two prefix laws have densities proportional to

    h_0,W(x_0) [product_{i=0}^{N-1} k_i,W(x_i,x_{i+1}) h_{i+1,W}(x_{i+1})] R_+,W(x_N),
    h_0,W(x_0) [product_{i=0}^{N-1} k_i,W(x_i,x_{i+1}) h_{i+1,W}(x_{i+1})] R_-,W(x_N).

The h factors and k kernels are common. The R factors can differ. All relevant normalizations are positive and finite. Assume

    exp(-B_i) <= k_i,W(x,y) <= exp(B_i),

uniformly in x,y,W, with B_i finite. A common scalar in either kernel is irrelevant. More generally, the argument only requires its cross-ratio oscillation to be at most 4B_i. The initial factor may be very large, depend on arbitrarily large W, or be replaced by a finite nonzero starting measure with fixed physical-plane variables already conditioned out.

Define forward weights

    l_0,W(x) = h_0,W(x),
    l_{i+1,W}(y) = h_{i+1,W}(y) integral l_i,W(x) k_i,W(x,y) nu_i(dx),

and reverse kernels

    Q_i,W(y,dx) = l_i,W(x) k_i,W(x,y) nu_i(dx)
                  / integral l_i,W(z) k_i,W(z,y) nu_i(dz).

The joint law can be sampled by first drawing x_N from its own terminal marginal and then using Q_{N-1,W},...,Q_0,W. This follows by direct multiplication: the intermediate forward normalizations telescope, leaving exactly the displayed density. Crucially, **none of these reverse kernels depends on R_+ or R_-**.

For y,y', the log density ratio between Q_i,W(y,.) and Q_i,W(y',.) has oscillation

    osc_x [log k_i,W(x,y) - log k_i,W(x,y')] <= 4B_i.

The l_i factors cancel exactly. The normalizing denominators add an x-independent constant and therefore also disappear from the oscillation.

Section 2 proves that probability measures with log density-ratio oscillation at most d have total variation distance, in the convention sup_A |P(A)-Q(A)|, at most tanh(d/4). Consequently,

    delta(Q_i,W) <= tanh(B_i).

Dobrushin contraction applied to the two arbitrary terminal marginals gives

    TV(P_W(x_r in .), Q_W(x_r in .)) <= epsilon(r,N).

Given x_r, the entire earlier prefix x_0,...,x_{r-1} has the same conditional law under both measures. Attaching this common conditional law preserves the total variation distance exactly. Thus

    TV(P_W|_{0:r}, Q_W|_{0:r}) <= epsilon(r,N).

For any real or complex F_W measurable in the tested prefix and bounded uniformly by M,

    |P_W F_W - Q_W F_W| <= 2M epsilon(r,N).

The argument permits hard/singular terminal laws as well: choose any two laws of x_N and run the common reverse kernels. In Wilson applications terminal densities are already positive and finite; no boundary-uniform terminal density ratio is required.

The empty product, r=N, is 1 and gives only the trivial estimate. To obtain decay, the test support must be separated from the tail-difference location by an increasing number of full retained interactions.

## 2. Sharp total-variation/Hilbert constant

Let r=dP/dQ with a<=r<=b, E_Q r=1, and 0<a<=1<=b. Convexity of (r-1)_+ and its endpoint chord imply

    TV(P,Q) = E_Q (r-1)_+ <= (b-1)(1-a)/(b-a).

For fixed t=b/a, the right side equals

    (t+1 - t a - 1/a)/(t-1).

It is maximized at a=t^(-1/2), where it becomes

    (sqrt(t)-1)/(sqrt(t)+1) = tanh(log(t)/4).

This is increasing in t, so b/a<=exp(d) yields TV<=tanh(d/4). Limits cover nonattained essential bounds. The constant is sharp already on a two-point space. For t=s^2, the probabilities

    P=(s/(s+1), 1/(s+1)),  Q=(1/(s+1), s/(s+1))

have Hilbert distance 2 log(s) and TV=(s-1)/(s+1).

Thus there is no missing factor of two: cross-ratio oscillation 4B gives tanh(B), not tanh(2B). With kernel bounds m<=k<=M, the same safe coefficient is (M-m)/(M+m), because B=(1/2)log(M/m) after a harmless scalar rescaling.

A primary-source consistency check is Samuel N. Cohen and Eliana Fausti, *Hyperbolic contractivity and the Hilbert metric on probability measures*, arXiv:2309.02413, version 2, 12 November 2024, which develops sharp Hilbert-to-total-variation comparisons and contraction. The proof above is self-contained and fixes the TV convention explicitly. Source: https://arxiv.org/abs/2309.02413 .

## 3. Relation to a backward Hilbert-metric proof

The Wilson transfer operators are strictly positive integral operators. For a kernel between exp(-B_i) and exp(B_i), its projective diameter is at most 4B_i, so Birkhoff's contraction coefficient is at most tanh(B_i). Common positive one-block weights do not change cross ratios.

Applying the rightmost common transfer first bounds the projective distance of two arbitrary positive terminal messages by 4B_{N-1}. Applying the remaining transfers yields

    H(message_+, message_-) <= 4 B_{N-1} product_{i=r}^{N-2} tanh(B_i).

Multiplying the two messages by the same prefix weight leaves their likelihood-ratio oscillation unchanged. This supplies a valid alternative bound after the Hilbert-to-TV inequality. The reverse-Markov proof is preferable because it yields the product of all tanh factors directly, with no initial projective-diameter prefactor and no need to compare terminal messages.

One cannot use a forward transition normalized without the actual common prefix weight and then assume it controls the posterior. The valid kernel here is the explicitly displayed reverse Q_i,W.

## 4. Wilson block factorization without gauge fixing

No gauge fixing or gauge-invariance restriction on F is needed. Use the physical link variables themselves, plus the auxiliary half-links when treating a bond cut. All unconditioned variables have product normalized Haar reference law.

For a coordinate normal t=x_0, assign a physical link to the block given by the minimum t-coordinate of its endpoints. Block t contains all transverse links at slice t and all normal links starting at t. Every transverse plaquette belongs to one block. Every temporal plaquette uses variables only from blocks t and t+1. Its Wilson exponent is beta_p w_p, with |w_p|<=1. Therefore

    B_t = sum_{p crossing the block boundary t|t+1} beta_p

is valid. For homogeneous beta and a fixed transverse induced complex T, one temporal plaquette corresponds to each transverse edge; hence B=beta E(T). In a rectangular cross-section with transverse side lengths L_1,...,L_{d-1} measured in lattice intervals,

    E(T) = sum_j L_j product_{k != j} (L_k+1).

There is no transverse-plaquette count in this sharp elementary B: all transverse plaquettes are common one-block weights, already absorbed into h_t. If a different block convention also assigns them to a cross kernel, including them gives a weaker safe constant, but it should not be presented as the exact cross-plaquette count.

For a coordinate bond cut, the half-links and first positive-slice tangent links supporting each Gaussian path can all be put in the initial collar block. A physical crossing-link observable remains excluded, as in the underlying Gaussian gluing construction.

For a coordinate site cut, condition on the fixed-plane tangent links. Their effect is a shared initial factor or a shared bounded first cross interaction. Enlarging the collar by one slice isolates all W dependence if desired. That enlargement reduces the number of available contraction steps and must be counted.

For h=x_i +/- x_j, assign a physical link to min(h(endpoint 1),h(endpoint 2)). Every elementary plaquette then has link-block labels spanning at most one integer. This is true even for an ij plaquette, although its vertex heights span two. Thus one-level blocks already give nearest-neighbor factorization; two-level blocks are also safe. A plaquette crossing the reflection plane h=0 has plus-side path links all assigned label 0, so its Gaussian factor belongs entirely to the initial block. Fixed-plane links in the remaining coordinate directions are conditioned boundary variables.

This locality observation alone does **not** provide a constant cross-section or a numeric bound on its cross-plaquette count. For an actual diagonal strip, count retained plaquettes at each boundary and verify the transverse shape is reflection-invariant and shared by the two compared half domains. Alternating slice cardinalities are harmless: the X_i spaces may vary with i.

Compactness of finite products of SU(2), finite beta, and the bounded plaquette action make the untouched kernels continuous and strictly positive. For each fixed finite Gaussian W, the collar feature is continuous and finite on the finite compact collar, even though its supremum is not uniform in W. The proof never requests such a supremum.

## 5. Actual posterior and RP consequences

Let rho be the actual W marginal, including both conditional partition functions. Since the conditional estimate is pointwise for every W where the normalized kernels exist,

    D_rho(F) = integral |a_F(W)-b_F(W)|^2 rho(dW)
              <= 4M^2 epsilon(r,N)^2.

No replacement of rho by the bare Gaussian reference law occurs. No Gaussian tail bound, density-ratio bound for rho, partition-function ratio, plane-area prefactor, or Gaussian typical-field event is used. Conditional correlations between W and terminal marginals are allowed: after fixing W, terminal marginals may be arbitrary.

Together with the previously established exact Gaussian gluing identities, this implies

    Re Q_mu(F) >= -M^2 epsilon(r,N)^2,
    dist(Q_mu(F), [0,infinity)) <= 2M^2 epsilon(r,N).

These are full complex-form bounds for the specified physical observable algebra. With F=M_a f_a and ||f_a||<=1, vanishing of M_a^2 epsilon_a suffices for the full form; vanishing M_a^2 epsilon_a^2 suffices only for the negative real-part bound.

## 6. Essential limitations and exact failure modes

1. **A common collar is essential.** With all cross interactions zero, the theorem predicts zero discrepancy after one step. If the left weights differ, take X_0={+1,-1}, initial laws (9/10,1/10) and (1/10,9/10), and F(x_0)=x_0. Their mismatch is 8/5 although every untouched cross kernel equals 1. Thus a collar difference cannot be hidden in a terminal factor.

2. **All differences must be beyond the buffer.** Unmatched lateral plaquettes or side-boundary fields at each slice change the common reverse kernels. They cannot be represented as arbitrary remote terminal weights. In particular, a generic pair of reflected halves of an asymmetric free box need not have the required cylindrical shared prefix.

3. **The test must remain inside the common prefix.** If it reaches the terminal boundary, the terminal laws may be mutually singular and no small bound follows. If F depends on W, its conditioned expression must still be identical in the two reflected descriptions and have a common uniform bound.

4. **The untouched cross interaction must stay bounded.** If an unbounded Gaussian-dependent term straddles each block interface, the relevant B_i is not uniformly finite. A two-state kernel exp(Hxy) has reverse contraction tanh(H), approaching 1 as H grows. One-block Gaussian weights cancel; Gaussian cross-block interactions do not automatically cancel.

5. **No width-uniform result follows.** For equal B=beta E and b=N-r, epsilon=tanh(beta E)^b. At large beta E, log(tanh(beta E)) is asymptotic to -2 exp(-2 beta E). To make this particular bound small along varying widths/couplings, one needs b exp(-2 beta E) tending to infinity. For a cubic d=4 cross-section of side L intervals, E=3L(L+1)^2. A usual box exhaustion with b of order L makes this estimate tend to 1, not 0, at every fixed beta>0.

6. **A single normal is not all reflections.** An elongated fixed-width cylinder controls its long direction. It does not, by itself, verify simultaneous coordinate and diagonal cuts on one growing four-dimensional exhaustion. It provides a quasi-one-dimensional all-finite-beta result and a correctly normalized transfer mechanism.

7. **Zero coupling and zero cross count.** If any buffer boundary has B_i=0, its kernel is constant up to common one-block factors and the terminal influence is exactly killed at that step. No division by tanh(B_i) is needed. If there is no buffer step, the empty product is 1.

## 7. Executed independent checks

The companion `check_audit.py` uses exact rational arithmetic for the stochastic calculations and integer geometry for the lattice checks. Its saved `check_results.json` reports:

- 50 sharp two-point Hilbert-to-TV extremizers;
- 160 finite-state chains, with 452 reverse kernels and one-block weights ranging through powers of two with exponents as large as 160 in absolute value;
- arbitrary hard terminal choices, contraction of every tested earlier marginal, exact equality of TV after attaching common prefixes, and complex unit-modulus test functions;
- 29 coordinate/signed-diagonal normal cases in dimensions 2 through 4;
- 63,475 elementary-plaquette link-locality checks;
- 1,494 diagonal Gaussian-collar path checks;
- 84 coordinate cross-section edge-count checks;
- the exact distinct-collar counterexample with TV=4/5.

All passed. These supplement the displayed proof. They do not integrate Wilson theory, bound a growing-width posterior defect, or establish the full four-dimensional common-exhaustion target.

## 8. Independent verification of the explicit diagonal counts

The author's full report was then read at `/workspace/shared/posterior-strip-contraction-20261019/RESULT.md`. Its strip is

    u=x_0-x_1, v=x_0+x_1, |v|<=W, |x_j|<=W for j>=2,
    L=2W+1, u=v modulo 2.

For a (0,1) plaquette based at (u,v)=(k,v), its vertices have u heights k,k+1,k,k-1 and v values v,v+1,v+2,v+1. Hence v ranges over [-W,W-2] with parity k. There are W eligible v values when k and W have the same parity, and W-1 otherwise. Its minimum-endpoint link heights are k-1,k-1,k,k. It crosses the one-level boundary t-1|t exactly when k=t, giving

    C_min,01 = [W-1+1_(t=W mod 2)] L^(d-2).

For each j>=2, a (0,j) plaquette crosses that boundary at base height k=t-1, and a (1,j) plaquette at base height k=t. Their eligible v interval [-W,W-1] has exactly W values of either required parity. There are 2W choices for the base j-coordinate and L choices for each other transverse coordinate. Each orientation therefore contributes

    2 W^2 L^(d-3).

Plaquettes with both directions at least 2 contribute zero. The resulting exact total is

    C_min(W,d,t) = [W-1+1_(t=W mod 2)] L^(d-2)
                  + 4(d-2)W^2 L^(d-3),

with the second term omitted in d=2. In d=4 its alternating values are

    L(10W^2-W-1),  W L(10W+1).

Under the old oriented-tail, two-level convention, the (0,1) base can instead be k=t-1 or k=t. The two parity classes sum to 2W-1, while mixed direction counts remain the same. Thus

    C_tail(W,d) = (2W-1)L^(d-2) + 4(d-2)W^2 L^(d-3),

again omitting the second term in d=2. This gives C_tail(W,4)=L(12W^2-1), as stated by the author.

For a finite strip -L_-<=u<=L_+ and cut u=a, the common reflected longitudinal depth is h=min(L_+-a,L_-+a). A min-height block n may contain a normal link reaching height a+n+1. Consequently N=h-1 guarantees all blocks through N are complete. The author's two-level alternative condition 2N+2<=h is likewise safe. These are sufficient bounds, not claims of optimal cutoff placement.

The separate independent script `check_diagonal_counts.py` enumerates every relevant plaquette and verifies the formulas by orientation. Its `diagonal_count_results.json` records 75 dimension/width/offset cases (d=2,3,4; W=1,...,5; t=-3,-2,0,1,4) and 159,492 adjacency checks. All passed.

## 9. Final audit status

The full current strip report passes this independent audit: exact shared-prefix factorization; reverse-kernel independence from terminal tails; sharp tanh constants; pointwise treatment of unbounded Gaussian collar values; actual posterior integration; complex-form constants; coordinate counts; diagonal two-level and improved one-level counts; and safe collar/buffer endpoint placement.

No substantive correction was needed. The minimum-endpoint-height blocking observation from this audit was incorporated by the author and independently counted in both implementations. The fixed-width, single-normal and shared-lateral-geometry limitations remain essential. Nothing in either proof closes the four-dimensional growing-width, simultaneous-all-cut or weak-coupling normalization target.

## 10. Separate nonuniform-limit example audited

The author's separate `SHARP_LIMIT_OBSTACLE.md` was also independently checked. For K_n=[[n,1],[1,n]] and terminal weights (n,1) versus (1,n), the common forward weights are constant by equal row/column sums. The terminal sign means are plus/minus q_n, with q_n=(n-1)/(n+1). Each of n reverse transitions multiplies the mean by q_n, giving means plus/minus q_n^(n+1) and mismatch 4q_n^(2n+2). Since (2n+2)log((n-1)/(n+1)) tends to -4, the mismatch tends to 4 exp(-4), strictly positive.

Rescaling K_n by 1/sqrt(n) puts its entries between exp(-B_n) and exp(B_n), where B_n=(1/2)log n. Thus n exp(-2B_n)=1. Every fixed n has a unique one-dimensional Gibbs state, but these constants do not imply forgetting in the joint parameter/length limit. This is correctly labeled an abstract two-state illustration, not a Wilson counterexample or a counterexample to any fixed-parameter uniqueness implication.

The independent `check_limit_example.py` directly propagates both reverse probability vectors using exact fractions for n=2,...,100. All 99 cases agree with the displayed means and mismatch. The results are saved in `limit_example_results.json`.
