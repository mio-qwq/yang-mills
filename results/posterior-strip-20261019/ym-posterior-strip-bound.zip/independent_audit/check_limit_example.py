#!/usr/bin/env python3
from fractions import Fraction as F
from pathlib import Path
import json
for n in range(2,101):
    q=F(n-1,n+1)
    plus=[F(n,n+1),F(1,n+1)]
    minus=plus[::-1]
    for _ in range(n):
        plus=[(n*plus[0]+plus[1])/(n+1),(plus[0]+n*plus[1])/(n+1)]
        minus=[(n*minus[0]+minus[1])/(n+1),(minus[0]+n*minus[1])/(n+1)]
    mplus=plus[0]-plus[1];mminus=minus[0]-minus[1]
    assert mplus==q**(n+1) and mminus==-q**(n+1)
    assert (mplus-mminus)**2==4*q**(2*n+2)
report={'status':'pass','exact_cases':99,'n_min':2,'n_max':100,'mismatch_formula':'4*((n-1)/(n+1))**(2*n+2)','limit':'4*exp(-4)','scope':'Two-state nonuniform-parameter illustration, not a Wilson counterexample.'}
Path(__file__).with_name('limit_example_results.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
