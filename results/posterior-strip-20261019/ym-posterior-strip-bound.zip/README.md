# Private fixed-width posterior strip bound, 19 October 2026 16:07 UTC

For each fixed finite transverse width and every finite beta>=0, shared-prefix reflected Wilson strips satisfy the pointwise normalized half-kernel bound

    |P_W F-Q_W F| <= 2 ||F||_infinity product_i tanh(beta C_i),
    E_rho |P_W F-Q_W F|^2 <= 4 ||F||_infinity^2 product_i tanh(beta C_i)^2.

The same near-cut geometry, collar weight, one-block factors, and interactions must be shared throughout the common buffer. The estimate is pointwise in the Gaussian collar and hence applies under the actual posterior. Far tails can differ. Read construction/RESULT.md and independent_audit/AUDIT.md for hypotheses and proof.

The one-level diagonal blocking has exact alternating 4D cross-plaquette counts (2W+1)(10W^2-W-1) and W(2W+1)(10W+1). These are finite-width combinatorial counts, not a four-dimensional continuum theorem. A separate exact two-state example has joint-limit mismatch 4 exp(-4)>0; it blocks a uniform inference from per-parameter positivity and is not a Wilson counterexample.

Compact prior proof dependencies are retained in dependencies/ and mapped by SOURCE_PROVENANCE.json. Original references in imported prose remain unchanged. Primary and independent exact finite-state/incidence checks supplement the mathematical proof; they do not integrate SU(2).

Replay offline with Python 3 standard library:

    python -B verify_bundle.py
    python -O -B verify_bundle.py

Imported independent scripts contain assertions. Raw -O execution removes those assertions, so raw byte equality alone is insufficient. The bundle runs originals unchanged AND an in-memory assertion-preserving runner that translates assertions into explicit exceptions. Fresh exact outputs match the pinned receipts, and mathematical mutations are rejected in both interpreter modes. Inventory and receipt corruption controls are included. No imported file is rewritten.

Rebuild outside this folder with python -B build_zip.py /chosen/path.zip.

Boundary: no width-uniform estimate, simultaneous mixed-direction reflection positivity, isotropically growing 4D control, continuum limit, rotation invariance, or mass gap is established. No upload, commit, PR, merge, release, or contact occurred.

Original imported checksum/manifests retain the historical source inventory, including any omitted duplicate receipts. The authoritative self-contained bundle inventory is the root SHA256SUMS.
