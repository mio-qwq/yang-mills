#!/usr/bin/env python3
"""Offline exact replay, source integrity, assertion-preserving and mutation controls."""
from pathlib import Path
import argparse,ast,hashlib,json,os,shutil,subprocess,sys,tempfile
ROOT=Path(__file__).resolve().parent

def require(ok,msg):
    if not ok: raise RuntimeError(msg)
def digest(b):return hashlib.sha256(b).hexdigest()
def compare_bytes(actual,expected,label):require(actual==expected,'exact replay mismatch: '+label)
def check_integrity(root):
    inventory={}
    for line in (root/'SHA256SUMS').read_text().splitlines():
        h,p=line.split('  ',1);require(p not in inventory,'duplicate hash path');inventory[p]=h
    actual={p.relative_to(root).as_posix() for p in root.rglob('*') if p.is_file() and p.name!='SHA256SUMS'}
    # Only the root inventory is excluded; nested imported inventories remain covered.
    actual={p.relative_to(root).as_posix() for p in root.rglob('*') if p.is_file() and p!=root/'SHA256SUMS'}
    require(actual==set(inventory),'inventory membership mismatch')
    require(not any(p.is_symlink() for p in root.rglob('*')),'symlink not allowed')
    for p,h in inventory.items():require(digest((root/p).read_bytes())==h,'hash mismatch: '+p)
    return len(inventory)
def command(root,task,raw=False):
    mode=['-O'] if sys.flags.optimize else []
    script=root/task['script']
    args=[sys.executable,*mode,'-B']
    if not raw: args += [str(root/'run_checked.py')]
    return subprocess.run(args+[str(script),*task.get('args',[])],cwd=script.parent,stdout=subprocess.PIPE,stderr=subprocess.PIPE,env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1'},timeout=300)
def copies(root,tmp,name):
    dest=Path(tmp)/name;shutil.copytree(root,dest);return dest

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--skip-mutations',action='store_true');a=ap.parse_args()
    n=check_integrity(ROOT);cfg=json.loads((ROOT/'CONFIG.json').read_text())
    replay=[];negative=[];fresh={}
    with tempfile.TemporaryDirectory(prefix='research-checkpoint-') as tmp:
        for index,task in enumerate(cfg['tasks']):
            rawdir=copies(ROOT,tmp,'raw'+str(index));checkdir=copies(ROOT,tmp,'checked'+str(index))
            raw=command(rawdir,task,True);checked=command(checkdir,task)
            require(raw.returncode==0,'raw replay failed: '+task['script']+' '+raw.stderr.decode())
            require(checked.returncode==0,'checked replay failed: '+task['script']+' '+checked.stderr.decode())
            compare_bytes(raw.stdout,checked.stdout,task['script']+' raw/checked stdout')
            entries=[]
            for spec in task['outputs']:
                expected=(ROOT/spec['expected']).read_bytes()
                b1=raw.stdout if spec['actual']=='stdout' else (rawdir/spec['actual']).read_bytes()
                b2=checked.stdout if spec['actual']=='stdout' else (checkdir/spec['actual']).read_bytes()
                compare_bytes(b1,expected,spec['expected']+' raw')
                compare_bytes(b2,expected,spec['expected']+' checked')
                fresh[spec['expected']]=b2
                entries.append({'path':spec['expected'],'sha256':digest(b2)})
            assertion_count=sum(isinstance(node,ast.Assert) for node in ast.walk(ast.parse((ROOT/task['script']).read_text())))
            replay.append({'script':task['script'],'status':'PASS','assertions_preserved':assertion_count,'outputs':entries})
        if not a.skip_mutations:
            for index,mutation in enumerate(cfg['source_mutations']):
                stage=copies(ROOT,tmp,'mutation'+str(index));task=cfg['tasks'][mutation['task']]
                p=stage/task['script'];s=p.read_text()
                require(s.count(mutation['old'])==1,'mutation anchor is not unique: '+mutation['name'])
                p.write_text(s.replace(mutation['old'],mutation['new']))
                got=command(stage,task)
                require(got.returncode!=0,'mathematical mutation was not rejected: '+mutation['name'])
                negative.append({'name':mutation['name'],'kind':'source-level mathematical mutation','result':'REJECTED'})
            # Fresh exact replay is the comparison oracle for receipt mutation tests.
            for mutation in cfg['receipt_mutations']:
                key=mutation['path'];obj=json.loads(fresh[key]);node=obj
                for k in mutation['keys'][:-1]:node=node[k]
                node[mutation['keys'][-1]]=mutation['value']
                b=(json.dumps(obj,indent=2,sort_keys=True)+'\n').encode()
                require(json.loads(b)!=json.loads(fresh[key]),'receipt mutation unchanged')
                try:compare_bytes(b,fresh[key],key)
                except RuntimeError:pass
                else:raise RuntimeError('receipt mutation was not rejected')
                negative.append({'name':mutation['name'],'kind':'fresh-replay receipt comparison','result':'REJECTED'})
            for kind in ('tamper','missing','unlisted'):
                stage=copies(ROOT,tmp,'integrity_'+kind);p=stage/cfg['integrity_target']
                if kind=='tamper':p.write_bytes(p.read_bytes()+b'\n')
                elif kind=='missing':p.unlink()
                else:(stage/'UNLISTED.txt').write_text('must fail')
                try:check_integrity(stage)
                except RuntimeError:pass
                else:raise RuntimeError('integrity negative control was not rejected')
                negative.append({'name':kind,'kind':'inventory integrity','result':'REJECTED'})
    result={'status':'PASS','bundle':cfg['bundle'],'inventory_entries':n,'replays':replay,'negative_controls':negative,'optimization_safe_checks':True,'scope':cfg['scope']}
    print(json.dumps(result,indent=2,sort_keys=True))
if __name__=='__main__':main()
