#!/usr/bin/env python3
"""Exact rational chain and lattice-incidence certificates; standard library only."""
from fractions import Fraction as Q
from itertools import product, combinations
from collections import defaultdict
import random, json, hashlib
from pathlib import Path


def require(condition, message):
    if not condition:
        raise RuntimeError(message)


def tv(p, q):
    return sum(abs(p.get(s, 0)-q.get(s, 0)) for s in set(p)|set(q))/2


def chain(N, collar, sites, kernels, terminal):
    law = {}
    for xs in product((0, 1), repeat=N+1):
        w = collar[xs[0]] * terminal[xs[N]]
        for i in range(1, N+1):
            w *= sites[i][xs[i]]
        for i in range(N):
            w *= kernels[i][xs[i]][xs[i+1]]
        law[xs] = w
    z=sum(law.values())
    return {xs:w/z for xs,w in law.items()}


def marginal(law, indices):
    ans=defaultdict(Q)
    for xs,w in law.items():
        ans[tuple(xs[i] for i in indices)] += w
    return dict(ans)


def reverse(k, left, y):
    weights=[left[x]*k[x][y] for x in (0,1)]
    z=sum(weights)
    return {x:weights[x]/z for x in (0,1)}


def rational_checks():
    rng=random.Random(20261019)
    count = reverse_count = 0
    for N in range(1,7):
      for trial in range(24):
        # No uniform bound on the collar ratio is used; include huge extremes.
        scale=Q(10)**(trial-12)
        collar=[Q(1),scale]
        sites=[[Q(1),Q(1)]]+[[Q(rng.randint(1,7)),Q(rng.randint(1,7))] for i in range(N)]
        kernels=[[[Q(rng.randint(1,4)) for y in (0,1)] for x in (0,1)] for i in range(N)]
        terminal_a=[Q(1),Q(10)**(trial%7)]
        terminal_b=[Q(10)**(trial%7),Q(1)]
        a=chain(N,collar,sites,kernels,terminal_a)
        b=chain(N,collar,sites,kernels,terminal_b)
        left=collar
        coeff=[]
        for i,k in enumerate(kernels):
            low=min(z for row in k for z in row)
            high=max(z for row in k for z in row)
            c=(high-low)/(high+low)
            coeff.append(c)
            qi=[reverse(k,left,y) for y in (0,1)]
            require(tv(qi[0],qi[1])<=c, 'reverse coefficient')
            for law in (a,b):
                pair=marginal(law,(i,i+1))
                for y in (0,1):
                    den=sum(pair[(x,y)] for x in (0,1))
                    require(all(pair[(x,y)]/den==qi[y][x] for x in (0,1)), 'terminal-independent reverse kernel')
                    reverse_count+=1
            left=[sites[i+1][y]*sum(left[x]*k[x][y] for x in (0,1)) for y in (0,1)]
        for r in range(N):
            p=Q(1)
            for c in coeff[r:]: p*=c
            dist=tv(marginal(a,range(r+1)),marginal(b,range(r+1)))
            require(dist<=p, 'prefix contraction')
            # Full complex expectation check, exact real/imag and squared modulus.
            vals={xs:(Q((-1)**sum(xs)),Q(xs[0]-xs[-1])) for xs in product((0,1),repeat=r+1)}
            ma=marginal(a,range(r+1)); mb=marginal(b,range(r+1))
            dr=sum((ma[xs]-mb[xs])*vals[xs][0] for xs in vals)
            di=sum((ma[xs]-mb[xs])*vals[xs][1] for xs in vals)
            # |F|<=sqrt(2), hence |difference|²<=8p².
            require(dr*dr+di*di<=8*p*p, 'complex mismatch')
            count+=1
    # The coefficient and n-step prefix estimate are sharp for arbitrary terminals.
    sharp=[]
    for N in range(1,8):
        k=[[Q(4),Q(1)],[Q(1),Q(4)]]
        sites=[[Q(1),Q(1)] for i in range(N+1)]
        a=chain(N,[Q(1),Q(1)],sites,[k]*N,[Q(1),Q(0)])
        b=chain(N,[Q(1),Q(1)],sites,[k]*N,[Q(0),Q(1)])
        for r in range(N):
            value=tv(marginal(a,range(r+1)),marginal(b,range(r+1)))
            require(value==Q(3,5)**(N-r), 'sharp product example')
            sharp.append({'N':N,'r':r,'tv':str(value)})
    return {'prefix_and_complex_checks':count,'reverse_conditional_checks':reverse_count,'sharp_examples':sharp,
            'collar_ratio_range':['1/1000000000000','100000000000']}


def plus(x,i):
    y=list(x);y[i]+=1;return tuple(y)


def plaquette(x,i,j):
    xi=plus(x,i);xj=plus(x,j);xij=plus(xi,j)
    return (x,xi,xj,xij), ((x,xi),(x,xj),(xi,xij),(xj,xij))


def diagonal_count(W,d,t, mode):
    total=0; bypair=defaultdict(int); adjacency_checks=0
    for u in range(t-3,t+4):
      for v in range(-W,W+1):
       if (u-v)%2:continue
       for z in product(range(-W,W+1),repeat=d-2):
        x=((u+v)//2,(v-u)//2)+z
        for i,j in combinations(range(d),2):
            vertices,edges=plaquette(x,i,j)
            if not all(abs(y[0]+y[1])<=W and all(abs(y[k])<=W for k in range(2,d)) for y in vertices):continue
            if mode=='tail': levels=[a[0]-a[1] for a,b in edges]
            elif mode=='minimum': levels=[min(a[0]-a[1],b[0]-b[1]) for a,b in edges]
            else: raise ValueError(mode)
            if mode=='tail':
                blocks=[(h-t)//2 for h in levels]
                require(max(blocks)-min(blocks)<=1,'tail two-level adjacency')
            else:
                require(max(levels)-min(levels)<=1,'minimum one-level adjacency')
            adjacency_checks+=1
            if min(levels)<t<=max(levels):
                total+=1;bypair[f'{i},{j}']+=1
    return total,dict(bypair),adjacency_checks


def coordinate_count(W,d):
    total=0
    for z in product(range(-W,W+1),repeat=d-1):
        x=(-1,)+z
        for j in range(1,d):
            vertices,edges=plaquette(x,0,j)
            if all(all(abs(y[k])<=W for k in range(1,d)) for y in vertices):total+=1
    return total


def geometry_checks():
    results=[]; adj=0
    for d in range(2,5):
      for W in range(1,5):
        L=2*W+1
        cc=coordinate_count(W,d)
        require(cc==2*(d-1)*W*L**(d-2),'coordinate formula')
        for t in range(-2,3):
            tail,pairs,a=diagonal_count(W,d,t,'tail');adj+=a
            extra=0 if d==2 else 4*(d-2)*W*W*L**(d-3)
            expected=(2*W-1)*L**(d-2)+extra
            require(tail==expected, 'tail diagonal formula')
            minimum,mpairs,a=diagonal_count(W,d,t,'minimum');adj+=a
            expected_min=(W-1+int((t-W)%2==0))*L**(d-2)+extra
            require(minimum==expected_min,'minimum diagonal formula')
            results.append({'d':d,'W':W,'t':t,'coordinate':cc,'diagonal_two_level_tail':tail,
                            'diagonal_one_level_minimum':minimum,'pairs_minimum':mpairs})
    return {'cases':len(results),'plaquette_adjacency_checks':adj,'results':results}


if __name__=='__main__':
    output={'status':'PASS','rational':rational_checks(),'geometry':geometry_checks()}
    output['checker_sha256']=hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
    print(json.dumps(output,indent=2,sort_keys=True))
