# Sharp obstruction to a uniform conclusion from per-width positivity

This complements RESULT.md. It is a two-state chain example, not a Wilson counterexample and not a disproof that uniqueness at fixed parameters implies the specific Gaussian mismatch criterion.

For each integer n>=2, take spins sigma_0,...,sigma_n in {-1,+1}, uniform single-site reference and the strictly positive nearest-neighbor kernel

    K_n(s,t) = n if s=t, and 1 otherwise.

The overall factor sqrt(n) is irrelevant to normalized laws, so this is the Ising kernel exp(J_n s t) with J_n=(1/2)log n. The sharp reverse contraction coefficient is

    q_n=(n-1)/(n+1)=tanh J_n.

Use a common uniform initial collar, no other one-site weights, and two strictly positive remote terminal weights

    R_+(sigma_n) = n if sigma_n=+1, and 1 otherwise,
    R_-(sigma_n) = n if sigma_n=-1, and 1 otherwise.

The two terminal means are ±q_n. Propagating backwards multiplies the mean by q_n at each of the n edges. Hence for the initial sign test F=sigma_0,

    a_n=+q_n^(n+1),  b_n=-q_n^(n+1),
    |a_n-b_n|^2=4q_n^(2n+2) -> 4 exp(-4)>0.

All finite-volume weights are strictly positive, and for each fixed n the associated infinite one-dimensional interaction has exactly one Gibbs state. The obstruction is a **joint parameter/length limit**: n exp(-2J_n)=1, so the transfer rate deteriorates at precisely the scale at which the end recedes.

Two conditionally independent halves with these weights and a trivial conditioning variable have posterior mismatch D_n=4q_n^(2n+2). Their physical reflected form for the sign test is -q_n^(2n+2). This last product construction has deliberately different terminal fields and is not a common free Wilson cutoff. It isolates only the logical failure of claiming uniform forgetting from pointwise kernel positivity for each width/coupling.

The product contraction estimate in RESULT.md cannot be improved to a uniformly decaying estimate using only the range bounds on K. For actual Wilson strips, additional gauge or geometric structure might improve those coarse constants; this example does not rule that out.

`check_limit_obstacle.py` verifies the exact rational local means by direct transfer sums for n=2,...,40, including both nonzero terminal weights. The limiting expression follows from n log((n-1)/(n+1))->-2.
