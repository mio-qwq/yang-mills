#!/usr/bin/env python3
from fractions import Fraction as Q
import json

def expectation(n, plus):
    # The vector is the integrated right tail at the current spin, ordered -,+.
    h=[Q(1),Q(n)] if plus else [Q(n),Q(1)]
    for i in range(n):
        h=[n*h[0]+h[1],h[0]+n*h[1]]
    return (h[1]-h[0])/(h[1]+h[0])

out=[]
for n in range(2,41):
    q=Q(n-1,n+1)
    a=expectation(n,True);b=expectation(n,False)
    if a!=q**(n+1) or b!=-q**(n+1):
        raise RuntimeError(f'failure n={n}')
    out.append({'n':n,'a':str(a),'b':str(b),'D':str((a-b)**2)})
print(json.dumps({'status':'PASS','cases':len(out),'results':out},indent=2,sort_keys=True))
