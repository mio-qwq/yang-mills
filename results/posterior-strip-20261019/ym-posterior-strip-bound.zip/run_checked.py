#!/usr/bin/env python3
"""Execute unchanged source with every assert replaced by an explicit runtime check.
This preserves checks under python -O without rewriting imported files on disk.
"""
import ast,sys
from pathlib import Path
class PreserveAssertions(ast.NodeTransformer):
    def visit_Assert(self,node):
        message=node.msg if node.msg is not None else ast.Constant('assertion failed')
        replacement=ast.If(test=ast.UnaryOp(op=ast.Not(),operand=node.test),body=[ast.Raise(exc=ast.Call(func=ast.Name(id='RuntimeError',ctx=ast.Load()),args=[message],keywords=[]),cause=None)],orelse=[])
        return ast.copy_location(replacement,node)
p=Path(sys.argv[1]).resolve();sys.argv=[str(p),*sys.argv[2:]]
tree=ast.fix_missing_locations(PreserveAssertions().visit(ast.parse(p.read_text(),filename=str(p))))
exec(compile(tree,str(p),'exec',optimize=0),{'__name__':'__main__','__file__':str(p),'__package__':None})
