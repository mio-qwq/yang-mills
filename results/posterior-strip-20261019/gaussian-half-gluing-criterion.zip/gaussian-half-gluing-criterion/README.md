# Audited conditional Gaussian half-gluing criterion

19 October 2026. Local source archive. No upload, repository mutation, PR merge,
release, or external announcement is part of this bundle.

## Result and stopping point

This is an audited **conditional recovery criterion**, not an all-coupling
mixing theorem. At every finite nonnegative Wilson coupling, positive Gaussian
features and exact Haar subdivision produce normalized conditional half-kernels
for coordinate-site, coordinate-bond, and integer signed-diagonal lattice cuts.
For a physical positive-half test F, the posterior-averaged mismatch D(F) gives

    Re Q(F) >= -D(F)/4,
    dist(Q(F), [0, infinity)) <= ||F||_infinity sqrt(D(F)).

If this mismatch tends to zero for each fixed required cut and local test along
one common physical exhausting sequence at fixed finite beta, every local weak
cluster point is a Wilson DLR state satisfying those RP inequalities. The
auxiliary representations may vary with the cut; the physical sequence may not.
The full-state symmetry conclusion requires the full-half observable algebra.

The bundle does **not** prove the required mismatch decay at weak coupling or
all beta, full-sequence convergence, uniqueness, a continuum limit, or a mass
gap. A positive-semidefinite phase-coupling approximation is an alternate
conditional route, also requiring a new estimate. The Gaussian identity itself
is standard Hubbard--Stratonovich algebra, not a novelty claim.

## Reading order and frozen sources

1. `source/RESULT.md`: complete proof and precise unresolved target.
2. `audit/AUDIT.md`: independent whole-report audit, conditional PASS.
3. `bond_audit/AUDIT.md`: independent bond, orientation, and common-limit audit.
4. `DEPENDENCIES.md`: historical provenance and runtime requirements.
5. `certificates/`: exact finite replay and genuine mutation results.

All three authors confirmed their source freezes. Original source and audit
bytes are preserved, with their original certificates and inventory files.
`SOURCE_ORIGINS.json` maps every imported file to its original location and
SHA256. Historical absolute paths and the source's statement that its full
audit was in progress are retained verbatim; the completed full audit is now
included here. `audit/SOURCE_RESULT.md` is byte-identical to `source/RESULT.md`.

Pinned principal hashes:

- Source proof: `951297ea6dc798f5abd8aaed2d99fd17f257baa9f47fb68396274c2fead8cde9`
- Full audit: `f4b9101dc712ec5b6c75d9d972952395560a6b042a8f2a7f184b6dc7cb5a2b33`
- Bond audit: `f1c869154cb3a3b4d7e5443bfbeb1dab26173415b834b1790455fdbf3c0f8c40`

## Replaying the checks

Run from this directory with Python 3.12 and the versions in `requirements.txt`
(recorded verification environment: `certificates/ENVIRONMENT.json`). The audit
and its mutation runner require only the Python standard library. The original
source checker additionally uses SymPy and its dependency mpmath.

    python -I -B tools/replay.py > /tmp/gluing.normal.json
    python -I -B -O tools/replay.py > /tmp/gluing.optimized.json
    cmp /tmp/gluing.normal.json certificates/REPLAY.json
    cmp /tmp/gluing.optimized.json certificates/REPLAY.optimized.json
    python -I -B tools/replay_audit_mutations.py audit/check_audit.py > /tmp/audit.mutations.json
    python -I -B -O tools/replay_audit_mutations.py audit/check_audit.py > /tmp/audit.mutations.optimized.json
    cmp /tmp/audit.mutations.json certificates/AUDIT_MUTATIONS.json
    cmp /tmp/audit.mutations.optimized.json certificates/AUDIT_MUTATIONS.optimized.json

The source and bond checkers use Python `assert`. Raw `python -O` deletes those
checks and is **not** a validation. `tools/run_assert_safe.py` parses the frozen
source and replaces every assertion with an explicit if/raise AST before
compilation. `tools/replay.py` checks direct normal execution against the
original certificates, then checks the transformed version in both normal and
optimized modes. A false-assertion canary must fail in both modes. Original
files are never edited; all executable copies and outputs are temporary.

The independent whole-report checker already uses explicit `require` calls.
Its direct normal and optimized runs match its pinned certificate. Eleven
distinct formula mutations (four source/bond and seven independent audit),
each tried in both modes, must be rejected for the intended verification
failure. These are real executable mutations in temporary source copies,
additional to the exact counterexamples already in the reports.

The finite tests supplement the analytic proofs. They do not integrate the
interacting SU(2) model or verify an infinite-volume mismatch estimate. The
source/bond checkers use a Hamilton quaternion convention; the independent
audit explicitly uses the minus-cross-product convention associated with the
displayed Pauli formula. Both check the relevant convention-invariant scalar
trace identities, and the audit independently verifies full bond words.

## Integrity and deterministic rebuild

`SHA256SUMS` covers every file in this directory except itself. The build tool
rejects missing, extra, changed, cached, or symlinked files. Original imported
inventory files retain historical paths; use the **top-level** inventory for
this portable bundle.

    sha256sum -c SHA256SUMS
    python -I -B tools/build_archive.py /tmp/gaussian-half-gluing-criterion.zip

The archive has sorted members, fixed timestamps and POSIX modes, no directory
entries, no compression-library dependency, and no caches. Its ZIP bytes are
deterministic, including after clean extraction and replay. The checkpoint's
external receipt records the archive hash and independent rebuild result; the
receipt is intentionally outside the archive to avoid a self-hash cycle.
