# Dependency and provenance boundaries

## Analytic inputs of the new conditional theorem

The proofs in `source/RESULT.md` and the two audits are self-contained modulo
standard elementary results: the Gaussian moment-generating identity,
normalized Haar invariance, Tonelli, Cauchy--Schwarz, compactness of a countable
compact product, and the finite-range continuous Gibbs/DLR specification.
There is no imported weak-coupling estimate or hidden mismatch-decay theorem.

## Historical sources copied for context

These are provenance, not new theorem assumptions. Their earlier certificates
are retained as historical evidence; this bundle's replay does not re-audit or
re-execute their separate projects.

- `dependencies/conditional-centering-RESULT.md`: earlier site-plane
  conditional-centering analysis. Its historical `CHECKS.json` and source
  recovery manifest are included alongside it.
- `dependencies/strong-coupling-seam-PROOF.md`: existing physical comparison
  with the condition `18 beta < 1`, recovered at repository commit
  `4ff17ed90aa40a453129d1d0b9cea0bf483c949a`, Git blob
  `1a5d84389251c62c7f02cad04fec0d047f37e9db`, SHA256
  `55703932aecdf8388a79c124e52a0f30b44688b1d57ae1e65579b24310053424`.
  Exact reference:
  https://github.com/mio-qwq/yang-mills/blob/4ff17ed90aa40a453129d1d0b9cea0bf483c949a/results/strong-coupling-seam/PROOF.md
  This physical comparison does not automatically control the new auxiliary
  posterior mismatch.
- `dependencies/simultaneous-RP-RESULT.md`: earlier state-selection analysis.
- `dependencies/layered-Ising-example.md`: earlier layered-Ising illustration,
  explicitly conditional on standard low-temperature two-dimensional layer
  facts. It is not a Wilson counterexample or an all-cut Wilson estimate.
- `dependencies/invariant-diagonal-RESULT.md`: earlier diagonal construction.

Every copied reference has an exact origin and digest in `SOURCE_ORIGINS.json`.
Historical reports can refer to other work not needed by the new conditional
proof. Large paper PDFs, unrelated source trees, and caches are intentionally
not included.

## Literature guardrail already cited by the source and audit

Robert B. Israel, *Some examples concerning the global Markov property*,
Communications in Mathematical Physics 105 (1986), 669--673.
https://doi.org/10.1007/BF01238938
Author bibliography: https://personal.math.ubc.ca/~israel/

This is a general warning against exchanging infinite-plane conditioning and
local limits. It is not used as a Wilson counterexample. The new proof stays
at finite volume until passing physical local expectations to the limit.
The archive preserves the reviewed references; packaging does not claim a new
literature search or a novelty certification.

## Execution dependencies

- Python 3.12.14, standard library for the independent audit, mutation runner,
  assertion-preserving adapter, integrity checks, and deterministic builder.
- SymPy 1.14.0 and mpmath 1.3.0 for the original source checker only.
- Exact `fractions.Fraction` or SymPy rational arithmetic is used throughout
  the substantive finite identity tests; no floating tolerance is substituted.

No downloaded code, network call, or account access is needed for replay with
these dependencies already installed. Versions are pinned in `requirements.txt`.
