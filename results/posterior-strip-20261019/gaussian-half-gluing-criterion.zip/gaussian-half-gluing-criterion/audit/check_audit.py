#!/usr/bin/env python3
"""Independent exact checks. No asserts, so python -O preserves all checks."""
from fractions import Fraction as F
from itertools import product, combinations
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
checks = {}

def require(condition, message):
    if not condition:
        raise RuntimeError(message)

def dot(a, b):
    return sum(x*y for x,y in zip(a,b))

def conj(a):
    return (a[0], -a[1], -a[2], -a[3])

def mul(a, b):
    # P=q0 I + i q.sigma: vector multiplication uses MINUS cross product.
    return (a[0]*b[0]-dot(a[1:],b[1:]),
            a[0]*b[1]+b[0]*a[1]-a[2]*b[3]+a[3]*b[2],
            a[0]*b[2]+b[0]*a[2]-a[3]*b[1]+a[1]*b[3],
            a[0]*b[3]+b[0]*a[3]-a[1]*b[2]+a[2]*b[1])

def word(*args):
    value = (F(1),F(0),F(0),F(0))
    for arg in args:
        value = mul(value,arg)
    return value

def rational_unit(t):
    t = tuple(F(x) for x in t)
    r = dot(t,t)
    return ((1-r)/(1+r), *(2*x/(1+r) for x in t))

qs = [rational_unit(t) for t in product(range(-1,2), repeat=3)]
for a,b in product(qs, repeat=2):
    require(dot(a,a)==dot(b,b)==1, 'unit quaternion failure')
    require(mul(a,conj(b))[0]==dot(a,b), 'dagger trace sign failure')
    for beta in (F(0),F(1,7),F(9,2)):
        mgf_exponent = -beta + beta*dot(tuple(x+y for x,y in zip(a,b)),
                                      tuple(x+y for x,y in zip(a,b)))/2
        require(mgf_exponent==beta*dot(a,b), 'Gaussian exponent failure')
checks['quaternion_pairs'] = len(qs)**2
checks['gaussian_exponents'] = len(qs)**2*3

bond_count = 0
for n in range(120):
    vmx,vpx,vmy,vpy,tp,tm = [qs[(n*k+j)%len(qs)]
                            for j,k in enumerate((1,2,4,5,7,8))]
    ux,uy=mul(conj(vmx),vpx),mul(conj(vmy),vpy)
    physical=word(ux,tp,conj(uy),conj(tm))
    pp=word(vpx,tp,conj(vpy))
    pm=word(vmx,tm,conj(vmy))
    require(physical[0]==mul(pp,conj(pm))[0], 'bond plaquette identity')
    reflected=word(conj(ux),tm,uy,conj(tp))
    require(reflected[0]==physical[0], 'bond reflected trace identity')
    bond_count += 1
checks['bond_trace_words'] = bond_count

q8 = []
for i in range(4):
    for sign in (-1,1):
        q8.append(tuple(F(sign if j==i else 0) for j in range(4)))
counts = {u:0 for u in q8}
for a,b in product(q8,repeat=2):
    counts[mul(conj(a),b)] += 1
require(set(counts.values())=={8}, 'finite group Haar-subdivision analogue')
checks['finite_group_subdivision_analogue_pairs'] = 64

def add(x,i):
    y=list(x); y[i]+=1; return tuple(y)

geometry={'site':0,'bond':0,'diagonal':0,'asymmetric_cut_instances':0}
for d in (2,3,4):
    ranges=[range(-1,3), range(0,4), range(-2,2), range(1,4)][:d]
    vertices=set(product(*ranges))
    edges=[(x,add(x,i)) for x in vertices for i in range(d)
           if add(x,i) in vertices]
    plaquettes=[]
    for x in vertices:
        for i,j in combinations(range(d),2):
            vs=(x,add(x,i),add(add(x,i),j),add(x,j))
            if all(v in vertices for v in vs):
                plaquettes.append(vs)
    cuts=[]
    for i in range(d):
        for k in range(-2,4):
            cuts += [('site',i,None,k,0),('bond',i,None,k,0)]
    for i,j in combinations(range(d),2):
        for s in (-1,1):
            for k in range(-3,5):
                cuts.append(('diagonal',i,j,k,s))
    for kind,i,j,k,s in cuts:
        def level(x):
            if kind=='site': return x[i]-k
            if kind=='bond': return 2*x[i]-(2*k+1)
            return x[i]+s*x[j]-k
        def reflect(x):
            y=list(x)
            if kind=='site': y[i]=2*k-x[i]
            elif kind=='bond': y[i]=2*k+1-x[i]
            else:
                h=level(x); y[i]-=h; y[j]-=s*h
            return tuple(y)
        require(all(reflect(reflect(v))==v for v in vertices),'involution')
        require(all(level(reflect(v))==-level(v) for v in vertices),'side swap')
        if {reflect(v) for v in vertices}!=vertices:
            geometry['asymmetric_cut_instances']+=1
        for e in edges:
            require(sum(abs(a-b) for a,b in zip(*map(reflect,e)))==1,
                    'reflection preserves lattice edges')
            if kind!='bond':
                require(not (min(map(level,e))<0<max(map(level,e))),
                        'site/diagonal edge joins strict sides')
        for vs in plaquettes:
            h=list(map(level,vs))
            if min(h)<0<max(h):
                require(kind!='site','coordinate site crossing plaquette')
                require(set(map(reflect,vs))==set(vs),'crossing plaquette not fixed')
                if kind=='diagonal':
                    fixed=[v for v in vs if level(v)==0]
                    require(len(fixed)==2,'diagonal fixed corners')
                    require(sum(abs(a-b) for a,b in zip(*fixed))==2,
                            'diagonal corners not opposite')
                    plus=next(v for v in vs if level(v)>0)
                    minus=next(v for v in vs if level(v)<0)
                    require(reflect(plus)==minus,'diagonal paths not exchanged')
                    require(all(reflect(v)==v for v in fixed),'fixed corner moved')
                else:
                    ce=[(vs[t],vs[(t+1)%4]) for t in range(4)
                        if level(vs[t])*level(vs[(t+1)%4])<0]
                    require(len(ce)==2,'bond crossing edge count')
                    require(all(reflect(a)==b and reflect(b)==a for a,b in ce),
                            'bond crossing edge not orientation reversed')
                geometry[kind]+=1
        # Site cases have zero crossing plaquettes; record inspected plaquettes.
        if kind=='site': geometry[kind]+=len(plaquettes)
checks['geometry'] = geometry

# Complex defects checked without floating arithmetic, using (real,imag) pairs.
def cmul(a,b): return (a[0]*b[0]-a[1]*b[1],a[0]*b[1]+a[1]*b[0])
def cc(a): return (a[0],-a[1])
def cs(a,b): return (a[0]-b[0],a[1]-b[1])
def norm2(a): return dot(a,a)
zs=[(F(a,3),F(b,3)) for a,b in product(range(-2,3),repeat=2)]
for a,b in product(zs,repeat=2):
    v=cmul(cc(b),a)
    defect=norm2(cs(a,b))
    m=((a[0]+b[0])/2,(a[1]+b[1])/2)
    require(v[0]==norm2(m)-defect/4,'midpoint equality')
    require(v[0]>=-defect/4,'negative real part bound')
    require(v[1]*v[1]<=norm2(a)*defect,'imaginary mismatch bound')
checks['complex_pointwise_defects'] = len(zs)**2

tilt=[]
for n in (2,3,10,100):
    eps=F(1,n*n)
    pi=[1-eps,eps]
    z=[1,F(n)]
    partition=sum(pi[w]*z[w]**2 for w in range(2))
    rho=[pi[w]*z[w]**2/partition for w in range(2)]
    # Every conditional sign probability is strictly positive: 1/2 at w=0;
    # (3/4,1/4) and (1/4,3/4) for plus/minus at w=1.
    a=[F(0),F(1,2)]; b=[F(0),-F(1,2)]
    prior=sum(pi[w]*(a[w]-b[w])**2 for w in range(2))
    post=sum(rho[w]*(a[w]-b[w])**2 for w in range(2))
    q=sum(rho[w]*a[w]*b[w] for w in range(2))
    require(prior==eps,'prior defect')
    require(post==1/(2-eps),'posterior defect')
    require(q==-post/4 and q<F(-1,8),'persistent negative RP')
    tilt.append({'n':n,'prior_defect':str(prior),
                 'posterior_defect':str(post),'reflected_form':str(q)})
checks['strictly_positive_tilt_counterexample'] = tilt

# Escaping-label limit: average out one remote fair plane sign.
joint = {}
for x,y in product((-1,1),repeat=2):
    joint[(x,y)] = sum(F(1,2)*(1+F(x*z,2))*(1-F(y*z,2))/4
                       for z in (-1,1))
require(sum(joint.values())==1,'escaping-label normalization')
require(all(p>0 for p in joint.values()),'escaping-label positivity')
ex=sum(x*p for (x,y),p in joint.items())
ey=sum(y*p for (x,y),p in joint.items())
exy=sum(x*y*p for (x,y),p in joint.items())
require(ex==ey==0 and exy==F(-1,4),'escaping-label limiting correlation')
checks['escaping_label_counterexample'] = {
    'mean_plus':str(ex),'mean_minus':str(ey),'correlation':str(exy),
    'joint_sign_probabilities':{str(k):str(v) for k,v in joint.items()}}

# Explicit negative controls: statements that would break the proof.
e=(F(0),F(1),F(0),F(0))
require(mul(e,e)[0]==-1 and dot(e,e)==1,'dagger-removal control')
require(F(1)*dot((F(2),0,0,0),(F(2),0,0,0))/2 != 1,
        'Gaussian normalization-removal control')
require(sum(F(1,4)*(u-v)**2 for u,v in product((-1,1),repeat=2))==2,
        'latent defect RP counterexample')
checks['negative_controls']={
    'dropping_path_dagger_changes_trace_sign':True,
    'dropping_feature_normalizer_changes_gaussian_kernel':True,
    'untilted_defect_does_not_control_reflected_form':True,
    'latent_defect_need_not_vanish_under_physical_RP':True,
}

payload={'status':'PASS','checks':checks,
         'scope':'Exact finite checks supplement the analytic proof; no Wilson mismatch decay is proved.'}
print(json.dumps(payload,indent=2,sort_keys=True))
