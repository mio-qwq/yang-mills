# Independent audit of normalized Gaussian half-gluing

19 October 2026. Mathematical audit and local verification only.

## Verdict and exact scope

**PASS as a conditional theorem.** I find no substantive flaw in the finite-volume Gaussian factorization, the normalized mismatch inequalities, or the simultaneous fixed-coupling limit theorem in the audited report. The full-state spatial-symmetry argument also works with the stated full-half-algebra hypothesis.

The audited source is `../gaussian-half-gluing-20261019-1440/RESULT.md`, SHA256

`951297ea6dc798f5abd8aaed2d99fd17f257baa9f47fb68396274c2fead8cde9`.

A byte-identical copy is retained as `SOURCE_RESULT.md`.

The theorem is a **sufficient reduction to annealed normalized conditional-kernel matching**, not a proof that this matching occurs. It gives neither an all-beta Wilson boundary-decay estimate nor a weak-bare-coupling continuum theorem. In particular, it does not close the earlier state-selection gap without its additional mismatch hypothesis.

The independent checks cover 729 exact rational quaternion pairs, 2,187 Gaussian exponent identities, 120 full bond-plaquette trace identities, 625 complex midpoint/defect identities, 1,458 bond-crossing and 1,426 signed-diagonal-crossing plaquettes, and coordinate-site noncrossing geometry. The finite domains include 245 asymmetric cut instances. All checks pass identically under ordinary Python and `python -O`.

## 1. Quaternion sign and positive Gaussian identity

With the source convention

    P = q0 I + i(q1 sigma1 + q2 sigma2 + q3 sigma3),

the vector part of quaternion multiplication uses **minus** the three-dimensional cross product. The checker uses this convention explicitly rather than importing a Hamilton-product sign convention unnoticed.

Independently of that notational choice,

    (1/2) Re Tr(P Q†) = q(P) · q(Q).

Thus the two half paths must run between the same fixed endpoints in the same endpoint order, so that the plaquette is `P+ (P-)†`. Dropping the dagger is not harmless: taking `P=Q=i sigma1` gives trace scalar `-1` for `P Q`, while `q(P)·q(Q)=1`.

For beta>=0 and xi~N(0,I4), the proposed feature

    phi(xi,P) = exp(sqrt(beta) xi·q(P) - beta/2)

satisfies

    E phi(xi,P) phi(xi,Q)
      = exp[-beta + (beta/2)|q(P)+q(Q)|²]
      = exp[beta q(P)·q(Q)].

Both unit-norm assumptions are used. The `-beta/2` in **each** feature is also needed: omitting it multiplies each crossing factor by `exp(beta)`. That constant could cancel in the final normalized physical measure if consistently retained, but the displayed exact kernel identity and partition functions would then be wrong.

The argument covers arbitrary finite nonnegative beta, including beta=0. It does not cover a negative Wilson coupling through this positive real feature formula. All Gaussian reference variables are independent before reweighting, but are generally neither independent nor standard Gaussian under their actual posterior law.

## 2. Bond subdivision and orientation

For a coordinate bond cut, write the physical normal link from its minus endpoint to its plus endpoint as

    U_x = (V_x^-)† V_x^+,

where both V variables are independent normalized Haar transporters from the midpoint to the corresponding endpoint. Haar left invariance gives

    ∫ f((V_x^-)† V_x^+) dV_x^- dV_x^+ = ∫ f(U_x) dU_x.

Applying this separately to each crossing edge proves the full joint Haar pushforward. No gauge-group-volume denominator or additional coupling is present. The checker also verifies the corresponding counting statement on the eight-element quaternion group; this is a finite-group analogue, not a substitute for the Haar argument above.

If T+ and T- are the two tangential links oriented from x to y on their respective sides, define midpoint-to-midpoint paths

    P+ = V_x^+ T+ (V_y^+)†,
    P- = V_x^- T- (V_y^-)†.

Then cyclicity of trace gives

    Tr(P+ (P-)†)
      = Tr[U_x T+ U_y† (T-)†].

Reflection exchanges the two V variables at each midpoint, hence sends each physical crossing link U to U†, as it should. It exchanges P+ and P- without changing their endpoint order. The 120 exact rational tests check the full noncommutative word, not just pairwise trace identities.

This proves a result for physical tests using original links whose endpoints lie on one side of the bond plane. It does **not** include an original complete crossing link in the physical positive-half algebra. Nor may the new half-link variables silently become physical tests. The source states both restrictions correctly.

## 3. Signed-diagonal and asymmetric-volume geometry

For a signed-diagonal plane

    x_i + s x_j = k,  s in {-1,1},  k integer,

put h(x)=x_i+s x_j-k. The reflection sends

    x_i -> x_i-h(x),   x_j -> x_j-s h(x),

and fixes the other coordinates. This is an integer-lattice automorphism. Each nearest-neighbor edge changes h by 0 or ±1, so no edge can join h<0 directly to h>0. A crossing elementary plaquette must use directions i,j and have two opposite fixed vertices and one vertex on either strict side. The two length-two paths between the fixed vertices are exchanged in the same endpoint order.

Each such crossing plaquette is individually reflection-fixed. Consequently a crossing plaquette already present in an asymmetric finite induced complex brings all of its own reflected links with it. This does not make the whole complex or all its side interactions reflection invariant.

For coordinate-site cuts, the same unit-span argument excludes any plaquette meeting both strict sides. Tangential plane links are pointwise fixed, including orientation. For coordinate-bond cuts, every crossing plaquette and each unoriented crossing link are individually fixed, and each crossing link is reversed.

To compare unequal half domains, one may embed both in any finite reflected ambient link set containing the original complex and its reflection. Every added link has independent normalized Haar measure. **All absent original interactions remain absent or have zero coupling**, including extra plaquettes that happen to appear if one takes the induced complex on a union of vertices. Restoring them would change the law. Also both F and its reflected support must be original physical links when the finite form is called a form of the original measure. A genuine exhaustion guarantees this eventually for each fixed local test.

No arbitrary real diagonal offset is covered: integrality of k is essential. The audit does not promote these lattice cuts to all Euclidean reflection planes.

## 4. Conditional factorization and the indispensable posterior tilt

Let nu be the product of plane Haar measure and crossing standard Gaussian measures. Let S0 be the fixed-plane Wilson action, and K+(W,Y+), K-(W,Y-) the two positive half weights. Define

    Z±(W) = ∫ K±(W,Y±) dH±(Y±),
    P±(dY±|W) = K±(W,Y±) dH±(Y±)/Z±(W),
    rho(dW) = Z^-1 exp(S0(W)) Z+(W) Z-(W) nu(dW).

The correct augmented law is precisely

    rho(dW) P+(dY+|W) P-(dY-|W).

All half partitions are finite and strictly positive for every finite W because the group variables are compact and all finite-volume actions are bounded for fixed W. Integrating the positive joint integrand in the Gaussian variables recovers a bounded finite-volume Wilson integrand, so Tonelli proves integrability and legitimizes rearrangement.

Common Gaussian coordinates create dependencies **within** a half when several crossing plaquettes share links; they do not spoil the product separation **between** halves conditional on W. The reflection acts trivially on each actual crossing-plaquette Gaussian index, since that plaquette is itself fixed, and fixes the physical plane links. It therefore identifies the two conditional means using the same W. Since W is fixed pointwise, its marginal is unchanged by swapping the halves; this does not identify the two conditional kernels or make the augmented joint law reflection invariant. No reflection invariance of the physical law is assumed.

The absence of an explicit partition-ratio or surface-area prefactor in the final bound is valid because the half kernels are normalized probabilities. The dependence on boundary size, beta, and geometry remains inside rho and the mismatch. No smallness follows from the normalization itself.

### Strictly positive counterexample to replacing rho by nu

For each integer n>=2, take W in {0,1} with prior

    nu_n(W=1)=1/n²,  nu_n(W=0)=1-1/n².

Let both half partition functions be 1 at W=0 and n at W=1. The normalized posterior then satisfies

    rho_n(W=1)=1/(2-1/n²) -> 1/2.

On each half take a sign X or Y. At W=0 both are conditionally fair. At W=1 let

    P(X=1|W=1)=3/4,   P(Y=1|W=1)=1/4,

and keep conditional independence. All conditional sign probabilities and all finite-volume unnormalized weights are strictly positive. For F(sign)=sign, the conditional means at W=1 are a=1/2 and b=-1/2; both vanish at W=0. Hence

    E_nu |a-b|² = 1/n² -> 0,
    E_rho |a-b|² = 1/(2-1/n²) -> 1/2,
    Q_n(F) = -1/[4(2-1/n²)] -> -1/8.

So even convergence in prior mean square and bounded tests do not control RP without the posterior weighting. The counterexample is a conditional-probability model, **not** an SU(2) Wilson counterexample. A Gaussian-prior analogue is obtained by putting W=1 on a Gaussian tail event of probability 1/n² and using the same positive weights there. No uniform-integrability assumption for the tilt is available merely from the reference Gaussian.

## 5. Defect bounds, complex reality, and finite families

For a bounded physical positive-half F, set a=P+F, b=P-F after reflected identification, M=||F||infinity, and

    D(F)=E_rho |a-b|².

Because these are probability kernels, |a|,|b|<=M. Conditional independence gives

    Q(F)=E_rho overline(b)a.

With m=(a+b)/2, the exact identity is

    Re Q(F)=E|m|²-D(F)/4 >= -D(F)/4.

The coefficient 1/4 is sharp, as the preceding positive finite-state counterexample shows. Comparing with the nonnegative number E|a|² gives the full complex estimate

    dist(Q(F),[0,infinity)) <= M sqrt(D(F)),
    |Im Q(F)| <= M sqrt(D(F)).

Thus the criterion controls reality as well as a negative real part. Merely checking the latter would not establish RP. The mean asymmetry satisfies |mu(F)-mu(F composed with theta)|<=sqrt(D(F)).

For a finite family, write T_a z=Σ z_i a_i and T_d z=Σ z_i(a_i-b_i). The reflected Gram difference from A_ij=E overline(a_i)a_j is `-T_d* T_a`, so

    ||G-A|| <= sqrt(||D|| ||A||)
             <= sqrt(||D|| Σ_i ||F_i||infinity²).

Its Hermitian part plus D/4 is exactly the Gram matrix of the midpoint functions. These calculations establish the source's matrix bounds, with no entrywise-to-operator-norm gap. Vanishing of finitely many diagonal defects gives vanishing trace of the positive defect matrix, hence vanishing norm.

Subtracting the complex constant mu(F) leaves a-b unchanged. The identity Q(F-mu(F))=Q(F)-mu(Theta F)mu(F) holds even before reflection invariance has been proved. Its norm is at most 2M, giving the stated safe connected-form bound.

If F_a=M_a f_a and ||f_a||infinity<=1, the full complex sufficient condition is M_a² sqrt(D_a(f_a))->0. The weaker condition M_a² D_a(f_a)->0 alone only controls the possible negative real part. Actual supports, coefficients, and deterministic source normalization must be retained.

## 6. One common physical sequence and symmetry

At fixed finite beta, extend each finite free law to the countable full lattice by independent Haar variables. The configuration space SU(2)^E is compact metrizable. A single local weakly convergent subsequence therefore exists.

If for **that same physical sequence** D_n,theta(F)->0 for every fixed required cut and fixed bounded continuous local positive-half F, then the physical local product (Theta F)F is continuous and the complex bound passes to the chosen limit. The limit form is a nonnegative real number. The same limit works for every cut and test: weak convergence concerns all continuous tests, and there is no need to take separate auxiliary weak limits or separate physical subsequences cut by cut. Countability allows a countable dense test formulation but is not a license to change the underlying measure by reflection-specific averaging.

A countable rational complex cylinder algebra is enough. Indeed sqrt(D(F)) is the L2 norm of the linear map F->a_F-b_F, which changes by at most 2||F-G||infinity when F is replaced by G. Uniform approximation extends the hypothesis to each fixed continuous cylinder F.

For any finite set of updated links, its finite interaction neighborhood eventually lies in every exhausting box. The finite-volume law then satisfies the exact Wilson local conditional identity. The finite-beta specification maps continuous local functions to continuous local functions, so the identity passes to the limit. Gauge invariance passes the same way. This proves a gauge-invariant DLR cluster point without uniqueness. It proves neither full-sequence convergence nor a continuum DLR statement at beta_n->infinity.

### Full spatial symmetry claim

The extra symmetry paragraph in the source is valid on the **full** physical half algebra:

1. For a site cut, RP polarization makes B(f,g)=mu[(overline(g) composed with theta)f] Hermitian. Consequently mu[(overline(g) composed with theta)f]=mu[(f composed with theta)overline(g)]. The two sides are a cylinder product and its reflection.
2. Because site cuts have no link joining the strict sides, products of half observables generate a uniformly dense cylinder algebra, with shared plane links allowed. Thus this equality implies reflection invariance of the whole state.
3. Coordinate-site reflections at levels 0 and 1 generate even lattice translations in the corresponding direction.
4. For any cylinder H and a given bond cut, translate H by a sufficiently large even normal translation T so that its support lies in the allowed bond-positive half. The mean-mismatch limit gives equality of the translated test and its reflection. Even-translation invariance and theta T=T^-1 theta translate that equality back to H. Hence the full state is bond-reflection invariant despite excluding crossing links from the original bond-positive algebra.
5. A coordinate-site reflection composed with its adjacent bond reflection gives a unit translation. Coordinate-site sign flips and origin diagonal reflections generate the hypercubic point group.

These steps use one state and fixed finite tests throughout. Full symmetry should not automatically be inferred when the mismatch hypothesis is imposed only on a smaller gauge-invariant observable sector. The source properly retains that qualification.

## 7. Conditional-state pitfalls and what is not proved

The mismatch is sufficient, not necessary, for physical RP. For example, let W=(U,V) be independent uniform signs, let the plus sign equal U and the minus sign equal V conditional on W, and then forget W. The physical signs are independent and identically distributed, hence RP, while the latent defect for the sign test is E(U-V)²=2. In particular an auxiliary centering function involving W need not be an admissible physical local observable.

Finite conditional independence also cannot be passed through an increasing infinite-plane conditioning without proof. An elementary escape-of-information example makes the issue explicit. Let plane signs Z_1,Z_2,... be independent and fair. For the n-th measure, conditionally on them let X,Y be independent signs with means Z_n/2 and -Z_n/2. For every n the two halves are conditionally independent given the plane. In the local weak limit, (X,Y) is independent of every finite plane subset, hence of the full plane sigma-algebra, but E(XY)=-1/4 while both conditional means are zero. The limiting halves are not conditionally independent given the limiting plane. All conditional probabilities in this example are positive. Its interactions are not a fixed finite-range Wilson interaction, so it is a measure-theoretic warning only, not a Wilson counterexample.

The source's stronger general finite-range warning is consistent with Robert B. Israel's paper, *Some examples concerning the global Markov property*, Communications in Mathematical Physics 105 (1986), 669–673. The author's [publication list](https://personal.math.ubc.ca/~israel/) confirms the bibliographic reference, and the [author-uploaded paper](https://www.researchgate.net/publication/38329904_Some_examples_concerning_the_global_Markov_property) states that extremal Gibbs examples can fail the global Markov property, including a translation-invariant example. This citation supplies a guardrail; the Gaussian theorem here avoids that issue by remaining at finite volume until physical local expectations are passed to the limit.

The source's positive-semidefinite finite-phase-coupling criterion is also correct. Symmetry or equality of phase marginals alone is insufficient: the anti-aligned two-phase matrix with off-diagonal entries 1/2 has eigenvalue -1/2 and sign-test form -1. The necessity statement in the source is explicitly conditional at fixed physical z and assumes linearly independent sector laws, which is the required scope.

Finally, the recovered q=18 beta<1 estimate already controls physical reflected products by direct Dobrushin comparison. It is neither a new result of this Gaussian reduction nor a proof of this particular auxiliary defect decay. The conditional half actions contain unbounded Gaussian-dependent coefficients, so the old physical influence bound cannot be reused under arbitrary auxiliary conditioning without a separate argument. The source now states this point explicitly.

## 8. Final stopping point

The exact all-finite-beta factorization and the conditional common-limit theorem may be retained as proved reductions with the stated hypotheses. The unresolved substantive input is still the actual common-volume local normalized mismatch decay, or another proved physical local comparison/positive phase-law approximation, in the required four-dimensional weak-coupling regime.

No review finding authorizes describing joint all-beta Wilson RP, full boundary independence, uniqueness, a continuum limit, or a mass gap as solved. No external state was changed in this audit.

`check_audit.py`, `CHECKS.json`, and `CHECKS.optimized.json` are supplementary finite exact checks. `SHA256SUMS` records the deliverable bytes. The counterexamples disprove omitted-assumption variants only; they are not counterexamples to the correctly normalized conditional theorem.
