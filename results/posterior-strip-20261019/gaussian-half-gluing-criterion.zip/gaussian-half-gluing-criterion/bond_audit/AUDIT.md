# Audit: Gaussian half-gluing and a common conditional RP limit

19 October 2026. Read-only mathematical audit; no repository or external modification.

## Verdict

The proposed coordinate-bond gluing identity and both mismatch bounds are correct for every finite **nonnegative** Wilson coupling. The same Gaussian construction handles lattice-preserving signed-diagonal cuts. It gives an exact finite-volume conditional factorization, and an independently proved vanishing-mismatch hypothesis gives simultaneous reflection positivity of every subsequential DLR limit of one common exhausting physical sequence. It does **not** prove the vanishing-mismatch hypothesis, full-sequence convergence, or a weak-bare-coupling continuum theorem.

The latent expectation must use the **tilted latent marginal**, not the original standard Gaussian law. Dummy variables may be added only with zero coupling for interactions absent from the original physical volume. These are substantive qualifications, not failures of the construction.

## 1. Coordinate-bond orientations and Haar measure

Use path-ordered multiplication along paths, and let the cut be x0=a+1/2, a integer. A crossing edge e_x joins x=(a,z) to x+e0=(a+1,z). Introduce independent normalized Haar variables V_x^- and V_x^+, oriented from its midpoint m_x to its minus and plus endpoints, respectively. Then

    U_x = (V_x^-)† V_x^+.

For any integrable function f, the Haar change of variables V_x^+=V_x^- U_x gives

    ∫ f((V_x^-)†V_x^+) dV_x^- dV_x^+ = ∫ f(U_x) dU_x.

This holds jointly for all crossing edges: the physical edge variables remain independent normalized Haar before reweighting. No missing group-volume factor occurs. Reflection exchanges V_x^- and V_x^+, and therefore sends U_x to U_x†, exactly as required because the original crossing edge is individually reversed.

For a crossing (0,j) plaquette, let its crossing edges be e_x and e_y, y=x+e_j, and let U_j^- and U_j^+ be the tangential links on its minus and plus sides. The two midpoint-to-midpoint paths, both oriented m_x→m_y, are

    P^- = V_x^- U_j^- (V_y^-)†,
    P^+ = V_x^+ U_j^+ (V_y^+)†.

Cyclicity of trace gives

    Tr(P^+ (P^-)†)
      = Tr(U_x U_j^+ U_y† (U_j^-)†).

Thus the proposed Wilson trace is exactly correct. Reflection exchanges P^+ and P^- without changing their fixed endpoint order. An orientation reversal of the whole plaquette does not matter because its SU(2) trace is real.

Every coordinate-bond crossing elementary plaquette is individually fixed as an unoriented plaquette by reflection. Therefore it cannot have an unmatched reflected crossing interaction, even in an asymmetric induced domain. This assertion concerns a single crossing plaquette, not reflection invariance of the whole action.

## 2. Positive Gaussian factorization

Write P=q0 I+i q·σ, where q(P) is a real unit vector in R4. Then

    w_p = q(P^+)·q(P^-).

For ξ_p a standard R4 Gaussian and β≥0,

    h_p^± = exp(√β ξ_p·q(P^±) − β/2),
    E[h_p^+ h_p^-] = exp(β w_p).

Indeed, the Gaussian moment generating function gives exponent

    (β/2)|q(P^+)+q(P^-)|² − β = β q(P^+)·q(P^-).

Independent Gaussians for different crossing plaquettes reproduce the full crossing action. Their factors can share side variables; this creates interactions within a half but does not spoil the product separation between the halves. The half factors are positive real weights, so the conditional kernels are probability kernels. At β=0 the Gaussian variables are harmless dummies. Negative β is not covered by this positive-factor proof.

## 3. Exact conditional product law and normalization

Let W contain all crossing-plaquette Gaussians and, for site/diagonal cuts, all fixed-plane tangent links. Let Y^± contain the remaining original or half-link variables on the corresponding side. With normalized product base measures dH^±, write

    K_±(W,Y^±) = exp(S_±(W,Y^±)) ∏_p h_p^±(W,Y^±),
    Z_±(W) = ∫ K_±(W,Y^±) dH^±(Y^±),
    P_±(dY^±|W) = K_±(W,Y^±) dH^±(Y^±)/Z_±(W).

Here S_± already includes the Wilson coupling. The fixed-plane action is S0(W); it is absent for a coordinate-bond cut. If ν is product normalized Haar on fixed-plane links times product standard Gaussian law, the latent marginal is

    ρ(dW) = Z^-1 exp(S0(W)) Z_+(W) Z_-(W) ν(dW).

The exact augmented law is

    ρ(dW) P_+(dY^+|W) P_-(dY^-|W).

It pushes forward to the original finite-volume physical Wilson law. In particular, ξ is standard Gaussian only in the reference measure ν, and generally is neither standard nor independent under the reweighted marginal ρ.

Reflection fixes W pointwise and identifies the two ambient half configuration spaces. It does not assert P_+=P_- in an asymmetric physical volume.

## 4. Symmetric completion, scope of tests, and other cuts

For asymmetric domains, use any finite reflection-invariant ambient complex containing Λ and θΛ; the induced union is one option. Add normalized Haar variables for missing links and give every absent original interaction coupling zero. New plaquettes that happen to appear in an induced union are also zero-coupling. Otherwise the original physical measure would change.

A physical bond-positive test F uses only original links whose endpoints lie on the positive side; it excludes the original crossing edges. A test may be represented on the augmented positive half because these links are unsplit. To call the resulting reflected form an expectation under the original μ_Λ, both F and its reflection must be supported on original links in Λ. If θF instead uses added dummies, the form belongs to the extended measure. This distinction disappears eventually for fixed local tests in a genuine exhaustion.

For a coordinate-site cut xi=c, c integer, no elementary plaquette meets both strict half-spaces. Fixing the tangent plane links gives the usual product factorization without crossing Gaussians.

For a signed-diagonal cut xi+s xj=c, s∈{−1,1}, c integer, the reflection is

    θ_i(x)=c−s xj,  θ_j(x)=s(c−xi),  θ_k(x)=xk for k≠i,j.

Nearest-neighbor edges never join the two strict half-spaces. The only straddling plaquettes are (i,j) diamonds with two opposite vertices on the fixed plane. They are individually reflection-fixed. Their positive and negative length-two paths have the same fixed lattice-vertex endpoints, so the Gaussian factorization above applies directly, without midpoint edge splitting. Fixed-plane tangent links are in directions k≠i,j and are pointwise fixed, including their orientation. Plaquette terms entirely in the plane belong to S0.

These statements cover lattice-preserving affine cuts only. An arbitrary real affine offset need not define a lattice reflection.

## 5. Mismatch identities and bounds

For a bounded physical positive-half test with |F|≤M, set

    a(W)=E[F|W] under P_+,
    b(W)=E[F∘θ|W] under P_-.

With ΘF=overline(F∘θ), conditional independence gives exactly

    Q_μ(F)=E_μ[(ΘF)F]=E_ρ[overline(b)a].

Put δ²=E_ρ|a−b|². Then

    Re Q_μ(F)=E_ρ|(a+b)/2|²−δ²/4 ≥−δ²/4.

Moreover E_ρ|a|² is a nonnegative real number and

    |Q_μ(F)−E_ρ|a|²|
       = |E_ρ[(overline(b)−overline(a))a]|
       ≤ δ ||a||_2 ≤ Mδ.

Hence

    dist(Q_μ(F),[0,∞)) ≤ Mδ.

The distance is in the complex plane and controls a nonzero imaginary part as well as negativity. A version with ||b||_2 follows symmetrically.

The criterion is sufficient and depends on the chosen augmentation. Although one can algebraically center by (a+b)/2 on the augmented space, this function generally depends on Gaussian variables that are not physical links. Thus this centering cannot automatically produce a physical negative witness or transfer the earlier site-cut necessity/equivalence theorem to bond or diagonal cuts.

## 6. One common DLR limit, with no uniqueness assumption

Fix d and β∈[0,∞). Let Λ_n eventually contain every fixed finite lattice set and its plaquette neighborhood, and let μ_n be the same sequence of physical free Wilson measures, extended outside Λ_n by any convenient independent Haar variables. Suppose that for every lattice-preserving coordinate-site/bond or signed-diagonal cut θ, and every fixed bounded continuous local positive-half F,

    δ_n(θ,F)² = E_{ρ_{n,θ}}|a_{n,θ,F}−b_{n,θ,F}|² → 0.

The latent constructions may differ with θ; the physical μ_n must not.

The countable product SU(2)^E is compact metrizable, so choose a single weakly convergent subsequence μ_nk→μ. For each fixed θ,F, the physical integrand (ΘF)F is continuous and local. Thus

    Q_μ(F)=lim_k Q_{μ_nk}(F) ∈ [0,∞).

This same subsequence and μ work for all θ,F: weak convergence is already simultaneous for every continuous test, and each mismatch estimate concerns the original physical sequence. One does not choose a different state for each reflection. In fact every local cluster point has all these inequalities.

The finite-range bounded continuous Wilson interaction has continuous finite-volume conditional expectations. Once the interaction neighborhood of a fixed finite link set lies in Λ_n, the finite-volume law obeys the exact corresponding Gibbs conditional identity. Passing that identity to the local limit establishes the DLR equations for μ. This step uses exhaustion and fixed finite β, not uniqueness.

Continuous-local RP extends, if desired, to bounded measurable local or half-space observables by approximating in L² of the sum of the positive-half marginals of μ and θ_*μ. Cauchy–Schwarz passes the reflected products to the limit. Alternatively, a countable uniformly dense cylinder algebra including rational complex linear combinations suffices to test the hypothesis and obtain all continuous-local inequalities.

The conclusion is existence of a common subsequential state, not convergence of the entire sequence. If β_n→β<∞, the same argument works with the limiting β specification. If β_n→∞, the fixed-β DLR passage does not apply; a separate zero-temperature or continuum formulation is needed. Changing lattice spacing, growing supports, source renormalizations, and continuum test convergence also require independent estimates.

## 7. What remains unproved

The gluing supplies an exact reformulation, not decay of δ_n. In particular:

- Asymmetry of the finite halves is not removed by adding dummies.
- Gauge invariance and reflection-fixed latent variables do not force equality of the two conditional kernels.
- Ordinary approximate physical RP does not imply this specific latent mismatch tends to zero.
- Conditional Gaussian half interactions have unbounded ξ-dependent coefficients; a uniform conditional mixing estimate cannot be borrowed without checking it.
- The earlier physical strong-coupling seam comparison bounds reflected products directly and does not, by itself, establish this Gaussian conditional mismatch criterion.

Consequently there is no identified algebraic flaw, but the all-β vanishing-mismatch theorem remains the substantive missing input.

## Verification artifact

`check_gluing.py` performs 20 exact-rational quaternion checks of the full plaquette orientation, Gaussian exponent, and crossing-edge inversion under reflection. It also enumerates all local elementary-plaquette patterns in dimensions 3 and 4 for coordinate-site, coordinate-bond, and both signed-diagonal cuts at three offsets, confirming the classifications above. These supplement the general proofs; they do not estimate any infinite-volume mismatch.
