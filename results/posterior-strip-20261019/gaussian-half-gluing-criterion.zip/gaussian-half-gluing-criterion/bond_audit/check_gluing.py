from fractions import Fraction as F
from itertools import combinations, product

def q(t):
    t=list(map(F,t)); s=sum(x*x for x in t); return ((1-s)/(1+s),*(2*x/(1+s) for x in t))
def mul(a,b):
    a0,a1,a2,a3=a; b0,b1,b2,b3=b
    return (a0*b0-a1*b1-a2*b2-a3*b3,
            a0*b1+a1*b0+a2*b3-a3*b2,
            a0*b2-a1*b3+a2*b0+a3*b1,
            a0*b3+a1*b2-a2*b1+a3*b0)
def inv(a): return (a[0],-a[1],-a[2],-a[3])
def pm(*args):
    z=(F(1),F(0),F(0),F(0))
    for a in args:z=mul(z,a)
    return z
def dot(a,b):return sum(x*y for x,y in zip(a,b))
for k in range(1,21):
    vmx,vpx,vmy,vpy,um,up=[q((F(k+j,7),F(j-2,5),F(k-j,11))) for j in range(6)]
    ux=pm(inv(vmx),vpx); uy=pm(inv(vmy),vpy)
    pp=pm(vpx,up,inv(vpy)); pn=pm(vmx,um,inv(vmy))
    wilson=pm(ux,up,inv(uy),inv(um))[0]
    assert wilson==dot(pp,pn)==pm(pp,inv(pn))[0]
    assert dot(pp,pp)==dot(pn,pn)==1
    assert F(1,2)*sum((a+b)**2 for a,b in zip(pp,pn))-1==wilson
    assert pm(inv(vpx),vmx)==inv(ux)
print('20 exact-rational quaternion orientation, inverse-reflection, and Gaussian-exponent checks passed.')

counts={}
for d in (3,4):
    def add(x,i):
        y=list(x);y[i]+=1;return tuple(y)
    for kind in ('site','bond','diag+','diag-'):
        for c in (-1,0,1):
            if kind=='site':
                h=lambda x:x[0]-c
                th=lambda x:(2*c-x[0],*x[1:])
            elif kind=='bond':
                h=lambda x:2*x[0]-2*c-1
                th=lambda x:(2*c+1-x[0],*x[1:])
            else:
                s=1 if kind=='diag+' else -1
                h=lambda x,s=s:x[0]+s*x[1]-c
                th=lambda x,s=s:(c-s*x[1],s*(c-x[0]),*x[2:])
            crossing=0
            for x in product(range(-2,3),repeat=d):
                for i,j in combinations(range(d),2):
                    p={x,add(x,i),add(x,j),add(add(x,i),j)}
                    hs=[h(v) for v in p]
                    if min(hs)<0<max(hs):
                        crossing+=1
                        assert {th(v) for v in p}==p
                        if kind=='bond':assert i==0
                        elif kind.startswith('diag'):
                            assert (i,j)==(0,1)
                            assert sum(t==0 for t in hs)==2
                        else:raise AssertionError('Site-cut crossing plaquette')
                for i in range(d):
                    y=add(x,i)
                    if h(x)*h(y)<0:
                        assert kind=='bond' and th(x)==y and th(y)==x
            counts[(d,kind,c)]=crossing
print('All coordinate-site/bond and signed-diagonal crossing classifications passed in dimensions 3 and 4, at three offsets.')
print(counts)
