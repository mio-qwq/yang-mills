#!/usr/bin/env python3
"""Exact finite checks supplementing, not replacing, RESULT.md proofs."""
from fractions import Fraction as F
from itertools import product, combinations
from pathlib import Path
import json
import sympy as s


def add(x, y):
    return tuple(a + b for a, b in zip(x, y))


def sub(x, y):
    return tuple(a - b for a, b in zip(x, y))


def geometry():
    cases = crosses = crossing_links = 0
    counts = {"site": 0, "bond": 0, "diagonal": 0}
    for dim in (2, 3, 4):
        bounds = [(-2, 3), (-1, 4), (-2, 2), (-1, 2)][:dim]
        vertices = set(product(*(range(lo, hi + 1) for lo, hi in bounds)))
        basis = [tuple(int(k == j) for k in range(dim)) for j in range(dim)]
        edges = [(x, add(x, e)) for x in vertices for e in basis if add(x, e) in vertices]
        squares = []
        for x in vertices:
            for i, j in combinations(range(dim), 2):
                p = (x, add(x, basis[i]), add(add(x, basis[i]), basis[j]), add(x, basis[j]))
                if all(v in vertices for v in p):
                    squares.append(p)
        cuts = []
        for i in range(dim):
            for k in (0, 1):
                cuts.append(("site", i, None, 1, k))
                cuts.append(("bond", i, None, 1, 2 * k + 1))
        for i, j in combinations(range(dim), 2):
            for sign in (-1, 1):
                for k in (0, 1):
                    cuts.append(("diagonal", i, j, sign, k))
        for kind, i, j, sign, k in cuts:
            def level(x):
                if kind == "bond":
                    return 2 * x[i] - k
                if kind == "site":
                    return x[i] - k
                return x[i] + sign * x[j] - k

            def reflect(x):
                y = list(x)
                if kind == "site":
                    y[i] = 2 * k - x[i]
                elif kind == "bond":
                    y[i] = k - x[i]
                else:
                    h = level(x)
                    y[i] -= h
                    y[j] -= sign * h
                return tuple(y)

            cases += 1
            for u, v in edges:
                if level(u) * level(v) < 0:
                    assert kind == "bond"
                    assert reflect(u) == v and reflect(v) == u
                    crossing_links += 1
            for p in squares:
                levels = [level(x) for x in p]
                if min(levels) < 0 < max(levels):
                    assert kind != "site"
                    assert {reflect(x) for x in p} == set(p)
                    counts[kind] += 1
                    crosses += 1
                    if kind == "diagonal":
                        fixed = [x for x in p if level(x) == 0]
                        plus = [x for x in p if level(x) > 0]
                        minus = [x for x in p if level(x) < 0]
                        assert len(fixed) == 2 and len(plus) == len(minus) == 1
                        assert all(reflect(x) == x for x in fixed)
                        assert reflect(plus[0]) == minus[0]
                        assert all(sum(abs(z) for z in sub(v, w)) == 1
                                   for v in fixed for w in plus + minus)
                    else:
                        assert levels.count(-1) == levels.count(1) == 2
                        pe = list(zip(p, p[1:] + p[:1]))
                        ce = [(u, v) for u, v in pe if level(u) * level(v) < 0]
                        assert len(ce) == 2
                        assert all(reflect(u) == v and reflect(v) == u for u, v in ce)
    return {"cut_cases": cases, "self_reflected_crossing_plaquettes": crosses,
            "self_reversed_crossing_links": crossing_links, "counts": counts}


def quat(t):
    norm = sum(x * x for x in t)
    den = 1 + norm
    return (F(1 - norm, den),) + tuple(F(2 * x, den) for x in t)


def mul(a, b):
    a0, x, y, z = a
    b0, u, v, w = b
    return (a0 * b0 - x * u - y * v - z * w,
            a0 * u + b0 * x + y * w - z * v,
            a0 * v + b0 * y + z * u - x * w,
            a0 * w + b0 * z + x * v - y * u)


def inv(a):
    return (a[0],) + tuple(-x for x in a[1:])


def chain(*qs):
    ans = (F(1), F(0), F(0), F(0))
    for q in qs:
        ans = mul(ans, q)
    return ans


def quaternion_checks():
    units = [quat(t) for t in product(range(-1, 2), repeat=3)]
    for q in units:
        assert sum(x * x for x in q) == 1
    trace_checks = gauss_checks = 0
    for k in range(120):
        xm, xp, ym, yp, tm, tp = [units[(k * (j + 2) + j * j) % len(units)] for j in range(6)]
        ux = mul(inv(xm), xp)
        uy = mul(inv(ym), yp)
        physical = chain(ux, tp, inv(uy), inv(tm))
        pp = chain(xp, tp, inv(yp))
        pm = chain(xm, tm, inv(ym))
        paired = mul(pp, inv(pm))
        assert physical[0] == paired[0]
        assert paired[0] == sum(x * y for x, y in zip(pp, pm))
        trace_checks += 1
        for beta in (F(0), F(1, 100), F(7, 3), F(10**6)):
            gaussian_exp = beta * sum((x + y) ** 2 for x, y in zip(pp, pm)) / 2 - beta
            wilson_exp = beta * sum(x * y for x, y in zip(pp, pm))
            assert gaussian_exp == wilson_exp
            gauss_checks += 1
    return {"exact_rational_bond_trace_checks": trace_checks,
            "exact_gaussian_exponent_checks": gauss_checks}


def defect_checks():
    weights = [s.Rational(1, 6), s.Rational(1, 3), s.Rational(1, 2)]
    a = [s.Rational(1, 2) + s.I / 3, -s.I / 2, s.Rational(-2, 3)]
    b = [-s.I / 3, s.Rational(2, 3), s.Rational(1, 4) + s.I / 2]
    avg = lambda xs: s.simplify(sum(w * x for w, x in zip(weights, xs)))
    abs2 = lambda x: s.expand(x * s.conjugate(x))
    Q = avg([s.conjugate(y) * x for x, y in zip(a, b)])
    D = avg([abs2(x - y) for x, y in zip(a, b)])
    middle = avg([abs2((x + y) / 2) for x, y in zip(a, b)])
    A = avg([abs2(x) for x in a])
    assert s.simplify(s.re(Q) - middle + D / 4) == 0
    assert abs2(Q - A) <= A * D <= D
    assert s.re(Q) >= -D / 4
    # Constant centering preserves the same defect and real-part lower bound.
    c = avg(a)
    ac, bc = [x - c for x in a], [y - c for y in b]
    Qc = avg([s.conjugate(y) * x for x, y in zip(ac, bc)])
    assert avg([abs2(x - y) for x, y in zip(ac, bc)]) == D
    assert s.re(Qc) >= -D / 4
    return {"Q": str(Q), "D": str(D), "exact_defect_identity": True,
            "complex_distance_comparison": True, "connected_defect": True}


def phase_checks():
    anti = s.Matrix([[0, s.Rational(1, 2)], [s.Rational(1, 2), 0]])
    independent = s.ones(2, 2) / 4
    aligned = s.eye(2) / 2
    v = s.Matrix([1, -1])
    assert (v.T * anti * v)[0] == -1
    assert (v.T * independent * v)[0] == 0
    assert (v.T * aligned * v)[0] == 1
    assert anti * s.ones(2, 1) == independent * s.ones(2, 1) == aligned * s.ones(2, 1)
    defect = sum(s.Rational(1, 4) * (u - w) ** 2 for u, w in product((-1, 1), repeat=2))
    assert defect == 2
    return {"anti_aligned_eigenvalues": [str(x) for x in anti.eigenvals()],
            "independent_eigenvalues": [str(x) for x in independent.eigenvals()],
            "equal_phase_marginals": True, "independent_label_defect": str(defect)}


if __name__ == "__main__":
    result = {"status": "PASS", "geometry": geometry(), "quaternions": quaternion_checks(),
              "defect": defect_checks(), "phase_coupling": phase_checks(),
              "scope": "Exact finite identities and geometry only; no weak-coupling mismatch estimate."}
    output = Path(__file__).with_name("check_results.json")
    output.write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result, indent=2))
