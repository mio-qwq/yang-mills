# Origin reflection positivity, Gibbs locality, and translation averaging

## Optional illustration and assumptions

This note uses the standard low-temperature two-dimensional Ising plus/minus-state facts: existence, positive spontaneous magnetization, translation invariance, and exhaustion-independent constant-boundary limits. For background see Biskup, *Reflection Positivity and Phase Transitions in Lattice Spin Models*, Section 2.3, pp.12–13: https://www.math.ucla.edu/~biskup/PDFs/private/2008-2010/Biskup-LNM08.pdf. Their origin RP follows from the constant-boundary finite-volume factorization described below; this use is also covered by the RP-boundary-data theorem in Fröhlich–Israel–Lieb–Simon, CMP 62 (1978), Theorem 3.5, pp.14–15: https://math.caltech.edu/SimonPapers/93.pdf. Read the illustration conditional on these layer facts; the main report's exact six-atom example does not need them.

## Result and scope

There is a bounded, nearest-neighbor, translation-invariant Ising interaction on Z^3 with a Gibbs state that is reflection-positive (RP) at all origin coordinate planes and at the diagonal x0=x1, but is not translation invariant. Its translation average is a translation-invariant Gibbs state that fails origin coordinate RP. Thus neither Gibbs locality nor finite range repairs the usual translation-averaging argument.

This is **not** a counterexample to simultaneous-RP existence for Wilson SU(2), or even for this Ising interaction. The Ising interaction below has other states that are simultaneously RP. It is anisotropic and does not have the full signed-coordinate-permutation group W3. The noninvariant state is obtained with selected symmetric boundary conditions, **not free boundary conditions**. Consequently the construction does not disprove a theorem specifically about free-cube limits of the Wilson interaction.

## Exact model

Write x=(x0,x1,k) in Z^3 and put spins sigma_x in {-1,+1}. Take

H(sigma) = -J sum_{x in Z^3} [sigma_x sigma_{x+e0} + sigma_x sigma_{x+e1}],

with J>0 and no e2-direction couplings. This is a translation-invariant, bounded, finite-range interaction; the k-layers are independent copies of the nearest-neighbor ferromagnetic Ising model on Z^2. Choose a finite inverse temperature beta sufficiently large that the two-dimensional plus and minus Gibbs states nu+ and nu- have magnetizations +m and -m with m>0.

The states nu+ and nu- are translation invariant and RP under the coordinate reflections and the diagonal reflection (x0,x1)->(x1,x0). For the origin planes this follows directly by taking square-volume limits with constant plus or minus boundary conditions: the finite-volume measure is reflection symmetric and has the usual reflection factorization/positive-kernel property. Constant-boundary monotonicity gives a unique plus/minus limit independent of the exhaustion and hence translation invariance.

Define a period-three sequence by

s(k)=+1 if k=0 mod 3; s(k)=-1 otherwise.

In particular s(-k)=s(k). Let

mu = product_{k in Z} nu_{s(k)},

where nu_{+1}=nu+ and nu_{-1}=nu- on layer k. The absence of interlayer interactions makes mu a DLR Gibbs state of the stated three-dimensional interaction. It is a weak limit of centered cube Gibbs measures whose boundary spin on layer k equals s(k).

## Origin RP and failure of translation invariance

For x0=0, x1=0, and x0=x1, the reflection acts separately within each layer. Each layer state is RP, and products of RP measures are RP (first check tensor-product cylinder functions and extend by the positive-semidefinite tensor-product Gram matrix).

For x2=0, the reflection pairs layers k and -k. Their distributions are identical since s(k)=s(-k), and the paired layers are independent. Conditional on the layer k=0, the two open half-spaces are independent reflected copies. Hence, for every positive-half-space cylinder function F,

mu(F overline{F composed with theta})
  = E_mu[ |E_mu[F | layer 0]|^2 ] >= 0.

But mu(sigma_(0,0,k))=m s(k), so mu is not invariant under translation by e2.

## Translation average fails RP

Let tau_j translate by j e2 and put

bar_mu = (mu + tau_1 mu + tau_2 mu)/3.

Because mu has period three in k and is translation invariant within each layer, bar_mu is invariant under every Z^3 translation. It remains a DLR Gibbs state by convexity and translation covariance of the specification. It is also invariant under reflection in x2=0; invariance alone is therefore insufficient.

Take F=sigma_(0,0,1), and let theta reflect x2 in 0. Then theta F=sigma_(0,0,-1). The two sites belong to different, independent layers under each translated component. Therefore

bar_mu(F theta F)
  = (m^2/3) sum_{j=0}^2 s(j+1)s(j-1)
  = (m^2/3)(1-1-1)
  = -m^2/3 < 0.

Thus averaging destroys even the original x2=0 RP property while preserving the DLR equations and producing full translation invariance.

## Consequence for the proposed abstract proof

Let C0 be the set of Gibbs measures satisfying the specified origin RP conditions. C0 is compact and convex (for compact spins and a continuous finite-range specification), but it is not stable under lattice translations. The amenable-group invariant-mean/fixed-point theorem therefore cannot be applied to C0. Intersecting all translated RP cones would make a translation-stable convex set, but proving that intersection nonempty is precisely the missing simultaneous-existence step. Finite intersection arguments need joint nonemptiness for arbitrary finite families of affine cuts; separate nonemptiness for each cut or for a common-center family does not establish it.
