#!/usr/bin/env python3
"""Run frozen verification sources with explicit checks, including under -O.

Every Assert AST node is replaced before compilation by an if/raise. Original
source bytes remain unchanged; this does not treat an unwrapped -O run as proof.
"""
import ast
from pathlib import Path
import sys


class PreserveChecks(ast.NodeTransformer):
    def visit_Assert(self, node):
        message = node.msg or ast.Constant(
            value=f"ASSERTION_CHECK_FAILED line {node.lineno}")
        replacement = ast.If(
            test=ast.UnaryOp(op=ast.Not(), operand=node.test),
            body=[ast.Raise(exc=ast.Call(
                func=ast.Name(id="AssertionError", ctx=ast.Load()),
                args=[message], keywords=[]), cause=None)],
            orelse=[])
        return ast.copy_location(replacement, node)


def main():
    if len(sys.argv) != 2:
        raise SystemExit("Usage: run_assert_safe.py TARGET.py")
    target = Path(sys.argv[1]).resolve()
    tree = ast.parse(target.read_text(encoding="utf-8"), filename=str(target))
    tree = ast.fix_missing_locations(PreserveChecks().visit(tree))
    if any(isinstance(node, ast.Assert) for node in ast.walk(tree)):
        raise RuntimeError("Assertion transformation incomplete")
    namespace = {"__name__": "__main__", "__file__": str(target),
                 "__package__": None, "__cached__": None}
    sys.argv = [str(target)]
    exec(compile(tree, str(target), "exec"), namespace)


if __name__ == "__main__":
    main()
