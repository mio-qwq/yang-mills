#!/usr/bin/env python3
"""Mutate temporary checker copies; never write the pinned source directory."""
from pathlib import Path
import argparse
import hashlib
import json
import subprocess
import sys
import tempfile

SOURCE_HASH='de68f86e9436f90f6f7544cc45cd7b6d09a7941f323358b931f6e2cf4282c08a'
OUTPUT_HASH='af1a3d0d9862af9c3d0abcaf68dd6807e7e62413ad326c9b160322e91e62ab22'

def require(ok, message):
    if not ok:
        raise RuntimeError(message)

parser=argparse.ArgumentParser()
parser.add_argument('checker',type=Path,help='Path to the frozen check_audit.py')
args=parser.parse_args()
source_bytes=args.checker.read_bytes()
require(hashlib.sha256(source_bytes).hexdigest()==SOURCE_HASH,'Wrong source checker hash')
source=source_bytes.decode('utf-8')
mutations=[
    ('remove_trace_dagger',
     "require(mul(a,conj(b))[0]==dot(a,b), 'dagger trace sign failure')",
     "require(mul(a,b)[0]==dot(a,b), 'dagger trace sign failure')",
     'dagger trace sign failure'),
    ('remove_gaussian_normalization',
     'mgf_exponent = -beta + beta*dot(',
     'mgf_exponent = beta*dot(',
     'Gaussian exponent failure'),
    ('reverse_bond_subdivision_incorrectly',
     'ux,uy=mul(conj(vmx),vpx),mul(conj(vmy),vpy)',
     'ux,uy=mul(vmx,vpx),mul(conj(vmy),vpy)',
     'bond plaquette identity'),
    ('drop_minus_path_inverse',
     "require(physical[0]==mul(pp,conj(pm))[0], 'bond plaquette identity')",
     "require(physical[0]==mul(pp,pm)[0], 'bond plaquette identity')",
     'bond plaquette identity'),
    ('corrupt_signed_diagonal_reflection',
     'h=level(x); y[i]-=h; y[j]-=s*h',
     'h=level(x); y[i]-=h; y[j]+=s*h',
     'involution'),
    ('replace_posterior_by_prior',
     'rho=[pi[w]*z[w]**2/partition for w in range(2)]',
     'rho=list(pi)',
     'posterior defect'),
    ('corrupt_midpoint_defect_sign',
     "require(v[0]==norm2(m)-defect/4,'midpoint equality')",
     "require(v[0]==norm2(m)+defect/4,'midpoint equality')",
     'midpoint equality'),
]
results=[]
with tempfile.TemporaryDirectory(prefix='gaussian-audit-mutations-') as work:
    work=Path(work)
    baseline=work/'baseline.py'
    baseline.write_bytes(source_bytes)
    for flags in ([],['-O']):
        run=subprocess.run([sys.executable,*flags,str(baseline)],capture_output=True)
        require(run.returncode==0,'Baseline replay failed')
        require(hashlib.sha256(run.stdout).hexdigest()==OUTPUT_HASH,
                'Baseline output differs from frozen certificate')
    for name,old,new,expected in mutations:
        require(source.count(old)==1,f'Nonunique mutation anchor: {name}')
        path=work/(name+'.py')
        path.write_text(source.replace(old,new,1),encoding='utf-8')
        modes=[]
        for flags in ([],['-O']):
            run=subprocess.run([sys.executable,*flags,str(path)],capture_output=True)
            stderr=run.stderr.decode('utf-8','replace')
            require(run.returncode!=0,f'Mutation escaped in {flags}: {name}')
            require('RuntimeError: '+expected in stderr,
                    f'Mutation failed for unintended reason: {name}: {stderr}')
            modes.append({'mode':'optimized' if flags else 'normal',
                          'rejected':True,'reason':expected})
        results.append({'mutation':name,'results':modes})
require(args.checker.read_bytes()==source_bytes,'Frozen source changed during replay')
print(json.dumps({'status':'PASS','source_sha256':SOURCE_HASH,
                  'baseline_output_sha256':OUTPUT_HASH,
                  'baseline_modes':['normal','optimized'],
                  'mutations':results,'frozen_source_unchanged':True},indent=2,sort_keys=True))
