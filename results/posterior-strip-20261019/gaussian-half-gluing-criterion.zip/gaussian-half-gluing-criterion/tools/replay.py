#!/usr/bin/env python3
"""Isolated normal/-O replays and real assertion-path mutation checks."""
import ast
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile

ROOT = Path(__file__).resolve().parents[1]


def require(ok, message):
    if not ok:
        raise RuntimeError(message)


def digest(data):
    return hashlib.sha256(data).hexdigest()


def run(path, mode, safe=False):
    command = [sys.executable, "-I", "-B"]
    if mode == "optimized":
        command.append("-O")
    if safe:
        command.append(str(ROOT / "tools/run_assert_safe.py"))
    command.append(str(path))
    return subprocess.run(command, cwd=path.parent, capture_output=True,
                          timeout=120)


def main():
    origins = json.loads((ROOT / "SOURCE_ORIGINS.json").read_text())
    for entry in origins["files"]:
        require(digest((ROOT / entry["bundled"]).read_bytes()) == entry["sha256"],
                "Frozen source hash mismatch: " + entry["bundled"])
    results = []
    mutations = []
    with tempfile.TemporaryDirectory(prefix="gaussian-gluing-replay-") as tmp:
        tmp = Path(tmp)
        for directory in ("source", "audit", "bond_audit"):
            shutil.copytree(ROOT / directory, tmp / directory)
        cases = [
            ("source/check_gluing.py", "source/check_results.json", True),
            ("bond_audit/check_gluing.py", "certificates/bond.expected.txt", True),
            ("audit/check_audit.py", "audit/CHECKS.json", False),
        ]
        for relative, golden, has_asserts in cases:
            target = tmp / relative
            expected = (ROOT / golden).read_bytes()
            assertion_count = sum(isinstance(node, ast.Assert)
                                  for node in ast.walk(ast.parse(target.read_text())))
            modes = [("normal", False)]
            if has_asserts:
                modes += [("normal", True), ("optimized", True)]
                require(assertion_count > 0, "Expected frozen assertions")
            else:
                modes += [("optimized", False)]
                require(assertion_count == 0, "Audit must be assert-free")
            for mode, safe in modes:
                completed = run(target, mode, safe)
                require(completed.returncode == 0,
                        "Replay failed: " + relative + ": " + completed.stderr.decode())
                require(completed.stdout == expected, "Certificate mismatch: " + relative)
                require(not completed.stderr, "Unexpected replay stderr: " + relative)
                results.append({"checker": relative, "mode": mode,
                                "assert_preserving_wrapper": safe,
                                "source_assertions": assertion_count,
                                "stdout_sha256": digest(completed.stdout), "status": "PASS"})
        # Calibration proves -O cannot erase the wrapper's verification gates.
        canary = tmp / "assertion_canary.py"
        canary.write_text("assert False, 'ASSERTION_CANARY'\n")
        for mode in ("normal", "optimized"):
            completed = run(canary, mode, True)
            require(completed.returncode != 0 and
                    b"AssertionError: ASSERTION_CANARY" in completed.stderr,
                    "Assertion preservation canary escaped in " + mode)
        changes = [
            ("source/check_gluing.py", "remove_gaussian_normalizer",
             "gaussian_exp = beta * sum((x + y) ** 2 for x, y in zip(pp, pm)) / 2 - beta",
             "gaussian_exp = beta * sum((x + y) ** 2 for x, y in zip(pp, pm)) / 2"),
            ("source/check_gluing.py", "remove_path_dagger",
             "paired = mul(pp, inv(pm))", "paired = mul(pp, pm)"),
            ("bond_audit/check_gluing.py", "remove_gaussian_normalizer",
             "assert F(1,2)*sum((a+b)**2 for a,b in zip(pp,pn))-1==wilson",
             "assert F(1,2)*sum((a+b)**2 for a,b in zip(pp,pn))==wilson"),
            ("bond_audit/check_gluing.py", "remove_crossing_inverse",
             "ux=pm(inv(vmx),vpx)", "ux=pm(vmx,vpx)"),
        ]
        for relative, name, old, new in changes:
            original = (ROOT / relative).read_text()
            require(original.count(old) == 1, "Mutation anchor not unique: " + name)
            mutated = tmp / (relative.replace("/", "_") + "_" + name + ".py")
            mutated.write_text(original.replace(old, new, 1))
            for mode in ("normal", "optimized"):
                completed = run(mutated, mode, True)
                require(completed.returncode != 0 and
                        b"AssertionError: ASSERTION_CHECK_FAILED line " in completed.stderr,
                        "Mutation escaped or failed unexpectedly: " + relative + " " + name)
                mutations.append({"checker": relative, "mutation": name,
                                  "mode": mode, "rejected": True,
                                  "reason": "explicit preserved assertion"})
    for entry in origins["files"]:
        require(digest((ROOT / entry["bundled"]).read_bytes()) == entry["sha256"],
                "Frozen source changed during replay")
    print(json.dumps({"status": "PASS", "replays": results,
                      "wrapper_false_assertion_canary_modes": ["normal", "optimized"],
                      "mutations": mutations, "frozen_sources_unchanged": True,
                      "scope": "Finite exact identities and geometry, not Wilson mismatch decay."},
                     indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
