#!/usr/bin/env python3
"""Verify inventory and rebuild a deterministic, uncompressed ZIP archive."""
import argparse
import hashlib
from pathlib import Path
import zipfile

ROOT = Path(__file__).resolve().parents[1]


def require(ok, message):
    if not ok:
        raise RuntimeError(message)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    output = args.output.resolve()
    require(ROOT not in output.parents, "Write archive outside its source bundle")
    inventory = (ROOT / "SHA256SUMS").read_text().splitlines()
    expected = {}
    for line in inventory:
        sha, relative = line.split("  ", 1)
        path = Path(relative)
        require(not path.is_absolute() and ".." not in path.parts,
                "Unsafe inventory path")
        require(relative not in expected, "Duplicate inventory path")
        expected[relative] = sha
    actual = set()
    for path in ROOT.rglob("*"):
        require(not path.is_symlink(), "Symlink in source bundle")
        if path.is_file():
            relative = path.relative_to(ROOT).as_posix()
            require("__pycache__" not in path.parts and path.suffix != ".pyc",
                    "Cache file in source bundle")
            if relative != "SHA256SUMS":
                actual.add(relative)
    require(actual == set(expected), "Inventory does not cover exact source file set")
    for relative, sha in expected.items():
        require(hashlib.sha256((ROOT / relative).read_bytes()).hexdigest() == sha,
                "Hash mismatch: " + relative)
    members = sorted([*expected, "SHA256SUMS"])
    with zipfile.ZipFile(output, "w", compression=zipfile.ZIP_STORED) as archive:
        for relative in members:
            info = zipfile.ZipInfo("gaussian-half-gluing-criterion/" + relative,
                                   date_time=(2026, 10, 19, 0, 0, 0))
            info.create_system = 3
            info.external_attr = 0o100644 << 16
            info.compress_type = zipfile.ZIP_STORED
            archive.writestr(info, (ROOT / relative).read_bytes())
    print(hashlib.sha256(output.read_bytes()).hexdigest())


if __name__ == "__main__":
    main()
