"""Offline SHA256 inventory validation. Hashes are not authenticity signatures."""
from pathlib import Path, PurePosixPath
import hashlib, json

def sha(raw):
    return hashlib.sha256(raw).hexdigest()

def require(ok, message):
    if not ok:
        raise RuntimeError(message)

def validate(root):
    root = Path(root)
    manifest = json.loads((root / 'MANIFEST.json').read_text())
    files = manifest['files']
    paths = [entry['path'] for entry in files]
    require(len(paths) == len(set(paths)), 'duplicate inventory path')
    for entry in files:
        relative = PurePosixPath(entry['path'])
        require(not relative.is_absolute() and '..' not in relative.parts and '\\' not in str(relative), 'unsafe inventory path')
        path = root / str(relative)
        require(path.is_file() and not path.is_symlink(), 'missing or symlinked inventory file: ' + str(relative))
        data = path.read_bytes()
        require(len(data) == entry['bytes'] and sha(data) == entry['sha256'], 'inventory mismatch: ' + str(relative))
    actual = {str(p.relative_to(root)) for p in root.rglob('*') if p.is_file()}
    require(actual == set(paths) | {'MANIFEST.json', 'SHA256SUMS'}, 'unexpected or missing package files')
    sums = ''.join(sha((root / p).read_bytes()) + '  ' + p + '\n' for p in sorted(paths + ['MANIFEST.json']))
    require((root / 'SHA256SUMS').read_text() == sums, 'SHA256SUMS mismatch')
    return manifest
