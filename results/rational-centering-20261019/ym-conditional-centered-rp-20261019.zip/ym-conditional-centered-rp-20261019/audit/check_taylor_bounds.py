"""Exact rational certification of the analytic Taylor witness constants."""
import argparse
import json
from fractions import Fraction as F
from pathlib import Path
ROOT=Path(__file__).parent
parser=argparse.ArgumentParser()
parser.add_argument('--output',type=Path,default=ROOT/'TAYLOR_CHECKS.json')
parser.add_argument('--negative-control',choices=('degree23_tail','wrong_half_count','unsafe_radius'))
a=parser.parse_args()
count=0

def require(condition,message):
    global count
    count+=1
    if not condition:raise RuntimeError(f'Taylor check {count} failed: {message}')

b=F(1,10**14)
r=F(1,1000 if a.negative_control=='unsafe_radius' else 1020)
Pplus=256 if a.negative_control=='wrong_half_count' else 255
Pminus=170
require(r*Pplus<=F(1,4),'positive action exponent bounded by 1/4')
require(r*Pminus<=F(1,4),'negative action exponent bounded by 1/4')
# For 0<=x<1, exp(x)<=1/(1-x); true term by term.
exp_bound=1/(1-F(1,4))
D_error=exp_bound-1
D_lower=1-D_error
N_upper=exp_bound
c_upper=N_upper/D_lower
require(D_error<=F(1,3),'denominator deviation bound')
require(D_lower>=F(2,3),'strict denominator nonvanishing')
require(c_upper<=2,'uniform complex c bound')
require(b<r,'requested beta interval inside complex disk')
N=23 if a.negative_control=='degree23_tail' else 24
ratio=20*(2**41)*(1020**(N+1))*b**(N+1-18)/(1-1020*b)
require(ratio<1,'Cauchy tail smaller than kappa/10 at endpoint')
require(N+1-18>0,'tail-to-gap ratio increasing over interval')
kappa=b**18/F(2**41)
epsilon_bound=kappa/10
require(epsilon_bound<1,'perturbation error below1')
require(epsilon_bound*(4+epsilon_bound)<=kappa/2,'Q perturbation costs at most half gap')
require((2+2*epsilon_bound)/4<=1,'exactly centered witness divided by4 has norm<=1')
require((kappa/2)/16==b**18/F(2**46),'final centered gap exponent46')
require(1-900*b>F(1,2),'inherited exponential gap factor')
# Degree recursion d_n <= n: denominator and numerator moments have degree <= n.
deg=[]
for n in range(25):
    candidates=[n]+[k+deg[n-k] for k in range(1,n+1)]
    deg.append(max(candidates))
    require(deg[-1]<=n,f'quotient coefficient degree for n={n}')
require(max(4,deg[-1])<=24,'total link-polynomial degree bound24')
report={
 'checks':count,'uses_explicit_checks_under_optimization':True,
 'beta_max':str(b),'complex_radius':str(r),
 'half_plaquette_counts':[Pplus,Pminus],
 'denominator_deviation_upper':str(D_error),
 'denominator_modulus_lower':str(D_lower),
 'conditional_c_modulus_upper':str(c_upper),
 'Taylor_order':N,'plane_degree_bound':deg[-1],
 'tail_to_kappa_over_10_endpoint_ratio_exact':str(ratio),
 'tail_to_kappa_over_10_endpoint_ratio_approx':float(ratio),
 'raw_F24_gap_lower':'beta^18 / 2^42',
 'centered_F24_div4_gap_lower':'beta^18 / 2^46'
}
a.output.write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
