import itertools,json
from pathlib import Path
ROOT=Path(__file__).parent

def cells(max0):
    verts=list(itertools.product(range(max0+1),range(6),range(6)))
    vmax=(max0,5,5)
    links=[]; faces=[]
    for v in verts:
        for d in range(3):
            if v[d]<vmax[d]: links.append((v,d))
        for i in range(3):
            for j in range(i+1,3):
                if v[i]<vmax[i] and v[j]<vmax[j]: faces.append((v,i,j))
    return set(links),set(faces)

def inc(v,d):
    w=list(v);w[d]+=1;return tuple(w)

def edges(f):
    v,i,j=f
    return {(v,i),(inc(v,i),j),(inc(v,j),i),(v,j)}

def vreflect(v):return (4-v[0],v[1],v[2])
def ereflect(e):
    v,d=e
    w=vreflect(v)
    if d==0: w=(w[0]-1,w[1],w[2])
    return (w,d),(-1 if d==0 else 1)

def freflect(f):
    v,i,j=f; w=list(vreflect(v))
    if i==0 or j==0:w[0]-=1
    return (tuple(w),i,j)

def half(e):
    v,d=e; w=inc(v,d)
    if v[0]==w[0]==2:return 'plane'
    if min(v[0],w[0])>=2:return 'plus'
    if max(v[0],w[0])<=2:return 'minus'
    raise AssertionError(e)

fullE,fullP=cells(5)
slabE,slabP=cells(4)
parts={h:{e for e in fullE if half(e)==h} for h in ['plane','plus','minus']}
pfaces={h:set() for h in ['plane','plus','minus']}
for p in fullP:
    hs={half(e) for e in edges(p)}
    assert not ('plus' in hs and 'minus' in hs),(p,hs)
    h='plus' if 'plus' in hs else 'minus' if 'minus' in hs else 'plane'
    pfaces[h].add(p)
for e in slabE:
    re,s=ereflect(e)
    assert re in slabE
    e2,s2=ereflect(re)
    assert e2==e and s*s2==1
    if half(e)=='plane':assert re==e and s==1
    else:assert half(re)!=half(e) and half(re)!='plane'
for p in slabP:
    rp=freflect(p)
    assert rp in slabP
    assert {ereflect(e)[0] for e in edges(p)}==edges(rp)
    assert freflect(rp)==p
p=((3,2,2),1,2);q=((1,2,2),1,2)
assert freflect(p)==q
assert all(half(e)=='plus' for e in edges(p))
assert all(half(e)=='minus' for e in edges(q))
# Link variables retained by outside-layer plaquettes are exactly tangent links
# on x0=4; hence marginalization induces a boundary function on that plane.
outsideP=fullP-slabP
interfaceE=set().union(*(edges(p)&slabE for p in outsideP))
plane4={e for e in slabE if e[0][0]==4 and e[1] in [1,2]}
assert interfaceE==plane4
# Reflection sends the induced far-plane boundary factor to x0=0.
assert {ereflect(e)[0] for e in interfaceE}=={e for e in slabE if e[0][0]==0 and e[1] in [1,2]}
report={
 'full_links':len(fullE),'full_plaquettes':len(fullP),
 'link_partition':{h:len(es) for h,es in parts.items()},
 'plaquette_partition':{h:len(ps) for h,ps in pfaces.items()},
 'slab_links':len(slabE),'slab_plaquettes':len(slabP),
 'outside_links':len(fullE-slabE),'outside_plaquettes':len(outsideP),
 'outside_boundary_factor_link_support':len(interfaceE),
 'fixed_plane_links_fixed_without_inversion':True,
 'no_plaquette_couples_plus_and_minus_off_plane_links':True,
 'reflection_is_oriented_link_involution_on_slab':True,
 'reflection_preserves_all_slab_plaquette_boundaries':True,
 'positive_and_negative_witness_supports_match':True,
 'marginal_boundary_factor_support_is_exactly_outer_tangential_plane':True
}
(ROOT/'GEOMETRY_CHECKS.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
