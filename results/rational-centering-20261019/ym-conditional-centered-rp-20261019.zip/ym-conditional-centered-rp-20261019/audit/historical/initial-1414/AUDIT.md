# Independent audit: real, centered negative reflection witness

19 October 2026, 14:10 UTC. Local research audit only; no repository changes or publication.

## Verdict

**PASS, with an essential support and measure qualification.** The proposed construction gives a bounded, real, continuous, gauge-invariant observable in the **closed positive-half algebra**, with a strictly negative real reflection form in the original free-box marginal. Averaging that marginal with its reflected image preserves this negative form and makes the observable centered, even conditionally on the fixed-plane links. The resulting measure is reflection invariant and gauge invariant.

The new observable can depend on all 60 tangent links in the cut plane, including links at the transverse boundary of the box. It is not the earlier strictly-interior observable. The reflected mixture is not the homogeneous free Wilson measure on the matched slab. These distinctions must remain in every theorem statement or summary.

The input strict expectation difference and its quantitative bound are imported from the previously audited character-expansion calculation in `../joint-lattice-rp-20261019-1311/RESULT.md`; this audit independently checks the new geometry, conditioning, symmetrization, regularity, gauge invariance, constants, and scope.

## 1. Precise configuration spaces and reflection

Let K have vertices {0,...,5}^3, all nearest-neighbor links, and all elementary plaquettes. Give each link its positive-coordinate orientation and use independent normalized SU(2) Haar variables in those orientations. A reversed link has the inverse group variable.

The site reflection is r(x0,x1,x2)=(4-x0,x1,x2). It is not an automorphism of K. It is an involution of the full matched subcomplex C with vertices {0,...,4} x {0,...,5}^2. All reflected forms below are defined on the configuration algebra of C, using the marginal nu of the full-box Wilson measure mu. The formulas written with mu are equal to the corresponding nu integrals because their integrands only use links in C.

For a positively oriented link e=(v,v+e_i), define the reflected configuration by evaluating the link from r(v) to r(v+e_i). For i=0 that is the inverse of the positively oriented reflected link; for i=1,2 its orientation is unchanged. Thus r is an involution on the slab configuration space and preserves product Haar measure. Write Rf=f composed with r and Theta f=conjugate(Rf).

Every tangent link at x0=2 is fixed pointwise and without inversion. In particular every real function c of those links satisfies Theta c=c exactly. This is the orientation fact required by the proposed proof.

Take p to be the (1,2)-plaquette based at (3,2,2), q the corresponding plaquette based at (1,2,2), X=(1/2)Tr U_p, and Y=(1/2)Tr U_q. SU(2) traces here are real, r sends p to q without reversing its tangent orientation, and Y=Theta X=RX.

The independent exhaustive check `check_geometry.py` verifies all reflected links and plaquette boundaries, not only these two plaquettes. Results are in `GEOMETRY_CHECKS.json`.

## 2. Exact link and plaquette partitions

Let E0 be all tangent links at x0=2. Let E+ be all other links whose endpoints both have x0>=2, and E- all other links whose endpoints both have x0<=2. No nearest-neighbor link crosses from x0<2 to x0>2 without meeting the site plane, so these sets partition all full-box links.

The independent counts are:

- Full box: 540 links and 450 plaquettes.
- E0: 60 links; E+: 288 links; E-: 192 links.
- Plane plaquettes: 25; positive-side plaquettes: 255; negative-side plaquettes: 170.
- Matched slab C: 444 links and 365 plaquettes.

Every elementary plaquette belongs to one closed half. A plaquette with normal direction 0 has normal coordinates either k,k+1; these cannot include both a value below 2 and a value above 2. A tangent plaquette has a single normal coordinate. Hence no plaquette uses both E+ and E- links. Plane plaquettes use E0 only.

Put Z=U restricted to E0 and U+,U- for the remaining variables. The full-box Wilson action decomposes exactly as

    S(U)=S0(Z)+S+(U+,Z)+S-(U-,Z).

Consequently the normalized conditional distribution of (U+,U-) given Z=z is

    [exp(beta S+(u+,z))/A+(z)] dH+(u+)
      times
    [exp(beta S-(u-,z))/A-(z)] dH-(u-),

where A+ and A- are their respective strictly positive partition functions. The plane term cancels from this conditional distribution. This proves conditional independence directly, without reflection invariance and without gauge fixing. Integrating out the positive outer layer preserves the conditional independence of the two off-plane halves retained in C.

## 3. Continuous gauge-invariant conditional expectations

Define canonical versions

    a(z) = integral X(u+) exp(beta S+(u+,z)) dH+ / A+(z),
    b(z) = integral Y(u-) exp(beta S-(u-,z)) dH- / A-(z),
    c(z) = (a(z)+b(z))/2,       h(z)=a(z)-b(z).

These finite Haar-integral ratios are defined for every z, not merely almost everywhere. Their numerators and denominators are continuous in z, and denominators are everywhere positive. On the compact plane configuration space they are bounded away from zero. Thus a,b,c are continuous; for fixed finite beta their regularity is also smooth in the usual compact Lie group coordinates. They are real and lie in [-1,1].

For any assignment of SU(2) gauge transformations at plane vertices, extend it to either closed half and change integration variables by that gauge transformation. Haar measure, the half Wilson action, and the corresponding plaquette trace are invariant. Therefore a(gz)=a(z) and b(gz)=b(z). Arbitrary gauge transformations off the plane do not change z. Hence c is invariant under the entire finite-box or slab vertex gauge group. This establishes genuine gauge invariance of the witness; it does not merely establish invariance in a particular gauge.

Set

    F = X-c(Z),       G=F/2.

Then F and G are real, continuous, gauge invariant, and measurable with respect to the links in C with endpoints x0>=2. Their bounds are |F|<=2 and |G|<=1. Since the plane is fixed pointwise,

    Theta F = Y-c(Z).

## 4. Exact negative reflection form

Conditional independence gives, at each z,

    E_mu[(Theta F)F | Z=z]
       = (b(z)-c(z))(a(z)-c(z))
       = -h(z)^2/4.

Thus, with rho the plane-link marginal,

    Q_mu(F)=Q_nu(F)=-E_rho[h^2]/4,
    Q_mu(G)=Q_nu(G)=-E_rho[h^2]/16.

Let delta=mu(X)-mu(Y)=E_rho[h]. The prior character-expansion certificate proves delta>0 in the specified small-beta range. Jensen's inequality then gives E[h^2]>=delta^2>0. Therefore both reflection forms are strictly negative real numbers. No separate demonstration that h is nonconstant is required.

The original unsymmetrized centered covariance must not be overstated. Indeed

    mu(F)=delta/2,       mu(Theta F)=-delta/2,

so

    Cov_mu(Theta F,F)=-Var_rho(h)/4<=0.

The known strict delta>0 alone does not prove this last covariance is strictly negative. The mixture construction below supplies strict connected negativity without this extra premise.

## 5. Reflected-mixture centering and invariance

On the slab configuration space define

    mubar = (nu+r_*nu)/2.

This is a well-defined probability measure, invariant under r. It is gauge invariant because nu is gauge invariant (extend each slab gauge transformation to K), and reflection only relabels the gauge group action.

The real product H=(Theta F)F=(Y-c)(X-c) satisfies RH=H pointwise. Consequently

    Q_mubar(F)=Q_nu(F)=-E_rho[h^2]/4<0.

Reflection fixes Z, so nu and r_*nu have the same plane marginal rho. Their conditional means for F are respectively a-c=h/2 and b-c=-h/2. Hence the stronger centering identity holds:

    E_mubar[F | Z]=0.

In particular mubar(F)=mubar(Theta F)=0. Therefore

    Cov_mubar(Theta F,F)=Q_mubar(F)<0,

and analogously for G. The reflected mixture no longer has conditional independence between halves; the argument does not assume that it does. It computes its reflected product by the pointwise reflection invariance of H, or equivalently by averaging the two conditional product laws.

## 6. Explicit constants

The previous remainder certificate gives

    delta >= beta^9 exp(-450 beta) / 2^19

for 0<beta<=10^(-14): the unnormalized difference is at least beta^9/2^19 and the full partition function is at most exp(450 beta).

Thus the normalized witness G satisfies

    Cov_mubar(Theta G,G)=Q_mubar(G)
       <= -delta^2/16
       <= -beta^18 exp(-900 beta)/2^42
       <= -beta^18/2^43 < 0.

The last inequality follows from exp(-900 beta)>=1-900 beta>1/2 on this interval. The same negative upper bound holds for the original uncentered form Q_mu(G). For F rather than G, the corresponding exponential bound has denominator 2^40. These inequalities give certified negativity, not the leading asymptotic order of Q: E[h^2] could be substantially larger than delta^2.

## 7. What measure the mixture actually is

This can be made exact rather than merely saying that the mixture is not free Wilson.

The omitted layer K\C has 96 links and 85 plaquettes. Every omitted plaquette uses retained links only in the tangent plane x0=4, and the union of those retained links is exactly all 60 tangent links on that plane. Integrating out the layer produces a strictly positive gauge-invariant continuous boundary factor B_beta(Z4), where Z4 denotes the tangent link configuration on x0=4. Therefore the marginal has density

    dnu/dH_C = Z_K^(-1) exp(beta S_C) B_beta(Z4).

Its reflected image has the same expression with Z0 in place of Z4, and the mixture has density

    dmubar/dH_C = Z_K^(-1) exp(beta S_C)
                   [B_beta(Z4)+B_beta(Z0)]/2.

This explicitly proves gauge invariance and reflection invariance as well. The boundary weight is generally a non-product sum. It is not the standard free slab measure, and it need not be an independently factorized reflection-positive boundary weight.

The mixture does retain the ordinary Wilson conditional specification for updates of link sets disjoint from the tangent boundary links at x0=0 and x0=4: its extra boundary factor is constant during such updates. This local statement should not be promoted to a claim that the whole finite measure has the free Wilson boundary law, or that it constructs an infinite-volume state.

## 8. Admissible algebra and exact limitations

1. **Closed half required.** The witness belongs to the algebra generated by links whose endpoints have x0>=2. Plane variables are essential to the displayed construction. It is not shown to belong to an algebra requiring all link endpoints to have x0>2.
2. **Boundary dependence.** Although X and Y are strictly inside the original cube, c may depend on every plane link, reaching x1 or x2 equal to 0 or 5. The new real centered negative witness therefore does not preserve the previous strictly-interior support claim. Its dependence is finite and compact, but it is not a uniformly fixed small local support across a growing-volume family.
3. **Beta dependence.** The centering function c is defined from the beta-dependent conditional laws. This provides an existential witness at each beta, not a single beta-independent polynomial with the stated uniform numerical bound.
4. **No numerical conditional integration assumed.** The finite integral formulas define c exactly and suffice for the theorem. This audit does not provide a practical numerical evaluation of that function.
5. **Continuous versus polynomial tests.** If the intended algebra is continuous gauge-invariant functions, admissibility is immediate. If it is finite polynomials in link matrix entries, strict negativity still gives an existential polynomial witness: uniformly approximate c by real plane polynomials and Haar-average over the compact plane gauge group SU(2)^{V_plane}, a finite product. The gauge action substitutes linear functions of the link matrix entries, so averaging the polynomial coefficients preserves finite polynomial degree. This preserves plane support and reality and gives uniform gauge-invariant approximants. Reflection fixes each such function. The resulting F_n converge uniformly to F, so their forms stay negative eventually; subtracting their mubar means gives exactly centered polynomial witnesses. No degree bound or uniform coefficient construction is supplied. A narrower prescribed family of Wilson-loop tests needs an explicit algebra-density argument and should not be claimed covered without it.
6. **Only the audited 3D small-beta input.** The conditional lemma itself is general for a site-separating local action, but strict delta here comes from the specific three-dimensional finite cube and small-beta proof. No all-beta or full-four-dimensional extension follows.
7. **No limit-state obstruction.** This does not rule out a common joint-RP infinite-volume state, approximate RP, or decay of boundary defects. It refutes this exact finite-volume reflected form and, separately, a naive assertion that reflection symmetrization alone guarantees positivity.
8. **No arbitrary-depth conclusion.** The fixed cube and its plane-spanning witness do not prove failure arbitrarily far from every boundary.

## Evidence and reproducibility

- Prior exact input: `../joint-lattice-rp-20261019-1311/RESULT.md`.
- New independent finite-complex enumeration: `check_geometry.py` and `GEOMETRY_CHECKS.json` in this directory.
- Deriving worker's proposed construction: `../conditional-free-box-rp-20261019-1410/RESULT.md`, Sections 1–5, cross-checked after the independent proof. The later boundary-distance comparison sections are outside this audit’s assigned scope.
- This audit changes no repository and takes no publishing, merging, or release action.
