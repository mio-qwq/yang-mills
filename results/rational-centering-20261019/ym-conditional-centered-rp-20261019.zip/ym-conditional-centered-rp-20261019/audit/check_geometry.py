"""Independent oriented-cubical geometry verifier; robust under python -O."""
import argparse
import itertools
import json
from pathlib import Path

ROOT = Path(__file__).parent
parser = argparse.ArgumentParser()
parser.add_argument('--negative-control', choices=(
    'shift_reflection_plane', 'invert_plane_orientation',
    'remove_plane_link', 'side_contains_plane_face'))
parser.add_argument('--output', type=Path, default=ROOT/'GEOMETRY_CHECKS.json')
args = parser.parse_args()
CHECK_COUNT = 0

def require(condition, message):
    global CHECK_COUNT
    CHECK_COUNT += 1
    if not condition:
        raise RuntimeError(f'geometry check {CHECK_COUNT} failed: {message}')

def cells(max0):
    verts=list(itertools.product(range(max0+1),range(6),range(6)))
    vmax=(max0,5,5)
    links=[]; faces=[]
    for v in verts:
        for d in range(3):
            if v[d]<vmax[d]: links.append((v,d))
        for i in range(3):
            for j in range(i+1,3):
                if v[i]<vmax[i] and v[j]<vmax[j]: faces.append((v,i,j))
    return set(links),set(faces)

def inc(v,d):
    w=list(v);w[d]+=1;return tuple(w)

def edges(f):
    v,i,j=f
    return {(v,i),(inc(v,i),j),(inc(v,j),i),(v,j)}

def vreflect(v):
    offset=6 if args.negative_control=='shift_reflection_plane' else 4
    return (offset-v[0],v[1],v[2])

def ereflect(e):
    v,d=e
    w=vreflect(v)
    if d==0: w=(w[0]-1,w[1],w[2])
    sign=-1 if d==0 else 1
    if args.negative_control=='invert_plane_orientation' and v[0]==2 and d!=0:
        sign=-1
    return (w,d),sign

def freflect(f):
    v,i,j=f; w=list(vreflect(v))
    if i==0 or j==0:w[0]-=1
    return (tuple(w),i,j)

def half(e):
    v,d=e; w=inc(v,d)
    if v[0]==w[0]==2:return 'plane'
    if min(v[0],w[0])>=2:return 'plus'
    if max(v[0],w[0])<=2:return 'minus'
    raise RuntimeError(f'unclassified link: {e}')

fullE,fullP=cells(5)
slabE,slabP=cells(4)
if args.negative_control=='remove_plane_link':
    fullE.remove(((2,0,0),1))
require(len(fullE)==540,'full-box link count')
require(len(fullP)==450,'full-box plaquette count')
require(len(slabE)==444,'slab link count')
require(len(slabP)==365,'slab plaquette count')
require(slabE<=fullE and slabP<=fullP,'slab inclusion')
parts={h:{e for e in fullE if half(e)==h} for h in ['plane','plus','minus']}
require({h:len(es) for h,es in parts.items()}=={'plane':60,'plus':288,'minus':192},'link partition counts')
pfaces={h:set() for h in ['plane','plus','minus']}
for p in sorted(fullP):
    require(edges(p)<=fullE,f'plaquette has existing links: {p}')
    hs={half(e) for e in edges(p)}
    require(not ('plus' in hs and 'minus' in hs),f'no cross-half plaquette: {p}')
    h='plus' if 'plus' in hs else 'minus' if 'minus' in hs else 'plane'
    pfaces[h].add(p)
require({h:len(ps) for h,ps in pfaces.items()}=={'plane':25,'plus':255,'minus':170},'plaquette partition counts')
for e in sorted(slabE):
    re,s=ereflect(e)
    require(re in slabE,f'reflected link stays in slab: {e}')
    e2,s2=ereflect(re)
    require(e2==e and s*s2==1,f'oriented involution: {e}')
    if half(e)=='plane':
        require(re==e and s==1,f'plane link fixed without inversion: {e}')
    else:
        require(half(re)!=half(e) and half(re)!='plane',f'exchange strict sides: {e}')
for p in sorted(slabP):
    rp=freflect(p)
    require(rp in slabP,f'reflected plaquette stays in slab: {p}')
    require({ereflect(e)[0] for e in edges(p)}==edges(rp),f'boundary commutes with reflection: {p}')
    require(freflect(rp)==p,f'plaquette involution: {p}')
p=((3,2,2),1,2);q=((1,2,2),1,2)
require(freflect(p)==q,'specified witness reflection')
require(all(half(e)=='plus' for e in edges(p)),'X is strictly positive half')
require(all(half(e)=='minus' for e in edges(q)),'Y is strictly negative half')
require(not ((edges(p)|edges(q)) & parts['plane']),'X and Y use no plane entries')
outsideP=fullP-slabP
interfaceE=set().union(*(edges(f)&slabE for f in outsideP))
plane4={e for e in slabE if e[0][0]==4 and e[1] in [1,2]}
require(interfaceE==plane4,'outside layer interacts only through full tangent plane4')
require({ereflect(e)[0] for e in interfaceE}=={e for e in slabE if e[0][0]==0 and e[1] in [1,2]},'boundary factor reflects to tangent plane0')
# A nonplane elementary plaquette can have at most one plane edge.
# This is the exact geometric input for plane degree <= n of the nth moment.
action_faces={h:set(pfaces[h]) for h in ['plus','minus']}
if args.negative_control=='side_contains_plane_face':
    action_faces['plus'].add(((2,0,0),1,2))
max_degree={}
for h in ['plus','minus']:
    for face in sorted(action_faces[h]):
        require(len(edges(face)&parts['plane'])<=1,f'{h} action plaquette has at most one plane link: {face}')
    max_degree[h]=max(len(edges(face)&parts['plane']) for face in action_faces[h])
require(max_degree=={'plus':1,'minus':1},'exact nonplane action maximum plane degree')
report={
 'checks':CHECK_COUNT,'uses_explicit_checks_under_optimization':True,
 'full_links':len(fullE),'full_plaquettes':len(fullP),
 'link_partition':{h:len(es) for h,es in parts.items()},
 'plaquette_partition':{h:len(ps) for h,ps in pfaces.items()},
 'slab_links':len(slabE),'slab_plaquettes':len(slabP),
 'outside_links':len(fullE-slabE),'outside_plaquettes':len(outsideP),
 'outside_boundary_factor_link_support':len(interfaceE),
 'fixed_plane_links_fixed_without_inversion':True,
 'no_plaquette_couples_plus_and_minus_off_plane_links':True,
 'reflection_is_oriented_link_involution_on_slab':True,
 'reflection_preserves_all_slab_plaquette_boundaries':True,
 'positive_and_negative_witness_supports_match':True,
 'marginal_boundary_factor_support_is_exactly_outer_tangential_plane':True,
 'max_plane_links_per_half_action_plaquette':max_degree,
 'witness_X_and_Y_plane_degree':0,
 'certified_Taylor_order_24_plane_degree_bound':24
}
args.output.write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
