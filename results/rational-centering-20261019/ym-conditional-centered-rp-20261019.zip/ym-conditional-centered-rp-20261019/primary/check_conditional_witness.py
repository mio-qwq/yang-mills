#!/usr/bin/env python3
"""Exact geometric and rational checks; no numerical SU(2) integration."""
from fractions import Fraction as Q
from itertools import product, combinations
from math import factorial
from collections import Counter, deque
import argparse
import json

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--negative-control', choices=['plane', 'sign', 'connected', 'constant', 'taylor_order', 'plane_degree'])
args = parser.parse_args()
checks = 0
def require(test, message):
    global checks
    checks += 1
    if not test:
        raise RuntimeError('CHECK FAILED: ' + message)

def plus(x, i):
    y = list(x); y[i] += 1; return tuple(y)

def complex_data(d, L, x0max=None):
    if x0max is None: x0max=L
    vs = set(product(range(x0max+1), *([range(L+1)]*(d-1))))
    es = {(x, i) for x in vs for i in range(d) if plus(x, i) in vs}
    fs = {}
    for x in vs:
        for i,j in combinations(range(d),2):
            e = frozenset(((x,i),(x,j),(plus(x,j),i),(plus(x,i),j)))
            if e <= es: fs[(x,i,j)] = e
    return vs, es, fs

def endpoints(e):
    x,i=e; return x, plus(x,i)
def reflected_vertex(x):
    return (4-x[0],)+x[1:]
def reflected_edge(e):
    a,b = map(reflected_vertex, endpoints(e))
    i=e[1]
    if b[i] > a[i]: return (a,i), 1
    return (b,i), -1

vs,es,fs = complex_data(3,5)
cvs,ces,cfs = complex_data(3,5,4)
plane = {e for e in es if all(x[0]==2 for x in endpoints(e))}
positive = {e for e in es-plane if all(x[0]>=2 for x in endpoints(e))}
negative = {e for e in es-plane if all(x[0]<=2 for x in endpoints(e))}
require(len(vs)==216 and len(es)==540 and len(fs)==450, 'full-box counts')
require((len(plane),len(positive),len(negative))==(60,288,192), 'half-link counts')
require(plane|positive|negative==es, 'partition exhaustive')
require(not(plane&positive or plane&negative or positive&negative), 'partition disjoint')
pf = {f for f,e in fs.items() if e <= plane}
plusf = {f for f,e in fs.items() if e & positive}
minusf = {f for f,e in fs.items() if e & negative}
require((len(pf),len(plusf),len(minusf))==(25,255,170), 'half-plaquette counts')
require(not(plusf&minusf), 'no plaquette couples strict halves')
require(pf|plusf|minusf==set(fs), 'plaquette split exhaustive')
max_plane_edges=max(len(fs[f]&plane) for f in plusf|minusf)
expected_plane_degree=0 if args.negative_control=='plane_degree' else 1
require(max_plane_edges==expected_plane_degree, 'each off-plane half plaquette has at most one plane link')
require((len(cvs),len(ces),len(cfs))==(180,444,365), 'slab counts')
for e in ces:
    re,orientation=reflected_edge(e)
    require(re in ces, 'reflection preserves slab link set')
    require(reflected_edge(re)==(e,orientation), 'reflection involution and orientation')
    require(orientation==(-1 if e[1]==0 else 1), 'correct orientation reversal')
    if e in plane:
        expected= -1 if args.negative_control=='plane' else 1
        require(re==e and orientation==expected, 'plane links individually fixed without inversion')
    elif e in positive:
        require(re in negative, 'reflection exchanges slab halves')
p=((3,2,2),1,2); q=((1,2,2),1,2)
require(fs[p]<=positive and fs[q]<=negative, 'plaquette supports in strict halves')
require({reflected_edge(e)[0] for e in fs[p]}==set(fs[q]), 'reflected plaquette exact')
for f in (p,q):
    require(all(all(0<t<5 for t in x) for e in fs[f] for x in endpoints(e)), 'original plaquettes strictly interior')
require(len(plane|set(fs[p]))==64, 'closed-half witness support upper bound')
require(any(any(x[j] in (0,5) for j in (1,2)) for e in plane for x in endpoints(e)), 'plane support reaches transverse boundary')

# Finite rational product kernels check the conditional algebra, including a
# genuine nonconstant conditional mismatch and a constant-mismatch edge case.
rho=[Q(1,3),Q(2,3)]
P=[[Q(1,2),Q(1,3),Q(1,6)],[Q(1,5),Q(3,10),Q(1,2)]]
R=[[Q(1,6),Q(1,3),Q(1,2)],[Q(1,2),Q(3,10),Q(1,5)]]
X=[[Q(-1),Q(0),Q(1)],[Q(-1),Q(1,4),Q(3,4)]]
def check_identity(rho,P,R,X):
    require(sum(rho)==1, 'plane law normalized')
    all_a=[]; all_b=[]; all_c=[]; raw=Q(0); mx=Q(0); mt=Q(0); symmean=Q(0)
    for z,rz in enumerate(rho):
        require(sum(P[z])==sum(R[z])==1, 'half kernels normalized')
        a=sum(p*x for p,x in zip(P[z],X[z])); b=sum(p*x for p,x in zip(R[z],X[z]))
        c=(a+b)/2; all_a.append(a); all_b.append(b); all_c.append(c)
        f=[x-c for x in X[z]]
        direct=sum(P[z][i]*R[z][j]*f[i]*f[j] for i in range(len(f)) for j in range(len(f)))
        expected=(a-b)**2/4 if args.negative_control=='sign' else -(a-b)**2/4
        require(direct==expected, 'negative conditional square')
        reversed_form=sum(R[z][i]*P[z][j]*f[i]*f[j] for i in range(len(f)) for j in range(len(f)))
        require(direct==reversed_form, 'real product is reflection invariant')
        require(all(abs(v)<=2 for v in f), 'unnormalized witness bound')
        raw+=rz*direct; mx+=rz*(a-c); mt+=rz*(b-c)
        symmean+=rz*((a+b)/2-c)
    delta=sum(rz*(a-b) for rz,a,b in zip(rho,all_a,all_b))
    ed2=sum(rz*(a-b)**2 for rz,a,b in zip(rho,all_a,all_b))
    require(raw==-ed2/4, 'integrated negative square')
    require(raw<=-delta**2/4, 'Jensen bound')
    require(mx==delta/2 and mt==-delta/2, 'asymmetric means')
    require(symmean==0, 'symmetrized mean is zero')
    require(raw-mx*mt==-(ed2-delta**2)/4, 'original connected variance identity')
    return {'a':list(map(str,all_a)),'b':list(map(str,all_b)),'c':list(map(str,all_c)),
            'delta':str(delta),'Q_original':str(raw),'connected_original':str(raw-mx*mt),
            'symmetrized_mean':'0','connected_symmetrized':str(raw)}
rational=check_identity(rho,P,R,X)
constant=check_identity([Q(1)],[[Q(3,4),Q(1,4)]],[[Q(1,4),Q(3,4)]],[[Q(-1),Q(1)]])
expected_conn=Q(-1,4) if args.negative_control=='connected' else Q(0)
require(Q(constant['connected_original'])==expected_conn, 'nonzero mean mismatch need not imply strict original connected negativity')
require(Q(constant['connected_symmetrized'])<0, 'symmetrized connected form strictly negative in edge case')

# Exact inherited Taylor-remainder and new norm-normalized constants.
b=Q(1,10**14); lead=Q(1,2**18); nplaq=450
relative=Q(2*nplaq**11,factorial(11))*b*b/(1-nplaq*b)/lead
require(relative<Q(1,2), 'inherited numerator remainder below one-half')
delta_coefficient=lead/2
negative_coefficient=delta_coefficient**2/16
expected_coeff=Q(1,2**41 if args.negative_control=='constant' else 2**42)
require(negative_coefficient==expected_coeff, 'normalized witness coefficient 2^-42')
require(900*b<Q(1,2), 'exp(-900 beta) lower bound greater than one-half')
require(negative_coefficient/2==Q(1,2**43), 'pure-power explicit negative bound')

# Complex-disk Cauchy certificate for a fully specified finite Taylor witness.
# r=1/(4*255), so denominator discrepancy <=1/3, numerator <=4/3,
# and each quotient and their average have absolute value <=2.
radius=Q(1,1020)
require(255*radius==Q(1,4), 'complex disk scale')
exp_upper=1/(1-255*radius)
require(exp_upper==Q(4,3), 'elementary exponential bound')
denominator_lower=1-(exp_upper-1)
require(denominator_lower==Q(2,3), 'nonzero conditional denominator')
require(exp_upper/denominator_lower==2, 'Cauchy sup bound')
taylor_order=23 if args.negative_control=='taylor_order' else 24
kappa=b**18/Q(2**41)
tail=2*(b/radius)**(taylor_order+1)/(1-b/radius)
tail_relative=tail/(kappa/10)
require(tail_relative<1, 'degree-24 Cauchy tail preserves certified gap')
require(tail<1 and kappa/10<1, 'normalization error below one')
require(tail*(4+tail)<=kappa/2, 'quadratic-form stability')
require(kappa/32==b**18/Q(2**46), 'centered degree-24 normalized gap')

# Independent rational radial consistency checks of the SU(2)=S^3 moments
# used to evaluate each Taylor coefficient without numerical integration.
def rising(a,n):
    ans=Q(1)
    for j in range(n): ans*=a+j
    return ans
def haar_even_moment(ks):
    ans=Q(1)
    for k in ks: ans*=rising(Q(1,2),k)
    return ans/rising(Q(2),sum(ks))
require(haar_even_moment((1,0,0,0))==Q(1,4), 'Haar quadratic moment')
require(haar_even_moment((2,0,0,0))==Q(1,8), 'Haar pure quartic moment')
require(haar_even_moment((1,1,0,0))==Q(1,24), 'Haar mixed quartic moment')
for K in range(13):
    radial=Q(0)
    for k0 in range(K+1):
        for k1 in range(K-k0+1):
            for k2 in range(K-k0-k1+1):
                k3=K-k0-k1-k2
                ks=(k0,k1,k2,k3)
                multinomial=Q(factorial(K), factorial(k0)*factorial(k1)*factorial(k2)*factorial(k3))
                radial+=multinomial*haar_even_moment(ks)
    require(radial==1, 'Haar radial norm identity at degree '+str(2*K))

# Formal quotient recursion is exact in any commutative coefficient algebra;
# test nonconstant rational coefficient sequences through the actual order.
D=[Q(1)]+[Q((-1)**n,n+1) for n in range(1,25)]
N=[Q(0)]+[Q(n,n+2) for n in range(1,25)]
A=[]
for n in range(25):
    an=N[n]-sum(D[k]*A[n-k] for k in range(1,n+1))
    A.append(an)
    require(sum(D[k]*A[n-k] for k in range(n+1))==N[n], 'quotient recurrence order '+str(n))

# Enumerate the comparison seams and multiplicity constants on actual free
# lattices; the Dobrushin theorem itself is proved in the report.
comparison=[]
for d in (3,4):
    vv,ee,ff=complex_data(d,5)
    cc,ce,cf=complex_data(d,5,4)
    cut={f for f,e in ff.items() if e & ce and f not in cf}
    B=set().union(*(ff[f] for f in cut))
    incident=Counter(); multiplicity=Counter(); adjacency={e:set() for e in ee}
    for f,eset in ff.items():
        for e in eset:
            incident[e]+=1
            for g in eset-{e}:
                multiplicity[e]+=1; adjacency[e].add(g)
        if f not in cut:
            require(eset<=ce or not(eset&ce), 'deletion separates core edge variables')
    require(max(incident.values())==2*(d-1), 'plaquette degree bound attained')
    require(max(multiplicity.values())==6*(d-1), 'comparison row multiplicity attained')
    cut_incidence=Counter(e for f in cut for e in ff[f])
    require(max(cut_incidence.values())<=2*(d-1), 'cut degree bound')
    require(all(e in B for e in cut_incidence), 'conditional discrepancy support')
    support=ff[((3,)+(2,)*(d-1),1,2)]
    dist={e:0 for e in B}; queue=deque(B)
    while queue:
        e=queue.popleft()
        for g in adjacency[e]:
            if g not in dist: dist[g]=dist[e]+1; queue.append(g)
    require(min(dist[e] for e in support)==1, 'actual example support-to-seam distance')
    comparison.append({'dimension':d,'links':len(ee),'plaquettes':len(ff),'cut_plaquettes':len(cut),
                       'cut_links':len(B),'max_link_plaquettes':max(incident.values()),
                       'max_row_multiplicity':max(multiplicity.values()),'test_distance':1})

report={'status':'PASS','checks_executed':checks,'method':'exact fractions, complete finite geometry, explicit require/raise',
        'full_box':{'vertices':len(vs),'links':len(es),'plaquettes':len(fs),
                    'plane_positive_negative_links':[len(plane),len(positive),len(negative)],
                    'plane_positive_negative_plaquettes':[len(pf),len(plusf),len(minusf)]},
        'slab':{'vertices':len(cvs),'links':len(ces),'plaquettes':len(cfs)},
        'witness_support_upper_bound':64,'rational_nonconstant_case':rational,'rational_constant_mismatch_case':constant,
        'beta_ceiling':str(b),'prior_relative_remainder':str(relative),'normalized_exponential_coefficient':str(negative_coefficient),
        'normalized_pure_power_coefficient':str(negative_coefficient/2),
        'taylor_certificate':{'order':taylor_order,'complex_radius':str(radius),'plane_entry_degree':taylor_order,
                              'maximum_plane_links_in_half_plaquette':max_plane_edges,
                              'tail_over_one_tenth_gap_at_beta_ceiling':str(tail_relative),
                              'normalized_polynomial_gap_coefficient':str(Q(1,2**46)),
                              'coefficient_list_expanded':False},
        'comparison_geometry':comparison,
        'scope':'No numerical SU(2) integration; no weak-coupling or arbitrary-depth theorem.'}
print(json.dumps(report,indent=2,sort_keys=True))
