# Conditional boundary asymmetry gives a real negative Wilson RP test

19 October 2026. Local derivation and verification; no external mutation, merge, or release.

## Results and novelty boundary

1. **New strengthening of the audited finite-cube obstruction.** The three-dimensional free SU(2) Wilson cube from the preceding report has a bounded, real, continuous, gauge-invariant observable in the **closed positive-half algebra** with a strictly negative reflected quadratic form. This replaces the previous merely nonreal complex form. The new observable uses a centering function of every fixed-plane link, so it reaches the transverse boundary; it is not a strictly interior or uniformly local witness.
2. **Averaging does not repair this actual finite Wilson example.** The average of the matched-slab marginal and its reflected marginal is reflection invariant and gauge invariant, but the same real observable has mean zero and strictly negative connected reflected covariance. This is a mixture of finite Wilson marginals, not itself the usual free Wilson measure on the slab.
3. **Boundary-distance decay is already available in the recovered strong-coupling range.** A direct comparison gives a quantitative full complex-form bound, stated in Section 6. This is a routine consequence of the existing Dobrushin seam result, not a new mixing theorem. The all-beta four-dimensional comparison needed on a weak-bare-coupling continuum trajectory remains unproved here.

There is also a constructive polynomial refinement: a beta-Taylor centering through order 24 gives a gauge-invariant link polynomial of degree at most 24 with certified negative form. Its coefficient recursion is specified exactly, but its large coefficient list is not expanded. This refinement retains the closed-half, boundary-reaching support and beta-dependent observable qualifications.

The new real test strengthens a finite-volume obstruction. It does not obstruct joint approximate RP or a common infinite-volume limit in the strong-coupling regime.

## 1. General conditional-centering identity

Let a reflection-invariant configuration space have coordinates `(Z,Y+,Y-)`, where reflection fixes `Z` pointwise and exchanges the two half configurations through a fixed identification. Suppose a probability law has conditional product form

    mu(dZ,dY+,dY-) = rho(dZ) P_Z(dY+) Q_Z(dY-).

The kernels need not be equal. Let `X=X(Z,Y+)` be a bounded real positive-half observable and `theta X=X(Z,Y-)` its reflected counterpart. Define

    a(Z)=E_mu[X | Z],       b(Z)=E_mu[theta X | Z],
    c(Z)=(a(Z)+b(Z))/2,     F=X-c(Z).

The function `c` is fixed by reflection: it is evaluated on the fixed coordinate `Z`; this does not assert that the original probability law is reflection invariant. Conditional independence gives exactly

    E_mu[(theta F)F | Z]
      = (b-c)(a-c) = -(a-b)^2/4.                       (1)

Consequently

    Q_mu(F):=E_mu[(theta F)F]
      = -E_rho[(a-b)^2]/4
      <= -(E_mu X-E_mu theta X)^2/4.                  (2)

If `|X|<=1`, then `|c|<=1`, `|F|<=2`, and the normalized real observable `G=F/2` obeys

    ||G||_infinity<=1,       Q_mu(G)<=-delta^2/16,
    delta=E_mu X-E_mu theta X.                        (3)

This is an exact bounded-measure identity, not a perturbative or Gaussian argument. Strict negativity follows whenever `a-b` is nonzero on a set of positive `rho`-measure; a nonzero scalar mean difference `delta` is sufficient.

**Connected-form distinction.** In the original asymmetric law,

    E_mu F=delta/2,       E_mu theta F=-delta/2,
    Cov_mu(theta F,F)=-Var_rho(a-b)/4 <= 0.            (4)

Equation (2) alone does not imply strict negativity in (4), since `a-b` could be a nonzero constant.

### Reflection symmetrization

Set `mu_bar=(mu+theta_*mu)/2`. The plane marginal `rho` is unchanged. The real product `(theta F)F` is pointwise reflection invariant, so

    E_mu_bar F=0,
    Cov_mu_bar(theta F,F)=Q_mu_bar(F)
      =Q_mu(F)=-E_rho[(a-b)^2]/4.                     (5)

Thus reflection symmetrization preserves the negative form and makes it a strictly negative connected form whenever the original conditional laws differ in the tested expectation. Symmetrization replaces `P_Z tensor Q_Z` by `(P_Z tensor Q_Z+Q_Z tensor P_Z)/2`; it does not replace it by a square product.

## 2. The actual free Wilson cube satisfies the factorization

Take all vertices, nearest-neighbor links, and elementary plaquettes in

    Lambda={0,1,...,5}^3.

Every positively oriented link carries an independent normalized SU(2) Haar variable; reversed orientation means inverse. Let

    dmu_beta = Z_beta^(-1) exp(beta sum_p w_p) dHaar,
    w_p=(1/2) Tr(U_p),       beta>=0.

SU(2) traces here are real and `|w_p|<=1`. The reflection is

    theta(x0,x1,x2)=(4-x0,x1,x2),

through the site plane `x0=2`. It preserves the matched slab

    C={0,...,4} x {0,...,5}^2,

but not the full box. Let `mu_C` be the marginal on the slab's links. The reflected form is defined on that marginal algebra.

Partition **all full-box links** into:

- `E0`: both endpoints on `x0=2`; these are the 60 tangent links in directions 1 and 2.
- `E+`: nonplane links with both endpoints in `x0>=2`.
- `E-`: nonplane links with both endpoints in `x0<=2`.

The sets are disjoint and exhaustive, with sizes `60,288,192`. No link joins both strict half-spaces. An elementary plaquette spans at most one unit in `x0`, so none meets both strict half-spaces. Splitting the Wilson action gives

    S=S0(U0)+S+(U0,U+)+S-(U0,U-).

There are respectively `25,255,170` plaquettes in these three parts. Conditional on the plane variables `U0=eta`, product Haar therefore makes `U+` and `U-` independent. Integrating the extra positive-side links outside `C` preserves this conditional product structure on the two slab halves.

Reflection fixes every positively oriented plane link individually, including its orientation; it exchanges the positive and negative nonplane links of the slab, with inversion when an oriented link is reversed. Thus the conditional-centering identity applies exactly.

Use

    X=w_p,  p the (1,2)-plaquette based at (3,2,2),
    theta X=w_q,  q based at (1,2,2).

The variables in `X` and `theta X` are strictly inside their respective halves and strictly inside the full geometric box. Define `a_beta,b_beta,c_beta` using the conditional law of the **full original free box**, then set

    F_beta=w_p-c_beta(U0),       G_beta=F_beta/2.       (6)

This is a precisely defined finite-dimensional observable. It depends on the four links of `p` and at most all 60 fixed-plane links. It belongs to the closed positive-half algebra of `C`; its reflection is `w_q-c_beta(U0)`.

### Continuity and gauge invariance

For example,

    a_beta(eta)
      = [integral w_p exp(beta S+(eta,U+)) dHaar(U+)]
        /[integral exp(beta S+(eta,U+)) dHaar(U+)].

The analogous ratio defines `b_beta`. At finite beta the denominators are strictly positive and the integrands continuous on compact spaces. Hence `a_beta,b_beta,c_beta` are continuous real functions of `eta`; on the real beta axis they are locally real analytic in beta. The plane action and the opposite half cancel from the conditional ratios.

A gauge transformation of the plane vertices extends to a transformation of the full box. Haar changes of variables in the conditional half integrals leave each ratio invariant, because `w_p,w_q` are gauge invariant. Off-plane gauge transformations act only on integration variables. Thus `c_beta`, `F_beta`, and `G_beta` are gauge invariant. No gauge fixing or singular conditional density is used.

## 3. A certified negative interval and bound

The preceding independently audited character-surface calculation gives

    delta(beta)=mu_beta(w_p)-mu_beta(w_q)
      = beta^9/2^18 + O(beta^11),

and, for the unnormalized numerator `N(beta)=Z_beta delta(beta)`,

    N(beta)>=beta^9/2^19,       0<beta<=10^(-14).     (7)

There are 450 plaquettes and `sum_p w_p<=450`, so `Z_beta<=exp(450 beta)`. Therefore

    delta(beta)>=beta^9 exp(-450 beta)/2^19 >0.

Applying (3) to the normalized real gauge-invariant observable (6),

    mu_C((Theta G_beta)G_beta)
      <= -beta^18 exp(-900 beta)/2^42
      <= -beta^18/2^43 <0,
                  0<beta<=10^(-14).                 (8)

The final inequality uses `exp(-900 beta)>=1-900 beta>1/2` on this interval. Since `G_beta` is real, `Theta G_beta=theta G_beta`.

No Taylor expansion of the conditional kernels is needed. The inherited scalar mean certificate and exact conditional factorization suffice. Bound (8) is deliberately tiny and conservative; it is not asserted to be the leading Taylor behavior of this new witness.

## 4. A reflection-invariant finite Wilson-marginal counterexample

On the matched slab define

    mu_bar_beta=(mu_C+theta_*mu_C)/2.                 (9)

This probability measure is exactly theta invariant and gauge invariant. The same observable `G_beta` has mean zero under (9), and (5),(8) imply

    Cov_mu_bar_beta(Theta G_beta,G_beta)
      <= -beta^18/2^43 <0.

This is an actual SU(2) Wilson-marginal averaging obstruction, unlike the earlier scalar-spin averaging examples. Its exact scope is the finite slab marginal with two possible asymmetric exterior extensions. It is not the standard free Wilson law on the slab, not a homogeneous infinite-volume Wilson Gibbs counterexample, and not a failure of standard Wilson RP on a reflection-invariant free volume.

More explicitly, let `Z_j` denote the tangent links on the outer slab plane `x0=j`. Integrating the 96 links of the extra layer `4<x0<=5` and its 85 extra plaquettes gives a strictly positive boundary factor `B_beta(Z_4)`. Relative to Haar on the slab,

    dmu_bar_beta/dHaar
      = exp(beta S_C) [B_beta(Z_4)+B_beta(Z_0)]/(2 Z_beta).

Thus the symmetrized marginal retains the ordinary Wilson conditional kernels for link updates disjoint from the tangent-link sets `Z_0` and `Z_4`. The failure is produced by effective boundary data. It is not a change of the Wilson plaquette action in the bulk. In fact the stronger centering `E_mu_bar_beta[F_beta|U0]=0` holds.

### Polynomial positive-half tests and a constructive degree bound

If the test algebra is restricted to matrix-coefficient polynomials, use a real plane polynomial `c_epsilon` with `||c_epsilon-c_beta||_infinity<=epsilon`. Such approximants exist by Peter-Weyl/Stone-Weierstrass density on the finite product of SU(2) groups. Averaging over the finitely many plane vertex gauge groups preserves polynomiality, does not worsen uniform error, and gives gauge-invariant approximants.

For `F_epsilon=w_p-c_epsilon`,

    |Q(F_epsilon)-Q(F_beta)|<=epsilon(4+epsilon).

This estimate holds under either measure, since `||F_beta||<=2`. Put `kappa_beta=beta^18/2^41`, the certified unnormalized-witness gap. Choosing `0<epsilon<=min(1,kappa_beta/10)` preserves a gap of at least `kappa_beta/2`. Under the symmetrized measure, subtracting `mu_bar_beta(F_epsilon)` gives an exactly mean-zero real gauge-invariant polynomial and only decreases its reflected form.

In this particular box, a finite Taylor construction gives the explicit **matrix-entry degree bound 24**; arbitrary approximation is unnecessary. Let `z` be the complex coupling and define, for each half,

    D_n^+(eta) = integral S+(eta,U+)^n/n! dHaar(U+),
    N_n^+(eta) = integral w_p S+(eta,U+)^n/n! dHaar(U+),

with the analogous minus quantities using `w_q,S-`. These are coefficients in the unnormalized conditional denominator and numerator. Set `a_0=N_0^+=0`, `b_0=N_0^-=0`; for `n>=1`, define recursively

    a_n=N_n^+ - sum_(k=1)^n D_k^+ a_(n-k),
    b_n=N_n^- - sum_(k=1)^n D_k^- b_(n-k),
    c_n=(a_n+b_n)/2.

These are exactly the Taylor coefficients of `a_z,b_z,c_z`, since `D_0^+=D_0^-=1`. Define the finite polynomial

    c_beta^[24](eta)=sum_(n=0)^24 beta^n c_n(eta).

Every off-plane half plaquette contains at most **one** plane link; the plane-only plaquettes were excluded from `S+` and `S-`. Also `w_p,w_q` have no plane links. Each `D_n^±,N_n^±` therefore has plane matrix-entry degree at most `n`; the displayed recurrence preserves that degree bound. Consequently `c_beta^[24]` has degree at most 24, and `w_p-c_beta^[24]` has total link-entry degree at most 24. Inverse SU(2) entries are linear in the real quaternion coordinates, so this degree convention includes inversely oriented links. All coefficients are real and gauge invariant.

The coefficient prescription is finite and exact: integrate each off-plane SU(2) link independently using its normalized quaternion-sphere moments. Odd exponents vanish, and for nonnegative integers `k_0,...,k_3`,

    integral product_(j=0)^3 q_j^(2k_j) dHaar
       = product_(j=0)^3 (1/2)_(k_j) / (2)_(sum k_j).

Thus the coefficients, in quaternion coordinates, are rational numbers multiplying plane polynomials. This is a recursive specification, not a claim that the large coefficient list was expanded, that the construction is efficient, or that a useful coefficient-height bound was obtained.

For completeness, its uniform approximation error has an elementary certificate. There are 255 plus-half and 170 minus-half plaquettes. On `|z|<=r=1/1020`, at every plane configuration,

    |D^±(z,eta)-1| <= exp(255r)-1 <= 1/3,
    |N^±(z,eta)| <= exp(255r) <= 4/3,

using `exp(1/4)<=1/(1-1/4)=4/3`. Hence the denominators do not vanish, the conditional quotients are holomorphic, and `|a_z|,|b_z|,|c_z|<=2`. Cauchy's coefficient estimate gives

    epsilon_beta:=||c_beta-c_beta^[24]||_infinity
       <= 2(1020 beta)^25/(1-1020 beta).

For all `0<beta<=10^(-14)`, exact rational arithmetic verifies

    epsilon_beta/(kappa_beta/10)
       <= 20*2^41*1020^25 beta^7/(1-1020 beta) <1.

The upper bound increases with beta on the stated interval, so checking its right endpoint suffices. It is also less than 1 in absolute error. Thus `F_beta^[24]=w_p-c_beta^[24]` has `Q<=-kappa_beta/2` under both the original marginal and its reflection symmetrization.

The two normalized polynomial versions

    G_beta,original^[24]=F_beta^[24]/4,
    G_beta,symmetric^[24]
       =(F_beta^[24]-mu_bar_beta(F_beta^[24]))/4

have sup norm at most 1; the latter is exactly mean zero. Their respective reflected forms obey

    Q <= -beta^18/2^46 <0.

For the second version, subtracting the mean changes `Q` to `Q-mu_bar_beta(F_beta^[24])^2` and cannot increase it. Its norm is at most `(2+2epsilon_beta)/4<=1`. The scalar centering coefficient is defined by the finite expectation; it need not be a polynomial in beta. Both observables are polynomials of degree at most 24 in the link coordinates at each fixed beta, with the same plane-reaching closed-half support caveat as before. This is not a single beta-independent test.

## 5. Exact characterization for a conditionally factorized site cut

In the setting of Section 1, assuming the usual compact metric half-configurations and continuous positive finite-volume kernels, the following are equivalent:

1. Real reflected positivity for all bounded continuous closed-positive-half observables, allowing dependence on `Z`.
2. `P_Z=Q_Z` for `rho`-almost every `Z`.
3. The original conditionally product law is reflection invariant.

For `2=>1`, the reflected form is the integral of an absolute square. For `1=>2`, apply (1) to each member of a countable measure-determining dense family of continuous half observables. Positivity forces each conditional expectation difference to vanish almost surely, and the countable intersection identifies the two kernels. For `2<=>3`, take conditional half marginals of the equality between `P_Z tensor Q_Z` and `Q_Z tensor P_Z`.

The continuum version of item 1 can be restricted to continuous functions because the conditional ratios used in the witness are continuous. This characterization is not asserted for diagonal cuts with nontrivial crossing-plaquette kernels, or for infinite-half-space conditional laws without a separately established global Markov property. In particular it cannot repair the earlier infinite-volume state-selection gap by itself.

## 6. Recovered quantitative boundary-distance upper bound

This section records a useful **routine corollary of the already available strong-coupling proof**, rather than a new coupling regime.

Let `Lambda` be a finite free induced lattice complex in dimension `d`, and let `theta` be a reflection for which

    C=Lambda intersect theta Lambda

is a reflection-invariant free induced complex with an established Wilson RP factorization on the chosen half-algebra. Suppose `F` and `theta F` are supported in `C`, `||F||_infinity<=M`, and `S` is their union of link supports. Retain independent Haar variables on all of `Lambda`.

Let `P_cut` be the plaquettes of `Lambda` that contain at least one link of `C` but are not plaquettes of `C`. Set their couplings to zero, retaining all other couplings. The resulting measure `mu_0` factors between the links of `C` and the remaining links, with `C` marginal equal to its free Wilson measure. The original full law is `mu_1`.

Let `B` be all links belonging to `P_cut`. Put an adjacency edge between distinct lattice links sharing a plaquette of `Lambda`, and let

    r=dist_graph(S,B),     q=6(d-1) beta.

For `0<q<1`, homogeneous couplings beta, or more generally any retained/interpolated couplings in `[0,beta]`, the standard single-link comparison gives

    |mu_1((Theta F)F)-mu_0((Theta F)F)|
      <= 2(d-1) beta M^2 |S| q^r/(1-q).              (10)

In dimension four, the right side is `6 beta M^2 |S| (18 beta)^r/(1-18 beta)`. This bound applies to complex `F` even when the full box or interpolation is not theta invariant. In particular

    dist(mu_1((Theta F)F), [0,infinity))
      <= 2(d-1) beta M^2 |S| q^r/(1-q),              (11)

where distance is in the complex plane. Thus it controls both a negative real part and a nonzero imaginary part. There is no seam-area factor.

### Constants and proof

Let `k_ef` count plaquettes containing distinct links `e,f`. A one-link conditional log-density change when only `f` changes has oscillation at most `4 beta k_ef`. The sharp elementary total-variation oscillation bound gives influence at most `tanh(beta k_ef)<=beta k_ef`. Each link lies in at most `2(d-1)` plaquettes, each with three other links; consequently the comparison matrix `C_ef=beta k_ef` has row sums at most `q`.

At a fixed outside configuration, deleting the `k_e^cut` incident cut plaquettes changes the one-link conditional log density by a function of oscillation at most `2 beta k_e^cut`. Thus its total-variation discrepancy is at most

    b_e<=tanh(beta k_e^cut/2)<=beta k_e^cut/2
        <=(d-1)beta 1_B(e).

The finite-volume heat-bath maximal-coupling comparison, derived in the recovered seam proof, gives for any bounded complex `h`

    |mu_1(h)-mu_0(h)|
      <= sum_e delta_e(h) [(I-C)^(-1)b]_e.

This complex version follows directly by the triangle inequality in the coupling telescoping bound; no real-covariance inequality is being applied to a complex function. Because `C` only joins adjacent links,

    sum_(f in B) [(I-C)^(-1)]_ef <= q^r/(1-q)

for `e in S`. Finally `h=(Theta F)F` satisfies `||h||<=M^2` and `delta_e(h)<=2M^2`. This proves (10). RP on `C` makes the reference form a nonnegative real number, giving (11).

If beta is zero, `P_cut` is empty, or the support is disconnected from `B` in the interaction graph, the corresponding error is zero and should be handled directly; no `0^0` or `q^infinity` convention is needed. For a constant `F`, the error is also zero.

For a finite collection of positive-half tests `F_i`, use the union support and apply (10) to `sum_i z_i F_i`. Cauchy-Schwarz bounds its sup norm by `||z||_2 (sum_i ||F_i||_infinity^2)^(1/2)`, so the finite reflected Gram form is uniformly close to a positive semidefinite Hermitian form. Different cuts may use different cores `C_j`; the original common measure `mu_1` is the same.

## 7. Recovery conditions and limits of the estimate

For any fixed finite list of affine coordinate-site or signed-diagonal cuts, centered growing cubes have reflected cores `C_j=Lambda_L intersect theta_j Lambda_L`. Every fixed local test and its reflection eventually lie far from the corresponding cut seam. Their graph distances tend to infinity. In the uniform contraction regime `q<=q0<1`, (11) therefore supplies joint approximate RP in one common free-cube sequence. Local DLR defects vanish, and all fixed tests pass to subsequential limits. This corollary was already implicit in the recovered strong-coupling work.

More generally, a proved local comparison modulus between each free cube and its reflected core, tending to zero for the tested products, suffices. Full Gibbs uniqueness at a fixed beta gives qualitative local boundary independence by compactness, without automatically providing an explicit rate. The comparison need only be established in the desired observable sector; asserting uniqueness is a sufficient input, not an established all-beta conclusion here.

With varying beta, support, and normalization, a sufficient version of (10) is

    [beta_a/(1-q_a)] M_a^2 |S_a| q_a^(r_a) -> 0,
    q_a=6(d-1)beta_a<1.                               (12)

A physical-distance statement must convert the actual plaquette-adjacency distance to physical units and retain the factors `M_a^2 |S_a|`. The new witness (6) uses the whole plane, including links at the transverse boundary, and the certified example is one fixed finite box. It supplies no fixed-support, arbitrarily deep obstruction. If adapted to growing boxes, its full growing support and its distance to the actual comparison seam must be retained; touching a different boundary face does not itself force the seam distance to be small. Nothing in (8) contradicts (12).

The Wilson normalization here is inverse bare coupling: along the intended weak-bare-coupling continuum trajectory beta tends to infinity. The bound `q=18 beta<1` in dimension four then fails. This failure of a sufficient contraction criterion is not a proof that a boundary estimate is false. A block-scale replacement would require a verified comparison bound for the actual blocked interaction, including multibody and large-field terms. Nothing in this report provides that missing theorem.

The recovered finite-width all-beta cylinder theorem also does not solve it: its contraction constant can deteriorate with transverse width. The mixed coordinate/diagonal affine group requires at least two unbounded directions; the one-dimensional fixed-width uniqueness proof cannot simply be applied uniformly to that limit.

## 8. Recovered sources, checks, and stopping point

Recovered before deriving the new claim:

- `wilson-simultaneous-rp-20261018/RESULT.md`: common-center joint RP, the all-affine finite-intersection gap, and scalar averaging obstructions.
- `invariant-diagonal-rp/construction/RESULT.md` and its `uniqueness/one_dimensional_uniqueness.md`: all-beta one-parallel-family construction; finite-width constants are not width uniform.
- `tilted-volume-compatibility/RESULT.md`: incompatible separating coordinate/diagonal period-lattice cuts and no established equality of selected local states.
- `strong-coupling-seam/PROOF.md`, pinned repository commit `4ff17ed90aa40a453129d1d0b9cea0bf483c949a`, Git blob `1a5d84389251c62c7f02cad04fec0d047f37e9db`: the explicit `18 beta<1` comparison and seam-response estimate. A verified copy is in `sources/`.
- `joint-lattice-rp-20261019-1311/RESULT.md` and `free-cube-rp-audit-20261019-1320/AUDIT.md`: the exact scalar mean mismatch and certified interval used in Section 3.

Primary comparison-theory attribution: Patrick Rebeschini and Ramon van Handel, *Comparison Theorems for Gibbs Measures*, Journal of Statistical Physics 157 (2014), 234-281, https://arxiv.org/abs/1308.4117 . The constants needed here are derived directly above and in the recovered seam proof; no all-beta SU(2) estimate is attributed to that paper.

`check_conditional_witness.py` verifies the actual free-box link/plaquette partition, matched-slab reflection including oriented-link behavior, support placement, scalar inequality arithmetic, and exact rational instances of every conditional-centering and symmetrization identity. It certifies the uniform degree-24 Taylor remainder, the one-plane-link degree count, quotient recursion identities, and rational Haar-moment consistency checks. It also enumerates link incidences and cut sets in dimensions 3 and 4 for (10). These computations supplement the general proofs; they do not numerically integrate SU(2), expand the new conditional coefficient polynomials, or prove weak-coupling mixing. The prior exact SU(2) coefficient audit is replayed separately and preserved in `sources/`.

The independent report `../centered-rp-audit-20261019-1410/AUDIT.md` independently verifies the factorization, orientations, continuity/gauge invariance, real negative form, connected-form distinction, constants, and effective-boundary scope.

**Unresolved target:** an all-beta four-dimensional, or suitable weak-coupling-sequence, local comparison of a common volume with each reflected core strong enough for the selected reflected products and deterministic source normalizations. Neither the new negative witness nor the recovered strong-coupling bound closes that target.
