# Normalized half-kernel criteria for simultaneous Wilson RP

19 October 2026. Local research only. No repository changes, PR merges, or releases.

## Result and limitation

This note gives an all-finite-coupling **reduction**, not an all-coupling mixing theorem. Standard Gaussian factorization and Haar subdivision turn the SU(2) Wilson measure on an asymmetric finite free box into a conditionally independent two-half model for each of the following lattice cuts:

* coordinate site planes `x_i=k`;
* coordinate bond planes `x_i=k+1/2`, for observables excluding the crossing links;
* signed-diagonal planes `x_i +/- x_j=k`, with integer `k`.

The same physical free-box measure can be used for every cut; only its auxiliary representation changes. A normalized, local, mean-square mismatch between the reflected conditional half kernels then controls the complete complex RP form, with **no area or partition-function-ratio prefactor**. Vanishing of that mismatch along one common exhaustion yields one Gibbs state satisfying all these RP inequalities. This is a reflection-specific sufficient input and does not require full Gibbs uniqueness.

The reduction is not a proof that the input vanishes for four-dimensional Wilson theory at arbitrary beta, or along beta tending to infinity. The existing `18 beta<1` comparison already supplies strong-coupling recovery and is not reproved here. The remaining all-beta issue is stated precisely in Section 8.

The Gaussian identity itself is standard Hubbard–Stratonovich algebra. The useful point here is its normalized conditional-probability implementation across the mixed affine cut family, including bond-plane subdivision, and the distinction between local tests and growing plane-dependent tests.

## 1. Finite-volume setup and the two halves

Let `Lambda` be a finite induced lattice complex, with independent normalized SU(2) Haar variables on positively oriented links and inverse variables on reversed links. Its free Wilson law has density

    Z_Lambda^(-1) exp(sum_(p in Lambda) beta_p w_p),
    w_p=(1/2) Re Tr U_p,       beta_p>=0.

The homogeneous model is `beta_p=beta`. Fix one of the listed reflections `theta`. A positive-half observable `F` depends only on physical links with both endpoints in the closed positive half-space; for a bond plane neither endpoint lies on the plane, so crossing links are excluded. Assume the supports of `F` and `F composed with theta` lie in `Lambda`.

If the two half domains have different shapes, put their variables into a common reflected ambient set using `Lambda union theta Lambda`, with independent unused Haar dummy variables for absent links. No absent plaquette is restored. This identifies the two half configuration spaces without changing any expectation under the original free law.

For a coordinate site plane, no plaquette meets both strict sides. The fixed-plane tangent links form a shared variable `Z`; conditioning on `Z` already gives conditional independence, as in the preceding conditional-centering report.

For a signed-diagonal plane, no link joins the two strict sides. Each plaquette that meets both strict sides is individually preserved by reflection and has two fixed opposite vertices. Its two two-link paths between those vertices are `P+` and `P-`, exchanged by reflection. With a suitable orientation,

    w_p=(1/2) Re Tr(P+ P-^dagger).

This remains true in an asymmetric induced box: if the crossing plaquette is present, all of its own reflected links are present because the plaquette is mapped to itself. Unmatched plaquettes lie wholly on one side and merely change that side's action.

Integer diagonal level is essential. The planes `x_i +/- x_j=k` with integer `k` give lattice automorphisms; arbitrary real translates are not included.

## 2. Coordinate bond planes: exact Haar subdivision

Consider `x_0=k+1/2`. Each crossing link `e=(u,u+e_0)` is mapped to the oppositely oriented version of itself. Introduce its midpoint `m_e` and two independent Haar variables `V_e^-`, `V_e^+`, interpreted as transporters from `m_e` to its minus and plus endpoints. Replace

    U_e=(V_e^-)^dagger V_e^+.

For any integrable function of the original links, integrating all new half-links gives exactly its original Haar integral: conditional on `V_e^-`, the product `(V_e^-)^dagger V_e^+` is normalized Haar. This argument applies independently to every crossing link. The extra midpoint gauge freedom contributes a factor one, not a gauge-volume denominator.

Every crossing plaquette is individually reflection-preserved. For a plaquette with crossing edges at tangent locations `x,y`, let `T+` and `T-` be its two tangent physical links, oriented from the `x` endpoint to the `y` endpoint. Set

    P+ = V_x^+ T+ (V_y^+)^dagger,
    P- = V_x^- T- (V_y^-)^dagger.

The usual physical plaquette trace equals `(1/2) Re Tr(P+ P-^dagger)`, by substituting the crossing links and cyclically moving `V_x^-`. Reflection exchanges `P+` and `P-`, and exchanges the two half-link variables at each midpoint. All other physical links and plaquettes lie on one side.

Thus a bond cut has become a path-pair cut with no shared physical plane links. This construction proves statements for the stated original positive-half algebra. It does not silently include complete crossing-link variables in that algebra. The half-link variables are integration variables, not new physical observables or changed Wilson interactions.

## 3. Positive Gaussian features give normalized conditional kernels

Write an SU(2) matrix as `P=q_0 I+i sum_(j=1)^3 q_j sigma_j`, where `q(P)` lies on the unit sphere in `R^4`. Then

    (1/2) Re Tr(P Q^dagger)=q(P) dot q(Q).

For a standard Gaussian vector `xi` in `R^4`, define

    phi_beta(xi,P)=exp(sqrt(beta) xi dot q(P)-beta/2).

The elementary Gaussian moment-generating identity gives exactly

    E_xi[phi_beta(xi,P) phi_beta(xi,Q)]
      = exp(beta q(P) dot q(Q)).                    (1)

The features are strictly positive real numbers. Introduce an independent `xi_p` for each crossing plaquette, using its coupling `beta_p`, and replace its Wilson factor by the integrand in (1). Integrating the Gaussians recovers the original Wilson law exactly. All integrals are finite: integrating the positive integrand first in the Gaussians gives the bounded finite-volume Wilson integrand. Tonelli therefore justifies every rearrangement.

Let `W` consist of the physical fixed-plane links `Z`, when present, and all crossing Gaussians. Given `W`, the augmented plus and minus variables have independent normalized laws `P_W` and `Q_W` on the common reflected half-space. Schematically,

    d mu_tilde(W,Y+,Y-)=rho(dW) P_W(dY+) Q_W(dY-).   (2)

The plus density contains its entire physical half action and all its factors `phi_beta(xi_p,P_p+)`; the minus density is defined analogously. The marginal `rho` includes the product of the two finite conditional partition functions, the fixed-plane action, Haar plane measure, and Gaussian reference measure. It need not be a product law and the conditional Gaussian fields are not asserted to remain Gaussian under `rho`.

All kernels in (2) are normalized probability kernels. For a physical positive-half test `F`, its two conditional means therefore satisfy

    a_F(W)=P_W F,      b_F(W)=Q_W F,
    |a_F|,|b_F| <= ||F||_infinity.

No ratio between a doubled-plus partition function and the original partition function enters this bound. A Hilbert-space comparison of unnormalized signed feature amplitudes can acquire an exponentially bad surface prefactor; normalized positive features avoid that particular artifact. They do not imply that `a_F-b_F` is small.

Gauge covariance is compatible with this augmentation. At the common endpoints of a path pair, left and right SU(2) multiplication acts orthogonally on its quaternion vector. Applying the same orthogonal transformation to the corresponding Gaussian preserves its reference law. For bond cuts there is also the harmless midpoint gauge action. Consequently one may restrict the test criterion to gauge-invariant physical observables if only sector RP is desired.

## 4. Exact defect identity and quantitative RP bounds

Define, for the original physical measure,

    Q_mu(F)=mu[overline(F composed with theta) F],
    D_mu,theta(F)=E_rho |a_F-b_F|^2.

Conditional independence in (2) gives

    Q_mu(F)=E_rho[overline(b_F) a_F].                (3)

Put `m=(a_F+b_F)/2` and `d=(a_F-b_F)/2`. Then

    Re Q_mu(F)=||m||_2^2-||d||_2^2
               >= -D_mu,theta(F)/4.                (4)

The imaginary part is not discarded. With `M=||F||_infinity`, compare (3) with the nonnegative number `E|a_F|^2`:

    dist(Q_mu(F),[0,infinity))
       <= |E[(overline(b_F)-overline(a_F)) a_F]|
       <= M sqrt(D_mu,theta(F)).                   (5)

In particular `|Im Q_mu(F)|` obeys the same upper bound. The mean asymmetry also obeys

    |mu(F)-mu(F composed with theta)| <= sqrt(D_mu,theta(F)).

These are inequalities for one common physical measure, not its reflection average. They hold for every finite nonnegative coupling, including an arbitrarily large finite beta. They are an exact algebraic reduction, not estimates of the mismatch itself.

For `F_1,...,F_s`, put `a_i=a_(F_i)`, `b_i=b_(F_i)` and

    G_ij=E[overline(b_i) a_j],
    D_ij=E[overline(a_i-b_i)(a_j-b_j)].

The Hermitian part of the reflected Gram matrix satisfies

    (G+G^dagger)/2 >= -D/4.                        (6)

Moreover its distance in operator norm from the positive matrix `A_ij=E[overline(a_i)a_j]` is at most

    ||G-A|| <= sqrt(||D|| sum_i ||F_i||_infinity^2).

Thus convergence of the finitely many diagonal defects suffices for a whole finite test family, including complex coefficients. There is no need to choose different physical subsequences for different linear combinations.

For connected forms use `F-mu(F)`. Subtracting a constant leaves `a_F-b_F` unchanged, so (4) still has the same defect. The counterpart of (5) has the safe bound `2M sqrt(D)`.

## 5. A common-exhaustion theorem

Fix a finite beta and a growing sequence of free induced boxes `Lambda_n` exhausting `Z^d`. Let `mu_n` be their actual Wilson laws, extended outside the boxes by independent Haar variables. Let `R` be any countable family of the coordinate site, coordinate bond, and integer signed-diagonal cuts above.

**Sufficient hypothesis.** For each `theta` in `R` and every bounded continuous cylinder function `F` in its specified positive-half algebra,

    D_(mu_n),theta(F) -> 0.                        (7)

The auxiliary representations may differ with `theta`; the physical law `mu_n` must be the same. Hypothesis (7) can equivalently be checked on a countable uniformly dense cylinder algebra and extended using `||a_F-a_G||_2<=||F-G||_infinity` and the same bound for `b`.

**Conclusion.** Every physical local weak cluster point of this one sequence is a gauge-invariant Wilson DLR state and is RP for every cut in `R` on the stated algebra.

Proof: compactness of the physical SU(2) product space supplies a cluster point. Each fixed finite set and its plaquette interaction neighborhood eventually lies inside every box, so the finite local DLR identity passes to the limit by continuity. For any fixed cut and test, (5) and continuity of its reflected cylinder product imply a nonnegative real limiting form. The same limit works for all tests and cuts; no convergence of the auxiliary laws is required.

If `R` contains all coordinate site planes, all coordinate bond planes, and the origin signed-diagonal planes, and (7) is imposed on the full physical half algebra, the limit is also translation invariant and hypercubic invariant. For site cuts the two closed-half algebras generate the whole physical cylinder algebra. The limit form is Hermitian by polarization, which implies reflection invariance on products of half observables and hence on all cylinder functions. Reflections in coordinate sites 0 and 1 give translations by 2. For a bond reflection, move an arbitrary cylinder test far enough into its positive half using an even translation; the limiting mean-asymmetry bound then gives invariance for that test, and even-translation invariance moves it back. A site reflection composed with the adjacent bond reflection gives a unit translation. The signed-diagonal site cuts supply the remaining signed coordinate permutations.

The sector-only version gives sector RP directly. Full spatial invariance should not be inferred from a smaller gauge-invariant test algebra without separately checking that it determines the desired state symmetry.

## 6. What does not require uniqueness, and what is still too strong

### Phase memory is allowed

Condition (7) compares two particular reflected conditional kernels under their actual joint boundary-field distribution. It does not compare arbitrary boundary conditions, require a supremum over them, or force `a_F(W)` to become deterministic. Both kernels may retain a shared nontrivial phase label for all volumes. For example, `P_W=Q_W=nu_(phase(W))` has defect zero even if the distinct `nu_+` and `nu_-` have different local order parameters.

This establishes that the input need not force Gibbs uniqueness. It does **not** establish the converse logical implication that physical Gibbs uniqueness automatically forces (7) for this particular growing auxiliary conditioning. That additional implication is not used or asserted. The local phase-law approximation criterion below also permits alternate representations rather than requiring the defect of one fixed augmentation to vanish.

A standard bounded finite-range Gibbs illustration is the layered Ising interaction on `Z^3` with ferromagnetic couplings only within each `(x_0,x_1)` layer. Below the two-dimensional critical temperature it has many Gibbs states. For free cubes, the layers have identical finite-volume distributions and are independent. For every affine cut normal to `e_2`, reflected local half kernels match exactly once the test and its reflection are inside the box, even though plus and minus boundary conditions within the layers select different local states. Thus reflection-specific kernel matching for this family can coexist with genuine failure of bulk uniqueness and full boundary independence. This is a logical separation, not a Wilson weak-coupling example or a proof for every mixed Ising cut.

### Vanishing mismatch is sufficient, not necessary

The conditioning variable includes an entire growing plane and, for diagonal/bond cuts, an entire growing collection of auxiliary fields. A witness such as `F-(a_F+b_F)/2` can depend on all those variables. It is generally not a fixed local physical observable; with Gaussian auxiliaries it need not even belong to the physical observable algebra. Therefore physical local RP does not force (7).

An exact elementary illustration has a remote shared label `W=(U,V)` with independent uniform signs. Given `W`, set the plus sign to `U` and the minus sign to `V`. For the physical local test `F(s)=s`, the defect is `E(U-V)^2=2`. After forgetting `W`, the two physical halves are independent identical fair signs, so the whole physical half algebra is RP. Moving the label farther out cannot turn this nonzero defect into a fixed local counterexample. This is a probability-model warning, not a Wilson or local-Gibbs construction.

### Positive phase coupling is a broader recovery condition

Suppose a reflected local pair law, perhaps after conditioning on a genuinely fixed physical plane variable `z`, has the form

    nu_z(dx,dy)=sum_(r,s=1)^k W_rs(z) nu_(r,z)(dx) nu_(s,z)(dy),

where `W_rs>=0`, `sum_rs W_rs=1`, and `W(z)` is real symmetric positive semidefinite. Then for every half observable, with `v_r(z)=nu_(r,z)F`, its conditional reflected form is `v(z)^dagger W(z) v(z)>=0`. Integration in `z` gives RP. This allows several phases and even nonzero mismatches under a finer conditioning. At a fixed `z`, if the sector laws are linearly independent as signed measures, their expectation vectors span `C^k`, so positivity of `W(z)` is also necessary for full-half RP of that conditional finite-sector law.

For two phases the conditions are

    W_++>=0, W_-->=0, W_+-=W_-+,
    W_++ W_-- >= W_+-^2.

Equality of the two phase marginals is much weaker. The anti-aligned law `W_+-=W_-+=1/2`, `W_++=W_--=0` is symmetric, has identical marginals, and has eigenvalue `-1/2`. A phase-sign observable has reflected form `-1`. Independent phase labels instead give `W_rs=1/4`, a positive semidefinite rank-one matrix, despite the defect 2 in the preceding finer-label representation. Thus phase-label alignment has spectral content, not just marginal symmetry.

This criterion is stable under local total-variation approximation: if a physical reflected-support marginal is within `eta` in TV (supremum over events) of such an RP law, then its complex reflected form is within `2 eta ||F||_infinity^2` of the nonnegative axis. This gives a second, broader recovery route. Producing the phase decomposition or its uniform approximation for Wilson theory is additional work, not established here.

## 7. Global Markov and boundary-law pitfalls

Finite conditional independence cannot simply be passed through conditioning on an entire infinite plane. Tail information can survive in the conditional boundary law, and exchanging these limits needs justification. The common-exhaustion theorem deliberately stays at finite volume and passes only physical local expectations to the limit.

Extremality does not fix this issue in general. Robert B. Israel, *Some examples concerning the global Markov property*, Communications in Mathematical Physics 105 (1986), 669–673, constructs bounded finite-range examples with extremal Gibbs states lacking the global Markov property, including a translation-invariant interaction. This is a general guardrail; it is not a counterexample for SU(2) Wilson theory. Primary publication: https://doi.org/10.1007/BF01238938 . The author's bibliography confirms the reference: https://personal.math.ubc.ca/~israel/ .

Likewise, reflection-symmetric phase marginals, equality of bulk pressures, or small surface/volume ratio do not verify either (7) or the positive-semidefinite phase-coupling condition. The exact anti-aligned matrix above shows the missing boundary information explicitly.

## 8. Exact remaining weak-coupling target

For the actual common four-dimensional free-box sequence, establish one of the following, for every required cut and tested physical observable sector:

1. the annealed normalized half-kernel defect (7), with enough control for the intended coupling/support/normalization sequence; or
2. a local approximation by a positive-semidefinite phase-coupling law as in Section 6, with vanishing error after source normalization.

If `F_a=M_a f_a` with `||f_a||_infinity<=1`, the sufficient full complex-form condition from (5) is

    M_a^2 sqrt(D_a(f_a)) -> 0.

For the negative real part alone, (4) only needs `M_a^2 D_a(f_a)->0`; the imaginary part still needs separate control. For the phase-law TV route one needs `M_a^2 eta_a->0`. Growing supports and actual deterministic source normalizations cannot be dropped.

There is no explicit beta or area loss in these algebraic bounds. The difficult beta-, width-, and distance-dependence has moved into a precisely defined conditional mismatch or boundary-law approximation. Nothing here shows it is uniformly small as beta tends to infinity. In particular the shared Gaussian fields have typical unconditioned amplitude of order one but enter half actions with `sqrt(beta)`; their posterior law is weighted by half partition functions. Their introduction is not a weak-coupling perturbation argument.

The conditional Gaussian interactions are unbounded as functions of the auxiliary fields. Thus the existing strong-coupling comparison for physical Wilson marginals does not automatically establish this particular conditional mismatch bound. Strong-coupling joint approximate RP is already available by the older direct physical comparison, regardless of whether this stronger auxiliary criterion is separately verified.

## 9. Verification and provenance

Read before this derivation:

* `/workspace/shared/conditional-free-box-rp-20261019-1410/RESULT.md`;
* its recovered `sources/strong-coupling-seam-PROOF.md`;
* `/workspace/shared/wilson-simultaneous-rp-20261018/RESULT.md` and the accompanying layered-Ising example;
* `/workspace/shared/wilson-invariant-diagonal-rp-20261018/construction/RESULT.md`.

The companion `check_gluing.py` checks the affine cut geometry in asymmetric boxes, the bond trace identity on exact rational unit quaternions, the Gaussian exponent identity, exact rational defect identities, and the two-phase matrix examples. These checks supplement the displayed proofs. They do not integrate the interacting SU(2) model, bound the half-kernel mismatch, or prove all-beta RP of a common Wilson Gibbs state.

The executed certificate `check_results.json` reports 76 cut cases in dimensions 2–4, 5,414 individually reflected crossing plaquettes, 1,344 individually reversed bond-crossing links, 120 exact rational quaternion trace checks, and 480 exact Gaussian exponent checks, all passing.

An independent bond/orientation and common-limit audit passed with the stated scope qualifications; its full proof is `/workspace/shared/gaussian-half-gluing-audit-20261019/AUDIT.md`. Its independent exact-rational and geometry checks also passed. A separate parent-coordinated audit of the complete report is in progress as this version is saved.
