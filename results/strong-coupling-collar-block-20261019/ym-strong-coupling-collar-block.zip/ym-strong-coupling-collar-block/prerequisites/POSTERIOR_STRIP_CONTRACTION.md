# Posterior half-kernel contraction on finite-width Wilson strips

19 October 2026. Local proof and reproducible finite certificates only. No repository or external changes.

## Main result

For a Wilson strip of fixed finite transverse width, the normalized conditional half-kernel mismatch of the Gaussian-gluing construction decays exponentially with the length of the common longitudinal buffer, at every finite nonnegative coupling. The estimate is **pointwise in all cut variables**, including every Gaussian auxiliary variable, and therefore holds under the actual posterior boundary law without any posterior-tail or partition-ratio estimate.

Let the two reflected halves have a common prefix of blocks `X_0,...,X_N`. The cut Gaussian factors, half-links if needed, and all variables on which those factors depend belong to the initial collar `X_0` (physical fixed-plane variables are held fixed). Suppose the physical Wilson action between blocks `X_i,X_(i+1)` contains `C_i` plaquettes, while all one-block weights and the initial collar weight agree between the reflected halves. The tails beyond `X_N` may differ arbitrarily. For a bounded physical half-test `F` supported in `X_0,...,X_r` and the fixed-plane variables, `r<N`, put

    M = ||F||_infinity,
    q_i = tanh(beta C_i),
    p_(r,N) = product_(i=r)^(N-1) q_i.

Then, for every finite value of the cut data `W`,

    |P_W F - Q_W F| <= 2 M p_(r,N),                 (1)
    D(F) = E_rho |P_W F-Q_W F|^2
         <= 4 M^2 p_(r,N)^2.                       (2)

Here `rho` is the **actual** Gaussian/plane posterior from the finite Wilson law. For inhomogeneous couplings use `q_i=tanh(B_i)`, where `B_i=sum beta_p` over the plaquettes between the two blocks. All statements include arbitrary shared positive one-block weights. The constants do not depend on the values of the auxiliary Gaussians.

Combining (2) with the already-proved normalized gluing identities gives

    Re Q_mu(F) >= -M^2 p_(r,N)^2,
    dist(Q_mu(F),[0,infinity)) <= 2 M^2 p_(r,N).     (3)

This is a genuine estimate of the previously conditional mismatch in a tractable Wilson subcase. It is **not** a width-uniform estimate or a simultaneous mixed-direction four-dimensional theorem.

## 1. What was recovered rather than reproved

The earlier fixed-width cylinder proof already establishes all-DLR uniqueness at each finite beta by a positive transfer kernel, with contraction `1-m/M`. Its proof and geometry are in:

- `/workspace/shared/wilson-invariant-diagonal-rp-20261018/construction/uniqueness/one_dimensional_uniqueness.md`
- `/workspace/shared/wilson-invariant-diagonal-rp-20261018/construction/RESULT.md`

The old `18 beta<1` Dobrushin estimate already gives width-uniform physical comparison in a strong-coupling regime; see `/workspace/shared/conditional-free-box-rp-20261019-1410/sources/strong-coupling-seam-PROOF.md`. It does not by itself prove this auxiliary posterior mismatch estimate.

The new deduction is the **uniform reverse-kernel contraction with an arbitrary common collar weight**, applied to the actual normalized Gaussian-conditioned halves. It also uses the sharper elementary coefficient `(M-m)/(M+m)` for a kernel between `m` and `M`, and counts only interblock plaquettes; one-block energy is absorbed in an arbitrary common positive weight.

The gluing definitions and complex-defect inequalities are inherited from `/workspace/shared/gaussian-half-gluing-20261019-1440/RESULT.md`, independently audited in `/workspace/shared/gaussian-half-gluing-audit-20261019-1444/AUDIT.md`.

## 2. A terminal-tail comparison lemma

Let `X_0,...,X_N` have probability reference measures `nu_i`. For a fixed external parameter `w`, consider two probability laws with densities

    Z_s(w)^(-1) g_w(x_0)
      product_(i=1)^N v_i,w(x_i)
      product_(i=0)^(N-1) k_i,w(x_i,x_(i+1))
      R_s,w(x_N),                                  (4)

where `s=+,-`. All factors except `R_s,w` are identical in the two laws. They are positive and yield finite positive integrals. The terminal weights can be any integrable positive weights produced by integrating different tails. Allowing nonnegative weights with positive normalizers, or fixed terminal distributions, follows by the same disintegration or a limit.

Assume, uniformly in `w,x,y`,

    0 < m_i <= k_i,w(x,y) <= M_i < infinity.         (5)

For `F=F_w(x_0,...,x_r)` with `|F|<=M`,

    |E_+ F-E_- F| <= 2M product_(i=r)^(N-1) c_i,
    c_i=(M_i-m_i)/(M_i+m_i).                       (6)

The estimate includes complex F. Equivalently, the two prefix marginal laws differ in total variation, defined as supremum over events, by at most the product in (6).

### Proof

Integrate the shared left prefix, without the terminal factor:

    l_0,w(x)=g_w(x),
    l_i,w(y)=v_i,w(y) integral l_(i-1),w(x)
                                  k_(i-1),w(x,y) nu_(i-1)(dx).

Under either law the reverse conditional transition is

    Q_i,w(y,dx) = l_i,w(x) k_i,w(x,y) nu_i(dx)
                 / integral l_i,w(z) k_i,w(z,y) nu_i(dz).   (7)

It does not involve `R_s,w`. These are the same reverse kernels for the two models, even when `g_w` is very sharply concentrated.

For two next-block values `y,y'`, the log likelihood ratio of `Q_i,w(y,.)` and `Q_i,w(y',.)` differs by a constant from

    log k_i,w(x,y) - log k_i,w(x,y').

Its oscillation in `x` is at most `2 log(M_i/m_i)`. The elementary likelihood-ratio inequality gives

    ||Q_i,w(y,.)-Q_i,w(y',.)||_TV
      <= tanh((1/2) log(M_i/m_i))
       = (M_i-m_i)/(M_i+m_i) = c_i.                (8)

For completeness, if a normalized likelihood ratio L lies in `[a,b]`, `a<=1<=b`, then

    TV <= (1-a)(b-1)/(b-a).

Subject to `b/a<=R`, the maximum is `(sqrt(R)-1)/(sqrt(R)+1)`, attained at `a=R^(-1/2), b=R^(1/2)`. This proves (8) with `R=(M_i/m_i)^2`.

Start from the two possibly unrelated `X_N` marginals, whose TV distance is at most one. Applying the common reverse kernels `Q_(N-1),...,Q_r` contracts this distance by at most the product in (6). Given `X_r`, the conditional law of the entire prefix `X_0,...,X_(r-1)` is again common; attaching it cannot increase TV. Finally the total variation norm of a signed measure of mass zero is twice the supremum-over-events convention, so complex bounded expectations differ by at most `2M TV`. This proves (6).

Nothing in the proof bounds, or needs to bound, `sup g_w/inf g_w`. The Gaussian collar factor occurs in `l_i,w` and cancels from the likelihood-ratio oscillation. This is the precise reason unbounded Gaussian coefficients are harmless **here**.

## 3. Wilson application and shared-geometry hypotheses

Fix one reflection direction, a finite transverse section invariant under the reflection, and two possibly unequal longitudinal cutoffs. Reflect the negative half into the positive half. Require that, up to a remote full block `X_N`, the two half domains have exactly the same link variables and the same interactions. Do not restore absent plaquettes.

For coordinate-site cuts there is no Gaussian crossing factor. Shared tangent plane links are included in `W`; all remaining weights have the ordinary bounded Wilson form. For coordinate-bond cuts, use the exact Haar subdivision from the gluing report. Put the new half-links and the first physical slice in `X_0`; every half crossing path and its Gaussian feature then depend only on `X_0`. For an integer diagonal cut, either use the recovered two-level tail blocks or the sharper one-level minimum-height blocks described below. In either convention, every positive half crossing path lies in the initial collar, so all its Gaussian features fit in `X_0`.

All cut-dependent weights in the initial collar are the same functions of the same `W` after reflected identification. They can be unbounded as functions of `W`, but are finite positive functions on the compact group variables for every fixed finite `W`.

Write each half action as one-block terms plus terms between adjacent blocks. Every interblock plaquette has `|w_p|<=1`, so

    k_i,w=exp(sum_(p crossing i,i+1) beta_p w_p),
    exp(-B_i)<=k_i,w<=exp(B_i),
    B_i=sum_(p crossing i,i+1) beta_p.

Thus (8) gives `c_i=tanh(B_i)`. Integrating each actual far tail gives `R_+,w` or `R_-,w`; the rest of (4) is common. This proves (1) pointwise in W. Integration against the actual posterior proves (2).

The theorem also covers free terminal boundaries and different lengths. Choose `X_N` inside **both** reflected domains, before the first missing or modified link or plaquette; integrate everything beyond it into `R_s,w`. The end of a finite strip need not contain a complete transfer block.

## 4. Explicit interblock plaquette counts

### Coordinate direction

Let the vertices of the infinite strip be `Z x A`, where

    A={-W,...,W}^(d-1),    W>=1,    d>=2.

Keep induced links and plaquettes with free transverse boundary. A regular block contains all positively oriented links with longitudinal tail coordinate `t`. Spatial plaquettes stay in that block. A longitudinal-spatial plaquette couples blocks `t,t+1`, and there is exactly one such plaquette per transverse edge. Therefore

    C_coord(W,d)=2(d-1)W(2W+1)^(d-2).              (9)

For d=4 this is `6W(2W+1)^2`. The special collar block can differ in size, but every regular buffer boundary has this count. If necessary, take `r>=1` so that the contraction product uses only regular boundaries. A larger collar test support only changes r.

### Diagonal direction

Use

    u=x_0-x_1,    v=x_0+x_1,
    D_W={x: |v|<=W, |x_j|<=W for j>=2}.

Keep induced links and plaquettes. The parity relation `u=v mod 2` is imposed. Fix the cut `u=a`, integer a. After reflection identify both halves with `u>=a`. Put positively oriented half links whose tail levels are `a+2n,a+2n+1` in `X_n`; remove the shared plane links from `X_0` and condition on them. Every positive half crossing path is contained in the first two levels, hence its Gaussian feature belongs to `X_0`. Every ordinary plaquette meets at most two adjacent blocks.

At a regular block boundary `u=t=a+2n`, a `(0,1)` plaquette straddles the boundary precisely when its base level is `t-1` or `t`. Summing the two opposite parity classes gives

    C_01=(2W-1)(2W+1)^(d-2).

For each `j>=2`, a `(0,j)` plaquette straddles at base level `t-1` and a `(1,j)` plaquette at level `t`. Each contributes `2W^2(2W+1)^(d-3)`. Plaquettes with both directions at least 2 stay within one block. Therefore

    C_diag(W,2)=2W-1,
    C_diag(W,d)=(2W-1)(2W+1)^(d-2)
                +4(d-2)W^2(2W+1)^(d-3), d>=3.  (10)

In particular

    C_diag(W,3)=8W^2-1,
    C_diag(W,4)=(2W+1)(12W^2-1).

The count is independent of the integer offset a and its parity. Signed diagonals follow by a coordinate reflection with oriented-link inversion; the count and Wilson scalar action are unchanged.

For a finite diagonal strip `-L_-<=u<=L_+`, put `h=min(L_+-a,L_-+a)`. The first `N+1` tail blocks are full away from the cut whenever `2N+2<=h`. Thus one safe choice is `N=floor((h-2)/2)` when this is nonnegative. The estimate is used only with `r<N`, and all tested physical links must actually be present.

### Sharper diagonal blocking: one level is enough

The old tail assignment is not necessary for this task. Assign each physical positive-half link `e=(x,y)` to its **minimum endpoint height**

    ell(e)=min(u(x),u(y)),

and put the links with `ell(e)=a+n` in `X_n`. The alphabet is two-periodic in n because of the lattice parity constraint; the nonstationary comparison lemma needs no period blocking.

For a `(0,1)` plaquette based at height k, the four link minimum heights are `k-1,k-1,k,k`. For a `(0,j)` plaquette they are in `{k,k+1}`; for a `(1,j)` plaquette they are in `{k-1,k}`; for two tangent directions they all equal k. Thus every plaquette meets at most two adjacent **one-level** blocks. Both links of the positive Gaussian crossing path have minimum height a, so every cut feature still belongs to `X_0`. Shared tangent plane links remain conditioned variables and are removed from that block.

Across the boundary between minimum heights `t-1` and t, only one `(0,1)` base level, k=t, occurs. Its allowed v-values are the integers in `[-W,W-2]` of parity t. There are `W` such values if `t=W mod 2`, and `W-1` otherwise. The other pair counts are unchanged. Consequently the exact improved count is

    C_min(W,d,t)=[W-1+epsilon_t](2W+1)^(d-2)
                +4(d-2)W^2(2W+1)^(d-3),           (13)
    epsilon_t=1 if t=W mod 2, otherwise 0,

where the second term is omitted for d=2. In d=4 the alternating counts are

    (2W+1)(10W^2-W-1),
    W(2W+1)(10W+1).                               (14)

With the same finite-strip h as above, every block through `X_N` is full when `N+1<=h`; hence `N=h-1` is safe. For the boundary between `X_i,X_(i+1)`, use `C_i=C_min(W,d,a+i+1)` in (1)-(3). This gives roughly twice as many contractions as the old two-level blocking, with no larger cross-action constant. The special case d=2, W=1 has alternating counts 0 and 1, so one empty-interaction boundary already makes the local tail dependence exactly zero, consistent with the incidence geometry.

The one-level observation and its role in this proof were independently suggested by the companion auditor. Both the two-level recovered convention and this improved convention are enumerated by the certificate.

## 5. Rates, recovery conditions, and exact stopping boundary

For a fixed geometry with regular interblock count C, write `q=tanh(beta C)` and `n=N-r`. Then

    D(F)<=4 M^2 q^(2n),
    dist(Q_mu(F),[0,infinity))<=2 M^2 q^n.          (11)

For fixed finite beta and fixed finite width, `q<1`; hence every fixed physical local test has vanishing mismatch as both longitudinal ends recede. This applies to one parallel family of cuts whose strip has the required reflection-compatible transverse geometry.

For varying beta, width, support and deterministic source normalization, the sufficient condition provided by this proof is exactly

    M_a^2 tanh(beta_a C_a)^(n_a) -> 0.             (12)

The corresponding negative-real-part estimate alone uses `M_a^2 q_a^(2n_a)->0`. For beta C>0, since

    -log(tanh x)=log((1+exp(-2x))/(1-exp(-2x)))
                 >=2 exp(-2x),

one explicit sufficient version of (12) is

    2 n_a exp(-2 beta_a C_a) - 2 log(max(1,M_a)) -> +infinity.

For bounded M, `n_a exp(-2 beta_a C_a)->infinity` suffices. Thus the quantitative proof permits a very elongated chosen sequence with width tending to infinity, but it becomes exponentially poor in beta times transverse area. It does not cover isotropically growing four-dimensional boxes by this bound. Failure of (12) is failure of this certificate, not evidence of a nonzero true defect.

At beta=0 every regular interblock kernel is one and q=0; if there is at least one regular buffer boundary, the two tested prefix marginals agree exactly. No `0^0` convention is needed. If n=0, only the trivial `D<=4M^2` is asserted.

The argument does not use physical Gibbs uniqueness to infer latent matching. It proves the stronger common-collar conditional contraction directly. It does not show that physical uniqueness in a general growing-plane model implies the Gaussian mismatch criterion. That general implication remains unproved here.

The strip must have one fixed finite transverse geometry and identical reflected near-cut actions. Rotating to another nonparallel cut changes that geometry and generally its limiting state. The earlier mixed-affine reflection-group obstruction still applies: one finite-width transfer estimate does not construct one state satisfying coordinate and diagonal RP simultaneously. Nor does this prove a continuum limit, Euclidean rotation invariance, source convergence, or a mass gap.

## 6. Reproducibility and sources

`check_strip.py` is standalone standard-library Python. It independently enumerates transverse plaquette counts, checks diagonal two-level and one-level adjacency, and checks the reverse-kernel identity and bounds on exact rational finite-state chains, including extremely uneven collar weights. It also exhibits equality in the universal transfer coefficient for a two-state kernel. These finite tests supplement the proof; they do not numerically integrate SU(2) or establish a uniform-width estimate.

The prior compact-alphabet transfer source was rechecked: Cioletti, Lopes and Stadlbauer, *Ruelle operator for continuous potentials and DLR-Gibbs measures*, DCDS 40 (2020), 4625–4652, DOI 10.3934/dcds.2020195, https://www.aimsciences.org/article/doi/10.3934/dcds.2020195. Its abstract explicitly treats one-sided DLR measures; our finite terminal-tail comparison is proved directly and is not attributed to a stronger unquoted theorem. The likelihood-ratio inequality is explicitly derived above and was already used in the recovered strong-coupling proof.

Executed certificate: 60 dimension/width/parity cases, 205,288 plaquette adjacency checks, 504 exact rational prefix/complex-form comparisons, and 2,016 terminal-independent reverse-conditional identities all pass. There are 28 exact sharpness examples for the universal transfer estimate. Ordinary Python and `python -O` produce byte-identical output.
