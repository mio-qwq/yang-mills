# A uniform arbitrary-collar comparison through a high-temperature buffer

19 October 2026. Local research only. No repository changes or publication.

## Result

An arbitrary common positive collar weight can be canceled from a normalized comparison, including an unbounded-in-the-parameter Gaussian weight, **provided the entire collar is separated from the differing tails by a common high-temperature buffer**. The correct quantity is a four-boundary-value log partition cross ratio. Neither terminal weights nor collar weights need a bounded likelihood ratio.

For four-dimensional Wilson interactions at `q=18 beta<1`, let C contain every variable in the arbitrary collar weight and every tested variable, let T be a terminal interface supporting arbitrary possibly different integrated tail weights, and let U be the common intervening variables. Suppose no physical plaquette touches both C and T. Let `r=dist_G(C,T)>=2`, where G is physical link plaquette adjacency. Then

    TV(P_C,Q_C) <= tanh( Delta/4 ),
    Delta <= 4 sum_(c in C,t in T)
        [A_CU (I-A_UU)^(-1) A_UT]_(c,t)
          <= 4 min(|Gamma_C|,|Gamma_T|) q^r/(1-q).       (1)

Here `A_ef=beta times the number of physical plaquettes containing e,f`, with zero diagonal, and Gamma_C and Gamma_T are the respective variables incident to U. Using |C| or |T| instead of the corresponding Gamma cardinality is always safe. Inhomogeneous couplings use the sum of their beta_p and any verified row-sum bound q<1.

The estimate is uniform in the common positive collar weight and both arbitrary terminal weights. It covers isotropically widening coordinate-cut free boxes: the collar area grows polynomially and the full collar-to-terminal distance grows linearly. It does not justify replacing r by distance from one local test when the rest of the collar touches a differing lateral boundary. Explicit obstructions to that replacement are supplied in the companion report identified below.

## 1. Exact finite-volume hypotheses

Take a finite product configuration space, with normalized product reference measures, partitioned into disjoint sets of sites C, U, T. In Wilson theory a site here is a physical link variable; conditioned physical plane variables are external parameters. Dummy Haar variables for missing links are allowed. Fix any external parameter w.

The two joint laws have unnormalized densities

    g_w(c) R_(s,w)(t) exp[H_w(c,u,t)],       s=+,-,       (2)

where

    H_w(c,u,t)=H_U,w(u)+H_CU,w(c,u)+H_UT,w(u,t).

There is no interaction meeting both C and T. All interactions contained wholly in C or wholly in T may be absorbed into g or R. Every remaining interaction is a bounded plaquette term beta_p w_p with beta_p>=0 and |w_p|<=1, and has the usual Wilson incidence. The argument also applies to other finite hypergraph interactions with the analogous influence matrix.

The common g and both R may be any nonnegative measurable weights for which the normalizers are finite and strictly positive. For the Gaussian application they are strictly positive. No uniform bounds on these weights, no locality of g within C, and no locality of R within T are assumed. All statements are pointwise in w. With compact group variables and finitely many finite auxiliary values the boundedness and integrability requirements hold. The conditional likelihood-ratio bounds do not depend on w.

A test F=F_w(c), real or complex, satisfies |F|<=M. To test an observable outside the original collar, enlarge C to contain its support, and recompute the interface and distance. Any Gaussian factor touching the added variables must still be wholly supported in C. It is not permitted to omit remote collar variables merely because F is local.

For a common finite-volume comparison of different shapes, first identify reflected half variables using their union and independent unused Haar dummy variables. A separator T must intercept every interaction path to any discrepancy. Integrating everything beyond T then produces R_+ and R_-; all interactions between C, U, T in (2) must truly agree in the two models. No absent plaquette is restored.

## 2. Elementary comparison input, including constants

For distinct unfixed sites i,j define

    A_ij=sum_(p containing i,j) beta_p,       A_ii=0.    (3)

Changing only j changes the unnormalized conditional log density at i by a function of oscillation at most 4 A_ij. For normalized densities with log-likelihood-ratio oscillation L, total variation in the convention `sup_events |P(E)-Q(E)|` is at most tanh(L/4). Consequently the conditional influence is at most A_ij. Bounded common one-site factors cancel from this ratio; in the present proof C and T are pinned, so the arbitrary multi-site weights never enter any U conditional law.

For fixed c,t, the U conditional influence matrix is bounded by A_UU. This remains true while replacing c by c' through the convex interpolation

    H_s(u,t)=(1-s)H_w(c',u,t)+s H_w(c,u,t),  0<=s<=1. (4)

Each interpolated plaquette remains a convex combination of bounded functions of its unfixed variables; the same 4 beta_p oscillation estimate applies.

If t,t' differ arbitrarily, their U conditional laws under (4) have single-site discrepancies at most

    b_i <= sum_(t_site in T) A_(i,t_site).

Let `D_U=(I-A_UU)^(-1)`. The elementary finite-volume Dobrushin comparison gives, for every real bounded h on U,

    |E_t h-E_t' h| <= sum_(i,j in U) delta_i h (D_U)_ij b_j.  (5)

For completeness, couple random-scan heat-bath updates by maximal couplings. If p_i(n) is the disagreement probability at i after n updates and m=|U|, then

    p(n+1) <= [(1-1/m)I+A_UU/m]p(n)+b/m.

The iteration converges to an upper bound D_U b because the row sum is below one. Finite bounded interactions give each heat-bath conditional a strictly positive lower bound relative to its reference measure; updating all sites in a fixed order gives a Doeblin minorization and convergence of each marginal chain. Telescoping h across disagreeing coordinates gives (5). The empty-U case has no C-to-T interaction and factorizes, so all subsequent cross ratios are zero.

In four dimensions each physical link is in at most six plaquettes, each containing three other links. Thus `sum_j A_ij<=18 beta=q`. Free boundaries and fixing plane links only remove incidences.

## 3. The effective boundary kernel and its cross ratio

Integrate only the common buffer:

    K(c,t)=integral exp[H_w(c,u,t)] dnu_U(u).             (6)

Any terms depending only on c or only on t cancel from the four-point expression below. For c,c', define

    V(u)=H_CU,w(c,u)-H_CU,w(c',u).

No C-T interaction ensures V is independent of t. For every i in U,

    delta_i V <=4 sum_(p containing i and meeting C) beta_p
               <=4 sum_(c_site in C) A_(i,c_site).       (7)

Differentiation under the finite bounded integral gives

    log K(c,t)-log K(c',t)=integral_0^1 E_(s,t) V ds.

Comparing t,t' with (5), uniformly throughout the interpolation, proves

    |log K(c,t)-log K(c',t)-log K(c,t')+log K(c',t')|
      <= Delta_matrix,

    Delta_matrix=4 1_C^T A_CU D_U A_UT 1_T.              (8)

This pins both boundary configurations before doing comparison. No Dobrushin assumption is imposed on a law containing g or R.

Expand D_U as its nonnegative Neumann series. A term `A_CU A_UU^n A_UT` is a sum over physical adjacency walks from C to T, length n+2, with all intermediate vertices in U. All such walks have length at least r. Since the full A has row sum at most q,

    Delta_matrix <=4 |Gamma_C| sum_(l>=r) q^l
                 =4 |Gamma_C| q^r/(1-q).               (9)

Symmetry of A and D_U permits the same estimate starting at Gamma_T, proving the minimum in (1). The distance in (9) is in the full physical adjacency graph of the common interaction geometry, with any genuine periodic shortcuts included if periodic boundaries are used. A path through an arbitrary collar interaction is not added to this graph; instead every collar site is already a possible starting point and contributes through the complete C interface.

If q=0, or there is no physical C-U-T path, the matrix expression is zero and the collar laws agree exactly. No 0^0 convention is needed.

## 4. Integrating arbitrary tail weights and canceling the collar

Set

    h_s(c)=integral K(c,t) R_s(t) dnu_T(t).

For each fixed c,c', the ratio h_s(c)/h_s(c') is an average of K(c,t)/K(c',t), under the probability law proportional to `K(c',t)R_s(t)dnu_T`. Equation (8) therefore implies

    osc_c log[h_+(c)/h_-(c)] <= Delta_matrix.             (10)

The normalized collar laws have densities proportional to `g(c)h_s(c)`. Their likelihood ratio is h_+/h_- times a normalization constant, so the arbitrary common g cancels from its oscillation. The elementary likelihood-ratio inequality yields (1).

One direct proof of that inequality is as follows. If a normalized likelihood ratio L lies in [a,b], with a<=1<=b, then

    TV <= (1-a)(b-1)/(b-a).

Under b/a<=exp(Delta), this is at most tanh(Delta/4), attained when a=exp(-Delta/2), b=exp(Delta/2). This argument also covers nonnegative g by restricting to its common support.

Consequently, with `epsilon=tanh(Delta_matrix/4)`,

    |P_W F-Q_W F| <=2 M epsilon,
    E_rho |P_W F-Q_W F|^2 <=4 M^2 epsilon^2.             (11)

The second bound holds under any posterior rho, in particular the actual Wilson Gaussian/plane posterior, since the first is pointwise in W. For an original physical F, whose dependence on W can arise only from physical plane links Z and not from the auxiliary Gaussians, the normalized Gaussian-gluing identities then give

    Re Q_mu(F) >= -M^2 epsilon^2,
    dist(Q_mu(F),[0,infinity)) <=2 M^2 epsilon.           (12)

These are finite-volume bounds. For varying source normalizations a sufficient full complex-form limit is `M_a^2 epsilon_a ->0`. The negative real part alone only requires `M_a^2 epsilon_a^2 ->0`.

## 5. Isotropically growing coordinate-cut Wilson boxes

Let `Lambda_L={-L,...,L}^d` have free induced links and plaquettes, homogeneous beta, and `q=6(d-1)beta<1`; in d=4 this is 18 beta. Fix a coordinate cut and reflect the negative half into the positive half. The two transverse sections are exactly the same, including their free lateral boundaries. Only their longitudinal terminal lengths differ.

Use full regular blocks X_j of physical links whose positive longitudinal tail has coordinate j relative to the first layer. Every ordinary Wilson plaquette is either within a block or connects adjacent blocks. The transverse vertex count and regular block size are

    V_L=(2L+1)^(d-1),
    E_L=2(d-1)L(2L+1)^(d-2),
    B_L=V_L+E_L.                                      (13)

A coordinate-site cut `x_0=k` has first layer k and shared plane tangent links conditioned in W. Put its free layer-zero longitudinal links in X_0; the fixed plane links are not integration variables. With

    h=L-|k|,       N=h-1,

all regular blocks through X_N are full in both reflected halves, when N>=0; X_0 is the stated special block with its plane tangent links conditioned and excluded.

For a coordinate-bond cut `x_0=k+1/2`, the first positive physical layer is k+1. Put the subdivided half-links and all first-layer physical variables in X_0; every Gaussian feature `V_x T_(x,y) V_y^dagger` then lies wholly in X_0. With

    h=min(L-k-1,L+k),       N=h-1,

all regular physical blocks through X_N are full in both reflected halves, when N>=0. Using this conservative N avoids any claim that a partial terminal block is full.

Suppose the physical test is supported in X_0,...,X_r0, with r0 fixed and nonnegative, and allow dependence on fixed plane data. Set

    C=X_0 union ... union X_r0,
    U=X_(r0+1) union ... union X_(N-1),
    T=X_N,

and require N-r0>=2. Integrate the two actual far tails into R_+ and R_-. All Gaussian factors and shared internal C terms form g_W. The ordinary half-links in the bond collar only participate in g, so they do not enlarge the physical C-U interface. Every path from C to T needs at least N-r0 adjacency steps, and Gamma_C lies in X_r0 with at most B_L variables. Thus

    epsilon_L <= tanh( B_L q^(N-r0)/(1-q) ).             (14)

At fixed beta with q<1, fixed affine cut and fixed local test, B_L grows as L^(d-1) and N=L-O(1). Hence epsilon_L tends to zero exponentially up to a polynomial factor. This is an isotropic-width conclusion for the actual normalized Gaussian-conditioned coordinate halves, stronger than the old fixed-width transfer estimate. It remains a strong-coupling result.

For centered signed-diagonal cuts `x_i +/- x_j=0`, the same centered free cube is exactly reflection invariant. Its two Gaussian-conditioned half actions agree after identification, so their mismatch is exactly zero at every finite L. Combined with (14) for coordinate site and bond cuts, the prior common-exhaustion argument yields simultaneous RP in a common limiting state for those cut families; coordinate translation invariance then transports the physical diagonal RP inequalities to integer affine translates. This last statement concerns physical limiting RP. It does not establish vanishing of the particular Gaussian posterior mismatch for each shifted diagonal cut at finite volume.

## 6. What fails for a general extended collar

If a nonzero-offset diagonal cut intersects mismatched lateral faces of a centered cube, the entire cut collar can be O(1) from a differing interaction even when a fixed central test is distance O(L) from that interaction. Formula (14) cannot be applied with the fixed-test distance. An arbitrary g may correlate the tested collar variable with the remote part of the same collar.

The companion report `/workspace/shared/collar-weight-obstruction-20261019-1650/RESULT.md` gives two exact positive finite-range Ising examples: a many-column area amplification example, and a local strongly coupled collar chain transmitting an endpoint discrepancy to a distant collar test. They show that high-temperature mixing of the buffer alone cannot support an area-free arbitrary-collar estimate in such geometry. They are not claimed to be the actual SU(2) Gaussian collar distribution.

The special product/local structure of actual Wilson Gaussian features permits a separate block comparison, proved in `DIAGONAL_BLOCK_THEOREM.md`; it is not used in this arbitrary-collar result. No claim here turns ordinary physical Gibbs uniqueness into conditional latent mismatch.

Nothing proves a weak-coupling or continuum Yang-Mills statement. Along the target bare-coupling trajectory beta tends to infinity and q<1 fails. This theorem is a controlled finite/strong-coupling deduction, with all collar, separation, area, and source-normalization conditions explicit.

## 7. Provenance and verification

Recovered source reports:

- `/workspace/shared/posterior-strip-contraction-20261019/RESULT.md`
- `/workspace/shared/gaussian-half-gluing-20261019-1440/RESULT.md`
- `/workspace/shared/conditional-free-box-rp-20261019-1410/sources/strong-coupling-seam-PROOF.md`

The comparison input is proved directly above using the same finite heat-bath coupling argument as the recovered source. No new general Dobrushin comparison theorem is claimed. `check_collar.py` verifies 100 finite hypergraph effective kernels, 25,600 four-point inequalities, 400 extreme positive collar/tail weight comparisons, 36 coordinate-cut geometries, 77,100 plaquette block incidences, and 14,072 shared-prefix plaquette matches. Ordinary Python and `python -O` produce byte-identical JSON. The finite-state part uses floating-point matrix inversion with explicit tolerances and does not replace the exact proof. Independent companion review found no correction in the matrix constant, interpolation, arbitrary-tail mixture step, or coordinate cutoff geometry; a second dedicated audit also passed, including independent arbitrary-table interactions, exact rational matrix bounds, zero-support collars, and disjoint terminal supports. Its report is archived in `audits/buffer/AUDIT.md`.
