# Actual diagonal Gaussian half-kernel matching by local blocks

19 October 2026. Local strong-coupling result. No repository changes or publication.

## Main theorem

For the actual positive Gaussian factorization of an elementary integer signed-diagonal Wilson cut, the unbounded Gaussian factors have **disjoint two-link supports**. Grouping those pairs into blocks removes their amplitude from the Dobrushin influence calculation. In four dimensions a valid row-sum bound is `q=22 beta`, uniformly in every fixed Gaussian and physical plane configuration.

Let P_W and Q_W be the reflected, normalized conditional half laws for a finite induced SU(2) Wilson complex with all plaquette couplings in [0,beta], and one cut `x_i +/- x_j=k`, with integer k. Use a common finite ambient set of complete blocks, adding independent unused Haar variables as needed. Let B_bad be the blocks touching an ordinary noncrossing plaquette factor that differs between the two half actions. Let S_F be a fixed, W-independent finite set of active blocks carrying the bounded complex physical test F's active-link support for every physical plane configuration Z. Put

    M=||F||_infinity,    s=|S_F|,
    q=22 beta<1,
    r=dist_Gblock(S_F,B_bad),
    epsilon=min(1, s q^r/(1-q)).                         (1)

The block graph joins two different blocks when an ordinary noncrossing plaquette in either half action touches both. For `0<q<1` and finite r,

    |P_W F-Q_W F| <=2 M epsilon                         (2)

for every finite W. If B_bad is empty, S_F is empty, or the tested blocks have no interaction path to B_bad, the mismatch is exactly zero. At beta=0 the half laws agree exactly. These zero cases do not use a convention for 0^0.

Under the actual Gaussian/plane posterior rho,

    D(F)=E_rho |P_W F-Q_W F|^2 <=4 M^2 epsilon^2,
    Re Q_mu(F)>=-M^2 epsilon^2,
    dist(Q_mu(F),[0,infinity))<=2 M^2 epsilon.            (3)

There is no area factor. The graph distance is from the tested blocks to ordinary-action discrepancies, and not from the entire extended collar.

The conclusion is valid for arbitrary common positive **one-block** weights on these disjoint pairs. It does not permit arbitrary unbounded interactions between different collar pairs. That difference is essential.

## 1. The exact block geometry

By a signed coordinate permutation it suffices to take

    u(x)=x_0-x_1,       cut u=k,       positive side u>=k.

A crossing plaquette must have directions (0,1). Its four heights are k-1,k,k,k+1. Plaquettes involving a tangent direction j>=2 have height range at most one and cannot meet both strict sides of the integer level k. Plaquettes with both directions tangent lie on one level.

For every positive apex v with u(v)=k+1, the unique crossing plaquette with this apex is based at v-e_0. Its positive path uses precisely

    B_v={ (v-e_0,v), (v,v+e_1) }.                        (4)

Distinct v give disjoint physical link sets: a link connecting levels k and k+1 has a unique height-k+1 endpoint, and only directions 0 or 1 can do so. The two-link path transporter P_v, with the orientations fixed in the Gaussian-gluing construction, is a function of B_v only.

Condition on the shared tangent-plane links Z and the crossing Gaussians xi_v. The common conditional factor from this crossing plaquette is

    g_(v,W)(B_v)=exp(sqrt(beta_v) xi_v dot q(P_v)-beta_v/2).

It is a positive function on one block. No other crossing Gaussian uses either link of B_v. For an absent crossing plaquette put g_v=1. Every other active half link is a singleton block. Fixed plane links are parameters, not active sites.

To compare asymmetric shapes, define this geometric partition first on the whole positive half lattice. Choose a finite set of complete blocks containing all active links in either reflected half and the tested support; complete any partially present pair with an independent unused Haar link. A crossing plaquette, if present in the original induced complex, is individually preserved by reflection, so its two-link factors occur in both identified halves with the same xi_v and beta_v. The product of all g_v is therefore exactly common. No absent ordinary plaquette is restored.

## 2. Uniform block influences and the constant 22

Let P_ordinary be the union of ordinary noncrossing plaquettes present in either identified half. At each p let beta_p^+ and beta_p^- be its two couplings, using zero for absence. In the homogeneous comparison every nonzero coupling is beta. For distinct blocks B,B', define

    A_(B,B')=sum_(p touching B and B') max(beta_p^+,beta_p^-),
    A_(B,B)=0.                                         (5)

The common g_B is incorporated in the single-block reference probability measure. The only interactions between blocks are bounded ordinary Wilson factors. Changing B' changes the conditional unnormalized log density at B by an oscillation at most `4 A_(B,B')`; g_B cancels pointwise. Hence the block conditional influence is bounded by

    tanh(A_(B,B'))<=A_(B,B').

This is uniform in W, even though g_B can be extremely sharply concentrated.

A singleton block has at most six incident plaquettes in d=4, each touching at most three other active blocks, and therefore row sum at most 18 beta.

A pair B_v has exactly ten incident ordinary plaquettes in the full positive half lattice:

- Two other (0,1) plaquettes. Each has one link in B_v, one link in another collar pair, and two singleton links, so it touches three other active blocks.
- Eight plaquettes involving one of directions 0,1 and one tangent direction j in {2,3}. Each has one link in B_v, one link in a neighboring collar pair, one singleton tangent link at height k+1, and one fixed tangent-plane link. Thus it touches two other active blocks.

The crossing (0,1) plaquette is absent from the ordinary action, having already been factorized. Therefore

    sum_(B'!=B_v) A_(B_v,B') <=(2*3+8*2)beta=22 beta.    (6)

Free-boundary deletion and zero couplings only decrease this count. More generally in dimension d>=2 the same proof gives `(8d-10)beta`, with singleton bound `6(d-1)beta<= (8d-10)beta`.

The complete padded finite halves are retained, including all their bounded ordinary physical tail plaquettes. Arbitrary integrated multi-block terminal weights from the separate collar theorem are not introduced into this block Dobrushin law.

The full Gaussian product is not treated as an arbitrary joint collar potential. Treating it that way would lose the disjoint-block structure and would incorrectly import the whole-collar obstruction into this special model.

## 3. Finite-volume comparison, including complex tests

Let P and Q denote the two half laws at fixed W, and let b_B be the supremum, over a common outside configuration, of the total variation distance between their single-block conditional laws. If no differing ordinary plaquette touches B, its conditional specifications are identical, since the Gaussian one-block factor and every incident ordinary factor agree. Consequently

    b_B=0 for B outside B_bad,       0<=b_B<=1 otherwise. (7)

Write `D=(I-A)^(-1)`. Couple random-scan block heat-bath updates using maximal coupling. With m blocks and p_B(n) the disagreement probabilities,

    p(n+1)<=[(1-1/m)I+A/m]p(n)+b/m.

The row sum q<1 gives `limsup p<=Db`. Marginal heat-bath convergence holds for every fixed finite W: one-block g_B can be absorbed into a probability reference, and the remaining finite interaction is bounded, giving a Doeblin minorization after a prescribed sequence updating every block. Thus for any set S of observed blocks the two marginal laws satisfy

    TV(P_S,Q_S)<=min(1,sum_(B in S,B' in B_bad)D_(B,B')). (8)

A term A^n from a tested block to B_bad vanishes for n<r. Row summation then gives

    TV(P_(S_F),Q_(S_F))<=min(1,s q^r/(1-q))=epsilon.

For complex bounded F, the total variation norm of the signed probability difference is twice the supremum-over-events convention, so `|PF-QF|<=2M TV`. This proves (2) without an extra real/imaginary factor. F may also depend on the fixed physical plane data Z contained in W; the argument is at each W and uses the global bound M. The physical RP statement does not allow F to depend on auxiliary Gaussian values.

Integration under rho and the exact normalized gluing identities prove (3). No posterior Gaussian tail bound or partition-function-ratio comparison is needed.

## 4. An isotropic common-box consequence for every fixed affine diagonal

Let `Lambda_L={-L,...,L}^4`, with homogeneous beta and free induced interactions. Fix an integer cut u=k and a fixed bounded physical positive-half cylinder test F, whose link endpoints lie in `[-R,R]^4`. The reflected cube is a signed-permuted cube translated by a vector of maximum norm |k|, so both cubes contain `[-(L-|k|),L-|k|]^4` whenever L>=|k|. Every ordinary plaquette wholly within this common cube appears with the same factor in both half actions.

Give a pair B_v anchor v and give a singleton its positive-orientation tail as anchor. Every anchor is an endpoint of every link in its block. If two blocks share an ordinary plaquette, both anchors are vertices of that plaquette, so their maximum-norm separation is at most one.

If a block is bad, some differing plaquette touches it. That plaquette has a vertex outside the common inner cube, whose integer maximum norm is at least L-|k|+1. The bad block anchor, being another vertex of the same plaquette, has maximum norm at least L-|k|. Tested block anchors have maximum norm at most R. Hence every block path from tested support to B_bad has length at least

    r_L >= max(0,L-|k|-R).                              (9)

If some tested links lie in the fixed plane, they are not active blocks and do not affect s. The remaining s is independent of L. For fixed beta with 22 beta<1,

    epsilon_L <=min(1, s (22 beta)^(L-|k|-R)/(1-22 beta)) (10)

once L>|k|+R, unless B_bad is absent or disconnected, in which case epsilon_L=0. Thus the actual Gaussian-conditioned half mismatch vanishes for every fixed integer signed-diagonal cut along this one isotropic free-cube exhaustion.

Combining this with the coordinate-site and coordinate-bond estimate in `RESULT.md` establishes the normalized mismatch sufficient hypothesis for the complete countable cut family of the recovered Gaussian-gluing theorem, for every fixed beta satisfying 22 beta<1. The coordinate bound uses 18 beta<1, automatically satisfied here. Every physical local weak cluster point of the common cube sequence therefore has simultaneous RP for the stated coordinate-site, coordinate-bond, and integer signed-diagonal positive-half algebras.

This proves a stronger auxiliary criterion than the older direct physical strong-coupling comparison; it does not enlarge the regime toward weak bare coupling. Standard strong-coupling physical RP recovery was already known in the recovered work. No novelty is claimed for block Dobrushin theory or high-temperature uniqueness.

For varying beta, cutoff, support and deterministic source normalizations, the sufficient full complex-form condition is explicitly

    M_a^2 min(1,s_a q_a^(r_a)/(1-q_a)) ->0,
    q_a=22 beta_a<1.                                  (11)

The negative real part alone requires the same condition with epsilon_a squared. This is not a weak-coupling Yang-Mills or continuum mass-gap result: beta tending to infinity violates the available contraction criterion.

## 5. Independent geometry audit and remaining verification

The disjoint-pair geometry and constants have been independently checked in

    /workspace/shared/collar-weight-obstruction-20261019-1650/DIAGONAL_AUDIT.md

Its executable incidence check covers dimensions 2–5, offsets -2 through 2, and 5,928 individual positive-path link assignments; pair row constants 6, 14, 22, 30 and singleton maxima 6, 12, 18, 24 all pass. This supports the displayed exact combinatorial argument. The companion final audit also verified the common padded blocks, shared weights, bad-set support, TV/complex-F constants, and exact integer distance bound; its two precision requests (W-independent test support, physical Z-dependence only) have been incorporated.

The independent executable `check_diagonal_application.py` in this directory verifies 60 signed-cut/cube cases in dimensions 2–4, offsets -2 through 2; 3,604 crossing self-reflections and shared path blocks; 351,944 ordinary block incidences; 1,016,088 unit anchor steps; and 60,224 exact graph-distance inequalities. The maximal observed row counts are 6, 14, 22. Ordinary Python and `python -O` produce byte-identical results. These exact integer checks supplement the displayed analytic proof. The frozen independent final theorem review is archived in `audits/diagonal/FINAL_THEOREM_AUDIT.md`.

Source definitions and gluing identities are in `/workspace/shared/gaussian-half-gluing-20261019-1440/RESULT.md`. The arbitrary-collar comparison in the neighboring `RESULT.md` is a separate theorem; its stronger unrestricted collar hypothesis requires separation from the entire collar and retains an interface-size factor. The two conclusions should not be conflated.
