#!/usr/bin/env python3
"""Finite checks supplementing, not replacing, the displayed proof."""
from itertools import product, combinations
from math import exp, log, tanh
import json, random
import numpy as np


def require(ok, label):
    if not ok:
        raise RuntimeError(label)


def logsumexp(xs):
    m=max(xs)
    return m+log(sum(exp(x-m) for x in xs))


def normalize_logs(xs):
    z=logsumexp(xs)
    return [exp(x-z) for x in xs]


def finite_checks():
    rng=random.Random(20261019)
    result={"effective_kernel_cases":0,"four_point_checks":0,"extreme_weight_comparisons":0,
            "largest_actual_to_matrix_ratio":0.0}
    C=(0,1); U=(2,3,4); T=(5,6); n=7
    cs=list(product((-1,1),repeat=len(C)))
    us=list(product((-1,1),repeat=len(U)))
    ts=list(product((-1,1),repeat=len(T)))
    eligible=[]
    for k in (2,3,4):
        for p in combinations(range(n),k):
            if set(p)&set(C) and set(p)&set(T):
                continue
            if not(set(p)&set(U)):
                continue
            eligible.append(p)
    for case in range(100):
        chosen=rng.sample(eligible,rng.randint(4,min(15,len(eligible))))
        raw=[rng.random()+.05 for p in chosen]
        A=np.zeros((n,n))
        for p,b in zip(chosen,raw):
            for i,j in product(p,repeat=2):
                if i!=j: A[i,j]+=b
        scale=(.05+.7*rng.random())/max(A.sum(axis=1))
        bs=[b*scale for b in raw]
        A*=scale
        signs=[rng.choice((-1,1)) for p in chosen]
        lk=np.zeros((len(cs),len(ts)))
        for ci,c in enumerate(cs):
            for ti,t in enumerate(ts):
                logs=[]
                for u in us:
                    x=dict(zip(C,c));x.update(zip(U,u));x.update(zip(T,t))
                    total=0
                    for p,b,s in zip(chosen,bs,signs):
                        v=s
                        for i in p:v*=x[i]
                        total+=b*v
                    logs.append(total)
                lk[ci,ti]=logsumexp(logs)-len(U)*log(2)
        mat=4*float(np.ones(len(C))@A[np.ix_(C,U)]@np.linalg.inv(np.eye(len(U))-A[np.ix_(U,U)])@A[np.ix_(U,T)]@np.ones(len(T)))
        delta=0.0
        for c,cp,t,tp in product(range(len(cs)),range(len(cs)),range(len(ts)),range(len(ts))):
            v=abs(lk[c,t]-lk[cp,t]-lk[c,tp]+lk[cp,tp])
            require(v<=mat+1e-11,"four-point matrix bound")
            delta=max(delta,v);result["four_point_checks"]+=1
        if mat>1e-13:
            result["largest_actual_to_matrix_ratio"]=max(result["largest_actual_to_matrix_ratio"],delta/mat)
        # Full physical graph may also have paths through C or T; use shortest C-to-T distance.
        dist={i:0 for i in C};front=list(C)
        while front:
            i=front.pop(0)
            for j in range(n):
                if A[i,j]>0 and j not in dist:
                    dist[j]=dist[i]+1;front.append(j)
        reachable=[dist[t] for t in T if t in dist]
        q=float(max(A.sum(axis=1)))
        if reachable:
            r=min(reachable)
            gc=sum(any(A[c,u]>0 for u in U) for c in C)
            gt=sum(any(A[t,u]>0 for u in U) for t in T)
            coarse=4*min(gc,gt)*q**r/(1-q)
            require(mat<=coarse+1e-11,"walk-distance bound")
        else:require(mat<1e-12,"disconnected zero")
        for extreme in (1,10,100,500):
            lg=[rng.uniform(-extreme,extreme) for c in cs]
            rp=[rng.uniform(-extreme,extreme) for t in ts]
            rm=[rng.uniform(-extreme,extreme) for t in ts]
            hp=[logsumexp([lk[c,t]+rp[t] for t in range(len(ts))]) for c in range(len(cs))]
            hm=[logsumexp([lk[c,t]+rm[t] for t in range(len(ts))]) for c in range(len(cs))]
            osc=max(a-b for a,b in zip(hp,hm))-min(a-b for a,b in zip(hp,hm))
            require(osc<=delta+2e-12,"tail integration cross-ratio bound")
            pp=normalize_logs([a+b for a,b in zip(lg,hp)])
            pm=normalize_logs([a+b for a,b in zip(lg,hm)])
            tv=sum(abs(a-b) for a,b in zip(pp,pm))/2
            require(tv<=tanh(delta/4)+2e-12,"common arbitrary collar TV bound")
            result["extreme_weight_comparisons"]+=1
        result["effective_kernel_cases"]+=1
    return result


def add(x,i):
    y=list(x);y[i]+=1;return tuple(y)


def canon_edge(x,y):
    return tuple(sorted((x,y)))


def cube(d,L):
    vs=set(product(range(-L,L+1),repeat=d))
    edges=set();ps=[]
    for x in vs:
        for i in range(d):
            y=add(x,i)
            if y in vs:edges.add(canon_edge(x,y))
        for i,j in combinations(range(d),2):
            y=add(x,i);z=add(x,j);v=add(y,j)
            if y in vs and z in vs and v in vs:
                ps.append(frozenset((canon_edge(x,y),canon_edge(x,z),canon_edge(y,v),canon_edge(z,v))))
    return vs,edges,ps


def geometry_checks():
    out={"coordinate_cut_cases":0,"plaquette_block_checks":0,"matched_prefix_plaquette_checks":0}
    for d in (2,3,4):
        for L in (2,3):
            vs,edges,ps=cube(d,L)
            for bond in (False,True):
                for k in (-1,0,1):
                    twice=2*k+int(bond);first=k+int(bond)
                    h=min(L-k-1,L+k) if bond else L-abs(k)
                    N=h-1
                    def ref_v(x):return (twice-x[0],)+x[1:]
                    def ref_e(e):return canon_edge(ref_v(e[0]),ref_v(e[1]))
                    pos={e for e in edges if min(e[0][0],e[1][0])>=first}
                    neg={e for e in edges if max(e[0][0],e[1][0])<=k}
                    negref={ref_e(e) for e in neg}
                    if not bond:
                        fixed={e for e in pos if e[0][0]==k and e[1][0]==k}
                        pos-=fixed;negref-=fixed
                    else:fixed=set()
                    def blk(e):return min(e[0][0],e[1][0])-first
                    VL=(2*L+1)**(d-1)
                    EL=2*(d-1)*L*(2*L+1)**(d-2)
                    BL=VL+EL
                    for j in range(max(0,N+1)):
                        a={e for e in pos if blk(e)==j};b={e for e in negref if blk(e)==j}
                        require(a==b,"coordinate reflected full block")
                        expected=VL if (not bond and j==0) else BL
                        require(len(a)==expected,"coordinate block count")
                    pplus=[p for p in ps if all(e in pos or e in fixed for e in p)]
                    pref=[]
                    for p in ps:
                        pp=frozenset(ref_e(e) for e in p)
                        if all(e in negref or e in fixed for e in pp):pref.append(pp)
                    prefix_plus=set();prefix_minus=set()
                    for pp,storage in ((pplus,prefix_plus),(pref,prefix_minus)):
                        for p in pp:
                            blocks=[blk(e) for e in p if e not in fixed]
                            if not blocks:continue
                            require(max(blocks)-min(blocks)<=1,"coordinate adjacent block support")
                            out["plaquette_block_checks"]+=1
                            if max(blocks)<=N:storage.add(p)
                    require(prefix_plus==prefix_minus,"shared coordinate prefix action")
                    out["matched_prefix_plaquette_checks"]+=len(prefix_plus)
                    out["coordinate_cut_cases"]+=1
    return out


if __name__=='__main__':
    result={"status":"PASS","finite_state":finite_checks(),"geometry":geometry_checks(),
            "scope":"Finite certificates supplement the proof; no SU(2) integration or continuum claim."}
    print(json.dumps(result,indent=2,sort_keys=True))
