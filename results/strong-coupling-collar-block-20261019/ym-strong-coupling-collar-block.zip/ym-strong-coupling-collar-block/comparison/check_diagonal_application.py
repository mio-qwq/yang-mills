#!/usr/bin/env python3
"""Exact finite incidence, common-shape, and graph-distance checks."""
from itertools import product,combinations
from collections import defaultdict,deque
import json


def require(ok, msg):
    if not ok:raise RuntimeError(msg)


def add(x,j):
    x=list(x);x[j]+=1;return tuple(x)


def edge(x,y):return tuple(sorted((x,y)))


def plaquette(x,i,j):
    y=add(x,i);z=add(x,j);v=add(y,j)
    return frozenset((edge(x,y),edge(x,z),edge(y,v),edge(z,v)))


def vertices(p):return set(v for e in p for v in e)


def audit():
    res={"cases":0,"crossing_self_reflection_checks":0,"shared_pair_checks":0,
         "ordinary_block_incidence_checks":0,"anchor_step_checks":0,
         "distance_lower_bound_checks":0,"max_row_by_dimension":{}}
    for d,L,k,sgn in product((2,3,4),(2,3),range(-2,3),(-1,1)):
        vs=set(product(range(-L,L+1),repeat=d)); ps=[]
        for x in vs:
            for i,j in combinations(range(d),2):
                p=plaquette(x,i,j)
                if vertices(p)<=vs:ps.append(p)
        def height(x):return x[0]+sgn*x[1]
        def refl(x):return (k-sgn*x[1],sgn*k-sgn*x[0])+x[2:]
        def reflp(p):return frozenset(edge(refl(e[0]),refl(e[1])) for e in p)
        def block(e):
            h0,h1=map(height,e)
            if h0==h1==k:return None
            if {h0,h1}=={k,k+1}:
                return ('pair',e[0] if h0==k+1 else e[1])
            return ('single',e)
        def anchor(b):return b[1] if b[0]=='pair' else b[1][0]
        def norm(x):return max(map(abs,x))
        def blocks(p):return {b for e in p if (b:=block(e)) is not None}
        pp={p for p in ps if min(map(height,vertices(p)))>=k}
        pm={reflp(p) for p in ps if max(map(height,vertices(p)))<=k}
        for p in ps:
            hs=list(map(height,vertices(p)))
            if min(hs)<k<max(hs):
                require(reflp(p)==p,'crossing plaquette fixed')
                res['crossing_self_reflection_checks']+=1
                ep=[e for e in p if min(map(height,e))>=k]
                em=[edge(refl(e[0]),refl(e[1])) for e in p if max(map(height,e))<=k]
                require(len(ep)==len(em)==2 and set(ep)==set(em),'shared positive Gaussian path')
                bb={block(e) for e in ep}
                require(len(bb)==1 and next(iter(bb))[0]=='pair','one Gaussian block')
                res['shared_pair_checks']+=1
        adj=defaultdict(set); row=defaultdict(int)
        for p in pp|pm:
            bs=blocks(p)
            for b in bs:
                require(anchor(b) in vertices(p),'block anchor is plaquette vertex')
                row[b]+=len(bs)-1
                res['ordinary_block_incidence_checks']+=1
                for bp in bs-{b}:
                    adj[b].add(bp)
                    require(max(abs(a-bb) for a,bb in zip(anchor(b),anchor(bp)))<=1,'unit anchor step')
                    res['anchor_step_checks']+=1
        maxrow=max(row.values(),default=0)
        require(maxrow<=8*d-10,'uniform block row')
        res['max_row_by_dimension'][str(d)]=max(res['max_row_by_dimension'].get(str(d),0),maxrow)
        bad=set().union(*(blocks(p) for p in pp^pm)) if pp^pm else set()
        for b in bad:require(norm(anchor(b))>=L-abs(k),'bad block far from core')
        ds={b:0 for b in bad};queue=deque(bad)
        while queue:
            b=queue.popleft()
            for bp in adj[b]:
                if bp not in ds:ds[bp]=ds[b]+1;queue.append(bp)
        for b,dist in ds.items():
            require(dist>=max(0,L-abs(k)-norm(anchor(b))),'cube-to-bad distance bound')
            res['distance_lower_bound_checks']+=1
        if k==0:require(not bad,'centered exact half actions')
        res['cases']+=1
    return {"status":"PASS","exact_integer_geometry":audit_summary(res),
            "scope":"Verifies finite geometry and row constants, not SU(2) integration or the analytic coupling theorem."}


def audit_summary(x):return x

if __name__=='__main__':print(json.dumps(audit(),indent=2,sort_keys=True))
