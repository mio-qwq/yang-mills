# Independent audit: arbitrary-collar buffer cross ratio

19 October 2026. Local review only. The primary report was not edited.

## Verdict

PASS. I found no substantive error in the finite-volume theorem, its constants, its allowance of arbitrary common collar and arbitrary terminal weights, the coordinate-cut isotropic geometry, or the stated limiting reflection-positivity corollary. The result is explicitly restricted to a verified high-temperature buffer and does not supply weak-coupling or continuum control.

Audited report: `/workspace/shared/uniform-collar-comparison-20261019-1650/RESULT.md`.
The initial reviewed version had SHA-256 `9348332a80b75f76a2116bf5bdaeefe72b77766766867a7cd33c6c7f960cc755`.

Dependencies checked where used:

- `/workspace/shared/gaussian-half-gluing-20261019-1440/RESULT.md`: Gaussian/Haar representation, normalized defect identity, complex RP bound, and common-exhaustion/symmetry argument.
- `/workspace/shared/posterior-strip-contraction-20261019/RESULT.md`: identification of the bond collar and coordinate blocks.
- `/workspace/shared/conditional-free-box-rp-20261019-1410/sources/strong-coupling-seam-PROOF.md`: influence and finite heat-bath comparison constants. The audited report also supplies this argument directly.

## Analytic checks

1. For one changed boundary site, oscillation of the conditional log-density difference is at most `4 A_ij`. The sharp normalized-likelihood inequality is `TV <= tanh(osc/4)`, hence influence is at most `A_ij`. Convex interpolation of the pinned C boundary preserves this same bound; it does not double it.

2. Pinning C and T before interpolation is essential and is done correctly. Neither g nor R enters the buffer conditional law. For `V=H_CU(c,.)-H_CU(c',.)`, the coordinate oscillation is at most `4 sum_c A_ic`. Changing the entire T configuration has discrepancy at most `sum_t A_jt`. Finite Dobrushin comparison therefore gives exactly

   `Delta_matrix = 4 1_C^T A_CU (I-A_UU)^(-1) A_UT 1_T`.

   There is no missing factor from interpolation, normalization, or the TV convention.

3. Every contributing matrix walk has length at least the full C-to-T distance. Starting only at the active C interface and using row sums at most q yields `4 |Gamma_C| q^r/(1-q)`. Symmetry of A and its U resolvent yields the terminal-interface counterpart and hence the minimum of the two interface cardinalities. Counting arbitrary collar interactions as graph edges is unnecessary because every collar variable is already a possible starting site.

4. For each fixed pair c,c', the integrated tail ratio is an average of `K(c,t)/K(c',t)`. Two arbitrary nonnegative terminal weights cannot extend the range of that ratio. Thus the integrated log likelihood oscillation is at most the kernel's four-point oscillation. Multiplication by the common g cancels exactly. Zeros of g cause no problem after restriction to its common support; disjoint terminal supports also cause no problem because K is strictly positive.

5. The stated finite positive joint normalizers, together with bounded H, already imply that g and each R have finite positive integrals, up to irrelevant null-set values. Thus `h_s(c)` is finite and strictly positive, and no extra likelihood-ratio or integrability assumption was silently needed.

6. The conditional expectation bound is `2 M epsilon` also for complex F. Squaring pointwise and integrating under any posterior gives `D <= 4 M^2 epsilon^2`. The normalized gluing identities consequently give `Re Q >= -M^2 epsilon^2` and `dist(Q,[0,infinity)) <= 2 M^2 epsilon`. The distinct source-normalization requirements for the real-part and full-complex conclusions are correctly retained.

## Coordinate geometry and common-state conclusion

For a site cut, the two reflected physical depths are `L-k` and `L+k`; a block contains outgoing longitudinal links and transverse links at its tail layer. Their common full terminal block is safely `N=L-|k|-1`. The site-plane tangent links are conditioned, so X0 is a special block containing only its free longitudinal links.

For a bond cut, the first physical layer is k+1 and the reflected depths are `L-k-1` and `L+k`. Thus `N=min(L-k-1,L+k)-1` is safe. Every subdivided Gaussian feature uses two auxiliary half-links and a first-layer tangent link, all in X0. Those auxiliary half-links have no ordinary physical interaction with the buffer.

Ordinary plaquettes have block span at most one. Therefore, with C ending at r0 and T at N, no direct C-T interaction exists when `N-r0>=2`, every C-to-T walk needs at least `N-r0` steps, and every active C interface variable lies in X_r0. Its cardinality is at most

`B_L=(2L+1)^(d-1)+2(d-1)L(2L+1)^(d-2)`.

The differing actual tails can be integrated into terminal weights: no differing interaction reaches U or C, and no missing plaquette is restored. For fixed affine cut and fixed test support, N grows linearly while B_L grows polynomially. This verifies the isotropic decay claim under fixed q<1.

Centered signed-diagonal reflections preserve the free cube and exchange the two Gaussian-conditioned half actions at the same W, giving exact matching there. The same physical box exhaustion can therefore satisfy all affine coordinate-cut and centered-diagonal RP limits simultaneously. Full site-half RP gives site-reflection invariance by polarization and generation of the whole cylinder algebra. Two site reflections give even translations. Translating a cylinder observable far into the bond-positive algebra then extends bond-reflection mean invariance to arbitrary cylinder tests, and composing a site and adjacent bond reflection gives unit translations. These translations transport centered diagonal RP to every integer affine diagonal. This does not assert finite-volume latent mismatch decay for shifted diagonal collars.

Minor wording improvement only: the report's phrase “all blocks through X_N are full” in the site paragraph can read as including the ordinary tangent part of X0, which has instead been conditioned away. “All regular blocks X_1,...,X_N are full, with X0 as described” is more literal. No estimate changes.

## Independent executable checks

`check_independent.py` uses only the Python standard library. It independently uses arbitrary bounded lookup-table hyperedge interactions, rather than only spin-product interactions. Its influence matrices and inverses are exact rational arithmetic; finite partition kernels and likelihood comparisons use stable floating-point log sums. Checks explicitly include a common collar weight with zero support, disjoint terminal supports, and positive log weights spanning scales up to 1000.

Executed successfully with ordinary Python and `python -O`, producing byte-identical JSON:

- 120 arbitrary-table hypergraph kernels
- 30,720 four-point cross-ratio bounds
- 120 exact rational matrix-to-walk bounds
- 1,440 zero-support or extreme-weight comparisons
- 36 coordinate-cut geometries in dimensions 2, 3, and 4
- 360,132 ordinary plaquette span checks
- 100,332 checks that actual discrepant plaquettes cannot touch C or U
- 54 full collar-interface checks with `N-r0>=2`

Results are in `check_results.json` and `check_results_optimized.json`. These finite certificates supplement the proof; they are not SU(2) integration or continuum evidence.

## Additional constant check

For the three-spin chain `H=b c u+b u t`, with fair spin reference measures, C={c}, U={u}, T={t}, one has

`K(c,t)=cosh(b(c+t))`,
`Delta_actual=2 log cosh(2b)`,
`Delta_matrix=4 b^2`.

With g=1 and terminal weights pinned at t=+1 and t=-1, respectively,

`TV=tanh(b)^2=tanh(Delta_actual/4)`.

As b tends to zero, `Delta_actual/(4 b^2)` tends to one. Thus both the factor 4 in the matrix estimate and the likelihood inequality's 1/4 are asymptotically optimal in the stated general interaction class. Strictly positive terminal weights approximate the pinned example. This sharpness observation is not asserted specifically for Wilson plaquettes.
