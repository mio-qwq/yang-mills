#!/usr/bin/env python3
"""Independent finite audit; standard library only, no SU(2) integration."""
from fractions import Fraction as Q
from itertools import product, combinations
from math import exp, log, tanh, cosh
import json
import random


def need(condition, description):
    if not condition:
        raise RuntimeError(description)


def lse(xs):
    m = max(xs)
    return m + log(sum(exp(x - m) for x in xs))


def inverse(a):
    n = len(a)
    b = [row[:] + [Q(i == j) for j in range(n)] for i, row in enumerate(a)]
    for j in range(n):
        k = next(i for i in range(j, n) if b[i][j])
        b[j], b[k] = b[k], b[j]
        z = b[j][j]
        b[j] = [x / z for x in b[j]]
        for i in range(n):
            if i != j:
                z = b[i][j]
                b[i] = [x - z * y for x, y in zip(b[i], b[j])]
    return [row[n:] for row in b]


def arbitrary_tables():
    rng = random.Random(165810192026)
    C, U, T = (0, 1), (2, 3, 4), (5, 6)
    n = 7
    configurations = [list(product((0, 1), repeat=len(s))) for s in (C, U, T)]
    cs, us, ts = configurations
    eligible = [s for k in (1, 2, 3, 4) for s in combinations(range(n), k)
                if set(s) & set(U) and not (set(s) & set(C) and set(s) & set(T))]
    out = {"arbitrary_table_hypergraphs": 0, "four_point_bounds": 0,
           "zero_or_extreme_weight_comparisons": 0, "exact_matrix_walk_bounds": 0}
    for case in range(120):
        edges = rng.sample(eligible, rng.randint(6, 18))
        raw = [rng.randint(1, 7) for e in edges]
        degrees = [sum(b * (len(e) - 1) for e, b in zip(edges, raw) if i in e)
                   for i in range(n)]
        scale = Q(rng.randint(1, 9), 10 * max(degrees))
        betas = [b * scale for b in raw]
        tables = [{x: rng.randint(-5, 5) / 5 for x in product((0, 1), repeat=len(e))}
                  for e in edges]
        A = [[Q(0) for j in range(n)] for i in range(n)]
        for e, b in zip(edges, betas):
            for i, j in product(e, repeat=2):
                if i != j:
                    A[i][j] += b
        D = inverse([[Q(i == j) - A[u][v] for j, v in enumerate(U)]
                     for i, u in enumerate(U)])
        delta_matrix = 4 * sum(A[c][u] * D[i][j] * A[v][t]
                               for c in C for i, u in enumerate(U)
                               for j, v in enumerate(U) for t in T)
        K = []
        for c in cs:
            row = []
            for t in ts:
                values = []
                for u in us:
                    x = c + u + t
                    values.append(sum(float(b) * table[tuple(x[i] for i in e)]
                                      for e, b, table in zip(edges, betas, tables)))
                row.append(lse(values) - len(U) * log(2))
            K.append(row)
        delta = 0
        for c, cp, t, tp in product(range(4), repeat=4):
            v = abs(K[c][t] - K[cp][t] - K[c][tp] + K[cp][tp])
            need(v <= float(delta_matrix) + 2e-12, "cross-ratio matrix bound")
            delta = max(delta, v)
            out["four_point_bounds"] += 1
        frontier = list(C)
        dist = {c: 0 for c in C}
        while frontier:
            i = frontier.pop(0)
            for j in range(n):
                if A[i][j] and j not in dist:
                    dist[j] = dist[i] + 1
                    frontier.append(j)
        if any(t in dist for t in T):
            r = min(dist[t] for t in T if t in dist)
            q = max(map(sum, A))
            gc = sum(any(A[c][u] for u in U) for c in C)
            gt = sum(any(A[t][u] for u in U) for t in T)
            need(delta_matrix <= 4 * min(gc, gt) * q**r / (1-q), "exact rational walk bound")
        else:
            need(delta_matrix == 0, "disconnected matrix zero")
        out["exact_matrix_walk_bounds"] += 1
        # Include a common zero collar support and disjoint terminal supports.
        for variation in range(12):
            size = (1, 10, 100, 1000)[variation % 4]
            g = [rng.uniform(-size, size) for c in cs]
            if variation >= 4:
                g[rng.randrange(4)] = float("-inf")
            rp = [rng.uniform(-size, size) for t in ts]
            rm = [rng.uniform(-size, size) for t in ts]
            if variation >= 8:
                rp = [0.0 if t == variation % 4 else float("-inf") for t in range(4)]
                rm = [0.0 if t == (variation + 2) % 4 else float("-inf") for t in range(4)]
            hp = [lse([K[c][t] + rp[t] for t in range(4)]) for c in range(4)]
            hm = [lse([K[c][t] + rm[t] for t in range(4)]) for c in range(4)]
            ratios = [p-m for p, m in zip(hp, hm)]
            need(max(ratios)-min(ratios) <= delta + 5e-11, "tail integration")
            p = [g[c] + hp[c] for c in range(4)]
            m = [g[c] + hm[c] for c in range(4)]
            zp, zm = lse(p), lse(m)
            tv = sum(abs(exp(a-zp)-exp(b-zm)) for a, b in zip(p, m))/2
            need(tv <= tanh(delta/4) + 5e-11, "zero/extreme common collar cancellation")
            out["zero_or_extreme_weight_comparisons"] += 1
        out["arbitrary_table_hypergraphs"] += 1
    return out


def sharpness():
    out = []
    for b in (.4, .2, .1, .01, .001):
        delta = 2 * log(cosh(2*b))
        tv = tanh(b)**2
        need(abs(tv-tanh(delta/4)) < 2e-15, "likelihood inequality equality")
        need(delta <= 4*b*b + 2e-15, "one-buffer matrix constant")
        out.append({"coupling": b, "cross_ratio_to_matrix_ratio": delta/(4*b*b),
                    "exact_TV": tv})
    return out


def slab(d, L, height, site):
    axes = [range(height+1)] + [range(-L, L+1)]*(d-1)
    edges = set()
    plaquettes = set()
    for x in product(*axes):
        for i in range(d):
            if x[i] < (height if i == 0 else L):
                if not (site and x[0] == 0 and i > 0):
                    edges.add((x, i))
        for i, j in combinations(range(d), 2):
            if x[i] >= (height if i == 0 else L) or x[j] >= (height if j == 0 else L):
                continue
            xi = list(x); xi[i] += 1
            xj = list(x); xj[j] += 1
            p = frozenset(((x, i), (x, j), (tuple(xi), j), (tuple(xj), i)))
            # Fixed site-plane tangent links do not count as integration variables.
            p = frozenset(e for e in p if not (site and e[0][0] == 0 and e[1] > 0))
            if p:
                plaquettes.add(p)
    return edges, plaquettes


def geometry():
    out = {"separated_coordinate_cut_cases": 0, "ordinary_plaquettes_checked": 0,
           "actual_discrepant_plaquettes_checked": 0, "collar_interfaces_checked": 0}
    for d, L, k, site in product((2, 3, 4), (4, 5), (-1, 0, 1), (False, True)):
        hp, hm = (L-k, L+k) if site else (L-k-1, L+k)
        N = min(hp, hm)-1
        ep, pp = slab(d, L, hp, site)
        em, pm = slab(d, L, hm, site)
        B = (2*L+1)**(d-1) + 2*(d-1)*L*(2*L+1)**(d-2)
        for j in range(N+1):
            bp = {e for e in ep if e[0][0] == j}
            bm = {e for e in em if e[0][0] == j}
            need(bp == bm, "same actual common block")
            expected = (2*L+1)**(d-1) if site and j == 0 else B
            need(len(bp) == expected, "actual block size")
        for p in pp | pm:
            heights = [e[0][0] for e in p]
            need(max(heights)-min(heights) <= 1, "one-step physical adjacency")
            out["ordinary_plaquettes_checked"] += 1
        for p in pp ^ pm:
            need(min(e[0][0] for e in p) >= N, "discrepancy cannot meet buffer or collar")
            out["actual_discrepant_plaquettes_checked"] += 1
        for r0 in range(N-1):
            # C ends at r0 and T is N. Verify every C-U incident edge is in last C block.
            gamma = set()
            for p in pp & pm:
                if any(e[0][0] <= r0 for e in p) and any(r0 < e[0][0] < N for e in p):
                    gamma.update(e for e in p if e[0][0] <= r0)
            need(all(e[0][0] == r0 for e in gamma), "last-block collar interface")
            need(len(gamma) <= B, "surface prefactor")
            need(N-r0 >= 2, "actual nonempty separation")
            out["collar_interfaces_checked"] += 1
        out["separated_coordinate_cut_cases"] += 1
    return out


if __name__ == "__main__":
    print(json.dumps({"status": "PASS", "arbitrary_tables": arbitrary_tables(),
                      "one_buffer_Ising_sharpness": sharpness(), "geometry": geometry(),
                      "scope": "Finite independent checks supplement the proof, not a numerical Wilson or continuum proof."},
                     indent=2, sort_keys=True))
