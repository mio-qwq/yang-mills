# Strong-coupling collar and diagonal-block checkpoint

19 October 2026. Local mathematical checkpoint. This is not a weak-coupling, continuum, or mass-gap result. Nothing here authorizes merging a research PR or publishing a research release.

## Results and distinct hypotheses

1. comparison/RESULT.md proves a separated arbitrary-collar bound. The common nonnegative collar and both terminal weights may be arbitrary with finite positive normalizers. All collar variables and tested variables must be included in C; a common high-temperature buffer U separates C from T, with no C-T plaquette. The four-point log-kernel bound is 4 1_C^T A_CU (I-A_UU)^(-1) A_UT 1_T, and TV<=tanh(Delta/4). In four-dimensional Wilson geometry q=18 beta<1. The resulting interface-size factor and distance from the entire collar cannot be replaced by local-test distance for arbitrary collar interactions.

2. comparison/DIAGONAL_BLOCK_THEOREM.md proves the actual integer signed-diagonal Gaussian comparison. Gaussian factors occupy disjoint two-link blocks and are absorbed into common positive one-block reference laws. Complete padded halves retain all bounded ordinary tail plaquettes. The block row bound is q=22 beta<1 in four dimensions (8d-10 times beta in dimension d). For a fixed W-independent support S_F of a bounded physical test, epsilon=min(1,|S_F| q^r/(1-q)) bounds the tested marginal TV, hence |P_W F-Q_W F|<=2||F|| epsilon. The bound is area-free because the actual block structure is stronger than an arbitrary common collar. In free cubes, r>=max(0,L-|k|-R); exact-zero cases are stated separately.

3. obstruction/RESULT.md supplies exact positive finite discrete counterexamples to proposed unrestricted-collar bounds: transverse amplification and strong local collar transmission. These are not counterexamples to the actual SU(2) Gaussian collar, Wilson RP, or an annealed posterior estimate. obstruction/FINAL_THEOREM_AUDIT.md independently audits the actual block theorem; independent/AUDIT.md separately audits the cross-ratio theorem and coordinate geometry.

The pointwise bounds imply the stated normalized mean-square mismatch and physical RP estimates using the prior gluing identities. They recover simultaneous RP along a common free-cube exhaustion in the explicitly small-beta regime. For varying physical source normalization M, the full complex form requires M^2 epsilon ->0; a negative-real-part-only bound uses epsilon squared. Physical tests may depend on conditioned physical plane data but not on auxiliary Gaussian values. Beta tending to infinity lies outside q<1. No numerical SU(2) integration, continuum construction or mass-gap theorem is claimed.

## Computational and mathematical prerequisites

Python 3.10 or later. comparison/check_collar.py additionally needs NumPy; requirements.txt pins numpy==2.3.5, the tested version. CPython 3.12.14 was used. Other checkers and all packaging/replay machinery use only the standard library. The finite hypergraph tests use floating point with explicit tolerances; combinatorial and obstruction tests use exact integers/rationals. Exact stored-output replay is checked in the stated environment; other numerical-library versions may differ in last-bit summary fields.

The minimal prior documents are preserved under prerequisites/: GAUSSIAN_HALF_GLUING.md supplies the actual Gaussian/Haar construction, normalized posterior identities, and common-exhaustion RP implication; POSTERIOR_STRIP_CONTRACTION.md supplies prior strip and coordinate-block context; STRONG_COUPLING_SEAM_PROOF.md supplies the earlier physical comparison context. The new comparison proofs also give their finite heat-bath arguments explicitly. Historical references from those documents to still older work are provenance, not extra computational replay inputs. This checkpoint does not claim to re-audit every earlier source transitively.

## Replay and archive integrity

Extract this ZIP into a new empty directory. From its extracted root run:

    python replay.py --receipt ../replay-receipt.json

This verifies every SHA-256, rejects unexpected payload files, runs every checker normally and with python -O, compares full JSON results with the bundled expected outputs, and requires normal/optimized stdout to be byte-identical. It then changes one checked mathematical invariant in a temporary copy of every checker and requires the intended exception in both modes. All checkers use explicit exceptions; no bare assert is relied upon. Temporary fault copies are discarded. The payload and original source files are not changed.

To reproduce the exact ZIP, choose a nonexistent output path outside the extracted root:

    python rebuild.py ../rebuilt.zip

The file list, byte contents, root name, sorted order, timestamp (2026-10-19 17:04:00 UTC), Unix file mode 0644 and DEFLATE level 9 are fixed. SHA256SUMS covers every payload file except itself; the outer archive SHA-256 covers that manifest too. The original packaging process verified byte-identical clean-extraction rebuilds, normal/optimized replay, and intended fault rejections. Original receipts are retained once as expected JSON, rather than duplicated normal/-O outputs. No cache, bytecode, temporary mutation, prior ZIP or redundant checker copy is included.

PROVENANCE.json maps each preserved file to its original local path, SHA-256 and byte size. Original document wording and historical absolute references are intentionally preserved. Use that map to locate bundled prerequisite copies; historical status phrases in old source notes are not current checkpoint status. The current independent audits and this README define the checkpoint status. No repository push, PR, merge, release, upload, or external communication is part of this checkpoint.
