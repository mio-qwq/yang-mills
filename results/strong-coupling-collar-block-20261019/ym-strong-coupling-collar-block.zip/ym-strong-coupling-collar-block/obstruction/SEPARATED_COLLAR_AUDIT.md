# Independent review of the separated-collar comparison

Reviewed 19 October 2026 against `/workspace/shared/uniform-collar-comparison-20261019-1650/RESULT.md` as read at approximately 16:58 UTC.

**Result: the displayed theorem and constants pass this review.**

1. For bounded plaquette terms, conditional log-ratio oscillation is at most `4 A_ij`; the TV coefficient is at most `tanh(A_ij)<=A_ij`. Convex interpolation between fixed collar configurations preserves this bound.
2. The derivative observable `V=H_CU(c,u)-H_CU(c',u)` has oscillation `delta_i V<=4 sum_c A_ic`. Combining with the terminal-discrepancy vector and `D_U=(I-A_UU)^(-1)` gives the stated factor `4 1_C^T A_CU D_U A_UT 1_T`.
3. Arbitrary tail factors introduce no extra constant: `h_s(c)/h_s(c')` is exactly a probability average of `K(c,t)/K(c',t)`. Both averages lie in the same positive interval. Hence their logarithms differ by no more than the four-point cross-ratio oscillation.
4. The shared collar factor cancels from the normalized likelihood ratio. The `tanh(Delta/4)` bound and complex-observable factor `2||F||` use consistent TV conventions.
5. The matrix walk expansion requires at least `dist(C,T)` physical adjacency steps. Symmetry permits the smaller of the two complete interface cardinalities. Arbitrary collar interactions do not invalidate this argument because every site they involve is already inside the starting set C.
6. The coordinate-site cutoff `N=L-|k|-1` is safe. For a coordinate-bond cut, `N=min(L-k-1,L+k)-1` is exactly the conservative last complete ordinary block in both reflected halves. The introduced half-links occur only inside the collar weight, so they add no physical C-U interface incidences.
7. Full transverse sections have the same lateral geometry for coordinate reflection in a centered cube. This justifies the remote separator construction. It is not valid without modification for a shifted diagonal collar reaching a lateral discrepancy.
8. Centered diagonal conditional halves agree exactly. Transporting their limiting physical RP inequalities by already-established lattice translation invariance is valid. The report correctly distinguishes this from the stronger finite-volume shifted-diagonal posterior-mismatch assertion.

The companion obstruction report establishes why the stated whole-collar geometric hypotheses matter. A separate diagonal disjoint-pair blocking argument may prove a stronger actual-Gaussian result, but that argument is not needed for the audited theorem.
