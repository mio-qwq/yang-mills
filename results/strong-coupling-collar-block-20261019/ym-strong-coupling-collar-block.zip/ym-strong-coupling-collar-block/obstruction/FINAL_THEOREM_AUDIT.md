# Independent audit of the actual diagonal Gaussian half-kernel theorem

19 October 2026. Audit target:
`/workspace/shared/uniform-collar-comparison-20261019-1650/DIAGONAL_BLOCK_THEOREM.md`.

## Verdict

The full finite-volume theorem and the isotropic common-box conclusion pass this independent mathematical review. The substantive result is stronger than the separated arbitrary-collar theorem: the actual diagonal Gaussian product can be absorbed into disjoint two-link block references, so only the **local tested block count**, not the cut area, enters the high-temperature comparison.

A deterministic-support convention is required for the displayed annealed bound: choose a finite set `S_F` independently of W that carries all active-link dependence of the fixed physical test, for every fixed physical plane configuration. Pointwise optimization to `S_F(W)` is possible, but its varying bound would have to be averaged or replaced by its supremum. Also, the physical RP consequence applies to physical tests depending on plane variables Z, not arbitrary Gaussian-dependent auxiliary tests. Both clarifications, together with the explicit assumption that all couplings lie in [0,beta], were incorporated in the audited theorem before freeze.

## 1. Common factors on complete padded blocks

The geometric partition is defined before choosing either finite half. Every link from height k to k+1 has a unique height-k+1 endpoint v and belongs to the corresponding two-link pair. Completing a partially present pair with independent unused Haar links makes both product reference spaces identical without introducing any physical plaquette.

A crossing plaquette is individually fixed by the diagonal reflection. If it is present in the original induced complex, both of its reflected positive-path factors exist and use the same Gaussian vector and coupling. After reflected identification they give the same one-block function of the same two group variables. If it is absent, both Gaussian factors are absent. Hence the product of one-block reference weights is exactly common, even for asymmetric shapes.

All remaining physical action terms are bounded ordinary plaquette factors. The theorem compares the entire padded finite halves, without replacing their tails by uncontrolled multiblock factors. This is important: arbitrary integrated tail interactions are not implicitly admitted into the block Dobrushin calculation.

## 2. Uniform influence matrix and bad blocks

The matrix defined from the union of ordinary plaquettes, using the larger of the two couplings on each plaquette, simultaneously bounds both half specifications. The union is still a subset of the ordinary full positive-half plaquette geometry, so its incidence cannot exceed 22 in dimension four. The independent geometric calculation and executable check are recorded in `DIAGONAL_AUDIT.md`.

Absorbing each positive integrable one-block Gaussian weight into its own normalized reference is valid for every fixed finite W. A shared one-block reference cancels from the conditional density ratio when another block is changed. Each shared plaquette contributes at most `4 beta` to its log-ratio oscillation, giving influence at most `tanh(A_ij)<=A_ij`.

If a block touches no differing ordinary plaquette, its two conditional specifications agree. Thus `b_i=0` away from the stated bad set and `b_i<=1` on it. Missing physical links do not create any additional discrepancy after padding: their Haar reference is already common, and any change in interactions is accounted for by missing ordinary plaquettes.

## 3. Coupling, local TV and complex constants

For `q=22 beta<1`, the finite random-scan coupling recurrence gives disagreement bound `(I-A)^(-1)b`. For each fixed W, bounded interactions relative to the normalized one-block references give a finite-sweep Doeblin minorization, so the two marginal chains converge to their target half laws.

The union bound on disagreements in S gives

    TV(P_S,Q_S) <= min(1, sum_(i in S,j in B_bad) [(I-A)^(-1)]_ij).

The Neumann-series terms of length less than `r=dist(S,B_bad)` vanish. Row summation gives `epsilon<=min(1,|S| q^r/(1-q))`. No cardinality of B_bad or of the whole cut is needed.

With the supremum-over-events convention for TV, the complex test bound is exactly `|PF-QF|<=2||F|| TV`. There is no additional factor from treating real and imaginary parts separately. Squaring and averaging the deterministic uniform bound yields `D(F)<=4M^2 epsilon^2`. The inherited gluing identities give `Re Q>=-M^2 epsilon^2` and distance from the nonnegative real axis at most `2M^2 epsilon`.

Empty observed/bad sets, disconnected components and beta zero are correctly treated as exact zero mismatch rather than through ambiguous exponent conventions.

## 4. Shifted signed cuts and exact distance growth

For an integer signed-diagonal cut with offset k, the reflection is a signed coordinate permutation followed by a translation of maximum norm |k|. Therefore the original centered cube and its reflected cube both contain the integer cube of radius L-|k|.

Any ordinary plaquette whose factors differ must have an integer-coordinate vertex outside that inner cube, hence of maximum norm at least `L-|k|+1`. Anchor a pair at its common apex and a singleton at its positive tail. An anchor is an endpoint of every link in its block. Therefore an anchor of any block touching the differing plaquette has maximum norm at least `L-|k|`.

If two blocks are adjacent, their anchors are vertices of one unit plaquette, so their maximum-norm separation is at most one. A test link with endpoints in the radius-R cube has its block anchor in that cube, including when its block is a pair. Consequently

    dist(S_F,B_bad) >= max(0,L-|k|-R).

The theorem's sharper integer distance is valid; the weaker extra-two-site margin initially considered in discussion is unnecessary. Signed-diagonal changes preserve the argument by coordinate sign changes.

## 5. Consequence and limits

At fixed beta with `22 beta<1`, the test block count is fixed and the discrepancy distance grows linearly. The actual diagonal Gaussian-conditioned mismatch therefore vanishes pointwise in W and under the actual posterior, for every fixed integer signed-diagonal cut along one centered free-cube exhaustion.

The coordinate comparison in the companion report requires only `18 beta<1`, so it applies in the same regime. The recovered Gaussian-gluing theorem then yields simultaneous physical RP for the full stated countable cut family in every physical local weak cluster point.

This is a valid stronger auxiliary criterion in a smaller explicitly high-temperature regime. It is not an extension to arbitrary beta, the weak-coupling trajectory, a continuum construction, or a mass-gap theorem. The arbitrary-collar counterexamples remain correct because their uncontrolled weights couple distinct blocks; they do not contradict this special disjoint-support argument.

## Verification scope

This review checked the proof, definitions, padding, discrepancy sets, constants and geometry independently. It did not run the companion author's code. The executable certificates in this directory were written independently and use exact finite discrete arithmetic or integer lattice enumeration; neither integrates the interacting SU(2) law numerically.
