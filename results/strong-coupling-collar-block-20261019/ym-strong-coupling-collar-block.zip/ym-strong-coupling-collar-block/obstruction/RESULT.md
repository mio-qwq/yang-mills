# Sharp obstructions for an arbitrary common collar weight

19 October 2026. Independent local mathematical note. No repository or external changes.

## Result in one paragraph

An arbitrary shared positive collar weight cannot be discarded when asking for a width-uniform local mixing estimate. It can coordinate the entire collar and turn `m` remote biases of size `t^N` into a local response of order `tanh(m atanh(t^N))`. An exact finite model below attains the sharp common-reweighting bound in the positive-weight limit. Even strictly positive nearest-neighbor collar factors suffice to keep a single local mismatch above `289/202` when `m=4^N`, while every ordinary exterior coupling has `tanh J=1/4`. This requires exponentially growing width and **does not rule out isotropic remote-buffer estimates**. A separate exact lateral example has width proportional to distance: an arbitrarily strong common collar chain carries a lateral boundary discrepancy to a fixed local test with mismatch at least `1/4`. The relevant separation is distance from the **whole uncontrolled collar**, not merely from the test.

Neither example is a counterexample for the actual Gaussian-conditioned SU(2) Wilson law or its actual posterior average. The examples disprove an abstract estimate uniform over all common positive collar weights, unless a collar-size/separation or controlled-collar hypothesis is imposed.

## 1. Sharp common-reweighting theorem

Let `C` be a finite state space. Let `f_+,f_->0` and let `g>0` be any shared weight. Put

    P_s(c) = g(c) f_s(c) / sum_z g(z) f_s(z),
    Delta = osc_c log(f_+(c)/f_-(c)).

With total variation defined as supremum over events,

    TV(P_+,P_-) <= tanh(Delta/4),                     (1)
    |P_+ F-P_- F| <= 2 ||F||_infinity tanh(Delta/4).  (2)

The bound includes complex `F`. There is no bound on `sup g/inf g`.

Indeed, the normalized likelihood ratio has the same logarithmic oscillation as `f_+/f_-`, since `g` cancels. A normalized likelihood ratio with max/min at most `R` has TV at most `(sqrt(R)-1)/(sqrt(R)+1)`. Here `R=exp(Delta)`, giving (1).

For fixed `f_+,f_-`, (1) is sharp as a supremum over strictly positive `g`. Concentrate `g` on one maximizing and one minimizing state of `f_+/f_-`, and choose their relative weights to give the optimal two-point likelihood ratio. Approximate that nonnegative weight by strictly positive weights on all other states. If the local observable distinguishes these two configurations, its expectation can attain the corresponding limit in (2).

This exact statement identifies what a uniform-in-`g` theorem must control: oscillation of the effective partition-ratio on the **entire support of the unrestricted common weight**. Small marginal changes before reweighting do not suffice.

## 2. Independent high-temperature teeth and remote endpoints

Fix `t=1/4` and an integer `N>=1`. Let `m` independent Ising chains have roots `x_j` in a common collar and depth `N`. All spins are in `{-1,+1}`. Use the positive edge factor

    1+t sigma sigma',

which is proportional to `exp(J sigma sigma')`, `tanh J=t`. Fix all terminal spins at depth `N` to the same sign `s`, and multiply the collar configuration by the same arbitrary positive `g(x_1,...,x_m)` in both models.

The ordinary exterior chains have Dobrushin row sums at most `2t=1/2`. This statement concerns the ordinary exterior interactions, not the unrestricted collar. Integrating each chain's internal spins gives, up to a common constant,

    f_s(x) = product_(j=1)^m (1+s a x_j),
    a=t^N.                                          (3)

The two models differ only at normal distance `N` from the entire collar. Their effective log-ratio oscillation is exactly

    Delta = 4m atanh(a).                             (4)

Therefore for every positive `g`,

    |P_+ F-P_- F| <= 2 ||F|| tanh(m atanh(a)).        (5)

The area dependence is real, not an artifact of a proof.

### 2.1 Exact strictly positive globally coordinating weight

Let `0<epsilon<1` and define

    g_epsilon(x) = 1       if all roots are equal,
                   epsilon otherwise.

Set

    A=(1+a)^m,  B=(1-a)^m.

For the single-spin test `F=x_1`, exact summation gives

    P_s x_1 = s [epsilon a 2^m+(1-epsilon)(A-B)]
                /[epsilon 2^m+(1-epsilon)(A+B)].     (6)

As `epsilon` decreases to zero,

    |P_+ x_1-P_- x_1| -> 2(A-B)/(A+B)
                         = 2 tanh(m atanh(a)),       (7)

which saturates (5) with a single fixed local observable. Every approximating `g_epsilon` is finite and strictly positive.

Take `m=4^N`, so `a=1/m`. Since `m atanh(1/m)>1`, the limiting mismatch exceeds `2 tanh(1)`, approximately `1.523`. Consequently no bound `C exp(-cN)` with `C,c>0` independent of width and common collar weight is possible, even for one local test and this uniformly high-temperature exterior.

One can also keep an explicitly finite positive weight, for example `epsilon=2^(-2m)`; the exact rational checker evaluates (6) for these choices. No hard constraint is necessary.

### 2.2 A strictly positive nearest-neighbor collar is already enough

The globally coordinating factor is not essential. Arrange the roots in a one-dimensional path and set

    g_epsilon(x) = epsilon^(number of collar domain walls),
    epsilon=1/(100m),   m=4^N.                        (8)

This is a product of strictly positive nearest-neighbor collar factors. Equivalently it is a ferromagnetic Ising collar with coupling

    K=(1/2) log(100m).

The uncontrolled strengths grow with width. No uniform high-temperature claim is made about these collar interactions.

Let `h=atanh(1/m)`. Ignoring common constants from (3), the plus law has weight

    epsilon^(number of domain walls) exp(h sum_j x_j).

Conditional on no collar domain wall, every root has mean

    tanh(mh) > tanh(1) > 3/4.                        (9)

The last strict inequality follows from `exp(2)>7`.

Let `Z_0=2 cosh(mh)` be the aligned-state partition sum, and `Z_bad` the partition sum over configurations with at least one wall. There are exactly `2 binom(m-1,k)` root configurations with `k` walls, and each field weight is at most `exp(mh)`. Thus

    Z_bad/Z_0
      <= 2 [(1+epsilon)^(m-1)-1]
      <= 2/99.                                      (10)

For the second inequality use `(1+x)^n <= 1/(1-nx)` for `0<=nx<1`, which follows coefficientwise from `binom(n,k)<=n^k`, and `(m-1)epsilon<1/100`.

Hence the probability `p_bad` of any wall is at most `2/101`. For every root `x_j`,

    P_+ x_j >= (1-p_bad) tanh(mh)-p_bad
             > (99/101)(3/4)-2/101
             = 289/404.                             (11)

Global spin flip sends the plus model to the minus model, so

    |P_+ x_j-P_- x_j| > 289/202 > 1.430.             (12)

This is an exact all-`N` estimate, with all finite weights positive and all collar interactions nearest-neighbor. It still uses exponentially large width `m=4^N`.

### 2.3 What the remote example does and does not say

- For fixed `m`, the uniform-in-`g` bound (5) tends to zero exponentially with `N`.
- More generally it tends to zero whenever `m t^N -> 0`, since `atanh(a)<=a/(1-a^2)`.
- In particular, polynomially growing width does not defeat remote contraction in this model, however strong the common positive collar weight becomes.
- Thus this example establishes necessary aggregate collar dependence. It does **not** obstruct an isotropic box estimate when the complete uncontrolled collar remains distance proportional to the box size from every discrepancy and its size is polynomial in that distance.
- A high-temperature bulk estimate of the form `Delta <= const |C| q^dist(C,T)/(1-q)` has exactly the right qualitative feature for this issue.

## 3. Lateral discrepancies are different

Let the collar be the path with sites `-m,...,m`, `m>=1`, and let the common collar factor be

    g_m(x)=product_(j=-m)^(m-1) (1+q_m x_j x_(j+1)),
    q_m=1-1/(2m).                                   (13)

All factors are finite, strictly positive, nearest-neighbor factors. Compare the two models with endpoint factors

    f_s(x)=1+s t x_m,   t=1/4.                       (14)

For example, (14) is one ordinary high-temperature edge to a fixed terminal sign `s` immediately beyond the lateral endpoint. The test is the one fixed central spin `F=x_0`.

The zero-field Ising chain with edge parameter `q_m` has exact correlation `E[x_0 x_m]=q_m^m`. Its endpoint has mean zero. Therefore

    P_s x_0 = s t q_m^m,
    |P_+ x_0-P_- x_0| = 2t q_m^m >= t=1/4.         (15)

The last inequality is Bernoulli's inequality:

    (1-1/(2m))^m >= 1-m/(2m)=1/2.

The support of the discrepancy moves distance `m` from the fixed test. The collar width is `2m+1`, only linear in that distance. One may append any number of shared independent normal teeth with edge parameter `t` and free terminal ends; integrating them out gives constants and changes none of (13)-(15). In particular, the normal depth may grow proportionally to `m`.

What fails is not the whole-collar distance estimate. The difference touches the uncontrolled collar at its lateral edge. Its distance from the collar is zero, or one if the fixed terminal spin is counted as the boundary set. The exact effective ratio oscillation is

    osc log(f_+/f_-)=4 atanh(t),                      (16)

which does not tend to zero. Distance from the **test alone** is irrelevant when an arbitrary strong shared collar can transmit the perturbation across that distance.

For an addition/removal version, compare `f_+=1+t x_m` with `f_0=1`. Then the local mismatch is `t q_m^m>=1/8`. This is a bounded discrepancy in a single boundary factor, rather than a replacement of its sign.

If the collar parameter `q<1` is uniformly fixed, the same lateral example instead gives `2t q^m -> 0`. The obstruction specifically uses the absence of any uniform control on the common collar.

## 4. Local tests outside the collar

Neither obstruction depends essentially on measuring a collar variable. Attach a shared free Ising branch of any fixed length `r` to a tested root, with all edge parameters `t`. Integrating this branch leaves the root law unchanged. If `F` is its endpoint spin, then

    P_s F = t^r P_s x_root.

Thus each lower bound is merely multiplied by the positive constant `t^r`. The observable can be a fixed local physical spin at any fixed positive distance from the cut.

## 5. Posterior and geometry implications

The strip result in `/workspace/shared/posterior-strip-contraction-20261019/RESULT.md` remains correct. Its interblock coefficient depends on the whole transverse interface, and fixed width gives a genuine contraction independent of the common collar weight. The remote example explains why an arbitrary-collar width-uniform improvement cannot simply ignore transverse multiplicity.

The Gaussian reduction in `/workspace/shared/gaussian-half-gluing-20261019-1440/RESULT.md` uses

    D(F)=E_rho |P_W F-Q_W F|^2.

The examples above are pointwise conditional-kernel examples. If one takes a one-point auxiliary space `W`, they also give abstract normalized two-half models with the same nonzero mean-square mismatch. For (12), this abstract defect exceeds `(289/202)^2`.

However, this does not show that the displayed collar weights are realizable by Wilson's particular local Gaussian features, or that their parameter regions have significant probability under its actual posterior `rho`. A failure of an all-weights, all-`W` estimate does not establish failure of an annealed Wilson estimate. The latter can require feature structure, posterior probability bounds, or a direct physical comparison.

There is a precise geometric distinction when using an uncontrolled-collar comparison theorem:

1. **Fixed collar / remote mismatch:** a controlled bound on the effective ratio oscillation may remain independent of the sharpness of `g`; no positive lower bound on `g` is needed.
2. **Growing full cut / remote mismatch:** aggregate collar size enters. Polynomial area is compatible with exponential remote decay; exponential area can defeat it.
3. **Growing full cut / lateral mismatch touching the collar:** normal depth alone cannot help. The lateral example rules out replacing whole-collar separation by test-to-boundary separation while retaining arbitrary collar weights.
4. **Artificially cropping the collar:** if omitted shared collar factors remain uncontrolled and couple the retained collar to the omitted part, they cannot then be treated as high-temperature buffer interactions. Cropping requires an additional locality/strength or posterior estimate.

These are obstructions to particular proof assumptions. No counterexample to simultaneous Wilson RP, Wilson strong-coupling uniqueness, or the actual posterior-mismatch criterion is claimed.

## 6. Independent exact checker

`check_obstruction.py` uses only Python's standard library and performs no network access. It checks:

- direct spin summation of short teeth against (3);
- direct enumeration against the exact positive-weight formula (6);
- exact integer transfer computation for (8), including the lower bound (11), for `N=1,...,6` (`m` up to 4096);
- direct enumeration of short lateral chains against (15), and exact rational lower bounds for larger `m`;
- the sharp common-reweighting limit on the two aligned root states.

`check_results.json` contains its output. These finite checks supplement the all-size proofs; they do not evaluate SU(2) integrals or the Wilson posterior.

## 7. Subsequent actual-Gaussian resolution in a controlled regime

The completed companion theorem `/workspace/shared/uniform-collar-comparison-20261019-1650/DIAGONAL_BLOCK_THEOREM.md` exploits a restriction absent from these counterexamples: actual diagonal Gaussian features have disjoint two-link supports. The full theorem was independently audited in `FINAL_THEOREM_AUDIT.md`. It gives a local, area-free pointwise mismatch estimate at `22 beta<1`, including shifted signed-diagonal cuts along isotropic free cubes. Thus the arbitrary-collar obstructions identify the necessary structural distinction; they do not block this actual-Gaussian result.

Both local checkers use explicit `require` failures, which remain active under Python optimization. Their ordinary and `python -O` receipts pass and are byte-identical.
