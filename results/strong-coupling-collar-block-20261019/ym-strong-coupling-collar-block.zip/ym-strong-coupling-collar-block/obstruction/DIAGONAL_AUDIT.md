# Independent diagonal Gaussian-block incidence audit

19 October 2026. This verifies geometry and the elementary influence constant, not a complete common-exhaustion theorem.

## Finding

The actual diagonal Gaussian collar weight is not an arbitrary coupled function of the whole cut. For the cut `u=x_0-x_1=a`, each positive-half Gaussian feature belongs to one disjoint **two-link block** indexed by a vertex `v` of height `a+1`:

    B_v = { (v-e_0,v), (v,v+e_1) }.

The unique crossing plaquette is based at `v-e_0` and has directions `(0,1)`. Its positive path uses exactly these two links. Different `v` give disjoint link sets. Thus the conditional Gaussian weight is a product of arbitrary positive one-block weights, uniformly for every finite value of the auxiliary fields. Shared tangent-plane links are held fixed.

Group all other positive-half links as singleton blocks. In dimension `d>=2`, a collar pair block has exactly

    2 ordinary (0,1) plaquettes, each touching 3 other active blocks;
    4(d-2) tangent plaquettes, each touching 2 other active blocks.

The tangent plaquette's fourth link is tangent to the fixed plane and is conditioned, hence is not an active block. The exact maximal pair row-incidence sum is

    2*3 + 4(d-2)*2 = 8d-10.

Each singleton block has at most `2(d-1)` incident plaquettes, each with at most three other active blocks, hence row sum at most `6(d-1)<=8d-10`.

For a Wilson plaquette scalar `w_p in [-1,1]`, changing a neighboring block gives a log-conditional-likelihood-ratio oscillation at most `4 beta` per shared plaquette. The arbitrary common positive one-block Gaussian weight cancels. Consequently

    c_ij <= tanh(beta n_ij) <= beta n_ij,
    max_i sum_j c_ij <= (8d-10) beta.

In four dimensions this is `22 beta`. At `22 beta<1`, the standard finite-volume block Dobrushin comparison applies uniformly in the auxiliary fields. Any derivation of the complete local mismatch estimate must still explicitly handle the shared reflected geometry, the boundary-discrepancy support and the observable's block support. There is no all-coupling conclusion.

Absent plaquettes only remove terms. Completing a missing positive-half link with independent dummy Haar measure does not create an interaction. One may group dummy and genuine links in the same geometrically fixed pair. Crossing plaquettes are individually reflection-invariant, so their Gaussian feature sets agree between the identified halves. These observations preserve the bound for asymmetric induced boxes after common-ambient identification.

The same result for signed diagonals follows by lattice coordinate sign changes and the corresponding oriented-link inversion. The fixed integer offset does not change the local incidence count.

## Exact combinatorial check

`check_diagonal_blocks.py` independently enumerates offsets `a=-2,...,2` and dimensions `d=2,...,5`. It checks 5,928 positive-path link ownership assignments, disjoint pair membership, the two plaquette classes, and every sampled singleton row. All 20 dimension/offset cases pass. Exact pair row constants are 6,14,22,30 in dimensions 2,3,4,5; sampled maximal singleton constants are 6,12,18,24.

Output: `diagonal_check_results.json`.

This local structure is why the arbitrary-collar obstructions in `RESULT.md` do not settle the actual Wilson Gaussian-posterior question. The obstructing collar chains contain uncontrolled interblock interactions; the diagonal Gaussian weights can be confined inside uniformly bounded, disjoint blocks instead.
