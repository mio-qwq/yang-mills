#!/usr/bin/env python3
"""Independent incidence audit for diagonal Gaussian-pair blocking."""
from itertools import product, combinations
from collections import Counter
import json

def require(condition, message):
    if not condition:
        raise AssertionError(message)

def shift(x, i, value):
    result = list(x)
    result[i] += value
    return tuple(result)

def height(x):
    return x[0] - x[1]

def plaquette(base, i, j):
    vertices = (base, shift(base, i, 1), shift(base, j, 1), shift(shift(base, i, 1), j, 1))
    links = ((base, i), (shift(base, j, 1), i), (base, j), (shift(base, i, 1), j))
    return (vertices, links)

def block(edge, a):
    x, i = edge
    y = shift(x, i, 1)
    lo, hi = sorted((height(x), height(y)))
    if lo < a:
        raise ValueError('not a closed positive-half link')
    if lo == hi == a:
        return None
    if lo == a and hi == a + 1:
        v = y if height(y) > height(x) else x
        return ('pair', v)
    return ('single', edge)

def incident(edge, d):
    x, i = edge
    result = set()
    for j in range(d):
        if j == i:
            continue
        ii, jj = sorted((i, j))
        result.add((x, ii, jj))
        result.add((shift(x, j, -1), ii, jj))
    return result

def neighborhood(edges, d, a):
    own = block(edges[0], a)
    require(all((block(e, a) == own for e in edges)), 'Certificate check failed at original source line 52')
    interactions = []
    for base, i, j in set().union(*(incident(edge, d) for edge in edges)):
        vertices, links = plaquette(base, i, j)
        if min(map(height, vertices)) < a:
            continue
        supports = {block(edge, a) for edge in links}
        supports.discard(None)
        require(own in supports, 'Certificate check failed at original source line 60')
        interactions.append((i, j, len(supports) - 1))
    return interactions

def main():
    rows = []
    ownership_checks = 0
    for d in (2, 3, 4, 5):
        for a in range(-2, 3):
            v = (a + 1, 0) + (0,) * (d - 2)
            edges = ((shift(v, 0, -1), 0), (v, 1))
            interactions = neighborhood(edges, d, a)
            types = Counter((('diagonal' if (i, j) == (0, 1) else 'tangent', n) for i, j, n in interactions))
            require(types['diagonal', 3] == 2, 'Certificate check failed at original source line 75')
            require(types['tangent', 2] == 4 * (d - 2), 'Certificate check failed at original source line 76')
            require(sum(types.values()) == 2 + 4 * (d - 2), 'Certificate check failed at original source line 77')
            incidence = sum((n for _, _, n in interactions))
            require(incidence == 8 * d - 10, 'Certificate check failed at original source line 79')
            owner = {}
            crossings = 0
            for base in product(range(-2, 3), repeat=d):
                if height(base) != a:
                    continue
                vertices, links = plaquette(base, 0, 1)
                plus_vertex = next((x for x in vertices if height(x) == a + 1))
                positive_path = [e for e in links if min(height(e[0]), height(shift(e[0], e[1], 1))) >= a]
                require(len(positive_path) == 2, 'Certificate check failed at original source line 91')
                for edge in positive_path:
                    require(block(edge, a) == ('pair', plus_vertex), 'Certificate check failed at original source line 93')
                    require(edge not in owner, 'Certificate check failed at original source line 94')
                    owner[edge] = plus_vertex
                    ownership_checks += 1
                crossings += 1
            largest_single = 0
            for x in product(range(-1, 3), repeat=d):
                for i in range(d):
                    y = shift(x, i, 1)
                    if min(height(x), height(y)) < a:
                        continue
                    tag = block((x, i), a)
                    if tag is None or tag[0] != 'single':
                        continue
                    row = sum((n for _, _, n in neighborhood(((x, i),), d, a)))
                    require(row <= 6 * (d - 1), 'Certificate check failed at original source line 109')
                    largest_single = max(largest_single, row)
            rows.append(dict(d=d, offset=a, pair_row=incidence, tangent_plaquettes=4 * (d - 2), diagonal_plaquettes=2, max_sampled_singleton_row=largest_single, crossing_plaquettes=crossings))
    print(json.dumps(dict(status='PASS', ownership_checks=ownership_checks, rows=rows), sort_keys=True, indent=2))
if __name__ == '__main__':
    main()
