#!/usr/bin/env python3
"""Exact finite certificates for arbitrary shared collar-weight obstructions."""
from fractions import Fraction as Q
from itertools import product
import json

def require(condition, message):
    if not condition:
        raise AssertionError(message)

def spins(n):
    return product((-1, 1), repeat=n)

def prod(values):
    result = 1
    for value in values:
        result *= value
    return result

def brute_tooth(n, t, root, terminal):
    answer = Q(0)
    for interior in spins(n - 1):
        chain = (root,) + interior + (terminal,)
        answer += prod((1 + t * chain[i] * chain[i + 1] for i in range(n)))
    return answer

def effective_collar(m, a, epsilon, side, local=False):
    z, num = (Q(0), Q(0))
    for x in spins(m):
        walls = sum((x[i] != x[i + 1] for i in range(m - 1)))
        g = epsilon ** walls if local else 1 if walls == 0 else epsilon
        weight = g * prod((1 + side * a * value for value in x))
        z += weight
        num += x[0] * weight
    return num / z

def global_formula(m, a, epsilon, side):
    aa, bb = ((1 + a) ** m, (1 - a) ** m)
    return side * (epsilon * a * 2 ** m + (1 - epsilon) * (aa - bb)) / (epsilon * 2 ** m + (1 - epsilon) * (aa + bb))

def local_integer_transfer(m, side=1):
    """Unnormalized site weights m+s*x; edge weights 100m equal, 1 unequal."""
    weights_by_first = {}
    bad_by_first = {}
    for first in (-1, 1):
        state = {first: m + side * first, -first: 0}
        for _ in range(1, m):
            state = {last: (m + side * last) * sum((value * (100 * m if old == last else 1) for old, value in state.items())) for last in (-1, 1)}
        weights_by_first[first] = sum(state.values())
        aligned = (m + side * first) ** m * (100 * m) ** (m - 1)
        bad_by_first[first] = weights_by_first[first] - aligned
    normalizer = sum(weights_by_first.values())
    numerator = weights_by_first[1] - weights_by_first[-1]
    bad = sum(bad_by_first.values())
    return (Q(numerator, normalizer), Q(bad, normalizer))

def direct_full_comb(m, n, t, epsilon, side):
    """Independent direct enumeration, including every nonterminal tooth spin."""
    z, num = (Q(0), Q(0))
    for values in spins(m * n):
        chains = [values[j * n:(j + 1) * n] + (side,) for j in range(m)]
        roots = [chain[0] for chain in chains]
        g = 1 if len(set(roots)) == 1 else epsilon
        weight = g * prod((1 + t * chain[i] * chain[i + 1] for chain in chains for i in range(n)))
        z += weight
        num += roots[0] * weight
    return num / z

def brute_lateral(m, q, t, side):
    z, num = (Q(0), Q(0))
    for x in spins(2 * m + 1):
        weight = (1 + side * t * x[-1]) * prod((1 + q * x[i] * x[i + 1] for i in range(2 * m)))
        z += weight
        num += x[m] * weight
    return num / z

def main():
    counts = dict(tooth_identities=0, global_weight_formulas=0, full_comb_enumerations=0, local_transfer_checks=0, lateral_enumerations=0, lateral_rational_bounds=0, aligned_sharpness=0)
    for n in range(1, 8):
        for t in (Q(1, 4), Q(1, 3), Q(2, 5)):
            for root, terminal in spins(2):
                actual = brute_tooth(n, t, root, terminal)
                expected = 2 ** (n - 1) * (1 + t ** n * root * terminal)
                require(actual == expected, 'Certificate check failed at original source line 100')
                counts['tooth_identities'] += 1
    for m in range(1, 8):
        for a in (Q(1, 4), Q(1, 16), Q(1, 64)):
            for epsilon in (Q(1, 2), Q(1, 100), Q(1, 2 ** (2 * m))):
                for side in (-1, 1):
                    require(effective_collar(m, a, epsilon, side) == global_formula(m, a, epsilon, side), 'Certificate check failed at original source line 107')
                    counts['global_weight_formulas'] += 1
            sharp_mean = ((1 + a) ** m - (1 - a) ** m) / ((1 + a) ** m + (1 - a) ** m)
            require(global_formula(m, a, Q(0), 1) == sharp_mean, 'Certificate check failed at original source line 111')
            aa, bb = ((1 + a) ** m, (1 - a) ** m)
            tv = abs(aa / (aa + bb) - bb / (aa + bb))
            require(tv == sharp_mean, 'Certificate check failed at original source line 115')
            counts['aligned_sharpness'] += 1
    for m, n in ((1, 5), (2, 4), (3, 3), (4, 2)):
        for side in (-1, 1):
            require(direct_full_comb(m, n, Q(1, 4), Q(1, 37), side) == global_formula(m, Q(1, 4) ** n, Q(1, 37), side), 'Certificate check failed at original source line 120')
            counts['full_comb_enumerations'] += 1
    for m in range(2, 9):
        actual, bad = local_integer_transfer(m)
        require(actual == effective_collar(m, Q(1, m), Q(1, 100 * m), 1, local=True), 'Certificate check failed at original source line 127')
        require(bad <= Q(2, 101), 'Certificate check failed at original source line 128')
        counts['local_transfer_checks'] += 1
    remote_rows = []
    for n in range(1, 7):
        m = 4 ** n
        mean, bad = local_integer_transfer(m)
        require(mean > Q(289, 404), 'Certificate check failed at original source line 135')
        require(bad <= Q(2, 101), 'Certificate check failed at original source line 136')
        opposite, _ = local_integer_transfer(m, -1)
        require(opposite == -mean, 'Certificate check failed at original source line 138')
        global_mean = global_formula(m, Q(1, m), Q(1, 2 ** (2 * m)), 1)
        remote_rows.append(dict(N=n, m=m, local_mismatch=float(2 * mean), local_bad_probability=float(bad), global_mismatch=float(2 * global_mean)))
        counts['local_transfer_checks'] += 2
    t = Q(1, 4)
    lateral_rows = []
    for m in range(1, 5):
        q = 1 - Q(1, 2 * m)
        for side in (-1, 1):
            require(brute_lateral(m, q, t, side) == side * t * q ** m, 'Certificate check failed at original source line 152')
            counts['lateral_enumerations'] += 1
    for m in (1, 2, 3, 4, 8, 16, 64, 256, 1024):
        q = 1 - Q(1, 2 * m)
        mismatch = 2 * t * q ** m
        require(mismatch >= Q(1, 4), 'Certificate check failed at original source line 157')
        lateral_rows.append(dict(m=m, mismatch=float(mismatch)))
        counts['lateral_rational_bounds'] += 1
    report = dict(status='PASS', arithmetic='exact rational / exact integer', checks=counts, remote_rows=remote_rows, lateral_rows=lateral_rows, scope='Finite discrete arbitrary-collar models; no SU(2) or posterior-probability calculation.')
    print(json.dumps(report, indent=2, sort_keys=True))
if __name__ == '__main__':
    main()
