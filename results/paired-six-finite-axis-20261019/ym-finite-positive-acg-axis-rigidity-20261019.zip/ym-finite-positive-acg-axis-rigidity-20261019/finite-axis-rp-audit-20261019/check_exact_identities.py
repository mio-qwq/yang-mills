#!/usr/bin/env python3
"""Independent exact algebra checks for the finite-axis obstruction."""
import argparse
import hashlib
import sympy as s

parser = argparse.ArgumentParser()
parser.add_argument('--corrupt', action='store_true')
args = parser.parse_args()
K, g, A, B = s.symbols('K g A B', positive=True)
# A and B stand for real alpha,beta where positivity is not needed in algebra.
a, beta, x, y, c, r, t = s.symbols('a beta x y c r t', real=True)
d, eta, ss, tau = s.symbols('d eta ss tau', positive=True)
u = s.symbols('u')
checks = []

def check(name, expression):
    reduced = s.factor(s.simplify(expression))
    if reduced != 0:
        raise RuntimeError(f'{name}: expected 0, got {reduced}')
    checks.append(name)
    print('PASS ' + name)

D = 1 + g*a*a
Disc = K + g*(K*a*a+beta*beta)
xx = -g*a*beta/D
yy2 = Disc/D**2
Q = D*u*u+2*g*a*beta*u+K+g*beta*beta
check('quadratic discriminant', D*(K+g*beta*beta)-(g*a*beta)**2-Disc)
check('upper-root real part', 2*D*xx+2*g*a*beta)
check('upper-root quadratic', D*(xx*xx-yy2)+2*g*a*beta*xx+K+g*beta*beta)
check('pole circle', xx*xx+yy2-K-(K*a*a-beta*beta)/(a*beta)*xx)
check('strict real-part derivative formula', s.diff(xx,g)+a*beta/D**2)
# Q'(u+) = 2 i D y, so the residue is -i/(d D y).
res = (-s.I if not args.corrupt else s.I)/(d*D*y)
check('upper residue', res*(2*s.I*D*y)-2/d)
check('lower residue conjugate', s.conjugate(res)-s.I/(d*D*y))
# Equal-circle rays: c=K/r-r; roots have opposite sign because product -K.
check('circle ratio', (K*a*a-beta*beta)/(a*beta)-(K/(beta/a)-beta/a))
check('ratio root product', (r*r+c*r-K).subs(r,-K/r)*r*r/K + (r*r+c*r-K))
check('t reparametrized real part', xx.subs({g:t/a**2,beta:r*a})+t*r/(1+t))
check('t reparametrized imaginary part', yy2.subs({g:t/a**2,beta:r*a})-(K+t*(K+r*r))/(1+t)**2)
# Write the Cayley transform algebraically; sqrt(K)>0.
k=s.symbols('k',positive=True)
w=(x+s.I*y-s.I*k)/(x+s.I*y+s.I*k)
den=x*x+(y+k)**2
wr=(x*x+y*y-k*k)/den
wi=-2*k*x/den
check('Cayley real and imaginary formula', w-(wr+s.I*wi))
check('Cayley radial circle image', (wr+c*wi/(2*k)).subs(y*y,k*k+c*x-x*x))
check('Cayley modulus one test', ((x*x+(y-k)**2)/den)-1+4*k*y/den)
wc=(x-s.I*y-s.I*k)/(x-s.I*y+s.I*k)
check('conjugate pole reciprocal radius', wc-1/s.conjugate(w))
# d=1+eta+(1-eta)s, gamma=4 eta tau/d^2.
deta=1+eta+(1-eta)*ss
gamma=4*eta*tau/deta**2
check('gamma derivative positive formula',s.diff(gamma,eta)-4*tau*(1+ss+(ss-1)*eta)/deta**3)
check('gamma zero endpoint',gamma.subs(eta,0))
check('gamma one endpoint',gamma.subs(eta,1)-tau)
# The homogeneous ratio inherited from the accepted physical-sheet formula.
p2, ap=s.symbols('p2 ap',real=True)
check('massless block reduction',2*deta/(deta*deta*p2+4*eta*tau*ap*ap)-(2/deta)/(p2+gamma*ap*ap))
# Scaling identity for original angular denominator.
kappa,b,q,v=s.symbols('kappa b q v',positive=True)
check('real momentum scaling',kappa*kappa/(b+kappa*kappa*(q+tau*v*v))-1/(b/kappa**2+q+tau*v*v))
print(f'PASS all {len(checks)} exact identities')
