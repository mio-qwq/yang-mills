# Independent audit: finite positive axial-mixture rigidity

19 October 2026. This is a local mathematical audit. No repository, PR, release, or other remote object was changed.

## Verdict

The proposed necessity is correct within the stated finite-axis scalar Gaussian covariance class. The simplest complete proof uses a Cayley transform for connectedness and a distributional Cauchy-transform argument for noncancellation. It does not require analytic parameter densities or generic separation of coincident arcs.

Let n be a unit reflection normal in R^4. Let

    rho(v) = c_0 + sum_(j=1)^N c_j integral rho_(lambda,a_j)(v) P_j(d lambda),
    rho_(lambda,a)(v) = sqrt(beta(lambda))
        /[1+(beta(lambda)-1)(a.v)^2]^2,
    beta(lambda)=((1-lambda)/(1+lambda))^2,

where c_0>=0, c_j>0, the a_j are unit axes, and each P_j is a probability Borel measure supported in a compact [ell_j,L_j] inside (0,1). Assume rho is invariant under reflection R_n. Normalize c_0+sum c_j=1; this is harmless because multiplying a covariance by a positive constant does not affect reflection positivity.

For fixed b,tau>0 consider

    F_b(p) = integral_(S^3) rho(v)/[b+|p|^2+tau(p.v)^2] d sigma(v).

If F_b is reflection positive at n, every active a_j must be either parallel or perpendicular to n. Equivalently, any oblique active axis forces failure for every b,tau>0. For every unit tangent m for which some (a_j.n)(a_j.m) is nonzero, all sufficiently large tangential frequencies k=kappa m have a negative compact-positive-time Hankel test. A finite tangential wave packet gives a real compact smooth spacetime witness.

This is a necessary condition, not a claim that every collection of normal/tangent axes is reflection positive at finite b.

## 1. Positive effective measures and exact massless continuation

The accepted axial decomposition from the preceding four-axis result supplies a finite positive effective measure

    mu_j(d eta) = (1+eta)P_j(d eta)/2
        + [1/(4sqrt(eta))]
          integral_[eta,L_j] (1-lambda)/sqrt(lambda) P_j(d lambda) d eta.

It has mass one, support in [0,L_j], and positive mass in (0,L_j]. In particular, below ell_j its density is exactly a positive constant times eta^(-1/2). The proof below only needs finiteness, positivity, and nonzero mass at eta>0.

At b=0, for real momentum p!=0, the accepted physical-sheet formula cancels exactly to

    T_(eta,a)(p) = (2/d)/(p^2+gamma(a.p)^2),
    d=1+eta+(1-eta)s, s=sqrt(1+tau), gamma=4eta tau/d^2.

Here d>0 and gamma strictly increases from 0 to tau as eta runs from 0 to 1:

    gamma'(eta)=4tau[1+s+(s-1)eta]/d^3 >0.

The formula agrees on real momenta with the actual homogeneous angular covariance. Its rational continuation therefore gives its analytic germ. No complex b->0 limit is used.

Fix nonzero tangent momentum k, K=|k|^2>0, alpha=a.n, beta=a.k. The elementary slice is

    T(u) = (2/d)/[(1+gamma alpha^2)u^2
                       +2gamma alpha beta u+K+gamma beta^2].

Its upper pole u_+=x+iy is

    x=-gamma alpha beta/(1+gamma alpha^2),
    y=sqrt[K+gamma(K alpha^2+beta^2)]/(1+gamma alpha^2)>0,

and its upper residue is

    R_+=-i/[d(1+gamma alpha^2)y].                         (1)

The lower pole and residue are their complex conjugates. All residues are uniformly bounded on each compact eta range [0,L_j].

## 2. Reflection symmetrization guarantees a right-hand obstruction

Replace every term in the given representation by the equally weighted pair with axes a_j and R_n a_j. This leaves rho unchanged by the assumed reflection invariance. It remains a finite positive representation.

For a tangent k, reflection replaces alpha by -alpha and preserves beta. Consequently, if alpha beta is nonzero, one member of the reflected pair has its upper pole strictly in the upper-right quadrant for every eta>0. This does not assume that the original finite list of axes was already closed under reflection.

Whenever an axis is oblique, choose unit tangent m with a.m nonzero. Conversely the argument works for every unit tangent m detecting at least one oblique axis in this way. No generic choice eliminating coincidences is necessary.

## 3. Exact connectedness of the finite-slit domain

For alpha beta!=0, the pole curve satisfies

    |u|^2=K+c Re u, c=(K alpha^2-beta^2)/(alpha beta).      (2)

Its real part is strictly monotone in gamma. Distinct c circles intersect only at the imaginary boundary points +/-i sqrt(K). Equal-circle upper-right arcs are nested initial portions of the same arc. One can verify this by setting r=beta/alpha: c=K/r-r, and the two roots for r have opposite signs, so the right-half-plane sign selects a unique r.

There is a simpler global topological proof that does not need a separate coincidence argument. Write q=sqrt(K), and apply the Cayley map

    w=(u-iq)/(u+iq).

It maps Re u>0 conformally onto Im w<0, because

    Re w=(|u|^2-K)/[x^2+(y+q)^2],
    Im w=-2qx/[x^2+(y+q)^2].

Equation (2) therefore maps to one ray from zero in the lower w-half-plane. An upper-right pole arc, with eta in [0,L_j], maps to a radial initial slit

    0<|w|<=R_j, 0<R_j<1.

Indeed eta=0 maps to zero, the pole curve is injective, and y>0 implies |w|<1. The conjugate lower-right arc maps to the same ray's terminal slit

    |w|>=1/R_j>1,

since w(conjugate u)=1/conjugate w(u). Imaginary-axis poles and the isotropic term remain outside the open right half-plane.

There are only finitely many slit rays and their endpoint radii stay uniformly away from one. Every point outside these slits can be joined radially to the unit semicircle without crossing a slit: on a slit ray an allowed radius lies between its maximal initial slit and minimal terminal slit. The unit semicircle in Im w<0 is unobstructed and connected. Therefore the right u-half-plane with all these pole arcs removed is path connected.

This verifies the essential two-sided analytic-continuation step. Merely observing that individual arcs have free endpoints would not by itself have replaced this global argument.

## 4. Noncancellation without regularity or endpoint assumptions

Partial fractions represent the massless slice F_0(u n+k) as the sum of a holomorphic isotropic term and finitely many Cauchy transforms of finite complex measures on the upper and lower pole arcs:

    sum_j c_j integral [R_(j,+)(eta)/(u-u_(j,+)(eta))
                 +conjugate R_(j,+)(eta)/(u-conjugate u_(j,+)(eta))]
                        mu_j(d eta).                    (3)

The expression is holomorphic off the arcs and is locally integrable in the full complex plane. The latter follows from local integrability of 1/|u-w| in two dimensions, uniformly for w in the compact pole sets, and finiteness of the measures. Atomic parameters cause no difficulty.

Suppose the real even slice had a Stieltjes representation S(u^2). The function S(u^2) is holomorphic on Re u>0. It agrees with (3) on the positive real axis, and hence everywhere in the connected slit domain of Section 3 by the identity theorem. A finite union of analytic arcs has planar area zero. Thus (3), interpreted as a locally integrable function, equals S(u^2) almost everywhere throughout the right half-plane and must have zero distributional d-bar there.

But d-bar[1/(u-w)]=pi delta_w. On the open upper-right quadrant, the d-bar of (3) is

    -i pi sum_j c_j (u_(j,+))_*
        {mu_j(d eta)/[d_j(1+gamma alpha_j^2)y_j]},        (4)

restricted to the axes with upper-right poles. This is -i times a positive measure. It is nonzero because Section 2 gives at least one such axis and its effective measure has positive mass at eta>0. All lower-pole measures lie below the real axis. Neither they nor the isotropic/imaginary-axis terms can cancel (4). Coincident upper arcs add positive measures, independent of parameterization.

The contradiction proves that the homogeneous slice is not Stieltjes. The proposed local analytic-tail jump argument is also valid, but is not needed for this proof.

## 5. From the homogeneous obstruction to legal finite-b tests

Take k=m unit, so K=1. Reflection invariance makes each real normal slice even. Positive normalized rho gives

    0<F_delta(u n+m)<=1/(delta+1+u^2).

Its inverse normal Fourier transform H_delta is bounded and continuous. Direct inversion of each angular quadratic, followed by angular averaging, gives

    |H_delta(T)|<=exp[-sqrt((delta+1)/(1+tau))|T|]
                        /(2sqrt(delta+1)).

The previously audited bounded-Hankel necessity argument applies unchanged: positivity on every smooth compact positive-time test implies all finite Hankel matrices are positive, whose symmetric shift semigroup is a strongly continuous positive contraction semigroup. Its spectral representation expresses H_delta(T) as a positive Laplace transform. The displayed decay forces its spectral support away from zero. Fourier inversion then gives a genuine Stieltjes representation, without a contact remainder. This audit rechecked the bounded-sequence contraction argument, continuity at time zero, spectral support inference, and Fourier integrability.

Therefore the non-Stieltjes homogeneous slice has a real h in C_c^infinity((0,infinity)) with Q_0(h)=-g<0. Only an existence witness is asserted.

The original angular formula, on real momenta, gives the uniform bound

    0<=F_0(u n+m)-F_delta(u n+m)<=delta/(1+u^2)^2,
    ||H_delta-H_0||_infinity<=delta/4,
    |Q_delta(h)-Q_0(h)|<=delta||h||_1^2/4.

Consequently Q_delta(h)<0 whenever delta<4g/||h||_1^2. The exact scaling

    kappa^2 F_b(kappa u n+kappa m)=F_(b/kappa^2)(u n+m)

and h_kappa(t)=kappa h(kappa t) produce

    Q_(b,kappa m)(h_kappa)=kappa^(-1)Q_(b/kappa^2)(h)<0

for every kappa^2>b||h||_1^2/(4g). This is an all-sufficiently-large finite-frequency statement; no numerical threshold has been calculated.

For fixed b>0 the fixed-k form is bounded and continuous in tangential k. A compactly supported smooth wave packet whose Fourier mass concentrates near kappa m gives a negative full spacetime form at a finite packet width. Reflection symmetry and realness let one select the real or imaginary part as a real witness. Its time support stays strictly above zero, so no Fourier delta, time-boundary distribution, or noncompact test is used. Origin-supported contact additions cannot repair this witness.

## 6. Coordinate/diagonal corollary and limits

If reflection positivity holds for every coordinate mirror, the necessity just proved forces each active axis to have at most one nonzero coordinate: otherwise a nonzero coordinate defines a mirror to which that axis is oblique. Thus every active axis must be a coordinate axis.

Any coordinate axis is oblique to a diagonal mirror involving that coordinate, for example n=(e_i+e_j)/sqrt(2), j!=i. Hence no nonzero finite positive axial mixture of this class, even with an arbitrary finite nonnegative isotropic background, can be reflection positive for all coordinate and diagonal mirrors simultaneously.

The finite-axis condition is indispensable to this proof. A continuum of axes may produce a pole support of positive area, so equality off that support does not imply equality almost everywhere, and its complement need not have the topology established above. No arbitrary continuous-axis or arbitrary smooth angular-density rigidity result follows. There is no interacting Yang-Mills or mass-gap claim.

## 7. Exact regression checks

The independent script check_exact_identities.py verifies 20 identities: discriminant and pole formulas, circle relation, monotonicity formula, both residues, coincidence ratios, effective parameterization, all Cayley formulas, gamma derivative and endpoints, the exact massless reduction, and the real scaling identity.

verify_regression_modes.py requires identical ordinary/optimized outputs and rejection of a deliberately sign-corrupted upper residue in both execution modes. The successful algebra-output SHA256 is

    fa6da00430d39be33065c0cefa0cfd8b98714339044fb5ab928b0219a0785ff5

These are algebra regression tests, not substitutes for the topology, distributional, or compact-test arguments above.

Sources directly checked: the root provisional DERIVATION.md; the preceding diagonal-rp-next-20261019/RESULT.md; and oblique-pole-audit-20261019/AUDIT.md. A source manifest records their exact byte lengths and hashes. The present audit derives and checks the finite-axis extension independently rather than treating its conclusion as an accepted dependency.

## 8. Reconciliation with the completed result and optional extension

The completed result was read in full and independently reconciled against this audit:

    /workspace/shared/finite-axis-rp-next-20261019/RESULT.md
    Bytes: 20787
    SHA256: b4a5e716063a2c532b14cb87b2c273332e17d014f496221276abbe98011c7b5d

Its precise theorem, all-sufficiently-large-frequency quantifier, coordinate/diagonal corollary, and stated limitations pass. No correction to these exact result bytes is required.

Section 8 of that result also legitimately extends the parameter measures from compact inner support to arbitrary probability Borel measures P_j on (0,1). Positive Fubini still constructs a probability effective measure on [0,1]. Although its density near eta=0 need not have the compact-case simple analytic form, the distributional proof requires no such form. The closed enclosing arcs can be extended to eta=1: d>=2, gamma<=tau, and y>=sqrt(K)/(1+tau)>0 uniformly. They still have Cayley endpoint radii strictly below one for each of the finitely many axes, so connectedness and the finite-measure argument remain unchanged. The original angular mixture is an L1 nonnegative normalized density by Tonelli. Real-momentum bounds and the compact-test transfer therefore also remain unchanged.

This extension is about parameter support, not axis support. It does not allow a continuum of axes. An actual atom at lambda=1 is excluded from the displayed density definition; an atom at lambda=0 is isotropic and may be absorbed into the background. These endpoint qualifications in the completed result are correct.
