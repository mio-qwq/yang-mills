#!/usr/bin/env python3
"""Require ordinary/optimized agreement and rejection of a corrupt residue."""
from pathlib import Path
import hashlib
import subprocess
import sys

script = Path(__file__).with_name('check_exact_identities.py')
outputs = []
for opt in ([], ['-O']):
    completed = subprocess.run([sys.executable, *opt, str(script)], capture_output=True, text=True)
    if completed.returncode:
        raise RuntimeError(completed.stdout + completed.stderr)
    outputs.append(completed.stdout)
    broken = subprocess.run([sys.executable, *opt, str(script), '--corrupt'], capture_output=True, text=True)
    if not broken.returncode or 'upper residue: expected 0' not in broken.stderr:
        raise RuntimeError('Corrupt residue was not rejected at the expected assertion-independent check.')
if outputs[0] != outputs[1]:
    raise RuntimeError('Normal and optimized outputs differ.')
print(outputs[0], end='')
print('PASS ordinary/optimized agreement and corrupt-residue rejection')
print('SHA256 ' + hashlib.sha256(outputs[0].encode()).hexdigest())
