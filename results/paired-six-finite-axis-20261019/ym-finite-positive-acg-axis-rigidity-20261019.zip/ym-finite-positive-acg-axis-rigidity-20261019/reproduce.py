#!/usr/bin/env python3
"""Offline source-integrity and exact-algebra replay; not a formal proof checker."""
import argparse
import hashlib
import importlib.util
import io
import json
import os
from pathlib import Path, PurePosixPath
import re
import stat
import subprocess
import sys
import tempfile
from zipfile import ZipFile

sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parent
PACKAGE = 'ym-finite-positive-acg-axis-rigidity-20261019'
DEP = 'ym-diagonal-rp-obstruction-20261019'
DEP_SHA = '6265bc42d9dc442cefe8b187e5759453c518be90d87383d7143ffbebe360128f'
PRIMARY = 'finite-axis-rp-next-20261019'
AUDIT = 'finite-axis-rp-audit-20261019'
PRIMARY_SHA = 'b4a5e716063a2c532b14cb87b2c273332e17d014f496221276abbe98011c7b5d'
AUDIT_SHA = '8364e86f1fc33d2e7dce0e6de7635aacdf2d591068eb0c92e4cb2f098fa25b2c'
ROOT_INPUT_SHA = '00de00ced05b82e5c9e300767edb124428cd3dd5a6931b205196e885deab48e4'
EXCLUDED_SHA = '3a921036dd6a15e02df86e7191a4d6c18ec4f7a1595a88bc8be7fc45ff9d7d6b'
CHECK_OUTPUTS = {
    PRIMARY: 'b0e209d4b27fff6ed1bf9c32fe999850fb35bba77d516a969cb89bac7e5297de',
    AUDIT: 'fa6da00430d39be33065c0cefa0cfd8b98714339044fb5ab928b0219a0785ff5',
}


def require(condition, message):
    if not condition:
        raise RuntimeError(message)


def sha(data):
    return hashlib.sha256(data).hexdigest()


def safe_name(name):
    p = PurePosixPath(name)
    require(bool(name) and not p.is_absolute() and '\\' not in name and name == p.as_posix()
            and '..' not in p.parts and bool(p.parts), 'Unsafe payload path: ' + name)
    return name


def parse_manifest(data):
    entries = {}
    for line in data.decode().splitlines():
        digest, name = line.split('  ', 1)
        safe_name(name)
        require(re.fullmatch('[0-9a-f]{64}', digest) is not None, 'Invalid digest: ' + name)
        require(name not in entries and name != 'SHA256SUMS', 'Duplicate or self-referential manifest: ' + name)
        entries[name] = digest
    require(bool(entries), 'Empty manifest')
    return entries


def verify_tree(root=None):
    root = ROOT if root is None else Path(root)
    entries = parse_manifest((root / 'SHA256SUMS').read_bytes())
    found = set()
    for p in root.rglob('*'):
        require(not p.is_symlink(), 'Symlink in payload: ' + str(p))
        if p.is_file():
            found.add(p.relative_to(root).as_posix())
    require(found == set(entries) | {'SHA256SUMS'}, 'Manifest file-set mismatch')
    for name, digest in entries.items():
        require(sha((root / name).read_bytes()) == digest, 'Integrity mismatch: ' + name)
    return len(entries)


def verify_zip(data, prefix, digest):
    require(sha(data) == digest, 'Dependency archive identity mismatch: ' + prefix)
    contents = {}
    with ZipFile(io.BytesIO(data)) as z:
        for entry in z.infolist():
            name = safe_name(entry.filename)
            require(not entry.is_dir() and name.startswith(prefix + '/'), 'Unexpected archive path: ' + name)
            require(name not in contents, 'Duplicate ZIP entry: ' + name)
            require(not stat.S_ISLNK(entry.external_attr >> 16), 'Symlink ZIP entry: ' + name)
            contents[name] = z.read(entry)
    manifest = parse_manifest(contents[prefix + '/SHA256SUMS'])
    require(set(contents) == {prefix + '/' + name for name in manifest} | {prefix + '/SHA256SUMS'},
            'Dependency manifest file-set mismatch: ' + prefix)
    for name, digest in manifest.items():
        require(sha(contents[prefix + '/' + name]) == digest, 'Dependency integrity mismatch: ' + name)
    return contents


def dependency_contents(root=None):
    root = ROOT if root is None else Path(root)
    return verify_zip((root / 'dependencies' / (DEP + '.zip')).read_bytes(), DEP, DEP_SHA)


def source_bytes(original_path, contents, root=None):
    root = ROOT if root is None else Path(root)
    p = Path(original_path)
    require(str(p).startswith('/workspace/shared/'), 'Unexpected original source path: ' + str(p))
    tail = p.relative_to('/workspace/shared').as_posix()
    if p.parent.name in (PRIMARY, AUDIT):
        return (root / tail).read_bytes()
    if p.parent.name == 'finite-axis-root-20261019':
        return (root / 'provenance-inputs' / tail).read_bytes()
    candidates = [DEP + '/' + tail, DEP + '/proof-dependencies/' + tail]
    available = [x for x in candidates if x in contents]
    require(len(available) == 1, 'Unresolved or ambiguous pinned source: ' + str(p))
    return contents[available[0]]


def verify_sources(contents, root=None):
    root = ROOT if root is None else Path(root)
    require(sha((root / PRIMARY / 'RESULT.md').read_bytes()) == PRIMARY_SHA, 'Accepted primary hash mismatch')
    require(sha((root / AUDIT / 'AUDIT.md').read_bytes()) == AUDIT_SHA, 'Accepted audit hash mismatch')
    require(sha((root / 'provenance-inputs/finite-axis-root-20261019/DERIVATION.md').read_bytes()) == ROOT_INPUT_SHA,
            'Provisional provenance hash mismatch')
    primary_sources = json.loads((root / PRIMARY / 'SOURCE_MANIFEST.json').read_text())['sources']
    audit_sources = json.loads((root / AUDIT / 'SOURCE_MANIFEST.json').read_text())
    pinned = []
    for entry in primary_sources + audit_sources:
        data = source_bytes(entry['path'], contents, root)
        require(len(data) == entry['bytes'] and sha(data) == entry['sha256'], 'Pinned source mismatch: ' + entry['path'])
        pinned.append({'original_path': entry['path'], 'sha256': sha(data)})
    artifact_manifest = json.loads((root / PRIMARY / 'ARTIFACT_MANIFEST.json').read_text())['artifacts']
    exclusions = []
    for entry in artifact_manifest:
        name = Path(entry['path']).name
        if name == 'NEXT_CANDIDATE.md':
            require(entry['sha256'] == EXCLUDED_SHA and not (root / PRIMARY / name).exists(), 'Excluded candidate mismatch')
            exclusions.append(name)
            continue
        data = (root / PRIMARY / name).read_bytes()
        require(len(data) == entry['bytes'] and sha(data) == entry['sha256'], 'Original artifact mismatch: ' + name)
    require(exclusions == ['NEXT_CANDIDATE.md'], 'Expected one excluded unaccepted candidate')
    receipt = json.loads((root / PRIMARY / 'FINAL_HASH_RECONCILIATION.json').read_text())
    require(receipt['status'] == 'passed' and receipt['audit_pins_exact_result_sha256'] is True,
            'Final reconciliation status mismatch')
    for key, expected in [('result', PRIMARY_SHA), ('audit', AUDIT_SHA)]:
        data = source_bytes(receipt[key]['path'], contents, root)
        require(receipt[key]['sha256'] == expected == sha(data) and receipt[key]['bytes'] == len(data),
                'Final reconciliation target mismatch: ' + key)
    require(receipt['regression']['exact_check_count'] == 20
            and receipt['regression']['exact_output_sha256'] == CHECK_OUTPUTS[PRIMARY]
            and receipt['regression']['corrupted_residue_rejected_in_both_modes'] is True
            and receipt['regression']['ordinary_optimized_identical'] is True,
            'Final reconciliation regression mismatch')
    provenance = json.loads((root / 'PROVENANCE.json').read_text())
    require(provenance['primary_sha256'] == PRIMARY_SHA and provenance['audit_sha256'] == AUDIT_SHA,
            'Provenance accepted hash mismatch')
    for item in provenance['originals']:
        safe_name(item['package_path'])
        data = (root / item['package_path']).read_bytes()
        require(sha(data) == item['sha256'] and len(data) == item['bytes'], 'Provenance original mismatch')
    require(provenance['dependency']['sha256'] == DEP_SHA, 'Provenance dependency pin mismatch')
    return {'primary_sha256': PRIMARY_SHA, 'audit_sha256': AUDIT_SHA, 'source_pins_verified': pinned,
            'excluded_unaccepted_candidate': 'NEXT_CANDIDATE.md', 'automated_proof_check': False}


def write_contents(contents, directory):
    for name, data in contents.items():
        safe_name(name)
        path = directory / name
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_bytes(data)


def run(command, env, cwd):
    return subprocess.run(command, capture_output=True, env=env, cwd=cwd)


def current_checks(env):
    reports = []
    for folder, flag, marker in [(PRIMARY, '--corrupt-residue', 'upper residue: nonzero exact residual'),
                                 (AUDIT, '--corrupt', 'upper residue: expected 0')]:
        script = ROOT / folder / 'check_exact_identities.py'
        runner = script.with_name('verify_regression_modes.py')
        outputs, regressions = [], []
        for options in ([], ['-O']):
            command = [sys.executable, *options, str(script)]
            result = run(command, env, ROOT)
            require(result.returncode == 0, 'Exact check failed: ' + folder + '\n' + result.stderr.decode())
            require(sha(result.stdout) == CHECK_OUTPUTS[folder], 'Exact output mismatch: ' + folder)
            if folder == PRIMARY:
                parsed = json.loads(result.stdout)
                require(parsed['status'] == 'passed' and parsed['count'] == 20, 'Exact check count mismatch')
            else:
                require(result.stdout.decode().count('\nPASS ') == 20 and result.stdout.decode().endswith('PASS all 20 exact identities\n'),
                        'Audit exact check count mismatch')
            outputs.append(result.stdout)
            bad = run(command + [flag], env, ROOT)
            require(bad.returncode != 0 and marker in bad.stderr.decode(), 'Corrupt residue wrongly accepted: ' + folder)
            regression = run([sys.executable, *options, str(runner)], env, ROOT)
            require(regression.returncode == 0, 'Original regression runner failed: ' + folder + '\n' + regression.stderr.decode())
            regressions.append(regression.stdout)
        require(outputs[0] == outputs[1], 'Normal/optimized exact outputs differ')
        require(regressions[0] == regressions[1], 'Normal/optimized original runner outputs differ')
        reports.append({'source': folder, 'exact_checks': 20, 'output_sha256': CHECK_OUTPUTS[folder],
                        'normal_and_optimized': 'PASS', 'corrupt_residue_both_modes': 'EXPECTED_REJECTION',
                        'original_runner_both_modes': 'PASS', 'runner_output_sha256': sha(regressions[0])})
    return reports


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--integrity-only', action='store_true')
    parser.add_argument('--with-dependency-replay', action='store_true')
    args = parser.parse_args()
    require(not (args.integrity_only and args.with_dependency_replay), 'Choose one replay mode')
    files = verify_tree()
    contents = dependency_contents()
    report = {'status': 'PASS', 'integrity_files': files, 'sources': verify_sources(contents)}
    env = dict(os.environ, PYTHONDONTWRITEBYTECODE='1', PYTHONHASHSEED='0')
    env.pop('PYTHONOPTIMIZE', None)
    with tempfile.TemporaryDirectory(prefix='finite-axis-dependency-') as directory:
        work = Path(directory)
        write_contents(contents, work)
        options = ['-O'] if sys.flags.optimize else []
        replay_flag = '--with-dependency-replay' if args.with_dependency_replay else '--integrity-only'
        dep_result = run([sys.executable, *options, str(work / DEP / 'reproduce.py'), replay_flag], env, work)
        require(dep_result.returncode == 0, 'Inherited dependency replay failed:\n' + dep_result.stderr.decode())
        dependency = json.loads(dep_result.stdout)
        require(dependency.get('status') == 'PASS', 'Inherited replay did not pass')
        report['dependency'] = {'archive_sha256': DEP_SHA, 'mode': replay_flag, 'result': dependency,
                                'output_sha256': sha(dep_result.stdout)}
    if not args.integrity_only:
        import sympy
        require(sympy.__version__ == '1.14.0', 'SymPy 1.14.0 required')
        report.update({'python': sys.version.split()[0], 'sympy': sympy.__version__,
                       'new_exact_check_total': 40, 'checks': current_checks(env)})
    report['claim_boundary'] = ('Finite positive prolate ACG axis mixtures; mirror RP forces every active axis '
                               'normal or tangent. Arbitrary positive Borel parameter measures on (0,1) '
                               'are covered; infinite axis sets, signed mixtures and oblate parameters are not. '
                               'Scalar Gaussian covariance only; no interacting Yang-Mills or mass-gap claim.')
    print(json.dumps(report, indent=2, sort_keys=True))


if __name__ == '__main__':
    main()
