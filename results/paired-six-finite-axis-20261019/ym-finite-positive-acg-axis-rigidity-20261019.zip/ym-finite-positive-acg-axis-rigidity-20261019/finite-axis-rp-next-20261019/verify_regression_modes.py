#!/usr/bin/env python3
"""Require ordinary/optimized agreement and fail-closed corrupted residue."""
import hashlib
import json
from pathlib import Path
import subprocess
import sys

HERE = Path(__file__).resolve().parent
SCRIPT = HERE / "check_exact_identities.py"


def run(optimized=False, corrupt=False):
    command = [sys.executable]
    if optimized:
        command.append("-O")
    command.append(str(SCRIPT))
    if corrupt:
        command.append("--corrupt-residue")
    return subprocess.run(command, capture_output=True, text=True, check=False)


ordinary, optimized = run(), run(True)
if ordinary.returncode != 0 or optimized.returncode != 0:
    raise RuntimeError(f"Clean check failed: {ordinary.stderr}\n{optimized.stderr}")
if ordinary.stdout != optimized.stdout:
    raise RuntimeError("Ordinary and optimized exact outputs differ")
for optimized_mode in (False, True):
    bad = run(optimized_mode, True)
    if bad.returncode == 0 or "upper residue: nonzero exact residual" not in bad.stderr:
        raise RuntimeError(f"Corrupted residue was not rejected, optimized={optimized_mode}")
print(json.dumps({
    "status":"passed",
    "ordinary_optimized_identical":True,
    "corrupted_residue_rejected_in_both_modes":True,
    "exact_output_sha256":hashlib.sha256(ordinary.stdout.encode()).hexdigest(),
    "exact_check_count":json.loads(ordinary.stdout)["count"],
}, indent=2, sort_keys=True))
