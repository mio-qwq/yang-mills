# Finite positive ACG-axis mixtures: an oblique axis forbids mirror RP

19 October 2026. Local scalar Gaussian covariance research only. No remote writes, merge, release, or publication.

## 1. Precise result and scope

Fix finitely many unoriented unit axes a_j in S^3. Let c_0>=0 and c_j>0, with c_0+sum_j c_j=1. For each active axis let P_j be a positive probability Borel measure supported on a compact interval [ell_j,L_j] strictly inside (0,1). Define

    beta(lambda)=((1-lambda)/(1+lambda))^2,
    rho_(lambda,a)(v)=sqrt(beta(lambda))
                       /[1+(beta(lambda)-1)(a.v)^2]^2,
    rho(v)=c_0+sum_j c_j integral rho_(lambda,a_j)(v) P_j(d lambda),
    F_b(p)=integral_(S^3) rho(v)/[b+|p|^2+tau(p.v)^2] d sigma(v).

Here d sigma is probability surface measure, b>0, and tau>0. Assume rho is invariant under reflection R_n through the hyperplane normal to a unit vector n.

**Theorem.** If F_b is reflection positive at n, every active axis a_j is either parallel to n or perpendicular to n. Equivalently, the presence of even one axis with

    0<|a_j.n|<1

forces failure of reflection positivity, for every b,tau>0 and every strictly positive weight on that axis, however large the nonnegative isotropic background is.

More precisely, choose any unit m perpendicular to n such that (a_j.n)(a_j.m) is nonzero for at least one active axis. For each fixed mixture, b, tau, and m, every sufficiently large finite tangential frequency kappa m has a strictly negative positive-time Hankel form. A finite tangential wave packet supplies an actual real C_c^infinity spacetime test supported strictly inside the positive half-space.

This is a necessity theorem, not a sufficiency theorem: finite-axis mixtures whose axes are all normal or tangent can still fail RP. It includes arbitrary smooth parameter weights and positive Borel weights, including atoms, at the displayed compact inner parameter support. It concerns prolate ACG densities, beta in (0,1). It does not assert a theorem for oblate ACG parameters, signed mixtures, infinitely many axes, or arbitrary angular densities.

The proof actually needs only finiteness of the axis set and finite positive effective parameter measures on [0,1] with nonzero mass at eta>0 on an oblique axis. Section 8 explains the legitimate extension to noncompact Borel parameter support in (0,1). The compact-supported version above is the main statement and directly matches the accepted prior results.

## 2. Symmetrization and the exact homogeneous reduction

No uniqueness assertion about the angular mixture representation is needed. Since rho(R_n v)=rho(v), replace each summand by half the original axis summand and half its reflected-axis summand:

    (1/2)rho_(lambda,a)(v)+(1/2)rho_(lambda,R_n a)(v).

The total density is unchanged. This produces another finite positive representation with the same parameter measures, now explicitly paired under reflection. Duplicated or coincident unoriented axes cause no difficulty. If a.n and a.m are nonzero, the two reflected axes have opposite signs of their product.

The accepted real-momentum axial identity is

    F_(lambda,a)=(1+lambda)T_(lambda,a)/2
          +(1-lambda)/2 integral_0^1 T_(lambda r^2,a) dr.

Consequently each P_j induces a finite positive probability measure M_j on [0,L_j] satisfying

    M_j(d eta)=(1+eta)P_j(d eta)/2
        +[1/(4sqrt(eta))]
            integral_[eta,L_j] (1-lambda)/sqrt(lambda) P_j(d lambda) d eta.

The second summand is interpreted on eta>0. Its eta=0 singularity is integrable. Positive Fubini proves that the total mass is one. In particular M_j gives positive mass to eta>0; indeed it has an explicit positive analytic density on (0,ell_j). The proof below needs positivity, not that additional analyticity.

At b=0 and real nonzero momentum p, put

    s=sqrt(1+tau),
    d(eta)=1+eta+(1-eta)s,
    gamma(eta)=4eta tau/d(eta)^2.

The accepted building block reduces exactly to

    T_(eta,a)(p)=(2/d(eta))
                 /[|p|^2+gamma(eta)(a.p)^2].                     (1)

This follows by cancelling the real positive square roots sqrt(|p|^2) and s sqrt(|p|^2) in the accepted formula. Equation (1), continued rationally, is therefore the continuation of the physical real-momentum germ; no alternative choice of complex square roots is being made.

For later use,

    gamma'(eta)=4tau[1+s+(s-1)eta]/d(eta)^3>0,
    gamma(0)=0, gamma(1)=tau, d(eta)>=2 for 0<=eta<=1.            (2)

Take a real tangential vector k, let K=|k|^2>0, and write p=u n+k. Set alpha=a.n and beta=a.k. Equation (1) becomes

    T_(eta,a)(u n+k)=(2/d)
       /[(1+gamma alpha^2)u^2+2gamma alpha beta u+K+gamma beta^2].  (3)

The total homogeneous slice f_0(u)=F_0(u n+k) is even in real u by reflection invariance. Its continuation will be studied in the u-plane, where the right half-plane maps conformally under u -> u^2 onto the Stieltjes slit domain C\(-infinity,0].

## 3. Exact pole circles, including every coincidence case

Write A=1+gamma alpha^2. The upper pole of (3) is w=x+i y, where

    x=-gamma alpha beta/A,
    y=sqrt(K A+gamma beta^2)/A>0.                               (4)

The lower pole is its complex conjugate. The poles remain distinct for every 0<=eta<=1. Uniformly on this compact parameter interval, y is bounded below by a strictly positive number; for example y>=sqrt(K)/(1+tau), since A<=1+tau and K A+gamma beta^2>=K.

If alpha beta=0, both poles lie on the imaginary axis. Such terms are holomorphic in the open right half-plane and create no off-axis obstruction.

If alpha beta is nonzero and eta>0, x has the fixed sign -sign(alpha beta), and its absolute value is strictly increasing with eta. Eliminating gamma yields the exact circle equation

    |w|^2=K+c x,
    y^2=K+c x-x^2,
    c=(K alpha^2-beta^2)/(alpha beta).                          (5)

Thus the upper-pole arc begins at i sqrt(K) and lies in the right half-plane precisely when alpha beta<0. It ends strictly inside that half-plane at eta=L_j (or at eta=1 when using the larger harmless enclosing arc). Lower right-half-plane arcs are their complex conjugates.

Two circles with different values c_1 and c_2 intersect only at x=0, y=+/-sqrt(K): subtracting their equations gives (c_1-c_2)x=0. In particular their upper arcs have no intersection in the open right half-plane.

For completeness, equal circles do not introduce a hidden crossing or sign exception. When alpha is nonzero write r=beta/alpha. Then

    c=K/r-r,
    c(r_1)=c(r_2) iff r_1=r_2 or r_1 r_2=-K.                  (6)

The second alternative has opposite signs of r and therefore places the two upper arcs in opposite half-planes. Within the right half-plane one must have r_1=r_2<0. The projected pairs (alpha,beta) are then proportional, their pole arcs lie on the same simple circle branch, and their parameter ranges trace nested initial segments of that branch. They may be combined geometrically into the longest segment. None of these statements requires a generic choice of k.

The upper-u residue of (3) is particularly simple:

    R_(eta,a)=2/[d A(w-conjugate(w))]
             =-i/[d A y].                                    (7)

Its coefficient of -i is strictly positive. Hence all contributions to any coincident upper-pole curve have the same complex phase. They cannot cancel under positive mixing, whether their parameterizations agree or differ. The lower residues have the opposite phase +i, but they have disjoint support in the lower half-plane. Circle nonintersection and (7) resolve both possible pole-curve crossings and residue cancellations exactly.

## 4. The continuation domain is connected

Consider the open right half-plane H={Re u>0}. For every axis with alpha beta<0, take the entire closed upper arc 0<eta<=L_j, whether or not its measure has support at every point, and its lower conjugate arc. An arc's initial point lies on the boundary of H and is not in H. Its other endpoint is strictly inside H. Collapse coincident nested arcs to the longest one.

There are finitely many arcs. The upper arcs are pairwise disjoint inside H by Section 3; the lower arcs are likewise disjoint; upper and lower arcs cannot meet because y stays strictly positive. Therefore their union Gamma is a finite collection of nonintersecting slits, each with one boundary endpoint and one free interior endpoint. H\Gamma is connected.

An exact conformal map makes the connectedness proof especially transparent. Put q=sqrt(K) and

    W(u)=(u-iq)/(u+iq).

It maps H bijectively onto the lower W-half-plane. For u=x+iy,

    Im W=-2qx/[x^2+(y+q)^2]<0,
    Re W=(x^2+y^2-K)/[x^2+(y+q)^2].

On the pole circle (5), these formulas give

    W(u)=x(c-2iq)/[x^2+(y+q)^2].

Hence every circle branch maps to one fixed ray. An upper-pole arc starts at W=0 and ends at a radius R<1, because y>0 is equivalent to |W|<1. Its image is exactly the initial radial segment 0<|W|<=R, by continuity and injectivity. The lower conjugate satisfies W(conjugate(u))=1/conjugate(W(u)), so its image is the same ray with |W|>=1/R>1. When several arcs have the same ray, retain the largest R. Consequently the lower unit semicircle is entirely unobstructed. Every point outside these radial slits can move radially to that semicircle without meeting a slit: on an occupied ray, the available radial interval is precisely R<|W|<1/R and contains 1; on an unoccupied ray there is no obstacle. Movement along the lower unit semicircle then joins all such points. This proves connectedness without a planar-topology assumption.

The same argument applies when an enclosing full arc contains parameter gaps or when a measure is atomic. Enlarging a pole support to its full enclosing arc merely gives a smaller, still connected comparison domain.

## 5. Positive Cauchy measures give a genuine off-axis obstruction

Use (7) to decompose each block into its upper and lower simple-pole terms. The residues are bounded on the compact parameter intervals, because d>=2, A>=1, and y has a uniform positive lower bound. Positive finite M_j therefore push forward to finite positive measures on the pole arcs.

In H the right upper poles contribute exactly a Cauchy transform of the form

    -i integral 1/(u-w) nu_+(d w),                              (8)

where nu_+ is a finite positive measure supported on the upper-right arcs. The lower right poles contribute

    +i integral 1/(u-w) nu_-(d w),                              (9)

with another finite positive measure, now in the lower-right arcs. All imaginary-axis poles, left-half-plane poles, and the isotropic term are holomorphic in H. The isotropic term is c_0[2/(1+s)]/(u^2+K).

If at least one active axis has alpha beta nonzero, reflection-pair symmetrization ensures that some positive-weight axis has alpha beta<0. Its effective measure has positive mass at eta>0. Equation (7) then shows nu_+ is nonzero. Coincident curves add positive measures; there is no cancellation assumption left to check.

Suppose, for contradiction, that the real homogeneous slice has a positive Stieltjes representation in z=u^2. Its Stieltjes function S(z) is holomorphic on C\(-infinity,0], so h(u)=S(u^2) is holomorphic on all of H. Both h and the rational-integral continuation f_0 are holomorphic on H\Gamma and agree on the positive real u-axis. By Section 4 and the identity theorem they agree throughout H\Gamma.

Every Cauchy transform of a finite compactly supported measure is locally integrable in the plane: integrate |u-w|^(-1) over a compact disk and use Fubini. A finite union of circle arcs has two-dimensional Lebesgue measure zero. Consequently f_0=h almost everywhere in H. Their distributional d-bar derivatives must coincide.

But the elementary fundamental-solution identity

    d-bar_u [1/(u-w)]=pi delta_w

gives, inside H,

    d-bar f_0=-i pi nu_+ + i pi nu_-.                          (10)

On the upper-right quadrant the second measure is absent and the first is a nonzero positive measure times -i. Thus (10) is not zero, contradicting holomorphicity of h.

This establishes that the actual homogeneous real-momentum germ is not Stieltjes. It is stronger than merely locating a formal pole: connectedness identifies the same germ on both sides of the cuts, and the locally integrable distribution argument proves that no analytic continuation can remove the positive cut measure. No smoothness, endpoint jump formula, singular limit of complex branches, generic tangential direction, or numerical test is used.

The finite-axis assumption matters in both parts of this argument: it gives the slit-complement geometry and zero planar area of the pole support. This proof cannot be applied to an arbitrary continuous distribution of axes or an arbitrary angular density by replacing the finite sum with an integral.

## 6. From the homogeneous obstruction to every positive b

Now choose k=m unit length, as in the theorem. For delta>=0 put

    G_delta(u^2)=F_delta(u n+m),
    H_delta(T)=(1/(2pi)) integral_R exp(iuT)G_delta(u^2) du.

The normalization of rho and its positivity give

    0<G_delta(u^2)<=1/(delta+1+u^2),
    0<=G_0(u^2)-G_delta(u^2)<=delta/(1+u^2)^2.                (11)

The functions G_delta are even in u. The kernels H_delta are real, even, bounded, continuous, and exponentially decaying. The same direct quadratic inversion as in the accepted diagonal result gives

    |H_delta(T)|<=exp[-sqrt((delta+1)/(1+tau))|T|]
                    /(2sqrt(delta+1)).                       (12)

The accepted bounded-Hankel necessity lemma now applies without change: if every compact smooth positive-time h has nonnegative form

    Q_delta(h)=integral_0^infinity integral_0^infinity
                 conjugate(h(t))H_delta(t+s)h(s) dt ds,

then G_delta is a Stieltjes function. In brief, positivity yields the Hilbert space of the Hankel kernel; boundedness makes its translation semigroup positive self-adjoint contractions; continuity yields a spectral representation H_delta(T)=integral exp(-ET) sigma(dE) with sigma positive; (12) bounds E away from zero; Fourier inversion yields G_delta(z)=integral 2E/(E^2+z) sigma(dE). Continuity and exponential decay exclude contact or constant remainders. The accepted source supplies the complete boundedness and null-vector argument.

Section 5 and the contrapositive give some real h in C_c^infinity((0,infinity)) and epsilon_h>0 such that

    Q_0(h)=-epsilon_h<0.                                     (13)

Equation (11), together with integral_R(1+u^2)^(-2)du=pi/2, implies

    ||H_delta-H_0||_infinity<=delta/4,
    |Q_delta(h)-Q_0(h)|<=delta ||h||_1^2/4.                  (14)

The exact real-momentum scaling relation is

    kappa^2 F_b(kappa u n+kappa m)=F_(b/kappa^2)(u n+m).       (15)

It follows that every

    kappa^2>b ||h||_1^2/(4epsilon_h)                          (16)

has a negative original fixed-kappa-m Hankel form, using h_kappa(t)=kappa h(kappa t). Indeed the original normal kernel satisfies

    H_(b,kappa m)(T)=kappa^(-1)H_(b/kappa^2)(kappa T),
    Q_(b,kappa m)(h_kappa)=kappa^(-1)Q_(b/kappa^2)(h)<0.

Only the real-momentum limit and explicit uniform estimate (14) are used. The proof never exchanges a b->0 limit with complex continuation. The existence of h and hence of a threshold is proved; explicit numerical witness coefficients or a computed threshold are not claimed.

For completeness, the same legal compact-spacetime witness argument as in the accepted diagonal theorem applies. The fixed-k form is continuous in real tangential k and uniformly bounded for b>0. With chi in C_c^infinity(R^3) nonzero, the packet

    g_R(x)=R^(-3/2)chi(x/R)exp(i kappa m.x)

has a normalized squared Fourier transform concentrating at kappa m. The reflected form of h_kappa(t)g_R(x) is the corresponding weighted average of the fixed-k forms, so it is negative for some finite R. At least one of its real and imaginary parts is negative. This produces a real C_c^infinity test strictly within {x.n>0}; no Fourier delta or boundary-supported test is used. Origin-supported contact terms cannot repair it because the supports of the test and its reflection are strictly separated.

## 7. Consequences and limits

1. To test a specific active oblique axis, choose m to be its normalized tangential projection. Then (a.n)(a.m) is nonzero, and the theorem applies. Conversely, if a is normal or tangent, this product vanishes for every tangent m. This proves the stated all-axes necessity exactly.

2. If the same finite positive ACG mixture is invariant and RP at every coordinate mirror, each active axis must be a coordinate axis. For an axis with two nonzero coordinates, either one of the corresponding coordinate mirrors would see an oblique axis.

3. If it is also invariant and RP at all diagonal mirrors with normals (e_i+/-e_j)/sqrt(2), no active anisotropic axis is possible: every coordinate axis is oblique at any diagonal mirror involving its coordinate. Thus, within this finite positive prolate-ACG class plus a constant background, simultaneous coordinate and diagonal mirror RP leaves only the constant density. This is a class-restricted rigidity statement, not rotational reconstruction for arbitrary densities.

4. The accepted four-axis counterexample is an immediate special case. The present proof removes equal weights, identical parameter densities, orthogonal axes, W4 symmetry, and generic-frequency restrictions. It retains finite axis support, positive weights, the prolate parameter range, and the relevant mirror invariance.

5. No sufficiency statement follows from the geometric normal-or-tangent condition. The accepted coordinate repair theorem supplies particular smooth mixtures for which all such fiber spectral densities become positive after adding a sufficiently large isotropic background; other normal/tangent mixtures fail. The new obstruction identifies the directions that no positive isotropic dilution can repair in this finite-axis class.

## 8. Optional parameter extension

The compact inner parameter support is not essential to this proof. Let each P_j instead be any positive probability Borel measure on (0,1). The accepted identity integrates by positive Fubini to a finite positive M_j of total mass one on [0,1]. The homogeneous building blocks and residues are uniformly bounded on the full closed interval 0<=eta<=1, and the full pole arcs at eta=1 still end inside the right half-plane with y>0. All arguments in Sections 2-6 therefore remain valid.

One may equivalently first derive the identities on compact subintervals and pass to P_j by dominated convergence in the original angular integral and in the homogeneous rational integrals. The angular mixture remains a normalized nonnegative L1 density by Tonelli, although it need not be smooth or bounded pointwise when the parameter distribution approaches 1. The extension does not include an actual atom at lambda=1, where the displayed ACG density itself is degenerate. An atom at lambda=0 can simply be included in the isotropic background.

## 9. Dependencies and verification

Mathematical inputs read:

- /workspace/shared/diagonal-rp-next-20261019/RESULT.md: physical homogeneous reduction, bounded-Hankel necessity lemma, real-momentum transfer, and compact spacetime witnesses.
- /workspace/shared/diagonal-rp-next-20261019/FINITE_B_LEMMA.md: branch-safety context; no finite-b pole continuation is required here.
- /workspace/shared/isotropic-rp-repair-20261019/RESULT.md: the accepted positive effective ACG parameter measure and the distinction between coordinate repair and oblique obstruction.

The new content is the arbitrary finite-axis pole-circle classification, all coincidence cases, same-phase positive residue measures, connected slit complement, and resulting necessity theorem. The independent audit supplied the conformal-map connectedness proof in Section 4. The proof is analytic; symbolic regressions only check the displayed algebra. The source manifest pins dependencies, and the regression report records the actual results.

Completed regression record: all 20 exact identities pass. Ordinary and optimized execution produce identical outputs. The deliberately sign-reversed upper residue is rejected in both modes, including when the harness itself runs under Python -O. The successful exact-output SHA256 is

    b0e209d4b27fff6ed1bf9c32fe999850fb35bba77d516a969cb89bac7e5297de

Reproduce from this directory with:

    python check_exact_identities.py
    python verify_regression_modes.py
    python -O verify_regression_modes.py

The independent mathematical audit is maintained separately at /workspace/shared/finite-axis-rp-audit-20261019/AUDIT.md. Its final-hash reconciliation, rather than an unverified statement here, records which exact result bytes were reviewed.
