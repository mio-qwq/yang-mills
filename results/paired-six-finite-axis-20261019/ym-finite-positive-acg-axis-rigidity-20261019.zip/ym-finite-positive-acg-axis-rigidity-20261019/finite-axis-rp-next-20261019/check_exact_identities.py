#!/usr/bin/env python3
"""Exact algebra checks; no Python assert statements and no numeric evidence claims."""
import argparse
import json
import sympy as S


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--corrupt-residue", action="store_true")
    args = parser.parse_args()
    checks = []

    def check(name, expression):
        reduced = S.simplify(S.factor(S.together(expression)))
        if reduced != 0:
            raise RuntimeError(f"{name}: nonzero exact residual {reduced}")
        checks.append(name)

    eta, tau, ss = S.symbols("eta tau ss", positive=True)
    d = 1 + eta + (1-eta)*ss
    gg = 4*eta*tau/d**2
    check("gamma derivative", S.diff(gg, eta)-4*tau*(1+ss+(ss-1)*eta)/d**3)
    check("gamma zero endpoint", gg.subs(eta, 0))
    check("gamma one endpoint", gg.subs(eta, 1)-tau)
    check("d lower bound identity", d-2-(ss-1)*(1-eta))

    gamma, K, alpha, beta, u = S.symbols("gamma K alpha beta u", real=True)
    A = 1+gamma*alpha**2
    x = -gamma*alpha*beta/A
    y2 = (K*A+gamma*beta**2)/A**2
    C = (K*alpha**2-beta**2)/(alpha*beta)
    check("pole real equation", A*(x*x-y2)+2*gamma*alpha*beta*x+K+gamma*beta**2)
    check("pole imaginary equation", 2*A*x+2*gamma*alpha*beta)
    check("pole norm", x*x+y2-(K+gamma*beta**2)/A)
    check("pole circle", x*x+y2-K-C*x)
    check("pole horizontal derivative", S.diff(x,gamma)+alpha*beta/A**2)
    check("quadratic factorization", A*((u-x)**2+y2)-(u*u+K+gamma*(alpha*u+beta)**2))

    r1, r2 = S.symbols("r1 r2", nonzero=True, real=True)
    check("circle coincidence factorization", (K/r1-r1)-(K/r2-r2)+(r1-r2)*(r1*r2+K)/(r1*r2))
    check("opposite-side reciprocal exception", (K/r1-r1)-(K/(-K/r1)+K/r1))

    dd, AA, yy, xx = S.symbols("dd AA yy xx", positive=True)
    residue = -S.I/(dd*AA*yy)
    if args.corrupt_residue:
        residue = -residue
    check("upper residue", 2/(dd*AA*(2*S.I*yy))-residue)
    check("partial fractions", 2/(dd*AA*((u-xx)**2+yy**2))-(-S.I/(dd*AA*yy)/(u-xx-S.I*yy)+S.I/(dd*AA*yy)/(u-xx+S.I*yy)))

    X, Y, q, c = S.symbols("X Y q c", real=True)
    U = X+S.I*Y
    W = (U-S.I*q)/(U+S.I*q)
    D = X**2+(Y+q)**2
    check("Mobius real and imaginary parts", W-((X**2+Y**2-q**2)-2*S.I*q*X)/D)
    check("Mobius circle ray residual", (W-X*(c-2*S.I*q)/D)-(X**2+Y**2-q**2-c*X)/D)
    WbarU = (X-S.I*Y-S.I*q)/(X-S.I*Y+S.I*q)
    check("Mobius conjugate inversion", WbarU-1/S.conjugate(W))
    check("Mobius inside unit disk", W*S.conjugate(W)-1+4*Y*q/D)

    b, kappa, h = S.symbols("b kappa h", positive=True)
    check("real-momentum scaling", kappa**2/(b+kappa**2*(u*u+K+tau*h*h))-1/(b/kappa**2+u*u+K+tau*h*h))
    lam = S.symbols("lam", positive=True)
    check("effective measure unit mass", (1+lam)/2+(1-lam)/(4*S.sqrt(lam))*2*S.sqrt(lam)-1)
    print(json.dumps({"status":"passed", "count":len(checks), "checks":checks}, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
