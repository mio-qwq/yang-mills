# Finite positive prolate ACG-axis rigidity

Accepted local scalar Gaussian covariance research, 19 October 2026.
No repository changes, merge, release, or external publication are part of this checkpoint.

## Accepted result

For a reflection-invariant finite positive mixture of prolate ACG angular densities,
with a nonnegative isotropic background, reflection positivity at a mirror forces
every active axis to be normal or tangent to that mirror. One oblique axis therefore
forces failure for every b,tau>0, with a real compact smooth positive-time spacetime
witness at every sufficiently large finite tangential frequency. This is a necessity
theorem: normal/tangent axes alone do not give sufficiency.

The compact inner parameter-support theorem is the main statement. The independently
reconciled extension permits arbitrary probability Borel parameter measures on
(0,1); it does not permit an infinite axis set. No explicit witness threshold is
computed. This is not an interacting Yang-Mills or mass-gap result.

Read:
- finite-axis-rp-next-20261019/RESULT.md
- finite-axis-rp-audit-20261019/AUDIT.md
- finite-axis-rp-next-20261019/FINAL_HASH_RECONCILIATION.json

The exact final primary SHA256 is
b4a5e716063a2c532b14cb87b2c273332e17d014f496221276abbe98011c7b5d.
The exact independent audit SHA256 is
8364e86f1fc33d2e7dce0e6de7635aacdf2d591068eb0c92e4cb2f098fa25b2c.

## Source preservation and dependency closure

All included original source bytes are unchanged. The preceding accepted diagonal-RP
archive is included once under dependencies; its nested archives supply the full
pinned proof and test chain. No dependency extraction is stored alongside it.
PROVENANCE.json maps original absolute paths to portable package paths. Original
absolute source paths are records only; replay never reads from /workspace/shared.

The provisional DERIVATION.md is included only because the audit pins and discusses
it. It is provenance, not an independent accepted theorem. NEXT_CANDIDATE.md (oblate)
is excluded completely. Its historical entry remains in the unchanged original
ARTIFACT_MANIFEST.json and is explicitly recorded as excluded in PROVENANCE.json.

## Offline replay

Requirements: Python 3.12 and preinstalled SymPy 1.14.0. Python/SymPy distributions
are not vendored; all research inputs are. Replay requires no network.

From this directory:

    PYTHONDONTWRITEBYTECODE=1 python reproduce.py --integrity-only
    PYTHONDONTWRITEBYTECODE=1 python reproduce.py --with-dependency-replay
    PYTHONDONTWRITEBYTECODE=1 python -O reproduce.py --with-dependency-replay
    PYTHONDONTWRITEBYTECODE=1 python test_package.py
    PYTHONDONTWRITEBYTECODE=1 python -O test_package.py

The two new independent algebra suites each verify 20 identities. Each runs in both
ordinary and optimized modes, as do its original regression runners; deliberately
sign-corrupted residues must fail in both modes. Full dependency replay also runs
the inherited checks. These tests are exact algebra and packaging regressions, not
machine verification of the analytic/topological proof in the reports.

The package tests reject changed/missing/extra/symlink payloads, changed accepted
hash pins, a changed inherited archive, corrupted source/receipt pins, unsafe ZIP
paths, duplicate ZIP entries, and symlink ZIP entries. Manifest refresh does not
bypass the separate accepted source pins.

## Deterministic build

    python build_archive.py /path/to/output.zip

The archive has sorted member names, fixed 1980-01-01 timestamps, regular-file 0644
permissions, and DEFLATE level 9. The build verifies the full file manifest first.
Two same-environment builds must be byte-identical. External checkpoint receipts
record clean temporary extraction, full normal/optimized replay, corruption tests,
and repeated-build identity without introducing a recursive archive-hash dependency.
