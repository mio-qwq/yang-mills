#!/usr/bin/env python3
"""Offline integrity and exact algebra replay. Analytic arguments remain proofs in prose."""
import argparse
import hashlib
import io
import json
import os
from pathlib import Path, PurePosixPath
import re
import stat
import subprocess
import sys
import tempfile
from zipfile import ZipFile

ROOT = Path(__file__).resolve().parent
COORD_ROOT = 'ym-coordinate-rp-repair-20261019'
COORD_SHA = '22c52749cb61123aedadc1313d316b8c5eebb36232c1bf71c7e8130036c61b0d'
W4_ROOT = 'ym-w4-parameter-mixtures-20261019'
W4_SHA = 'f255905f22eb287a30d8309f01af932b7798a17e14b52df0c40c16a8652d84bd'
AXIAL_ROOT = 'ym-positive-infinite-angular-20261019'
AXIAL_SHA = '476a47359f8ff24bef53709d7e0cefa7dfa5e27001c9e4f5326f3d2e1ffe303b'
FINAL_PROOF_SHA = '34a58bd052c703d84c7939ce08c36f86e0cfc6f8349e5eb85ee62175cb357f2a'
HISTORICAL_PROOF_SHA = '19e713f5a28d2ef58d931f83ea5778d66dd34f6e3e56cca3449320132f4090bb'


def require(condition, message):
    if not condition:
        raise RuntimeError(message)


def sha(data):
    return hashlib.sha256(data).hexdigest()


def safe_name(name):
    path = PurePosixPath(name)
    require(bool(name) and not path.is_absolute() and '\\' not in name
            and name == path.as_posix() and '..' not in path.parts,
            'Unsafe payload path: ' + name)
    return name


def parse_manifest(data):
    entries = {}
    for line in data.decode('utf-8').splitlines():
        digest, name = line.split('  ', 1)
        safe_name(name)
        require(re.fullmatch('[0-9a-f]{64}', digest) is not None,
                'Invalid digest: ' + name)
        require(name not in entries and name != 'SHA256SUMS',
                'Duplicate or self-referential manifest entry: ' + name)
        entries[name] = digest
    require(bool(entries), 'Empty manifest')
    return entries


def verify_tree(root=ROOT):
    entries = parse_manifest((root / 'SHA256SUMS').read_bytes())
    found = set()
    for path in root.rglob('*'):
        require(not path.is_symlink(), 'Symlink in payload: ' + str(path))
        if path.is_file():
            found.add(path.relative_to(root).as_posix())
    require(found == set(entries) | {'SHA256SUMS'}, 'Manifest file-set mismatch')
    for name, digest in entries.items():
        path = root / name
        require(path.resolve().is_relative_to(root.resolve()), 'Path escaped payload: ' + name)
        require(sha(path.read_bytes()) == digest, 'Integrity mismatch: ' + name)
    return len(entries)


def verify_zip(data, prefix, digest):
    require(sha(data) == digest, 'Dependency archive identity mismatch: ' + prefix)
    contents = {}
    with ZipFile(io.BytesIO(data)) as archive:
        for entry in archive.infolist():
            name = safe_name(entry.filename)
            require(not entry.is_dir() and name.startswith(prefix + '/'),
                    'Unexpected dependency archive path: ' + name)
            require(name not in contents, 'Duplicate dependency ZIP entry: ' + name)
            require(not stat.S_ISLNK(entry.external_attr >> 16), 'Symlink in dependency ZIP: ' + name)
            contents[name] = archive.read(entry)
    manifest = parse_manifest(contents[prefix + '/SHA256SUMS'])
    expected = {prefix + '/' + name for name in manifest} | {prefix + '/SHA256SUMS'}
    require(set(contents) == expected, 'Dependency manifest file-set mismatch: ' + prefix)
    for name, digest in manifest.items():
        require(sha(contents[prefix + '/' + name]) == digest,
                'Dependency payload integrity mismatch: ' + prefix + '/' + name)
    return contents, len(manifest)


def verify_sources():
    primary = ROOT / 'diagonal-rp-next-20261019'
    audit = ROOT / 'oblique-pole-audit-20261019'
    for item in json.loads((primary / 'ARTIFACT_MANIFEST.json').read_text())['files']:
        data = (primary / item['file']).read_bytes()
        require(len(data) == item['bytes'] and sha(data) == item['sha256'],
                'Primary original artifact mismatch: ' + item['file'])
    audit_hashes = json.loads((audit / 'SHA256.json').read_text())
    for name, digest in audit_hashes.items():
        require(sha((audit / name).read_bytes()) == digest, 'Audit original artifact mismatch: ' + name)
    source_manifest = json.loads((primary / 'SOURCE_MANIFEST.json').read_text())
    dependencies = []
    for item in source_manifest['dependencies']:
        source = Path(item['path'])
        local = 'proof-dependencies/' + source.parent.name + '/' + source.name
        data = (ROOT / local).read_bytes()
        require(len(data) == item['bytes'] and sha(data) == item['sha256'],
                'Pinned proof dependency mismatch: ' + local)
        dependencies.append({'path': local, 'bytes': len(data), 'sha256': sha(data)})
    review = source_manifest['independent_reviews'][0]
    require(sha((audit / 'AUDIT.md').read_bytes()) == review['sha256'], 'Accepted independent audit mismatch')
    observed = json.loads((audit / 'SOURCE_MANIFEST.json').read_text())['sources']
    for item in observed:
        source = Path(item['path'])
        if source.parent.name == 'diagonal-rp-next-20261019':
            require(item['sha256'] == HISTORICAL_PROOF_SHA, 'Historical audit pin changed')
        else:
            local = ROOT / 'proof-dependencies' / source.parent.name / source.name
            require(sha(local.read_bytes()) == item['sha256'], 'Historical dependency mismatch: ' + str(source))
    require(sha((primary / 'RESULT.md').read_bytes()) == FINAL_PROOF_SHA, 'Final primary proof mismatch')
    receipt = json.loads((ROOT / 'audit-resolution/FINAL_HASH_RECEIPT.json').read_text())
    final = (primary / 'RESULT.md').read_bytes()
    require(receipt.get('final_primary_sha256') == FINAL_PROOF_SHA and receipt.get('status') == 'PASS',
            'Missing final-version audit resolution')
    require(len(final) == receipt['final_primary_bytes'], 'Final audit byte count mismatch')
    cut = receipt['previous_primary_bytes']
    require(sha(final[:cut]) == HISTORICAL_PROOF_SHA == receipt['previous_primary_sha256'],
            'Historical audited prefix mismatch')
    suffix = (ROOT / 'audit-resolution/APPENDED_SUFFIX.txt').read_bytes()
    require(final[cut:] == suffix and len(suffix) == receipt['appended_bytes']
            and sha(suffix) == receipt['appended_sha256'], 'Append-only audit bridge mismatch')
    require(sha((audit / 'AUDIT.md').read_bytes()) == receipt['independent_audit_sha256'],
            'Final audit receipt target mismatch')
    require(sha((audit / 'SOURCE_MANIFEST.json').read_bytes()) == receipt['original_source_manifest_sha256'],
            'Original audit manifest changed')
    return {'exact_proof_dependencies': dependencies,
            'historical_audit_primary_sha256': HISTORICAL_PROOF_SHA,
            'final_primary_sha256': FINAL_PROOF_SHA,
            'resolution': 'audit-resolution/FINAL_HASH_RECEIPT.json; original historical manifest preserved',
            'automated_proof_check': False}


def dependencies():
    coord, coord_count = verify_zip((ROOT / 'dependencies' / (COORD_ROOT + '.zip')).read_bytes(), COORD_ROOT, COORD_SHA)
    w4, w4_count = verify_zip(coord[COORD_ROOT + '/dependencies/' + W4_ROOT + '.zip'], W4_ROOT, W4_SHA)
    axial, axial_count = verify_zip(w4[W4_ROOT + '/dependencies/' + AXIAL_ROOT + '.zip'], AXIAL_ROOT, AXIAL_SHA)
    return coord, {'coordinate_archive_sha256': COORD_SHA, 'coordinate_manifest_files': coord_count,
                   'w4_archive_sha256': W4_SHA, 'w4_manifest_files': w4_count,
                   'axial_archive_sha256': AXIAL_SHA, 'axial_manifest_files': axial_count,
                   'accepted_axial_proofs': [
                       {'path': name, 'sha256': sha(axial[name])}
                       for name in (AXIAL_ROOT + '/RESULT.md', AXIAL_ROOT + '/AUDIT_POSITIVE.md')]}


def run(command, env, cwd=ROOT):
    return subprocess.run(command, capture_output=True, env=env, cwd=cwd)


def current_checks(env):
    tasks = [
        ('diagonal-rp-next-20261019', 22,
         '84df0872ca136d62bae38dfbec64999405a239bb010ddf50dcf8fb4d6f976e15', 'FAIL: upper residue'),
        ('oblique-pole-audit-20261019', 22,
         '0cd16efdb781932cfaa402025c6259fecad0279dcbd5242a6094ef3d8f08e46d', 'upper residue identity'),
    ]
    results = []
    for directory, count, expected, marker in tasks:
        good_outputs, runner_outputs = [], []
        script = ROOT / directory / 'check_exact_identities.py'
        runner = script.with_name('verify_regression_modes.py')
        for flags in ([], ['-O']):
            command = [sys.executable, *flags, str(script)]
            good = run(command, env)
            require(good.returncode == 0, 'Positive check failed: ' + directory + '\n' + good.stderr.decode())
            result = json.loads(good.stdout)
            require(result.get('status') == 'PASS' and result.get('count') == count,
                    'Unexpected exact check report: ' + directory)
            require(sha(good.stdout) == expected, 'Accepted output mismatch: ' + directory)
            good_outputs.append(good.stdout)
            bad = run(command + ['--negative-control'], env)
            require(bad.returncode != 0 and marker in (bad.stdout + bad.stderr).decode(),
                    'Negative control did not reject expected corruption: ' + directory)
            verification = run([sys.executable, *flags, str(runner)], env)
            require(verification.returncode == 0,
                    'Original regression runner failed: ' + directory + '\n' + verification.stderr.decode())
            runner_outputs.append(verification.stdout)
        require(good_outputs[0] == good_outputs[1], 'Checker mode mismatch: ' + directory)
        require(runner_outputs[0] == runner_outputs[1], 'Regression runner mode mismatch: ' + directory)
        results.append({'source': directory, 'exact_checks': count, 'positive_output_sha256': expected,
                        'positive_normal_and_optimized': 'PASS',
                        'negative_controls': 'EXPECTED_REJECTION_BOTH_MODES',
                        'original_runners_normal_and_optimized': 'PASS',
                        'runner_output_sha256': sha(runner_outputs[0])})
    return results


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--integrity-only', action='store_true')
    parser.add_argument('--with-dependency-replay', action='store_true')
    args = parser.parse_args()
    require(not (args.integrity_only and args.with_dependency_replay), 'Choose integrity-only or dependency replay')
    file_count = verify_tree()
    source_report = verify_sources()
    coord, dependency_report = dependencies()
    report = {'status': 'PASS', 'integrity_files': file_count, 'sources': source_report,
              'dependency_integrity': dependency_report}
    if args.integrity_only:
        print(json.dumps(report, indent=2, sort_keys=True))
        return
    import sympy
    require(sympy.__version__ == '1.14.0', 'SymPy 1.14.0 required; found ' + sympy.__version__)
    env = dict(os.environ, PYTHONDONTWRITEBYTECODE='1', PYTHONHASHSEED='0')
    env.pop('PYTHONOPTIMIZE', None)
    report.update({'python': sys.version.split()[0], 'sympy': sympy.__version__, 'current_exact_check_total': 44,
                   'checks': current_checks(env), 'dependency_full_replay': 'NOT RUN; use --with-dependency-replay'})
    if args.with_dependency_replay:
        with tempfile.TemporaryDirectory(prefix='ym-diagonal-dependency-') as directory:
            work = Path(directory)
            for name, data in coord.items():
                target = work / name
                target.parent.mkdir(parents=True, exist_ok=True)
                target.write_bytes(data)
            flags = ['-O'] if sys.flags.optimize else []
            result = run([sys.executable, *flags, str(work / COORD_ROOT / 'reproduce.py'), '--with-dependency-replay'], env, work)
            require(result.returncode == 0, 'Dependency replay failed:\n' + result.stderr.decode())
            details = json.loads(result.stdout)
            require(details.get('status') == 'PASS', 'Dependency did not report PASS')
            report['dependency_full_replay'] = details
            report['dependency_replay_output_sha256'] = sha(result.stdout)
    report['claim_boundary'] = ('This four-axis scalar Gaussian covariance family fails diagonal RP for every '
                               '0 < epsilon <= 1 and b,tau > 0, at all sufficiently large tangential frequencies. '
                               'A real compact smooth witness exists but is not explicitly computed. '
                               'The coordinate-RP repair remains valid. No general W4 rigidity or Yang-Mills conclusion.')
    print(json.dumps(report, indent=2, sort_keys=True))


if __name__ == '__main__':
    main()
