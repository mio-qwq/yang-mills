# Diagonal reflection positivity fails for every positive dilution in this family

Local reproducible source checkpoint, 19 October 2026. No remote operation was performed.

## Result and limits

For the same four-axis angular-central-Gaussian mixture, every positive mixture weight 0 < epsilon <= 1 fails diagonal reflection positivity for every b > 0 and tau > 0. The original parameter probability density is supported in [ell,L] with 0 < ell < L < 1. The normal is (e1+e2)/sqrt(2), with W4 symmetry giving all diagonal mirrors. Every sufficiently large finite tangential frequency in direction (e1-e2)/sqrt(2) has a negative Hankel form.

A genuine real smooth compactly supported positive-half-space countertest exists. Its coefficients, support, and numerical frequency threshold have not been computed. This is an analytic existence proof, not an explicit numerical witness.

The previously accepted coordinate-RP repair rho = 1199/1200 + rho_taper/1200 remains valid at all coordinate mirrors. The new theorem excludes that same family as a simultaneous coordinate-and-diagonal construction. It does not establish rigidity for arbitrary W4-invariant densities, rotational reconstruction, interacting Yang-Mills theory, or a mass gap. The supplementary finite-b pole lemma is not required for the main theorem.

## Reading order and provenance

1. diagonal-rp-next-20261019/RESULT.md: precise theorem and analytic proof.
2. oblique-pole-audit-20261019/AUDIT.md: independent audit.
3. audit-resolution/FINAL_HASH_RECEIPT.md: additive final-version review. The original audit manifest pins the 17,353-byte earlier proof; the final file contains that exact prefix and only a 938-byte supplement/audit notice appended. Independent review confirms those additions. Both original manifests are retained unchanged.
4. proof-dependencies/: all five mathematical dependencies exactly as pinned in the primary source manifest. They are directly readable offline.
5. dependencies/ym-coordinate-rp-repair-20261019.zip: unchanged coordinate-RP checkpoint, including the prior W4 and axial source archives with all their retained proofs and replay scripts. Some source paths inside historical documents are absolute provenance references; current replay resolves the bundled bytes, never those workspace paths.
6. PROVENANCE.json: full selected input hashes, dependency links, and exact limits.

The original audit-resolution/verify_receipt.py is preserved as historical source and uses absolute source paths. Use reproduce.py for a portable hash-bridge verification. All original proof, audit, check, and small result files are byte-for-byte copies. No original was changed.

## Offline reproduction

Use Python 3.10+ and SymPy 1.14.0, already installed in an environment of your choice. No network connection or original workspace location is needed for replay. Python/SymPy runtimes are not bundled.

    python reproduce.py
    python -O reproduce.py
    python reproduce.py --with-dependency-replay
    python -O reproduce.py --with-dependency-replay
    python -O reproduce.py --integrity-only
    python test_package.py
    python -O test_package.py

The default replay verifies every payload hash, the five exact proof dependencies, the old-to-final audit hash bridge, and all three nested source-archive manifests. It runs each of the 22 primary and 22 independent exact algebra checks in ordinary and optimized Python, requires the preserved output hashes, and requires the deliberately wrong residue to fail in both modes. Both original regression runners are also run in both modes. --with-dependency-replay reruns the complete coordinate, W4-mixture, and axial replay chain. --integrity-only does not import SymPy. Test-package checks deliberate payload, pin, audit-bridge, and ZIP-path corruptions using temporary copies.

These checks support the algebra and audit provenance. They do not formally verify the analytic proof or compute a compact countertest. A count of identities is not a count of independent theorems.

Replay creates only temporary working directories; subprocess bytecode writes are disabled. A clean payload is required: unmanifested files or symlinks are rejected. SHA256SUMS covers every payload file except itself. Authenticate that manifest by first verifying the externally recorded archive SHA256.

## Deterministic rebuild

From a clean verified extraction:

    python build_archive.py ../ym-diagonal-rp-obstruction-20261019-rebuilt.zip

The builder refuses existing targets and targets inside the payload. Entries are sorted, use fixed 1980-01-01 timestamps, regular-file permissions 0644, and DEFLATE level 9. Byte-identical rebuilding requires the same zlib implementation. No executable binaries, caches, or large regenerable ledgers are included. The ZIP dependencies contain source material, not binary runtimes.
