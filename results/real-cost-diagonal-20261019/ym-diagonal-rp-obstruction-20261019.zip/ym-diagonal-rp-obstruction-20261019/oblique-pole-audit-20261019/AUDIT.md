# Independent audit: diagonal obstruction survives every nonzero isotropic dilution

19 October 2026. Local scalar Gaussian covariance research only. No repository, PR, release, or other remote object was changed.

## Verdict and exact scope

The diagonal obstruction passes independent audit. Fix b>0 and tau>0. Let p be a nonnegative probability density supported in [ell,L] with 0<ell<L<1. This includes every smooth or globally Lipschitz density in the accepted coordinate-repair theorem; no regularity beyond integrability is needed for this obstruction. Form its four-axis angular-central-Gaussian mixture rho_mix, and let

    rho_epsilon = (1-epsilon) + epsilon rho_mix,  0<epsilon<=1.

Then rho_epsilon fails reflection positivity at n=(e1+e2)/sqrt(2). In fact its normal-frequency slice fails at every sufficiently large tangential frequency k=kappa(e1-e2)/sqrt(2). The threshold need not be computed for the conclusion.

The obstruction is an off-real Cauchy jump in the homogeneous high-frequency limit. The limiting argument is legitimate at fixed positive b. It neither asserts that individual finite-b pole arcs have been classified nor interchanges an unproved singular boundary limit with a parameter integral.

This excludes this particular smooth four-axis ACG repair family from simultaneous coordinate/diagonal reflection positivity. It does not establish rigidity of arbitrary W4-invariant smooth densities and has no interacting Yang-Mills or mass-gap consequence.

## 1. Effective parameter measure and regularity

Use the accepted positive decomposition into elementary axial covariances T_(eta,a). With p extended by zero, the effective measure is

    mu(eta) = (1+eta)p(eta)/2
        + [1/(4sqrt(eta))] integral_eta^1 p(lambda)(1-lambda)/sqrt(lambda) d lambda.

It is nonnegative, has total mass one, and is supported in [0,lambda_*], where lambda_*=sup supp(p)<1. For every 0<eta<lambda_* its second term is strictly positive: by the definition of support, some positive p-mass lies above eta. Thus mu(eta)>0 throughout this open interval, even when p has gaps. If p is smooth or locally Lipschitz, mu has the corresponding local regularity. For a completely general integrable p, the interval 0<eta<ell still has the exact analytic positive density mu(eta)=C_*/sqrt(eta), where C_*=(1/4) integral p(lambda)(1-lambda)/sqrt(lambda) d lambda>0. The singularity at zero is integrable. This analytic interval suffices for the interior jump, while finiteness alone suffices for dominated holomorphic integration away from the full arcs.

## 2. Exact physical-sheet homogeneous formula

Set

    n=(e1+e2)/sqrt(2), m=(e1-e2)/sqrt(2), z=u^2,
    s=sqrt(1+tau), d=1+eta+(1-eta)s,
    h=2eta tau, alpha=d^2+h, r=h/alpha.

At b=0 and tangential momentum m, q=u^2+1. For real u, both square roots in the accepted elementary formula are positive and

    sqrt((1+tau)q)=s sqrt(q).

The same identity holds throughout the slit q-plane on the principal branches because s>0. Hence there is no branch-sign substitution in the following cancellation:

    T_+(u)=2d/[alpha(u^2+1)+2hu],
    T_-(u)=2d/[alpha(u^2+1)-2hu],
    T_(eta,e3)(u)=T_(eta,e4)(u)=2/[d(u^2+1)].

The first pair is even after summing. Its four-axis average is the rational function

    f_eta(z) = (d/alpha)(z+1)/Q_eta(z) + 1/[d(z+1)],
    Q_eta(z)=(z+1)^2-4r^2 z.                                  (1)

Agreement on positive real z identifies the physical analytic germ uniquely. Thus rational continuation of (1) is the correct continuation of the homogeneous slice. No choice of sqrt(z) remains in this even sum.

The uniform angular term is

    f_iso(z)=2/[(1+s)(z+1)].

Consequently the exact limiting diluted slice is

    f_0(z)=(1-epsilon)f_iso(z)+epsilon integral mu(eta) f_eta(z) d eta.  (2)

## 3. Pole locations, injectivity, and exact residue

For eta>0,

    0<r<1,
    r'(eta)=2tau d[1+s+(s-1)eta]/alpha^2 >0.

The roots of Q_eta are

    zeta(eta)=2r^2-1+2ir sqrt(1-r^2),
    conjugate(zeta(eta)).                                     (3)

They lie on the unit circle, strictly in the upper and lower half-planes. Their real part 2r^2-1 is strictly increasing. Therefore the upper root gives a simple injective smooth arc, beginning at -1 as eta decreases to zero and terminating at zeta(lambda_*) strictly inside the upper half-plane. Indeed lambda_*<1 and even r(1)=tau/(tau+2)<1.

Let A=d/alpha. The residue of the first term of f_eta at its upper pole is exactly

    R(eta)=A(zeta+1)/(zeta-conjugate(zeta))
          =(d/(2alpha))[1-i r/sqrt(1-r^2)].                    (4)

In particular Re R=d/(2alpha)>0, so it never vanishes. The curve derivative never vanishes either; with r as parameter,

    |d zeta/dr|^2=4/(1-r^2)>0.

The conjugate pole is strictly below the real axis. The other two axes and the isotropic term have only the pole z=-1. They cannot cancel an upper-half-plane jump.

## 4. Why smoothing the parameter does not remove the obstruction

For eta>0, write the oblique term as

    A(z+1)/Q_eta(z)=R(eta)/(z-zeta(eta))
                    +conjugate(R(eta))/(z-conjugate(zeta(eta))).

The integral (2) is holomorphic away from the two compact arcs and the negative real axis. This follows from ordinary dominated holomorphic integration: mu is integrable, r is uniformly below one, the residues are bounded, and on each compact set away from the arcs the denominators have a positive lower bound.

Choose eta_0 in (0,ell), where the effective density is exactly analytic, and choose a small arc segment about zeta(eta_0). Only the upper-pole contribution from parameters close to eta_0 is singular there. Its one-sided boundary values have difference, up to the choice of side orientation,

    2 pi i epsilon mu(eta_0) R(eta_0)/zeta'(eta_0).            (5)

This is nonzero by Section 3 and positivity of mu. The formula is the ordinary interior Cauchy jump for an analytic arc with analytic density. It can also be proved directly by subtracting the local density at eta_0 and reducing the remaining singular term to integral dx/(it-x); no endpoint boundary substitution or singular Fubini exchange is required.

The topology is important. Removing an arc from the upper half-plane that has one endpoint at the boundary point -1 and its other endpoint strictly inside the upper half-plane leaves a connected domain. Both sides of an interior segment can be reached from the positive-real germ by going around the free endpoint. In the slit plane with both conjugate arcs removed, the same statement holds. Therefore a hypothetical globally holomorphic Stieltjes continuation would, by the identity theorem, equal (2) on both sides of the arc. Such a continuation would have equal limits across that segment, contradicting (5).

Local analytic continuation through part of an arc, when available for an especially regular density, does not defeat this argument: its continued branch on the other side would differ from the integral branch, while the latter is also connected to the original positive-real germ around the free endpoint. This is precisely why an interior nonzero jump is an obstruction here even if the endpoint density vanishes to every order.

Thus f_0 is not a Stieltjes function for every epsilon>0.

## 5. Fixed-slice RP gives an ordinary finite Stieltjes measure

This section independently checks the measure and contact-term hypotheses used below. Let rho be any bounded normalized nonnegative angular density invariant under reflection in the chosen normal, and fix a nonzero tangential vector k. For real u,

    0<=F_b(un+k)<=1/(b+|k|^2+u^2).

The normal slice is even and belongs to L1(du). Its inverse normal Fourier transform H_k(T) is continuous, bounded, real, even, and tends to zero at infinity.

A direct resolvent inversion provides a stronger bound. Write a=n.v, d=k.v, A=1+tau a^2, C=tau a d, D=b+|k|^2+tau d^2. Then

    Delta=AD-C^2=A(b+|k|^2)+tau d^2,
    H_(v,k)(T)=exp[-sqrt(Delta)|T|/A] exp[-iCT/A]/[2sqrt(Delta)].

Averaging against rho gives

    |H_k(T)| <= exp[-sqrt((b+|k|^2)/(1+tau))|T|]/[2sqrt(b+|k|^2)]. (6)

Full reflection positivity implies positive semidefiniteness of the Hankel matrices [H_k(t_i+t_j)] at every fixed k, not merely almost every k. Indeed the corresponding compact-time quadratic form is continuous in k, and compact smooth spatial wave packets can concentrate their Fourier mass at any specified k. A strictly negative value at one k would yield a legal compact spacetime test.

For completeness, the bounded-Hankel implication is elementary. Make formal vectors e_t with inner products H_k(t+s). On their span the positive-time shifts T_a e_t=e_(t+a) are symmetric. For a finite vector xi, b_j=||T_a^j xi||^2 is uniformly bounded in j, and Cauchy-Schwarz gives b_j^2<=b_0 b_(2j). Iteration proves b_1<=b_0, including null vectors. Hence shifts descend to self-adjoint contractions on the Hilbert completion. They are positive because T_a=T_(a/2)^2, and continuity of H_k gives a strongly continuous semigroup exp(-aL) with L>=0. Continuity at zero supplies a vector e_0, and the spectral theorem supplies a finite positive measure sigma such that

    H_k(T)=integral exp(-ET) sigma(dE), T>=0.

Bound (6) forces support in E>=sqrt((b+|k|^2)/(1+tau)). Fourier inversion is justified by this gap and finite sigma, giving exactly

    F_b(un+k)=integral 2E sigma(dE)/(u^2+E^2).

Set nu=(E^2)_*(2E sigma). It is the ordinary Stieltjes measure. Although its finiteness is not initially assumed, monotone convergence and the real-momentum bound imply

    nu([0,infinity))=lim_(x->infinity) x F_b(sqrt(x)n+k)<=1.   (7)

There is no contact or polynomial remainder: the actual inverse Fourier transform is continuous on the entire real axis and equals the even Laplace mixture there. Fourier inversion above is an equality of the actual kernels, not an equality away from T=0. Any polynomial frequency addition would contradict the L1 normal covariance as well.

## 6. Fully justified fixed-b high-frequency closure

Suppose, for contradiction, that the diluted covariance at some fixed b>0 were diagonal RP. For every kappa>0 define the scaled normal slice

    G_kappa(z)=kappa^2 F_b(kappa sqrt(z)n+kappa m)
              =F_(b/kappa^2)(sqrt(z)n+m), z>0.              (8)

The first equality plus Section 5 shows that G_kappa is Stieltjes. If nu_kappa is its spectral measure, then it is the pushforward of the original normal spectral measure under x->x/kappa^2. Hence it has total mass at most one. It is supported in

    x >= (1+b/kappa^2)/(1+tau) >= 1/(1+tau).

One can also recover the mass bound directly from

    0<=G_kappa(x)<=1/(x+1+b/kappa^2).

Take any sequence kappa->infinity. Positive measures of mass at most one have a weakly convergent subsequence on the one-point compactification [1/(1+tau),infinity]. For each real x>0, the kernel t->1/(x+t), extended by zero at infinity, is continuous on that compactification. The limiting transform is therefore

    G(x)=integral_[1/(1+tau),infinity) nu(dt)/(x+t).

Any escaped mass at infinity contributes zero. This is an ordinary finite positive Stieltjes transform; no constant or contact term can appear.

On the other hand, real-momentum angular dominated convergence identifies the full pointwise limit in (8), not merely this subsequence, with f_0(x) in (2). The denominator of the angular integrand is at least 1+x, uniformly in kappa. Therefore f_0 would be Stieltjes, contradicting Section 4.

This establishes failure of diagonal RP for every fixed b>0, tau>0, and epsilon>0. The argument never requires a finite-b classification of complex poles.

## 7. Stronger transfer: every sufficiently large tangential frequency fails

The same proof can be strengthened without a spectral-limit argument. Because f_0 is not Stieltjes, the bounded-Hankel implication in Section 5, applied at b=0 and |k|=1, shows that there is an actual h in C_c^infinity((0,infinity)) with a strictly negative massless Hankel quadratic form Q_0(h)=-gamma<0. Existence follows by approximating a negative finite Hankel matrix with narrow smooth bumps. The nonzero tangential momentum keeps all kernels bounded even at b=0.

Let delta=b/kappa^2. The angular denominator D_0(u,v) is at least 1+u^2, so

    0 <= f_0(u^2)-F_delta(un+m)
       <= delta/(1+u^2)^2.

With inverse Fourier convention (2pi)^(-1) integral exp(iuT)du,

    ||H_delta-H_0||_infinity <= delta/4,

because integral_R (1+u^2)^(-2)du=pi/2. Hence

    |Q_delta(h)-Q_0(h)| <= (delta/4)||h||_1^2.

Thus the same compact-time h is negative whenever

    kappa^2 > b||h||_1^2/(4gamma).

Scaling normal time converts h into a compact positive-time test for the original tangential slice kappa m; explicitly G_kappa's kernel is kappa H_(b,kappa m)(T/kappa), so h_kappa(t)=h(kappa t) has original quadratic form kappa^(-3) Q_delta(h). Finally a sufficiently concentrated compact smooth tangential wave packet gives a genuine compact spacetime RP counterexample. This is an existence proof of finite legal tests, not an explicit numerical witness or a use of plane-wave delta tests as admissible tests.

## 8. Relation to the coordinate repair and limits of this audit

The accepted constant dilution can make all coordinate mirrors positive. Nothing in the present proof alters its spectral-measure estimate or its explicit epsilon=1/1200 example. The result here shows that adding the diagonal mirror cannot be achieved by any positive amount of this same mixture, however small epsilon is. The obstruction survives because the isotropic contribution is holomorphic at the off-real arc.

The conclusion does not cover arbitrary W4 densities or require analysis of parameter support accumulating at eta=1. Smooth and globally Lipschitz compact-supported p satisfy every condition above. The primary proof also states an optional positive Borel-measure extension on [ell,L]: this extension passes audit because the same analytic effective tail persists below ell, and every additional atomic or rough parameter contribution lies on a separated portion of the injective arc. The density-scope theorem alone settles the coordinate-repair family.

## 9. Exact regression checks

The accompanying check_exact_identities.py verifies the homogeneous denominator reduction, even-pair sum, four-axis average, isotropic limit, r derivative, upper/lower pole polynomial, unit-circle location, exact residue, partial fractions, nonzero curve derivative, angular discriminant, dilution-limit identity, and Fourier error constant using exact SymPy expressions.

verify_regression_modes.py runs ordinary Python and python -O, requires identical good output, and runs a deliberately corrupted residue formula under both modes. Both corruption runs must fail with the intended mismatch. These finite checks support the algebra and do not substitute for the analytic arguments above.

## 10. Cross-audit of the primary proof

The complete primary proof in /workspace/shared/diagonal-rp-next-20261019/RESULT.md was independently read after this audit was drafted. Its connected-domain argument, local analytic-tail jump, bounded-Hankel reconstruction, and time rescaling all pass. Its convention h_kappa(t)=kappa h(kappa t) gives Q_original(h_kappa)=kappa^(-1)Q_delta(h), consistent with Section 7 here, which uses h(kappa t) without the harmless prefactor and therefore obtains kappa^(-3). There is no disagreement between the two conventions.

The primary proof's weaker parameter assumptions are valid: choosing eta_0 below the original support makes the local effective density analytic even for rough p. This audit has been updated to include that strengthening. No overlooked domain-connectivity or contact-term issue was found.

## 11. Completed verification record

All 22 checks passed. The ordinary and python -O successful outputs were identical. Both ordinary and optimized corruption runs failed at the intended upper-residue identity. The regression runner itself was run in ordinary and optimized modes and produced identical reports.

Successful algebra-output SHA256: 0cd16efdb781932cfaa402025c6259fecad0279dcbd5242a6094ef3d8f08e46d.

Saved reports: exact-checks.json, regression-validation.json, regression-validation-optimized.json. Reproduce with python check_exact_identities.py; python verify_regression_modes.py; python -O verify_regression_modes.py. Both python check_exact_identities.py --negative-control and python -O check_exact_identities.py --negative-control must fail.
