#!/usr/bin/env python3
"""Exact algebra regression, independent of Python assert optimization."""
import argparse
import hashlib
import json
import sys
import sympy as S

parser = argparse.ArgumentParser()
parser.add_argument('--negative-control', action='store_true')
args = parser.parse_args()
checks = []

def check(name, expr):
    val = S.factor(S.cancel(expr))
    if val != 0:
        print(json.dumps({'status': 'FAIL', 'check': name, 'mismatch': str(val)}, sort_keys=True))
        raise SystemExit(1)
    checks.append(name)

def mod_circle(expr):
    numerator = S.cancel(expr).as_numer_denom()[0]
    return S.rem(S.Poly(S.expand(numerator), t), S.Poly(t*t-(1-r*r), t)).as_expr()

eta, s = S.symbols('eta s', positive=True)
u, z = S.symbols('u z')
tau = s*s-1
d = 1+eta+(1-eta)*s
h = 2*eta*tau
alpha = d*d+h
r_eta = h/alpha
Dp = d*d*(u*u+1)+h*(u+1)**2
Dm = d*d*(u*u+1)+h*(u-1)**2
check('plus denominator homogeneous reduction', Dp-(alpha*(u*u+1)+2*h*u))
check('minus denominator homogeneous reduction', Dm-(alpha*(u*u+1)-2*h*u))
pair = 2*d/Dp+2*d/Dm
rational_pair = 4*d/alpha*(u*u+1)/((u*u+1)**2-4*r_eta*r_eta*u*u)
check('even pair rational identity', pair-rational_pair)
four = pair/4+1/(d*(u*u+1))
check('four-axis rational identity', four-(d/alpha*(u*u+1)/((u*u+1)**2-4*r_eta*r_eta*u*u)+1/(d*(u*u+1))))
check('eta zero isotropic identity', four.subs(eta, 0)-2/((1+s)*(u*u+1)))
check('one minus r positive factor', 1-r_eta-d*d/alpha)
check('r derivative positive factor', S.diff(r_eta, eta)-2*tau*d*(1+s+(s-1)*eta)/alpha**2)
check('r endpoint eta one', r_eta.subs(eta, 1)-tau/(tau+2))
check('derivative auxiliary positive factor', d-2*eta*S.diff(d, eta)-(1+s+(s-1)*eta))

r, t, A = S.symbols('r t A', positive=True)
zeta = 2*r*r-1+2*S.I*r*t
zetabar = 2*r*r-1-2*S.I*r*t
Q = (z+1)**2-4*r*r*z
check('upper pole polynomial', mod_circle(Q.subs(z, zeta)))
check('lower pole polynomial', mod_circle(Q.subs(z, zetabar)))
check('unit circle location', mod_circle(zeta*zetabar-1))
check('quadratic root factorization', mod_circle((z-zeta)*(z-zetabar)-Q))
res = A/2*(1-S.I*r/t)
if args.negative_control:
    res = A/2*(1+S.I*r/t)
check('upper residue identity', mod_circle(res*(zeta-zetabar)-A*(zeta+1)))
resbar = A/2*(1+S.I*r/t)
check('partial fractions', mod_circle(res/(z-zeta)+resbar/(z-zetabar)-A*(z+1)/Q))
check('residue positive real part', (res+resbar)/2-A/2)
zeta_prime = 4*r+2*S.I*(1-2*r*r)/t
zeta_prime_bar = 4*r-2*S.I*(1-2*r*r)/t
check('curve derivative exact speed', mod_circle(zeta_prime*zeta_prime_bar-4/t**2))
check('curve real part derivative', S.diff(2*r*r-1, r)-4*r)

T, a, kv, B, K = S.symbols('T a kv B K', real=True)
Av = 1+T*a*a
Cv = T*a*kv
Dv = B+K+T*kv*kv
check('angular quadratic discriminant', Av*Dv-Cv*Cv-(Av*(B+K)+T*kv*kv))
D0, delta = S.symbols('D0 delta', positive=True)
check('positive mass perturbation difference', 1/D0-1/(D0+delta)-delta/(D0*(D0+delta)))
x = S.symbols('x', real=True)
check('uniform Fourier perturbation constant', S.integrate(1/(1+x*x)**2, (x, -S.oo, S.oo))/(2*S.pi)-S.Rational(1, 4))
nu, kappa = S.symbols('nu kappa', positive=True)
check('spectral scaling kernel', kappa*kappa/(kappa*kappa*z+nu)-1/(z+nu/(kappa*kappa)))

result = {'status': 'PASS', 'count': len(checks), 'checks': checks}
print(json.dumps(result, indent=2, sort_keys=True))
