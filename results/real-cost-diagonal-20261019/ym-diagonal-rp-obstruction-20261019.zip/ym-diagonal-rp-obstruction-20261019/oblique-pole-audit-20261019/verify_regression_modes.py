#!/usr/bin/env python3
"""Require identical exact checks and effective deliberate corruption in both modes."""
import hashlib
import json
from pathlib import Path
import subprocess
import sys

root = Path(__file__).resolve().parent
script = root / 'check_exact_identities.py'
good_outputs = []
mode_results = []
for optimized in (False, True):
    cmd = [sys.executable] + (['-O'] if optimized else []) + [str(script)]
    good = subprocess.run(cmd, capture_output=True, text=True)
    if good.returncode != 0:
        raise SystemExit(f'Good check failed in optimized={optimized}: {good.stdout} {good.stderr}')
    data = json.loads(good.stdout)
    if data.get('status') != 'PASS' or data.get('count') != 22:
        raise SystemExit(f'Unexpected good report: {data}')
    good_outputs.append(good.stdout)
    bad = subprocess.run(cmd+['--negative-control'], capture_output=True, text=True)
    if bad.returncode == 0:
        raise SystemExit(f'Deliberate corruption unexpectedly passed in optimized={optimized}')
    bad_data = json.loads(bad.stdout)
    if bad_data.get('check') != 'upper residue identity' or bad_data.get('status') != 'FAIL':
        raise SystemExit(f'Wrong corruption failure: {bad.stdout} {bad.stderr}')
    mode_results.append({'optimized': optimized, 'good': 'PASS', 'negative_control': 'EXPECTED_FAIL', 'negative_control_check': bad_data['check']})
if good_outputs[0] != good_outputs[1]:
    raise SystemExit('Ordinary and optimized successful outputs differ')
report = {'status': 'PASS', 'modes': mode_results, 'successful_output_sha256': hashlib.sha256(good_outputs[0].encode()).hexdigest()}
print(json.dumps(report, indent=2, sort_keys=True))
