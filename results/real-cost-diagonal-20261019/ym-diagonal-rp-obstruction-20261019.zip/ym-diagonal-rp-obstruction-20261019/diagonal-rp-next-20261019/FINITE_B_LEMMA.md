# Supplement: finite-b oblique poles cannot collide across parameters

This exact lemma is not needed for the accepted proof in RESULT.md, which uses real-momentum scaling and legal compact tests. It records a useful direct physical-sheet calculation for future work.

Fix b,tau,kappa>0. Set p=u n+kappa m with n=(e1+e2)/sqrt(2), m=(e1-e2)/sqrt(2), z=u^2, q=z+kappa^2. Work in Im z>0 and choose u=sqrt(z) in the first quadrant. Put

    A0=sqrt(b+q), C0=sqrt(b+(1+tau)q),
    P=A0+C0, M=A0-C0.

Both roots are individually principal and lie in the first quadrant. In particular

    |M/P|<1,
    PM=-tau q.

The two oblique denominators are exactly

    D_plus(u,eta)=P^2+4eta tau kappa u+eta^2 M^2,
    D_minus(u,eta)=P^2-4eta tau kappa u+eta^2 M^2.          (1)

To check (1), expand [(1+eta)A0+(1-eta)C0]^2+2eta tau(u +/- kappa)^2 and use PM=-tau q. The coefficient of eta q cancels.

At a fixed u in this physical domain, the product of the two eta roots of D_minus is

    P^2/M^2,

whose modulus exceeds one. (M is nonzero because PM=-tau q and Im q>0.) Therefore:

1. D_minus cannot vanish at two distinct parameters eta1,eta2 in (0,1).
2. D_plus and D_minus cannot vanish at the same u for parameters eta1,eta2 in (0,1), since this would give the two roots eta1,-eta2 of D_minus, again with product of modulus below one.
3. The numerator 2[(1+eta)+(1-eta)C0/A0] cannot vanish at an oblique pole: numerator zero would make the squared-root combination zero, forcing u=+/-kappa from the original denominator, contrary to Im z>0.
4. The e3,e4 tangent terms have no pole in Im z>0: their denominator is the square of a positive linear combination of the two first-quadrant roots.

Thus a physical oblique parameter pole has a nonzero numerator and cannot be canceled by an identical pole of another allowed parameter or of the other three axis terms.

For each fixed eta in (0,1), such a pole exists at sufficiently large kappa. Put delta=b/kappa^2 and u=kappa w. At delta=0 the minus denominator is

    d^2(w^2+1)+2eta tau(w-1)^2,
    d=1+eta+(1-eta)sqrt(1+tau).

Its first-quadrant zero is

    w=r+i sqrt(1-r^2),
    r=2eta tau/[d^2+2eta tau].

It is simple, and w^2 lies strictly in the upper half-plane. The roots A0/kappa and C0/kappa are analytic near this point for delta near zero, since Im(w^2+1)>0. The analytic implicit-function theorem therefore preserves this simple physical pole for all sufficiently small positive delta, equivalently all sufficiently large finite kappa. The same holds uniformly over a sufficiently small closed interval about any chosen eta0 in (0,1); nonzero parameter derivative persists from the massless arc.

This supplement does not replace the main proof's global analytic continuation or compact-witness argument. Local pole existence and noncollision alone are not presented as a complete global continuum-mixing obstruction. RESULT.md supplies that complete obstruction through the simpler homogeneous limit, together with exact finite-b transfer.
