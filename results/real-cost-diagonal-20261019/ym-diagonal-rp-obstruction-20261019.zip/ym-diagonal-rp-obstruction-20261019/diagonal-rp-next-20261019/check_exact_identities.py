#!/usr/bin/env python3
"""Exact algebra regression; analytic conclusions are in RESULT.md."""
import argparse
import json
import sympy as S

parser = argparse.ArgumentParser()
parser.add_argument('--negative-control', action='store_true')
args = parser.parse_args()
checks = []

def same(name, lhs, rhs):
    difference = S.factor(S.simplify(lhs - rhs))
    if difference != 0:
        raise SystemExit(f'FAIL: {name}: {difference}')
    checks.append(name)

u, d, h, z = S.symbols('u d h z', real=True)
alpha = d*d+h
pair = 2*d/(alpha*(u*u+1)+2*h*u) + 2*d/(alpha*(u*u+1)-2*h*u)
same('even oblique pair', pair, 4*d*alpha*(u*u+1)/(alpha**2*(u*u+1)**2-4*h*h*u*u))
same('pair parity', pair.subs(u,-u),pair)
same('four-axis oblique factor', pair/4, d/alpha*(u*u+1)/((u*u+1)**2-4*(h/alpha)**2*u*u))
same('two tangent axes factor', (2/(d*(z+1))+2/(d*(z+1)))/4,1/(d*(z+1)))

eta, s, tau = S.symbols('eta s tau', positive=True)
d_eta=1+eta+(1-eta)*s
h_eta=2*eta*tau
alpha_eta=d_eta**2+h_eta
r_eta=h_eta/alpha_eta
same('r derivative positive factor', S.diff(r_eta,eta),2*tau*d_eta*(1+s+(s-1)*eta)/alpha_eta**2)
same('one minus r',1-r_eta,d_eta**2/alpha_eta)
same('d positive decomposition',d_eta,(1+eta)+(1-eta)*s)
same('r numerator',r_eta*alpha_eta,2*eta*tau)

r=S.symbols('r',real=True,positive=True)
t=S.sqrt(1-r*r)
zeta=2*r*r-1+2*S.I*r*t
zetabar=2*r*r-1-2*S.I*r*t
same('unit circle pole norm',zeta*zetabar,1)
same('pole polynomial factorization',(z-zeta)*(z-zetabar),(z+1)**2-4*r*r*z)
same('upper root',((z+1)**2-4*r*r*z).subs(z,zeta),0)
same('pole derivative norm',S.diff(zeta,r)*S.diff(zetabar,r),4/(1-r*r))
a=d/(2*alpha)*(1-S.I*r/t)
if args.negative_control:
    a=d/(2*alpha)*(1+S.I*r/t)
same('upper residue',d/alpha*(zeta+1)/(zeta-zetabar),a)
abar=d/(2*alpha)*(1+S.I*r/t)
same('partial fractions',a/(z-zeta)+abar/(z-zetabar),d/alpha*(z+1)/((z+1)**2-4*r*r*z))
same('residue real part',(a+abar)/2,d/(2*alpha))
same('residue sum',a+abar,d/alpha)

b,kappa,A=S.symbols('b kappa A',positive=True)
same('real scaling resolvent',kappa**2/(b+kappa*kappa*A),1/(b/(kappa*kappa)+A))
delta=S.symbols('delta',nonnegative=True)
same('difference resolvent',1/A-1/(A+delta),delta/(A*(A+delta)))
same('normal domination integral',S.integrate(1/(1+u*u)**2,(u,-S.oo,S.oo)),S.pi/2)
same('normal kernel bound coefficient',(S.pi/2)/(2*S.pi),S.Rational(1,4))

# The original oblique denominator and the massless reduced one coincide.
q=u*u+1
same('plus physical denominator',d_eta**2*q+4*eta*tau*(u+1)**2/2,alpha_eta*(u*u+1)+2*h_eta*u)
same('minus physical denominator',d_eta**2*q+4*eta*tau*(u-1)**2/2,alpha_eta*(u*u+1)-2*h_eta*u)

print(json.dumps({'status':'PASS','count':len(checks),'checks':checks},indent=2))
