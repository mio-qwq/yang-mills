#!/usr/bin/env python3
"""Require identical optimized/ordinary checks and robust negative controls."""
import hashlib
import json
import pathlib
import subprocess
import sys

root=pathlib.Path(__file__).resolve().parent
script=root/'check_exact_identities.py'
outputs=[]
negative=[]
for mode in ([],['-O']):
    good=subprocess.run([sys.executable,*mode,str(script)],capture_output=True,text=True)
    if good.returncode:
        raise SystemExit('Good run failed: '+good.stdout+good.stderr)
    outputs.append(good.stdout)
    bad=subprocess.run([sys.executable,*mode,str(script),'--negative-control'],capture_output=True,text=True)
    if bad.returncode == 0 or 'FAIL: upper residue' not in bad.stdout+bad.stderr:
        raise SystemExit('Negative control did not fail as required: '+bad.stdout+bad.stderr)
    negative.append({'optimized':bool(mode),'returncode':bad.returncode,'expected_failure':True})
if outputs[0]!=outputs[1]:
    raise SystemExit('Ordinary and optimized successful outputs differ')
print(json.dumps({'status':'PASS','check_count':json.loads(outputs[0])['count'],'output_sha256':hashlib.sha256(outputs[0].encode()).hexdigest(),'negative_controls':negative},indent=2))
