#!/usr/bin/env python3
"""Build a deterministic source ZIP, refusing an existing or internal destination."""
import argparse
import hashlib
from pathlib import Path
import stat
import sys
from zipfile import ZIP_DEFLATED, ZipFile, ZipInfo
sys.dont_write_bytecode = True
from reproduce import ROOT, require, verify_tree


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('output', type=Path)
    args = parser.parse_args()
    output = args.output.resolve()
    require(not output.is_relative_to(ROOT), 'Output must be outside the payload directory')
    require(not output.exists(), 'Refusing to overwrite existing output: ' + str(output))
    verify_tree()
    with ZipFile(output, 'x', compression=ZIP_DEFLATED, compresslevel=9) as archive:
        for path in sorted(p for p in ROOT.rglob('*') if p.is_file()):
            relative = path.relative_to(ROOT).as_posix()
            info = ZipInfo('ym-diagonal-rp-obstruction-20261019/' + relative, (1980, 1, 1, 0, 0, 0))
            info.create_system = 3
            info.external_attr = (stat.S_IFREG | 0o644) << 16
            info.compress_type = ZIP_DEFLATED
            archive.writestr(info, path.read_bytes(), compress_type=ZIP_DEFLATED, compresslevel=9)
    print(str(output.stat().st_size) + ' bytes; SHA256 ' + hashlib.sha256(output.read_bytes()).hexdigest())


if __name__ == '__main__':
    main()
