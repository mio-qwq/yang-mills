#!/usr/bin/env python3
"""Optimization-resistant negative controls for the source package verifier."""
import hashlib
import io
import json
from pathlib import Path
import shutil
import sys
import tempfile
import warnings
from zipfile import ZipFile
sys.dont_write_bytecode = True
import reproduce as R

ROOT = Path(__file__).resolve().parent


def refresh_manifest(root):
    lines = []
    for p in sorted(root.rglob('*')):
        if p.is_file() and p.name != 'SHA256SUMS':
            lines.append(R.sha(p.read_bytes()) + '  ' + p.relative_to(root).as_posix())
    (root / 'SHA256SUMS').write_text('\n'.join(lines) + '\n')


def reject(name, action, marker, reports):
    try:
        action()
    except Exception as error:
        R.require(marker in str(error), 'Wrong rejection for ' + name + ': ' + str(error))
        reports.append({'case': name, 'status': 'EXPECTED_REJECTION'})
    else:
        raise RuntimeError('Corruption incorrectly accepted: ' + name)


def main():
    R.verify_tree()
    R.verify_sources()
    R.dependencies()
    reports = []
    with tempfile.TemporaryDirectory(prefix='ym-diagonal-package-test-') as directory:
        work = Path(directory)
        def tree_case(name, mutate, verify, marker, rehash=False):
            root = work / name
            shutil.copytree(ROOT, root)
            mutate(root)
            if rehash:
                refresh_manifest(root)
            original = R.ROOT
            try:
                R.ROOT = root
                reject(name, lambda: verify(root), marker, reports)
            finally:
                R.ROOT = original
        def alter_primary(root):
            p = root / 'diagonal-rp-next-20261019/RESULT.md'
            p.write_bytes(p.read_bytes() + b'corrupt\n')
        tree_case('changed_payload', alter_primary, R.verify_tree, 'Integrity mismatch')
        tree_case('missing_payload', lambda r: (r / 'requirements.txt').unlink(), R.verify_tree, 'file-set mismatch')
        tree_case('unexpected_payload', lambda r: (r / 'untracked.txt').write_text('extra'), R.verify_tree, 'file-set mismatch')
        tree_case('symlink_payload', lambda r: (r / 'unexpected-link').symlink_to(r / 'README.md'), R.verify_tree, 'Symlink in payload')
        def alter_proof_dependency(root):
            p = root / 'proof-dependencies/infinite-angular-candidates-20261019/RESULT.md'
            p.write_bytes(p.read_bytes() + b'corrupt\n')
        tree_case('repinned_dependency_proof', alter_proof_dependency, lambda _: R.verify_sources(), 'Pinned proof dependency mismatch', True)
        def alter_suffix(root):
            p = root / 'audit-resolution/APPENDED_SUFFIX.txt'
            p.write_bytes(p.read_bytes() + b'corrupt\n')
        tree_case('repinned_audit_bridge', alter_suffix, lambda _: R.verify_sources(), 'Append-only audit bridge mismatch', True)
        def alter_archive(root):
            p = root / 'dependencies' / (R.COORD_ROOT + '.zip')
            p.write_bytes(p.read_bytes() + b'corrupt\n')
        tree_case('repinned_dependency_archive', alter_archive, lambda _: R.dependencies(), 'Dependency archive identity mismatch', True)
    reject('manifest_parent_path', lambda: R.parse_manifest(('0'*64 + '  ../escape\n').encode()), 'Unsafe payload path', reports)
    reject('manifest_duplicate', lambda: R.parse_manifest(('0'*64 + '  file\n') .encode()*2), 'Duplicate or self-referential', reports)
    def bad_zip(names):
        stream = io.BytesIO()
        with warnings.catch_warnings():
            warnings.simplefilter('ignore', UserWarning)
            with ZipFile(stream, 'w') as z:
                for name in names:
                    z.writestr(name, b'data')
        data = stream.getvalue()
        return lambda: R.verify_zip(data, 'payload', hashlib.sha256(data).hexdigest())
    reject('zip_parent_path', bad_zip(['payload/../escape']), 'Unsafe payload path', reports)
    reject('zip_duplicate', bad_zip(['payload/file', 'payload/file']), 'Duplicate dependency ZIP entry', reports)
    print(json.dumps({'status': 'PASS', 'negative_control_count': len(reports), 'cases': reports}, indent=2, sort_keys=True))


if __name__ == '__main__':
    main()
