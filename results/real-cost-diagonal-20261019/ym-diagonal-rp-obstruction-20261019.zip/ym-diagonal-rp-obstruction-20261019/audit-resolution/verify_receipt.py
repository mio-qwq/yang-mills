#!/usr/bin/env python3
import hashlib
import json
from pathlib import Path
root=Path(__file__).resolve().parent
r=json.loads((root/'FINAL_HASH_RECEIPT.json').read_text())
b=Path(r['primary_path']).read_bytes()
def need(condition, message):
    if not condition: raise SystemExit(message)
need(len(b)==r['final_primary_bytes'],'Final byte length mismatch')
need(hashlib.sha256(b).hexdigest()==r['final_primary_sha256'],'Final hash mismatch')
n=r['previous_primary_bytes']
need(hashlib.sha256(b[:n]).hexdigest()==r['previous_primary_sha256'],'Earlier exact-prefix hash mismatch')
suffix=(root/'APPENDED_SUFFIX.txt').read_bytes()
need(suffix==b[n:],'Appended suffix differs')
need(hashlib.sha256(suffix).hexdigest()==r['appended_sha256'],'Suffix hash mismatch')
for kind in ('independent_audit','original_source_manifest'):
    need(hashlib.sha256(Path(r[kind+'_path']).read_bytes()).hexdigest()==r[kind+'_sha256'],kind+' changed')
print(json.dumps({'status':'PASS','exact_old_prefix':n,'append_only_bytes':len(suffix),'final_sha256':r['final_primary_sha256']},sort_keys=True))
