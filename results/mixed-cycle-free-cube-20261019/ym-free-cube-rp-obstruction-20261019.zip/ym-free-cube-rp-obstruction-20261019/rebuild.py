#!/usr/bin/env python3
"""Rebuild the byte-deterministic source ZIP using only the Python standard library."""
from pathlib import Path
import argparse
import hashlib
import zipfile

ROOT = Path(__file__).resolve().parent
ARCHIVE_ROOT = 'ym-free-cube-rp-obstruction-20261019'
DEFAULT_NAME = ARCHIVE_ROOT + '.zip'
FIXED_TIME = (2026, 10, 19, 0, 0, 0)

def inventory():
    entries = []
    for line in (ROOT / 'SHA256SUMS').read_text(encoding='utf-8').splitlines():
        digest, name = line.split('  ', 1)
        path = ROOT / name
        if path.is_symlink() or not path.is_file():
            raise RuntimeError('Missing or nonregular input: ' + name)
        if Path(name).is_absolute() or '..' in Path(name).parts:
            raise RuntimeError('Unsafe inventory path: ' + name)
        actual = hashlib.sha256(path.read_bytes()).hexdigest()
        if actual != digest:
            raise RuntimeError('SHA256 mismatch: ' + name)
        entries.append(name)
    if len(entries) != len(set(entries)):
        raise RuntimeError('Duplicate inventory entries')
    if entries != sorted(entries):
        raise RuntimeError('Inventory is not sorted')
    return entries + ['SHA256SUMS']

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('output', nargs='?', type=Path, default=ROOT.parent / DEFAULT_NAME)
    args = parser.parse_args()
    names = inventory()
    output = args.output.resolve()
    if output == ROOT or ROOT in output.parents:
        raise RuntimeError('Write the rebuilt ZIP outside its source directory')
    output.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(output, 'w', compression=zipfile.ZIP_STORED) as archive:
        for name in sorted(names):
            info = zipfile.ZipInfo(ARCHIVE_ROOT + '/' + name, FIXED_TIME)
            info.create_system = 3
            info.external_attr = 0o100644 << 16
            info.compress_type = zipfile.ZIP_STORED
            archive.writestr(info, (ROOT / name).read_bytes())
    print(hashlib.sha256(output.read_bytes()).hexdigest() + '  ' + output.name)

if __name__ == '__main__':
    main()
