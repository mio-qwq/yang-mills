#!/usr/bin/env python3
"""Verify this exact source checkpoint, including deliberate-error controls."""
import argparse
import ast
from fractions import Fraction
import hashlib
from itertools import product
import json
from math import factorial
import os
from pathlib import Path
import subprocess
import sys
import tempfile

ROOT = Path(__file__).resolve().parent
CHECKERS = (
    ('primary/check_cube_incidence.py', 'primary/CUBE_CHECKS.json'),
    ('primary/check_tube.py', 'primary/CHECKS.json'),
    ('audit/audit_exact.py', 'audit/CHECKS.json'),
)

def require(condition, message):
    if not condition:
        raise RuntimeError('CHECKPOINT CHECK FAILED: ' + message)

def digest(data):
    return hashlib.sha256(data).hexdigest()

def inventory_check():
    entries = {}
    for line in (ROOT / 'SHA256SUMS').read_text().splitlines():
        value, name = line.split('  ', 1)
        require(name not in entries, 'duplicate manifest member: ' + name)
        require(not Path(name).is_absolute() and '..' not in Path(name).parts, 'unsafe manifest path')
        path = ROOT / name
        require(path.is_file() and not path.is_symlink(), 'missing/nonregular file: ' + name)
        require(digest(path.read_bytes()) == value, 'hash mismatch: ' + name)
        entries[name] = value
    require(list(entries) == sorted(entries), 'manifest order')
    actual = {p.relative_to(ROOT).as_posix() for p in ROOT.rglob('*') if p.is_file() and '__pycache__' not in p.parts}
    require(actual == set(entries) | {'SHA256SUMS'}, 'extra or missing checkpoint files')
    return len(entries)

def run(script, flags=(), extra=(), cwd=None):
    env = dict(os.environ)
    env['PYTHONDONTWRITEBYTECODE'] = '1'
    env['PYTHONHASHSEED'] = '0'
    return subprocess.run([sys.executable, *flags, str(script), *extra], cwd=cwd or ROOT,
                          env=env, capture_output=True, timeout=180)

def error_line(completed):
    lines = completed.stderr.decode('utf-8', errors='replace').strip().splitlines()
    return lines[-1] if lines else ''

def check_scope():
    reflect = lambda x: (4-x[0], x[1], x[2])
    slab = set(product(range(5), range(6), range(6)))
    box = set(product(range(6), repeat=3))
    require({reflect(v) for v in slab} == slab, 'slab reflection invariance')
    require(all(reflect(reflect(v)) == v for v in slab), 'reflection involution')
    require({reflect(v) for v in box} != box, 'full cube must not be reflection invariant')
    p = {(3, 2+a, 2+b) for a,b in product((0,1), repeat=2)}
    q = {(1, 2+a, 2+b) for a,b in product((0,1), repeat=2)}
    require({reflect(v) for v in p} == q, 'reflected plaquette vertices')
    require(all(v[0] > 2 for v in p) and all(v[0] < 2 for v in q), 'strict half-space supports')
    require(all(all(0 < t < 5 for t in v) for v in p | q), 'strict cube-interior supports')
    a = Fraction(1, 2**18)
    b = Fraction(1, 10**14)
    ratio = Fraction(2 * 450**11, factorial(11)) * b*b / ((1-450*b)*a)
    require(ratio == Fraction(30993639120000, 153999999999307), 'exact numerator remainder ratio')
    require(0 < ratio < Fraction(1,2), 'numerator positivity interval')
    return {'slab_invariant':True, 'full_cube_invariant':False, 'strictly_interior_supports':True,
            'leading_coefficient':str(a), 'beta_ceiling':str(b), 'numerator_relative_remainder_bound':str(ratio)}

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--bootstrap-record', action='store_true',
                        help='For package preparation only: write the report before sealing SHA256SUMS.')
    args = parser.parse_args()
    if not args.bootstrap_record:
        inventory_check()
    pins = json.loads((ROOT / 'SOURCE_PINS.json').read_text())
    for item in pins['source_files']:
        require(digest((ROOT / item['path']).read_bytes()) == item['sha256'], 'source pin: ' + item['path'])
    python_files = sorted(ROOT.rglob('*.py'))
    for path in python_files:
        require(not any(isinstance(node, ast.Assert) for node in ast.walk(ast.parse(path.read_text()))),
                'assert statement would disappear under -O: ' + str(path.relative_to(ROOT)))
    positive_runs = []
    for script_name, output_name in CHECKERS:
        expected = (ROOT / output_name).read_bytes()
        for flags in ((), ('-O',)):
            completed = run(ROOT / script_name, flags)
            require(completed.returncode == 0, script_name + ': ' + error_line(completed))
            require(completed.stdout == expected, 'frozen output mismatch: ' + script_name)
            require(json.loads(completed.stdout) == json.loads(expected), 'invalid JSON result')
            positive_runs.append({'script':script_name, 'python_flags':list(flags), 'returncode':0,
                                  'output_sha256':digest(completed.stdout), 'matches_frozen_output':True})
    require((ROOT / 'audit/CHECKS.optimized.json').read_bytes() == (ROOT / 'audit/CHECKS.json').read_bytes(),
            'independent normal/optimized output mismatch')
    negative_runs = []
    for control, expected_error in (
        ('incidence', 'RuntimeError: CHECK FAILED: p cube/domino counts and strict interior status'),
        ('coefficient', 'RuntimeError: CHECK FAILED: degree-nine coefficient must be exactly 2^-18'),
    ):
        for flags in ((), ('-O',)):
            completed = run(ROOT / 'audit/audit_exact.py', flags, ('--negative-control', control))
            require(completed.returncode != 0 and error_line(completed) == expected_error,
                    'audit negative control did not fail for expected reason: ' + control)
            negative_runs.append({'script':'audit/audit_exact.py','control':control,'python_flags':list(flags),
                                  'returncode':completed.returncode,'last_error_line':error_line(completed)})
    mutations = (
        ('primary/check_cube_incidence.py', 'geometry', 'L=5', 'L=4', 'Expected ten domino boundaries at the positive plaquette'),
        ('primary/check_cube_incidence.py', 'remainder', 'b=Q(1,10**14)', 'b=Q(1,10**13)', 'remainder'),
        ('primary/check_tube.py', 'coefficient', 'expected=Q(1,2**(8*(first+1)+2))',
         'expected=Q(1,2**(8*(first+1)+3))', 'unexpected leading coefficient'),
    )
    with tempfile.TemporaryDirectory(prefix='ym-rp-negative-') as temporary:
        for script_name, control, old, new, expected_substring in mutations:
            original = (ROOT / script_name).read_text()
            require(original.count(old) == 1, 'negative-control mutation anchor: ' + control)
            mutated = Path(temporary) / (Path(script_name).stem + '-' + control + '.py')
            mutated.write_text(original.replace(old, new))
            for flags in ((), ('-O',)):
                completed = run(mutated, flags, cwd=temporary)
                require(completed.returncode != 0 and 'RuntimeError:' in error_line(completed)
                        and expected_substring.lower() in error_line(completed).lower(),
                        'primary negative control did not fail for expected reason: ' + control + ': ' + error_line(completed))
                negative_runs.append({'script':script_name,'control':control,'python_flags':list(flags),
                                      'returncode':completed.returncode,'last_error_line':error_line(completed)})
    report = {'status':'PASS', 'check_semantics':'All checks use explicit exceptions; no Python assert nodes.',
              'python_source_files_checked':len(python_files), 'source_pins_verified':len(pins['source_files']),
              'scope_checks':check_scope(), 'positive_runs':positive_runs,'negative_runs':negative_runs,
              'mathematical_limit':'The finite scripts check geometry and exact algebra; the exhaustive character-label argument is supplied as a readable proof, not a formal machine proof.'}
    encoded = json.dumps(report, indent=2) + '\n'
    if args.bootstrap_record:
        (ROOT / 'CHECKPOINT_VERIFICATION.json').write_text(encoded)
    else:
        require((ROOT / 'CHECKPOINT_VERIFICATION.json').read_text() == encoded, 'checkpoint verification report mismatch')
    print(encoded, end='')

if __name__ == '__main__':
    main()
