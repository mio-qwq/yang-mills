#!/usr/bin/env python3
"""Independent exact checks for a non-invariant 3D free-box RP witness.
This checks incidences, low-order rational series, and a numerator remainder.
The exhaustive spin-label exclusion is proved in AUDIT.md, not inferred from
numerical integration or brute-force cutoffs.
"""
from itertools import product
from functools import reduce
import argparse
from fractions import Fraction as Q
from math import factorial
import json
import sympy as s

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument("--negative-control", choices=("incidence", "coefficient"),
                    help="Deliberately corrupt one expected value; must exit nonzero.")
args = parser.parse_args()
checks_executed = 0
def require(condition, message):
    """Optimization-resistant verification; never relies on assert."""
    global checks_executed
    checks_executed += 1
    if not condition:
        raise RuntimeError("CHECK FAILED: " + message)

L=5
def add(x,i,n=1):
    y=list(x);y[i]+=n;return tuple(y)
def face(x,normal): return (normal,tuple(x))
def boundary(cell):
    return {face(y,i) for i in range(3) for y in (cell,add(cell,i))}
def edges(f):
    n,x=f; a,b=[i for i in range(3) if i!=n]
    return {(a,x),(a,add(x,b)),(b,x),(b,add(x,a))}
def face_vertices(f):
    n,x=f;a,b=[i for i in range(3) if i!=n]
    return {tuple(x[k]+aa*(k==a)+bb*(k==b) for k in range(3)) for aa,bb in product((0,1),repeat=2)}
cells=list(product(range(L),repeat=3))
faces=set().union(*(boundary(c) for c in cells))
require(len(faces)==450, "full box must have 450 plaquettes")
p=face((3,2,2),0);q=face((1,2,2),0)
cubes=[boundary(c) for c in cells]
dominos=[boundary(c)^boundary(d) for c in cells for i in range(3) if (d:=add(c,i)) in cells]
require(len(dominos)==300, "full box must have 300 dominos")
counts={}
for name,f in [('p',p),('q',q)]:
    counts[name]={'cubes':sum(f in S for S in cubes),'dominos':sum(f in S for S in dominos),'strictly_interior':all(all(0<a<L for a in v) for v in face_vertices(f))}
expected_p_dominos = 11 if args.negative_control == 'incidence' else 10
require(counts['p']=={'cubes':2,'dominos':expected_p_dominos,'strictly_interior':True},
        'p cube/domino counts and strict interior status')
require(counts['q']=={'cubes':2,'dominos':9,'strictly_interior':True},
        'q cube/domino counts and strict interior status')
# Inspect the finite local lemma used in the proof: each external face touches
# at most one edge of the boundary of any unit cube.
max_shared_external_edges=0
for c in cells:
    S=boundary(c);es=set().union(*(edges(f) for f in S))
    for f in faces-S:
        shared=len(edges(f)&es)
        max_shared_external_edges=max(max_shared_external_edges,shared)
require(max_shared_external_edges==1, 'external face shares at most one cube edge')
# Every cube/domino is a sphere with each surface edge incident twice.
sphere_data=[]
for typ,seq,F in [('cube',cubes,6),('domino',dominos,10)]:
    invariants=set()
    for S in seq:
        es=set().union(*(edges(f) for f in S))
        vs=set().union(*(face_vertices(f) for f in S))
        require(all(sum(e in edges(f) for f in S)==2 for e in es),
                typ + ' surface edge multiplicity must be two')
        require(len(vs)-len(es)+len(S)==2, typ + ' surface Euler characteristic must be two')
        invariants.add((len(vs),len(es),len(S)))
    sphere_data.append({'shape':typ,'VEF':sorted(invariants),'character_integral':str(Q(1,2**(F-2)))})
# Center transformation eta_i(x)=(-1)^sum_{j<i} x_j flips each plaquette.
def eta(e):
    i,x=e;return (-1)**sum(x[:i])
require(all(reduce(lambda a,b:a*b,(eta(e) for e in edges(f)),1)==-1 for f in faces),
        'center transformation must flip every plaquette')
# Independent exact univariate series and inhomogeneous-derivative formula.
b=s.symbols('beta')
c0=sum(b**(2*k)/(2**(2*k)*s.factorial(k)*s.factorial(k+1)) for k in range(7))
c1=sum(2*b**(1+2*k)/(2**(1+2*k)*s.factorial(k)*s.factorial(k+2)) for k in range(7))
t=s.series(c1/c0,b,0,12).removeO()
means={name:s.series(t/2+s.Rational(data['cubes'],16)*s.diff(t,b)*t**5+s.Rational(data['dominos'],256)*s.diff(t,b)*t**9,b,0,11).removeO() for name,data in counts.items()}
difference=s.expand(means['p']-means['q'])
expected_coefficient = s.Rational(1, 2**17 if args.negative_control == 'coefficient' else 2**18)
require(difference==expected_coefficient*b**9, 'degree-nine coefficient must be exactly 2^-18')
# Bound D(beta)=integral (wp-wq) exp(beta sum wr) dH; |wp-wq|<=2.
P=len(faces);beta_ceiling=Q(1,10**14);a=Q(1,2**18)
relative=Q(2*P**11,factorial(11))*beta_ceiling**2/(1-P*beta_ceiling)/a
require(relative<Q(1,2), 'numerator relative remainder must be less than one-half')
report={'status':'PASS','verification':'explicit require/raise; checks survive Python -O','checks_executed':checks_executed,'scope':'3D free Haar Wilson box; reflection does not preserve full volume','box_vertices':'[0,5]^3 intersection Z^3','counts':counts,'plaquettes':P,'dominos':len(dominos),'sphere_integrals':sphere_data,'external_face_max_shared_cube_edges':max_shared_external_edges,'center_flip_all_faces':True,'t_series_through_11':str(t),'mean_series_through_9':{k:str(v) for k,v in means.items()},'difference_through_9':str(difference),'explicit_beta_ceiling':str(beta_ceiling),'numerator_remainder_relative_bound':str(relative),'numerator_remainder_bound_less_than_half':True}
print(json.dumps(report,indent=2))
