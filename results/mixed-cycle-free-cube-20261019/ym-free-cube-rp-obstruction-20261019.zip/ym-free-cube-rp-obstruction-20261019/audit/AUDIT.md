# Independent audit: a non-invariant free-box Wilson reflection witness

19 October 2026. This is a local mathematical audit, with no repository mutation, PR merge, or release.

## Verdict

**The proposed leading coefficient and finite-volume complex reflection-positivity failure check out.** With the definitions below,

\[
\langle w_p\rangle_\beta-\langle w_q\rangle_\beta
=2^{-18}\beta^9+O(\beta^{11}).
\]

For every sufficiently small positive coupling this difference is positive. The explicit interval \(0<\beta\le10^{-14}\) is certified by a deliberately crude Taylor bound. The bounded gauge-invariant observable \(F=1+iw_p\) then has a nonreal reflected form.

Two wording constraints are essential:

1. The reflection does **not** preserve the full box. This is a counterexample to extending reflection positivity to matched interior observables merely because both supports fit in an arbitrary free box. It is not a counterexample to standard Wilson reflection positivity on reflection-invariant finite volumes.
2. The simple explicit Taylor-remainder bound is a bound on the **unnormalized numerator difference**, which suffices for the sign because the partition function is positive. Do not identify it without further work with the remainder of the normalized mean difference.

The audit does not establish a negative real reflected form, a four-dimensional example, an infinite-volume failure, or any continuum or mass-gap statement.

## 1. Model, geometry, and observable

Let the vertex set be \(\Lambda=\{0,1,\ldots,5\}^3\). Include every nearest-neighbor edge and every elementary plaquette contained in this set. Each unoriented edge has one independent \(SU(2)\) variable with normalized Haar law; reversing orientation inverts it. For a plaquette \(r\), let

\[
w_r=\tfrac12\operatorname{tr}(U_r),\qquad
S=\sum_{r\in P(\Lambda)}w_r,\qquad
d\mu_\beta=Z(\beta)^{-1}e^{\beta S}\,dH.
\]

The trace is real, \(|w_r|\le1\), and there are \(P=3\cdot5^2\cdot6=450\) plaquettes. No boundary edge is fixed: all contained edges are integrated. This free-Haar convention is part of the statement.

Let \(p\) be the \((1,2)\)-plaquette based at \((3,2,2)\), and let \(q\) be its reflection through \(x_0=2\), based at \((1,2,2)\). Their vertices all lie strictly inside the geometric box. Every vertex of \(p\) is on the strict positive side, and every vertex of \(q\) on the strict negative side.

The geometric reflection \(\theta(x)=(4-x_0,x_1,x_2)\) sends the slab \(\{0,\ldots,4\}\times\{0,\ldots,5\}^2\) to itself but sends the full box to \(\{-1,\ldots,4\}\times\{0,\ldots,5\}^2\). Thus \(\Theta\) is defined here on cylinder observables whose supports and reflected supports are both contained, rather than as a geometric automorphism of the entire box configuration algebra. Equivalently, take the reflection-invariant slab subalgebra and the marginal of the full-box measure on it.

On this subalgebra, \(\Theta F=\overline{F\circ\theta}\). For \(F=1+iw_p\),

\[
(\Theta F)F=(1-iw_q)(1+iw_p)
=1+w_pw_q+i(w_p-w_q).
\]

A nonzero imaginary part contradicts the complex RP demand that every such quadratic form be a nonnegative real number. It establishes failure of Hermiticity on the two-dimensional span of \(1,w_p\); it does not by itself produce a negative value for a real observable.

## 2. Character normalization

Index \(SU(2)\) irreducibles by \(n=0,1,\ldots\), with spin \(n/2\), dimension \(n+1\), and character \(\chi_n\). In particular \(\chi_1=\operatorname{tr}\). Use the convention

\[
e^{\beta\chi_1/2}=\sum_{n\ge0}c_n(\beta)\chi_n,
\qquad
c_n(\beta)=\sum_{k\ge0}
\frac{(n+1)\beta^{n+2k}}
{2^{n+2k}k!(n+k+1)!}.
\]

These are the full character coefficients, not coefficients with the representation dimension factored out. Thus

\[
c_0=1+\beta^2/8+\cdots,\qquad
c_1=\beta/2+\beta^3/24+\cdots,\qquad
 t:=c_1/c_0=\beta/2-\beta^3/48+\cdots.
\]

Also \(c_0'=c_1/2\), so \(c_0'/c_0=t/2\). The exact coefficient formula follows directly from the \(SU(2)\) Weyl integral (equivalently \(c_n=2(n+1)I_{n+1}(\beta)/\beta\)). It agrees with the dimension-factored convention in the primary lecture source listed below after the factor \(n+1\) is restored.

## 3. Exhaustiveness through total coupling degree 10

Introduce separate plaquette couplings \(\beta_r\), and factor \(\prod_r c_0(\beta_r)\) out of the partition function. A character-label configuration \((n_r)\) starts in total degree \(\sum_r n_r\). Each subsequent degree increment is even.

### 3.1 Necessary edge rules

If an edge has just one incident nontrivially labelled plaquette, its Haar integral vanishes. If an edge has exactly two such plaquettes, their labels must agree, by character-matrix orthogonality (equivalently, the tensor product contains a singlet only for equal labels).

Changing one edge variable by the central element \(-I\) proves that the sum of incident labels must be even. Therefore the set \(O=\{r:n_r\text{ odd}\}\) is a cubical 2-cycle over \(\mathbb F_2\).

### 3.2 Possible odd support

A finite cubical 2-cycle in this box is the boundary of a finite set of unit cubes. If the enclosed set has \(V\) cubes, the discrete isoperimetric bound gives

\[
|\partial C|\ge 6V^{2/3}.
\]

For completeness, each nonempty coordinate line through the cube set contributes at least two boundary faces; hence the boundary is at least twice the sum of the three projection cardinalities. The discrete Loomis-Whitney inequality and AM-GM give the displayed bound. For \(V\ge3\), the bound exceeds 12, so the boundary cannot have at most 10 faces. For \(V=2\), nonadjacent cubes have 12 boundary faces and adjacent cubes have 10.

Consequently, a nonempty odd support with at most 10 faces is exactly a unit-cube boundary (6 faces) or an adjacent two-cube domino boundary (10 faces).

### 3.3 Empty odd support

If every nonzero label is even and the total label sum is at most 10, there are at most five supported faces. Any nonempty finite set of at most five elementary lattice faces has a free edge:

- A chosen face needs four distinct other faces to cover its four different edges, since two distinct unit lattice faces share at most one edge.
- If there are exactly five faces and no free edge, every pair must share an edge, since each face needs all four others.
- But the two faces covering opposite edges of the chosen square cannot share an edge with each other in the cubic lattice.

This is a contradiction. Hence every nontrivial all-even configuration of total degree at most 10 vanishes.

### 3.4 Cube odd support and added even labels

The six odd labels already cost six degrees. Through degree 10, at most two faces outside the cube boundary can have nonzero even labels. Every elementary face outside a unit-cube boundary shares at most one edge with that boundary. If one or two outside faces are added, each such face can share at most one additional edge with the other outside face, leaving a free edge. Such configurations vanish.

With no outside faces, every cube edge sees exactly two representations, so all six labels must be equal. The only possibility with total label sum at most 10 is that all six equal 1.

### 3.5 Domino odd support

Its ten odd labels exhaust the degree budget, so all ten labels equal 1 and all others equal 0.

These arguments exclude nonfundamental labels, disconnected surfaces, branched odd supports, and small even-label decorations at the claimed orders. The sole nontrivial configurations through degree 10 are therefore fundamental cube and domino boundaries. This conclusion is proved analytically; the script does not purport to enumerate arbitrary spin foams.

## 4. Surface integrals and partition expansion

For an orientable closed genus-zero plaquette surface with \(F\) faces carrying a common dimension-\(d\) character, each edge integration supplies \(d^{-1}\), and the remaining vertex index loops give \(d\). Therefore

\[
\int\prod_{r\in\Sigma}\chi_n(U_r)\,dH
=d^{V-E}=d^{2-F}.
\]

Here the cube has \((V,E,F)=(8,12,6)\), the domino has \((12,20,10)\), and \(d=2\), so the factors are respectively \(1/16\) and \(1/256\). The script checks all surface edge multiplicities and Euler characteristics in this finite box. Sphere orientations can always be chosen consistently, and changing a plaquette orientation does not change an \(SU(2)\) character.

Writing \(t_r=c_1(\beta_r)/c_0(\beta_r)\), the factored partition function is

\[
\widetilde Z(\boldsymbol\beta)
=1+\frac1{16}\sum_{C\text{ unit cube}}\prod_{r\in\partial C}t_r
 +\frac1{256}\sum_{D\text{ domino}}\prod_{r\in\partial D}t_r
 +O_{\mathrm{total}}(12).
\]

There is no total degree 11 contribution. One way to see exact evenness is to multiply each link in direction \(i\), based at \(x\), by \(\eta_i(x)=(-1)^{\sum_{j<i}x_j}\). Every plaquette changes sign, and Haar measure is unchanged. Thus \(Z(-\boldsymbol\beta)=Z(\boldsymbol\beta)\). The factored partition function has the same property.

## 5. Incidences and derivative

There are 125 unit cubes and 300 dominos. Both \(p\) and \(q\) belong to two unit-cube boundaries. For any interior face with two adjacent cubes, the domino-boundary incidence is

\[
(\deg C_- -1)+(\deg C_+ -1),
\]

because one must join one of its two adjacent cubes to a different cube, excluding the domino that crosses the face and makes it internal. Cube degree means the number of adjacent cubes retained in the free box.

For \(p\), both adjacent cubes have degree 6, giving \(5+5=10\). For \(q\), the adjacent cube based at \((0,2,2)\) has degree 5 while the one based at \((1,2,2)\) has degree 6, giving \(4+5=9\). The script independently enumerates these incidences.

Since \(\langle w_r\rangle=\partial_{\beta_r}\log Z\), differentiation before specialization to equal couplings gives

\[
\langle w_r\rangle
=\frac t2+\frac{N_C(r)}{16}t't^5
 +\frac{N_D(r)}{256}t't^9+O(\beta^{11}).
\]

At these orders replacing \(1/\widetilde Z\) by 1 is allowed: its first correction has degree 6, while the first numerator term has degree 5. Subtracting the formulas for \(p,q\) cancels the common local and cube terms:

\[
\langle w_p\rangle-\langle w_q\rangle
=\frac1{256}t't^9+O(\beta^{11})
=\frac{\beta^9}{2^{18}}+O(\beta^{11}).
\]

As an additional exact-rational consistency check, the individual expansions through degree 9 are

\[
\langle w_p\rangle=\frac\beta4-\frac{\beta^3}{96}
+\frac{\beta^5}{384}-\frac{\beta^7}{1440}
+\frac{3127\beta^9}{17694720}+O(\beta^{11}),
\]

\[
\langle w_q\rangle=\frac\beta4-\frac{\beta^3}{96}
+\frac{\beta^5}{384}-\frac{\beta^7}{1440}
+\frac{6119\beta^9}{35389440}+O(\beta^{11}).
\]

## 6. An explicit positive-coupling interval

Use the unnormalized difference

\[
D(\beta)=\int(w_p-w_q)e^{\beta S}\,dH.
\]

Since \(Z(0)=1\), the above result gives \(D(\beta)=a\beta^9+O(\beta^{11})\), where \(a=2^{-18}\). The center change of variables shows that \(D\) is odd. Taylor's theorem through degree 10, \(|w_p-w_q|\le2\), and \(|S|\le450\) yield, for \(\beta\ge0\),

\[
|D(\beta)-a\beta^9|
\le\frac{2\,450^{11}}{11!}e^{450\beta}\beta^{11}.
\]

Put \(b=10^{-14}\). Since \(e^x\le(1-x)^{-1}\) for \(0\le x<1\), throughout \(0<\beta\le b\) the relative remainder is bounded by the exact rational number

\[
\frac{2\,450^{11}b^2}{11!a(1-450b)}
=\frac{30993639120000}{153999999999307}<\frac12.
\]

Thus \(D(\beta)>a\beta^9/2>0\), and \(D/Z>0\) because \(Z>0\). This proves the nonreal reflected form on that explicit interval. The bound is intentionally coarse; it is not intended as a useful coupling threshold.

## 7. Scope and sources

This is an interacting, isotropic, three-dimensional Wilson measure at positive coupling on a fully three-dimensional free cube. The witness is gauge invariant, bounded, and strictly interior with its reflected support also strictly interior. Nevertheless, the boundary is asymmetric with respect to the chosen off-center reflection. The finite correction detects that boundary asymmetry.

No conclusion about a different reflection, a centered invariant box, periodic boundary conditions, dimension four, an infinite-volume limit, all positive couplings, a continuum limit, or a Yang-Mills mass gap follows. In particular, the boundary-driven discrepancy could disappear in an infinite-volume limit.

Primary-source normalization cross-check: M. Caselle's lattice-gauge lecture notes, character-expansion appendix, state the Wilson plaquette character expansion and discuss full coefficients versus representation-dimension-normalized coefficients: https://www.eoinfnpr.it/SNFT_PISTP/1999/Caselle/Caselle.pdf . The actual audit above derives the needed coefficients and exclusions directly rather than importing a strong-coupling table.

Primary bibliographic RP scope reference: P. Menotti and A. Pelissetto, “General proof of Osterwalder-Schrader positivity for the Wilson action,” Communications in Mathematical Physics 113 (1987), 369–373, DOI https://doi.org/10.1007/BF01221251 ; bibliographic abstract https://inspirehep.net/literature/244772 . This source concerns Wilson positivity, including site-containing reflection planes; the current off-center non-invariant-volume calculation does not contradict that theorem.

Reproducibility: run `python audit_exact.py`. Exact rational and combinatorial output is in `CHECKS.json`. Numerical group integration is not used.

### Verification hardening, 19 October 2026

The executable verifier now uses explicit `require` checks that raise `RuntimeError`; verification does not depend on Python assertions. Normal execution and `python -O audit_exact.py` each execute 858 checks and produce byte-identical reports (`CHECKS.json` and `CHECKS.optimized.json`). The `--negative-control incidence` and `--negative-control coefficient` modes deliberately corrupt one expected value; both are rejected with nonzero exit status in normal and optimized execution. The four results are recorded in `NEGATIVE_CONTROLS.json`. The earlier assertion-based script and output are retained as historical files with `assert-original` in their names; they are not the hardened verifier.
