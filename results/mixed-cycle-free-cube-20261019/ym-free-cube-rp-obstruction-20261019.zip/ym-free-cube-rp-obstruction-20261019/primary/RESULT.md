# A finite free-box obstruction to simultaneous-cut RP

19 October 2026. Fixed lattice spacing. **Three-dimensional SU(2) Wilson theory only for the new explicit example below.** Research and local verification; no external publication.

## Result and route decision

A finite free cube can fail a displaced coordinate-site reflection test even when the observable and its reflected observable are both strictly inside the cube. This is an actual interacting SU(2) Wilson example, not a scalar Gaussian or pressure countermodel.

Let K be the full free cubical complex on vertices {0,...,5}^3, with every contained link and elementary plaquette and normalized independent Haar link measure. Let

    d mu_beta = Z_beta^(-1) exp(beta sum_f w_f) d Haar,
    w_f = (1/2) Tr U_f,       beta >= 0.

Let p be the (1,2)-plaquette based at (3,2,2), and q the (1,2)-plaquette based at (1,2,2). Reflection r(x0,x1,x2)=(4-x0,x1,x2), through the coordinate site plane x0=2, sends p to q. Both entire plaquette boundaries lie strictly inside K. The reflection r is not an automorphism of the whole box K. To make the reflected form precise, use the marginal algebra on the reflection-invariant slab K'={0,...,4} x {0,...,5}^2, or equivalently only observables whose original and reflected supports both belong to K. On that slab algebra, Theta F=conjugate(F composed with r) is well defined. Then

    mu_beta(w_p)-mu_beta(w_q)
       = beta^9 / 262144 + O(beta^11),                 (1)

as beta tends to zero. In particular the difference is strictly positive for all sufficiently small positive beta. The deliberately crude fully explicit interval

    0 < beta <= 10^(-14)                              (2)

also works, as certified below.

With the bounded gauge-invariant observable F=1+i w_p, supported strictly in the positive half x0>2,

    mu_beta((Theta F)F)
      = 1 + mu_beta(w_q w_p)
          + i [mu_beta(w_p)-mu_beta(w_q)].             (3)

It is not real and therefore is not a nonnegative real number. Thus the proposed RP inequality fails on a test whose original and reflected supports both fit inside the finite free cube. This is a **non-Hermitian reflected-form certificate on that slab algebra**, not a claim of a negative real reflected norm for a real-valued F.

This closes only the exact finite-volume shortcut “put all required test supports into one large free cube and inherit each displaced reflection inequality.” It does **not** rule out joint approximate RP, a common infinite-volume state, or a boundary-comparison theorem. In fact, sufficiently small beta belongs to the already-established uniqueness regime, where the infinite-volume joint-RP limit can exist while these finite-box defects vanish. The new example does not settle the four-dimensional state-selection problem.

## 1. SU(2) character expansion with exact degree bookkeeping

Write chi_n for the spin n/2 character, of dimension n+1, so w=chi_1/2. For a real or complex plaquette parameter b,

    exp(b w(g)) = sum_(n>=0) c_n(b) chi_n(g),

where

    c_n(b) = sum_(k>=0)
      (n+1) b^(n+2k) / [2^(n+2k) k! (n+k+1)!].         (4)

This follows by integrating against the SU(2) character with Haar angle measure (2/pi) sin^2(theta) dtheta, or by the elementary Bessel-series identity. In particular,

    c_0(b)=1+O(b^2),   c_1(b)=b/2+O(b^3),
    c_n(b)=b^n/(2^n n!)+O(b^(n+2)).

Put t(b)=c_1(b)/c_0(b). The finite-volume integrals are entire in all finitely many plaquette parameters; the character series is absolutely and uniformly convergent on compact parameter sets. For a Taylor coefficient through total degree 10, only face labels with sum_f n_f <= 10 can matter.

A necessary condition for a character product to have a nonzero Haar integral is that the sum of its n_f labels around each link is even. Indeed changing that link variable U_e to -U_e multiplies the integrand by (-1)^(sum n_f) while preserving Haar measure. Therefore the support of odd-labeled plaquettes is a finite mod-2 cubical 2-cycle.

A second necessary condition is that every link incident to a nontrivial face representation is incident to at least two such faces. A link occurring in just one nontrivial character integrates to zero by matrix-coefficient orthogonality.

## 2. Complete classification through total degree 10 in three dimensions

Every finite mod-2 2-cycle in the full cubical lattice Z^3 is the boundary of a unique finite set of unit 3-cubes. For completeness, the usual discrete isoperimetric estimate for a finite cube set A is

    |boundary A| >= 6 |A|^(2/3).                       (5)

One proof counts at least two exposed faces per occupied line in each coordinate direction and uses the discrete Loomis-Whitney inequality |A|^2 <= |pi_01 A| |pi_02 A| |pi_12 A|, followed by the arithmetic-geometric mean inequality. Thus a nonempty cycle with at most 10 plaquettes encloses at most two cubes. It is either one elementary cube boundary (6 faces), or the boundary of two face-adjacent cubes (10 faces). Two nonadjacent cubes have at least 12 boundary faces.

The following details exclude lower-degree spin-network loopholes.

- If the odd-label support is empty, every nonzero label is at least 2. Through degree 10 there can be at most five nontrivial faces. Any nonempty finite set of at most five lattice squares has a free edge, so its Haar integral vanishes. To see the latter assertion: with at most four squares, any selected square has fewer than four possible distinct neighbors for its four edges. With exactly five and no free edge, each square would have to share its four different edges with the other four squares. Neighbors attached to two opposite edges of a square cannot themselves share a lattice edge, contradicting this requirement.
- If the odd-label support is one cube boundary, the remaining degree budget is at most four. There can be at most two additional even-labeled faces. A square outside that cube boundary shares at most one edge with it; at most one further extra square can meet it on another edge. It therefore still has a free edge and the contribution is zero. Without such extra faces, each edge of the cube surface meets exactly two nontrivial representations; Haar orthogonality forces their labels to agree. Connectivity forces all six labels equal. Any odd label at least 3 costs at least 18. Thus all six labels must be 1.
- If the odd-label support is the 10-face boundary of a two-cube domino, degree 10 forces every label to be exactly 1 and forbids any additional nontrivial face.

Consequently only fundamental elementary-cube surfaces and fundamental domino-boundary surfaces can contribute nontrivially through degree 10.

For a cellulated spherical surface with F faces, Haar orthogonality gives

    integral product_(f in surface) chi_1(U_f) d Haar
       = 2^(2-F).                                    (6)

A direct verification is to fix a spanning tree of its vertices, integrate successive internal edges using the matrix-coefficient orthogonality identity, and apply Euler's formula V-E+F=2. Equivalently, gluing two disks uses character convolution and gives one factor 1/2 for each additional face after the first two. Both the cube and domino boundary are such spheres. Thus their integrals are 1/16 and 1/256, respectively. Links outside the surface do not enter the integrand and integrate to 1.

Combining the complete classification and (6), with an independent source b_f at every face, gives the multivariate Taylor identity

    Z({b_f}) / product_f c_0(b_f)
      = 1
        + (1/16) sum_elementary-cubes C product_(f in boundary C) t(b_f)
        + (1/256) sum_dominos D product_(f in boundary D) t(b_f)
        + O_total(12).                               (7)

Here O_total(12) denotes an analytic remainder whose Taylor monomials have total degree at least 12. There is no degree-11 term: all face labels contributing nontrivially have even total degree, since any odd-label 2-cycle is a cube-set boundary with an even number of faces; (4) adds only even powers.

## 3. The two strictly interior plaquettes have unequal counts

For the specified p and q, each lies in exactly two elementary cube boundaries. Therefore the first nontrivial terms in their source derivatives of (7) cancel identically, including all higher terms in the common analytic function t.

A domino boundary contains a plaquette exactly when it contains one of its incident cubes and the second cube is a face-neighbor other than across that plaquette. For p, both incident cubes lie at normal coordinates 2 and 3, and all five permissible neighbors of each are present: there are 10 dominos. For q, the incident cube at normal coordinate 0 lacks its outward normal neighbor, whereas the cube at normal coordinate 1 has all five: there are 9 dominos. All tangential coordinates are 2, so none of these tangential neighbors is omitted by the free box.

Differentiate (7) in b_p and b_q, subtract, then set every b_f=beta. The baseline derivatives cancel. The cube terms cancel because their incidence counts agree. The domino terms give

    (partial_b_p Z - partial_b_q Z)|_(all beta)
      = [product_f c_0(beta)]
          [ t'(beta) t(beta)^9 / 256 + O(beta^11) ]
      = beta^9 / 2^18 + O(beta^11).                   (8)

Terms differentiating the common product of c_0's cancel as well, since both source derivatives of that product have the same uniform-beta value. Since Z_beta=1+O(beta^2)>0, division by Z_beta proves (1).

## 4. Explicit positive interval without numerical integration

There are P=3*5^2*6=450 plaquettes. Write

    N(beta) = integral (w_p-w_q) exp(beta S) d Haar,
    S=sum_f w_f,       |S|<=P,       |w_p-w_q|<=2.

Equation (8) says its coefficients below degree 9 vanish, its degree-9 coefficient is a=2^(-18), and its degree-10 coefficient vanishes. Taylor's remainder therefore satisfies, for beta>=0,

    |N(beta)-a beta^9| <= 2 (P beta)^11 exp(P beta)/11!.

For b=10^(-14), exp(P beta)<=1/(1-P b) on 0<=beta<=b, and exact rational arithmetic gives

    2 P^11 b^2 / [11! (1-P b) a]
       = 30993639120000 / 153999999999307
       < 1/2.

Hence N(beta) >= a beta^9/2>0 on (2), proving the stated RP failure on that interval. The bound is intentionally very conservative and does not estimate the true size of the parameter interval.

## 5. Verification and exact scope

- `check_cube_incidence.py` independently enumerates every elementary cube and face-adjacent cube pair in the free 5^3 box, verifies the counts 2/2 and 10/9, verifies the reflected coordinates, checks that all vertices of both plaquettes are strictly interior, and checks the remainder inequality with exact fractions. Output: `CUBE_CHECKS.json`.
- `check_tube.py` provides a separate exact character-transfer check on unit-width free tubes. Its 5-cube case independently gives the same coefficient beta^9/2^18, and longer cases check coefficients at longitudinal depths 2 and 3. Output: `CHECKS.json`. This is supplementary evidence, not a replacement for the full-cube character-surface proof.
- The tube reduction integrates the four side plaquettes of each slab to a cylinder kernel K(g,h)=sum_n (c_n/(n+1))^4 chi_n(g)chi_n(h). Internal cap integrals use the exact SU(2) fusion rule chi_a chi_b=sum_(k=|a-b|,step2)^(a+b) chi_k. All retained calculations use rational arithmetic; omitted labels start beyond the requested Taylor order. No Monte Carlo evidence is used.
- The new 3D cube theorem is not asserted for the 4D full cube without a fresh character-surface classification. Embedding the 3D free complex as a subcomplex of Z^4 is possible, but is not the same as a full 4D free-volume approximation.
- The fixed cube has minimum boundary distances 1 and 2 for the two plaquettes. The report does not claim failure at arbitrary distance from every boundary. Supplementary tube checks of greater longitudinal depth retain fixed transverse width and are not arbitrarily deep full-cube examples.
- Complex RP on the specified reflection-invariant slab algebra requires a Hermitian reflected form, so (3) is decisive for that proposed property. It does not settle positivity restricted only to selected real observables or selected connected covariance matrices.

Independent review: the separate mathematical and exact-arithmetic audit in `../free-cube-rp-audit-20261019-1320/AUDIT.md` passed the degree-at-most-10 classification, sphere factors, coefficient, and explicit remainder interval. Its recommended clarification of the reflection domain has been incorporated above.

## 6. Dedupe and remaining research target

The pinned own repository at 4ff17ed90aa40a453129d1d0b9cea0bf483c949a was read directly. Relevant exact sources are recorded in `SOURCE_MANIFEST.json`.

Already available and not claimed new here:

1. `invariant-diagonal-rp/construction/RESULT.md`: existence at every finite nonnegative beta of a gauge/translation-invariant Gibbs state RP for one chosen parallel diagonal family.
2. `tilted-volume-compatibility/RESULT.md`, Section 4: no full-rank period lattice supplies both standard separating coordinate and diagonal cuts.
3. Existing local `wilson-simultaneous-rp-20261018/RESULT.md`: common-center free-cube RP, the closed-convex finite-intersection gap, and an exact spin averaging counterexample.
4. `strong-coupling-seam/PROOF.md`: the explicit 18 beta<1 comparison/uniqueness regime. Its joint-RP corollary is routine and is not a new advance.
5. `source-pressure-scope/RESULT.md`: the unproved source differentiability/zero-free bridge and its separate scope restrictions.

The remaining all-beta four-dimensional task is to produce a common selected state or prove joint approximate RP for every finite list of affine cuts and local tests while local DLR defects tend to zero. Common-center exact RP and one-orientation all-parallel RP still do not supply that premise. The new result makes one incorrect exact finite-cube substitute impossible, but supplies neither a common state nor a quantitative large-box defect estimate. Research should therefore move to a genuinely uniform state-selection/local-boundary-comparison input rather than another period-lattice or naive symmetry-averaging variant.
