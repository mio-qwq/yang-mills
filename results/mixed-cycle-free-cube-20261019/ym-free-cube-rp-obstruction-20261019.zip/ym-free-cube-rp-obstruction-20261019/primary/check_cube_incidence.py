#!/usr/bin/env python3
"""Exact 3D free-cube geometry and rational remainder certificate."""
from itertools import product
from fractions import Fraction as Q
from math import factorial
import json

def require(condition, message):
    if not condition:
        raise RuntimeError(message)

def plus(x,i,a=1):
    x=list(x);x[i]+=a;return tuple(x)
def face(x,i,j):return (x,tuple(sorted((i,j))))
def cell_faces(x):
    out=set()
    for normal in range(3):
        ij=tuple(i for i in range(3) if i!=normal)
        out.add(face(x,*ij));out.add(face(plus(x,normal),*ij))
    return out
L=5
cells=set(product(range(L),repeat=3))
cubes={x:cell_faces(x) for x in cells}
p=face((3,2,2),1,2);q=face((1,2,2),1,2)
dominos=[]
for x in cells:
    for axis in range(3):
        y=plus(x,axis)
        if y in cells:
            bd=cubes[x]^cubes[y]
            require(len(bd)==10, f"Domino {x}, {y} does not have ten boundary faces")
            dominos.append((x,y,bd))
counts={}
for name,f in [('positive',p),('reflected',q)]:
    counts[name]={'face':f,'cube_count':sum(f in fs for fs in cubes.values()),'domino_boundary_count':sum(f in z[2] for z in dominos)}
require(counts['positive']['cube_count']==counts['reflected']['cube_count']==2, 'Expected two cube boundaries at each plaquette')
require(counts['positive']['domino_boundary_count']==10, 'Expected ten domino boundaries at the positive plaquette')
require(counts['reflected']['domino_boundary_count']==9, 'Expected nine domino boundaries at the reflected plaquette')
# Reflection x0 -> 4-x0 fixes the plane x0=2 and maps p to q.
require((4-p[0][0],p[0][1],p[0][2])==q[0], 'Specified reflection does not map the positive plaquette to its partner')
# All vertices of both plaquettes are in the strict interior of [0,5]^3.
for f in [p,q]:
    x,ij=f
    for bits in product([0,1],repeat=2):
        v=x
        for i,a in zip(ij,bits):v=plus(v,i,a)
        require(all(0<v_i<L for v_i in v), f'Plaquette vertex {v} is not strictly interior')
P=3*L*L*(L+1)
b=Q(1,10**14)
a9=Q(1,2**18)
# |R_11| / (a9 beta^9) <= this rational number on 0<beta<=b.
# exp(P beta) <= 1/(1-P b), valid since P b<1.
require(P*b<1, 'Exponential upper bound requires P*b<1')
ratio=Q(2*P**11,factorial(11))*b*b/(1-P*b)/a9
require(ratio<Q(1,2), 'Taylor remainder ratio is not below one half')
out={'dimension':3,'side_cells':L,'plaquettes':P,'cube_count':len(cells),'domino_count':len(dominos),'reflection_plane':'x0=2','strictly_interior':True,'counts':counts,'mean_difference_leading_degree':9,'mean_difference_leading_coefficient':str(a9),'explicit_beta_ceiling':str(b),'remainder_relative_bound':str(ratio),'remainder_below_half':True}
print(json.dumps(out,indent=2))
