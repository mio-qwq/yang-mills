#!/usr/bin/env python3
"""Exact SU(2) character transfer series for a finite open unit-width tube.
No repository code or numerical group integral is used.
"""
from fractions import Fraction as Q
from math import factorial
import json

def require(condition, message):
    if not condition:
        raise RuntimeError(message)

def run(L, order, first, second):
    require(L>=1 and 0<=first<second<=L, "Invalid tube length or insertion sites")
    require(order%2==0 and order>=4*(first+1)+1, "Use an even truncation order above the expected leading degree")
    N=order
    zero=lambda:[Q(0)]*(N+1)
    def const(v):
        a=zero();a[0]=Q(v);return a
    def add(a,b):return [x+y for x,y in zip(a,b)]
    def mul(a,b):
        c=zero()
        for i,x in enumerate(a):
            if x:
                for j,y in enumerate(b[:N+1-i]):
                    if y:c[i+j]+=x*y
        return c
    def power(a,n):
        r=const(1)
        for _ in range(n):r=mul(r,a)
        return r
    def deriv(a):return [Q(k+1)*a[k+1] for k in range(N)]+[Q(0)]
    def char(n):
        a=zero()
        for k in range((N-n)//2+1):
            a[n+2*k]=Q(n+1,2**(n+2*k)*factorial(k)*factorial(n+k+1))
        return a
    # If 4n > N+1 then a nonzero edge label n cannot affect the
    # numerator through degree N, even allowing one source derivative.
    nmax=(N+1)//4
    cs=[char(n) for n in range(2*nmax+1)]
    edge=[power([x/Q(n+1) for x in cs[n]],4) for n in range(nmax+1)]
    M=[[sum_polys([cs[k] for k in range(abs(a-b),a+b+1,2)],add,zero) for b in range(nmax+1)] for a in range(nmax+1)]
    def partition(insert=None):
        vec=[mul(deriv(cs[n]) if insert==0 else cs[n],edge[n]) for n in range(nmax+1)]
        for site in range(1,L):
            vec=[mul(sum_polys([mul(vec[a],deriv(M[a][b]) if insert==site else M[a][b]) for a in range(nmax+1)],add,zero),edge[b]) for b in range(nmax+1)]
        return sum_polys([mul(vec[n],deriv(cs[n]) if insert==L else cs[n]) for n in range(nmax+1)],add,zero)
    z=partition()
    nums=[partition(t) for t in range(L+1)]
    diff=[a-b for a,b in zip(nums[second],nums[first])]
    # Numerator difference suffices because Z is strictly positive.
    coeffs={str(k):str(v) for k,v in enumerate(diff) if v}
    require(all(nums[t]==nums[L-t] for t in range(L+1)), f'Tube length {L} violates exact midpoint reflection symmetry')
    require(z[0]==1, f'Tube length {L} has incorrect Haar partition constant')
    require(bool(coeffs), f'Tube length {L} has no detected numerator difference')
    expected_degree=4*(first+1)+1
    expected=Q(1,2**(8*(first+1)+2))
    require(min(map(int,coeffs))==expected_degree, f'Tube length {L} has unexpected leading degree: {coeffs}')
    require(diff[expected_degree]==expected, f'Tube length {L} has unexpected leading coefficient: {coeffs}')
    return {'length':L,'order':N,'first_site':first,'second_site':second,'numerator_difference_coefficients':coeffs,'leading_degree':expected_degree,'leading_coefficient':str(expected),'reflection_check':True,'Z0':str(z[0])}

def sum_polys(ps,add,zero):
    s=zero()
    for p in ps:s=add(s,p)
    return s

if __name__=='__main__':
    reports=[run(3,10,0,2),run(5,12,1,3),run(7,16,2,4),run(9,20,3,5)]
    out={'method':'Exact rational SU(2) character series; n labels cut only when minimum degree is above truncation','reports':reports}
    print(json.dumps(out,indent=2))
