#!/usr/bin/env python3
"""Build a byte-reproducible ZIP_STORED archive from this exact package."""
import argparse
import hashlib
import json
import pathlib
import subprocess
import sys
import zipfile

ROOT = pathlib.Path(__file__).resolve().parents[1]
ARCHIVE_PREFIX = 'ym-general-angular-rigidity-20261019'


def rebuild(output):
    output = output.resolve()
    if output == ROOT or ROOT in output.parents:
        raise RuntimeError('Write the archive outside the package directory')
    subprocess.run([sys.executable, '-I', '-B', str(ROOT / 'tools/verify_package.py')], check=True, capture_output=True)
    with zipfile.ZipFile(output, 'w', compression=zipfile.ZIP_STORED) as archive:
        for path in sorted(ROOT.rglob('*')):
            if not path.is_file():
                continue
            relative = path.relative_to(ROOT).as_posix()
            info = zipfile.ZipInfo(ARCHIVE_PREFIX + '/' + relative, date_time=(2026, 10, 19, 0, 0, 0))
            info.compress_type = zipfile.ZIP_STORED
            info.create_system = 3
            info.external_attr = 0o100644 << 16
            info.extra = b''
            info.comment = b''
            archive.writestr(info, path.read_bytes())
    data = output.read_bytes()
    return {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest(), 'entries': len(zipfile.ZipFile(output).infolist()), 'method': 'ZIP_STORED, sorted paths, fixed UTC-independent metadata'}


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('output', type=pathlib.Path)
    arguments = parser.parse_args()
    print(json.dumps(rebuild(arguments.output), indent=2, sort_keys=True))
