#!/usr/bin/env python3
"""Verify complete file inventory and SHA-256 pins using only the standard library."""
import hashlib
import json
import pathlib
import sys

ROOT = pathlib.Path(__file__).resolve().parents[1]


def verify(root=ROOT):
    manifest = json.loads((root / 'MANIFEST.json').read_text())
    entries = manifest['files']
    names = [entry['path'] for entry in entries]
    if len(names) != len(set(names)):
        raise RuntimeError('Duplicate manifest entry')
    actual = sorted(str(path.relative_to(root)) for path in root.rglob('*') if path.is_file())
    if actual != sorted(names + ['MANIFEST.json']):
        raise RuntimeError('File inventory mismatch')
    for entry in entries:
        relative = pathlib.PurePosixPath(entry['path'])
        if relative.is_absolute() or '..' in relative.parts:
            raise RuntimeError('Unsafe manifest path')
        path = root / relative
        if path.is_symlink():
            raise RuntimeError('Symlink not permitted')
        data = path.read_bytes()
        if len(data) != entry['bytes'] or hashlib.sha256(data).hexdigest() != entry['sha256']:
            raise RuntimeError('Hash or size mismatch: ' + str(relative))
    return {'status': 'PASS', 'verified_files': len(entries), 'manifest_sha256': hashlib.sha256((root / 'MANIFEST.json').read_bytes()).hexdigest()}


if __name__ == '__main__':
    try:
        print(json.dumps(verify(), indent=2, sort_keys=True))
    except (OSError, ValueError, KeyError, RuntimeError) as error:
        print(str(error), file=sys.stderr)
        raise SystemExit(1)
