#!/usr/bin/env python3
"""Replay preserved local algebra checkers in clean directories; no theorem proving."""
import hashlib
import json
import pathlib
import platform
import subprocess
import sys
import tempfile

ROOT = pathlib.Path(__file__).resolve().parents[1]


def require(condition, message):
    if not condition:
        raise RuntimeError(message)


def run(script, optimized, cwd):
    command = [sys.executable, '-I', '-B']
    if optimized:
        command.append('-O')
    command.append(str(script))
    process = subprocess.run(command, cwd=cwd, capture_output=True, timeout=120)
    return {
        'optimized': optimized,
        'returncode': process.returncode,
        'stdout': process.stdout.decode(),
        'stderr': process.stderr.decode(),
        'stdout_sha256': hashlib.sha256(process.stdout).hexdigest(),
    }


def replay():
    cases = {
        'primary': ('checks/check_exact.py', 'reference-results/primary-normal.json'),
        'audit': ('checks/check_algebra.py', 'reference-results/audit-original.txt'),
    }
    mutations = {
        'primary': [
            ('upper_residue', "check('upper_residue',1/(2*At*w+2*Bt)+i/(2*r))", "check('upper_residue',1/(2*At*w+2*Bt)-i/(2*r))"),
            ('jensen_exact_defect', "check('jensen_exact_defect',1/t-1/K+(t-K)/K**2-(t-K)**2/(K**2*t))", "check('jensen_exact_defect',1/t-1/K-(t-K)/K**2-(t-K)**2/(K**2*t))"),
            ('hessian_first_moment', "check('hessian_first_moment',hessian_moment-(C/A**2-4*B**2/A**3))", "check('hessian_first_moment',-hessian_moment-(C/A**2-4*B**2/A**3))"),
        ],
        'audit': [
            ('rotation_discriminant', "on_unit_circle(A*C-B*B-t)", "on_unit_circle(A*C-B*B+t)"),
            ('original_root_modulus', "-(1+tau*(a*a+b*b)))==0", "+(1+tau*(a*a+b*b)))==0"),
            ('circle_locus', "on_unit_circle(x*x+y2-1+((c*c-s*s)/(s*c))*x)", "on_unit_circle(x*x+y2-1-((c*c-s*s)/(s*c))*x)"),
            ('root_monotonicity', "on_unit_circle(S.diff(x,t)+s*c/(A*A))", "on_unit_circle(S.diff(x,t)-s*c/(A*A))"),
            ('angular_generating_formula', "S.factor(2*G/(1+h)-1/(1+(h*h-1)*t*t))==0", "S.factor(2*G/(1+h)+1/(1+(h*h-1)*t*t))==0"),
        ],
    }
    results = {}
    with tempfile.TemporaryDirectory(prefix='ym-algebra-clean-') as directory:
        clean = pathlib.Path(directory)
        for name, (script_path, expected_path) in cases.items():
            source = (ROOT / script_path).read_bytes()
            expected = (ROOT / expected_path).read_bytes()
            script = clean / (name + '.py')
            script.write_bytes(source)
            baseline = [run(script, mode, clean) for mode in (False, True)]
            for result in baseline:
                require(result['returncode'] == 0, name + ' baseline failed')
                require(result['stderr'] == '', name + ' unexpected stderr')
                require(result['stdout'].encode() == expected, name + ' differs from preserved expected output')
            require(baseline[0]['stdout'] == baseline[1]['stdout'], name + ' optimization mismatch')
            if name == 'primary':
                data = json.loads(baseline[0]['stdout'])
                require(data['status'] == 'passed' and data['count'] == 31, 'Primary result shape mismatch')
                rejected = [item for item in data['checks'] if item.startswith('rejected_')]
                require(len(rejected) == 3 and len(data['checks']) - len(rejected) == 28, 'Primary counts mismatch')
                require(set(rejected) == {'rejected_wrong_upper_residue', 'rejected_wrong_jensen_sign', 'rejected_wrong_hessian_sign'}, 'Primary controls mismatch')
            else:
                require(len(baseline[0]['stdout'].splitlines()) == 5, 'Audit check count mismatch')
                require(all(line.endswith(' PASS') for line in baseline[0]['stdout'].splitlines()), 'Audit result failed')
            negative = []
            for check, old, new in mutations[name]:
                original = source.decode()
                require(original.count(old) == 1, 'Mutation anchor is not unique: ' + check)
                mutated = clean / (name + '_mutant_' + check + '.py')
                mutated.write_text(original.replace(old, new, 1))
                for mode in (False, True):
                    result = run(mutated, mode, clean)
                    require(result['returncode'] != 0, name + ' mutant escaped: ' + check)
                    output = result['stdout'] + result['stderr']
                    marker = ('RuntimeError: ' + check + ': nonzero residual') if name == 'primary' else (check + ' FAIL')
                    require(marker in output, 'Unexpected mutant failure: ' + check)
                    # Traceback file paths are temporary and nondeterministic; retain only
                    # the exact decisive error line instead of the entire traceback.
                    result['stderr'] = '\n'.join(line for line in result['stderr'].splitlines() if line.startswith('RuntimeError:'))
                    result['mutation'] = check
                    result['expected_rejection'] = True
                    negative.append(result)
            results[name] = {'baseline_runs': baseline, 'external_corruption_runs': negative}
    version = subprocess.run([sys.executable, '-I', '-B', '-c', 'import sympy; print(sympy.__version__)'], capture_output=True, text=True, check=True).stdout.strip()
    return {
        'status': 'PASS',
        'scope': 'Exact algebra and validation regressions only; no analytic theorem certification.',
        'python_version': platform.python_version(),
        'sympy_version': version,
        'clean_temporary_directory': True,
        'isolated_python_mode': True,
        'optimization_independent': True,
        'primary_valid_checks_per_mode': 28,
        'primary_builtin_rejections_per_mode': 3,
        'audit_valid_checks_per_mode': 5,
        'external_mutation_variants': 8,
        'external_corruption_runs_rejected': 16,
        'results': results,
    }


if __name__ == '__main__':
    print(json.dumps(replay(), indent=2, sort_keys=True))
