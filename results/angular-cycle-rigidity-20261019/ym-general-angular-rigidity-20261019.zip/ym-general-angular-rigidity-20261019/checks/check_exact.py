#!/usr/bin/env python3
"""Exact algebra checks only; these do not replace the analytic proof."""
import json,sys
import sympy as S
r,z,u,K,t,A,B,C,eps=S.symbols('r z u K t A B C eps', positive=True, real=True)
i=S.I
checks=[]
def check(name, expr):
    value=S.factor(S.cancel(S.together(expr)))
    if value != 0:
        raise RuntimeError(f'{name}: nonzero residual {value}')
    checks.append(name)
At=(1+r*r*z*z)/(1+z*z)
Bt=z*(r*r-1)/(1+z*z)
Ct=(z*z+r*r)/(1+z*z)
w=(z*(1-r*r)+i*r*(1+z*z))/(1+r*r*z*z)
check('rotated_discriminant',At*Ct-Bt*Bt-r*r)
check('upper_pole',At*w*w+2*Bt*w+Ct)
check('upper_derivative',2*At*w+2*Bt-2*i*r)
check('upper_residue',1/(2*At*w+2*Bt)+i/(2*r))
x=z*(1-r*r)/(1+r*r*z*z)
y=r*(1+z*z)/(1+r*r*z*z)
check('circle',x*x+y*y-1-(z*z-1)*x/z)
check('cayley_upper',(w-i)/(w+i)-(1-r)/(1+r)*(z-i)/(z+i))
wb=S.conjugate(w)
check('cayley_lower_reciprocal',(wb-i)/(wb+i)-1/S.conjugate((w-i)/(w+i)))
check('jensen_exact_defect',1/t-1/K+(t-K)/K**2-(t-K)**2/(K**2*t))
f=(1/(A+2*B*eps+C*eps**2)+1/(A-2*B*eps+C*eps**2))/2
hessian_moment=-S.diff(f,eps,2).subs(eps,0)/2
check('hessian_first_moment',hessian_moment-(C/A**2-4*B**2/A**3))
mass=S.limit(u*u*(1/(A*u*u+2*B*u+C)+1/(A*u*u-2*B*u+C))/2,u,S.oo)
check('mass_asymptotic',mass-1/A)
large_moment=S.limit(u*u*(1/A-u*u*(1/(A*u*u+2*B*u+C)+1/(A*u*u-2*B*u+C))/2),u,S.oo)
check('moment_asymptotic',large_moment-hessian_moment)
c0=S.symbols('c0',positive=True)
p1,p2,p3,p4=S.symbols('p1 p2 p3 p4',real=True)
p=S.Matrix([p1,p2,p3,p4])
q=sum(a*a for a in p)
Fr=c0/q
H=S.hessian(Fr,p)
H1=H.subs({p1:1,p2:0,p3:0,p4:0})
for j in (1,2,3):
    check(f'isotropic_hessian_{j}',-H1[j,j]/2-c0)
for j in (1,2,3):
    for k in (1,2,3):
        if j!=k: check(f'isotropic_mixed_{j}_{k}',H1[j,k])
np=S.Matrix([1,1,0,0])/S.sqrt(2)
nm=S.Matrix([1,-1,0,0])/S.sqrt(2)
e3=S.Matrix([0,0,1,0]);e4=S.Matrix([0,0,0,1])
for name,n in [('plus',np),('minus',nm)]:
    other=nm if name=='plus' else np
    T=S.Matrix.hstack(other,e3,e4)
    if T.T*T!=S.eye(3) or n.T*T!=S.zeros(1,3):
        raise RuntimeError('diagonal tangent basis failed')
    checks.append('diagonal_tangent_basis_'+name)
for rv,zv in [(S.Rational(1,2),S.Rational(1,3)),(S.Rational(3,2),S.Rational(2)),(S.Rational(1),S.Rational(5,4))]:
    wv=w.subs({r:rv,z:zv})
    check(f'numeric_exact_pole_{rv}_{zv}',(At*w*w+2*Bt*w+Ct).subs({r:rv,z:zv}))
    xv=S.re(wv);yv=S.im(wv)
    if yv<=0 or S.sign(xv)!=S.sign(1-rv):
        raise RuntimeError('pole quadrant failure')
    checks.append(f'pole_quadrant_{rv}_{zv}')
# Deliberate corruption checks exercise the actual zero-test, never Python assert.
for name,expr in [('wrong_upper_residue',1/(2*At*w+2*Bt)-i/(2*r)),('wrong_jensen_sign',1/t-1/K-(t-K)/K**2-(t-K)**2/(K**2*t)),('wrong_hessian_sign',-hessian_moment-(C/A**2-4*B**2/A**3))]:
    try:
        check('MUTANT_'+name,expr)
    except RuntimeError:
        checks.append('rejected_'+name)
    else:
        raise RuntimeError('Deliberate corruption escaped: '+name)
print(json.dumps({'status':'passed','checks':checks,'count':len(checks)},sort_keys=True,indent=2))
