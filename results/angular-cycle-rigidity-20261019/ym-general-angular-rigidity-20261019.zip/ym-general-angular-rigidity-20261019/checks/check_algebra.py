import sympy as S

u,t,c,s,tau,a,b,r,h=S.symbols('u t c s tau a b r h', real=True)
A=c*c+t*s*s
B=s*c*(t-1)
C=s*s+t*c*c

def on_unit_circle(expr):
    numerator=S.together(expr).as_numer_denom()[0]
    return S.rem(S.Poly(numerator,c),S.Poly(c*c+s*s-1,c)).as_expr()==0

checks={}
checks['rotation_discriminant']=on_unit_circle(A*C-B*B-t)
checks['original_root_modulus']=S.expand((1+tau*a*a)*(1+tau*b*b)-(tau*a*b)**2-(1+tau*(a*a+b*b)))==0
x=s*c*(1-t)/A
y2=t/(A*A)
checks['circle_locus']=on_unit_circle(x*x+y2-1+((c*c-s*s)/(s*c))*x)
checks['root_monotonicity']=on_unit_circle(S.diff(x,t)+s*c/(A*A))
# Here h=sqrt(1+tau), so tau=h^2-1.
r=(1-h)/(1+h)
G=(1+r)/((1+r)**2-4*r*t*t)
checks['angular_generating_formula']=S.factor(2*G/(1+h)-1/(1+(h*h-1)*t*t))==0
for name, passed in checks.items():
    print(name, 'PASS' if passed else 'FAIL')
if not all(checks.values()):
    raise SystemExit(1)
