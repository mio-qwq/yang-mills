# Every positive dilution of this four-axis family fails diagonal RP

19 October 2026. Local scalar Gaussian covariance research only. No remote edits, merging, releases, or publishing.

## The precise result

Let b>0 and tau>0. Let p(lambda) be a nonnegative probability density supported in [ell,L], where 0<ell<L<1. In particular p may be any of the globally Lipschitz or smooth parameter densities covered by the accepted coordinate-repair theorem. Put

    beta(lambda)=((1-lambda)/(1+lambda))^2,
    rho_mix(v)=integral p(lambda) (1/4) sum_(j=1)^4
        sqrt(beta(lambda))/[1+(beta(lambda)-1)v_j^2]^2 d lambda,
    rho_epsilon=(1-epsilon)+epsilon rho_mix,
    F_b(p)=integral_(S^3) rho_epsilon(v)
          /[b+|p|^2+tau(p.v)^2] d sigma(v).

Here d sigma is probability surface measure. Then for EVERY 0<epsilon<=1, F_b is NOT reflection positive at

    n=(e1+e2)/sqrt(2).

More precisely, set m=(e1-e2)/sqrt(2). For each fixed p, tau, epsilon, and b, there exists a finite kappa_0 such that every kappa>kappa_0 has a strictly negative fixed-tangential-frequency Hankel form at k=kappa m. For each such kappa, a finite tangential wave packet converts the violation into a real C_c^infinity test supported strictly inside {x.n>0}. Neither a Fourier delta nor an endpoint distribution is used as a legal test.

The threshold and witness are proved to exist; their numerical values are not computed. W4 symmetry transports the conclusion to all diagonal mirrors with normals (e_i +/- e_j)/sqrt(2).

Consequently the explicit repaired taper

    rho_repaired=1199/1200+(1/1200)rho_taper

has the established coordinate RP but fails every diagonal mirror, for every b,tau>0. This rejects the proposed four-axis mixture as a simultaneous coordinate/diagonal construction. It does not settle arbitrary smooth W4-invariant densities, rotational reconstruction, interacting Yang-Mills theory, or a mass gap.

## 1. Accepted axial decomposition and the positive analytic tail

The accepted one-axis identity, valid on real momenta, is

    F_(lambda,a)=(1+lambda)T_(lambda,a)/2
               +(1-lambda)/2 integral_0^1 T_(lambda r^2,a) dr.

After mixing lambda it becomes

    F_(mix,a)=integral_0^L mu(eta) T_(eta,a) d eta,
    mu(eta)=p(eta)(1+eta)/2
       +[1/(4sqrt(eta))] integral_eta^L
                         p(lambda)(1-lambda)/sqrt(lambda) d lambda.       (1)

This is a positive probability measure. Crucially, for 0<eta<ell,

    mu(eta)=C_*/sqrt(eta),
    C_*=(1/4) integral p(lambda)(1-lambda)/sqrt(lambda) d lambda>0.          (2)

Thus a whole nonempty parameter interval has strictly positive analytic density, regardless of any lack of smoothness of p itself. The integrable tail at zero is retained.

For a general axis a and real momentum p write q=|p|^2. The accepted building block is equivalently

    T_(eta,a)(p)=2[A+C sqrt(b+(1+tau)q)/sqrt(b+q)]
      /{[A sqrt(b+q)+C sqrt(b+(1+tau)q)]^2+4eta tau(a.p)^2},              (3)
    A=1+eta, C=1-eta.

The roots in (3) are individually continued from positive real q. This identity follows either from the accepted harmonic generating function or by substituting the normal and tangential special cases into its general expression.

## 2. Exact homogeneous diagonal slice, with its physical continuation

Introduce the auxiliary b=0 covariance only at nonzero momentum. Set

    p=u n+m, z=u^2, q=z+1,
    s=sqrt(1+tau),
    d=1+eta+(1-eta)s,
    h=2eta tau,
    alpha=d^2+h,
    r=h/alpha.

For real u, q>0 and the two roots in (3) are sqrt(q) and s sqrt(q). They cancel exactly. The axes e1 and e2 have projections (u+1)/sqrt(2) and (u-1)/sqrt(2), so

    T_plus=2d/[alpha(u^2+1)+2hu],
    T_minus=2d/[alpha(u^2+1)-2hu].                                  (4)

The axes e3,e4 both give 2/[d(z+1)]. In the equal four-axis average the oblique pair therefore contributes

    B_eta(z)=(d/alpha)(z+1)/[(z+1)^2-4r^2z],                       (5)

and the two remaining axes contribute 1/[d(z+1)].

Equations (4)-(5) are rational continuations of the actual real-momentum germ. They do not result from replacing a product of two physical square roots by a different principal root. No complex-variable limit b->0 is used: the limit will be taken only on real momenta in Section 5.

For eta>0, d>0 and 0<r<1. Its derivative is

    r'(eta)=2tau d[1+s+(s-1)eta]/alpha^2 >0.                       (6)

The two poles of (5) are

    zeta(eta)=2r^2-1+2ir sqrt(1-r^2),
    conjugate(zeta(eta)).                                         (7)

They have modulus one and nonzero imaginary parts. The upper pole moves injectively along an upper unit-circle arc: it begins at -1 as eta decreases to zero, and it ends strictly before +1 since L<1 and r(L)<1. In particular zeta'(eta) is never zero; directly,

    |zeta'(eta)|^2=4r'(eta)^2/(1-r^2).

The partial-fraction residue of (5) at the upper pole is

    a(eta)=(d/alpha)(zeta+1)/(zeta-conjugate(zeta))
          =d/(2alpha)[1-ir/sqrt(1-r^2)].                         (8)

Thus Re a(eta)=d/(2alpha)>0, and the residue never vanishes. Both a and zeta are analytic in eta near any point of (0,L).

## 3. A genuine nonreal cut survives every positive dilution

Let G_0(z) denote the homogeneous diagonal slice after the rho_epsilon mixture. Equations (1), (5), and (8) give

    G_0(z)=c_epsilon/(z+1)
       +epsilon integral_0^L mu(eta)
           [a(eta)/(z-zeta(eta))
               +conjugate(a(eta))/(z-conjugate(zeta(eta)))] d eta,        (9)

where

    c_epsilon=2(1-epsilon)/(1+s)
                  +epsilon integral_0^L mu(eta)/d(eta) d eta.

This is holomorphic away from -1 and the two compact conjugate arcs Gamma_+, Gamma_-. The integral is normally convergent on compact sets disjoint from these sets because mu is finite and a is bounded on [0,L].

Let Omega=C\(-infinity,0]. The domain Omega\(Gamma_+ union Gamma_-) is connected. To see this explicitly, its points with modulus below one connect to the positive ray through the punctured unit disk without crossing the negative ray; its points with modulus above one connect through the exterior of the unit disk. These regions join along the positive ray because both arcs end before +1. Points on the unit circle but off the arcs can be moved into either region.

Suppose G_0(x), x>0, had a positive Stieltjes representation. Its Stieltjes function would be holomorphic on Omega. By the identity theorem and the preceding connectedness, it would agree with (9) on BOTH sides of every interior point of Gamma_+.

Choose any eta_0 in (0,ell). On a short interval around eta_0 the density mu is the analytic positive function (2), zeta is analytic and injective with nonzero derivative, and a is analytic and nonzero. The local upper-arc integral in (9) can therefore be written

    integral_arc g(w)/(z-w) dw,
    g(zeta(eta))=epsilon mu(eta)a(eta)/zeta'(eta).

The function g is holomorphic in a neighborhood of this short arc. The two boundary values at zeta(eta_0) differ, up to the orientation sign, by

    2pi i epsilon mu(eta_0)a(eta_0)/zeta'(eta_0),                    (10)

which is nonzero. Here is a direct local verification: subtract g(z) from g(w) inside the integral. The resulting quotient has a removable singularity and gives a holomorphic term. The remaining integral is g(z) times the difference of the two endpoint logarithms, whose two-side continuation differs by 2pi i. All other portions of (9) are holomorphic in a sufficiently small neighborhood of zeta(eta_0): injectivity separates the remaining upper-arc parameters, and the lower arc and -1 are disjoint.

Thus no holomorphic function on Omega can agree with both sides. This contradiction proves that G_0 is NOT Stieltjes for every epsilon>0.

An equivalent distributional check avoids all boundary-value terminology. The Cauchy transform in (9) is locally integrable, and its distributional d-bar is a nonzero complex measure on Gamma_+. The identity d-bar[1/(z-w)]=pi delta_w gives its density epsilon mu a. The injective map and Re a>0 prevent cancellation, while every genuine Stieltjes function has zero d-bar off the negative axis. The connectedness above again ensures that the same analytic germ is being compared.

No endpoint regularity of p, no numerical sign, no finite angular truncation, and no exchange of a singular parameter-boundary limit is used.

## 4. Why non-Stieltjes implies a compact positive-time negative form

This section restates the already independently audited bounded-Hankel argument from w4-angular-symmetrization-20261019/RESULT.md, Section 6, including the hypotheses needed here.

For delta>=0 define the real normal slice

    G_delta(u^2)=F_delta(u n+m).

Positive normalization of rho_epsilon gives

    0<G_delta(u^2)<=1/(delta+1+u^2).

It is even in u because rho_epsilon is invariant under the diagonal reflection. Its inverse normal Fourier transform

    H_delta(T)=(1/2pi) integral_R exp(iuT)G_delta(u^2) du

is real, even, bounded, and continuous. Direct inversion of each angular quadratic also gives

    |H_delta(T)|<=exp[-sqrt((delta+1)/(1+tau))|T|]/(2sqrt(delta+1)).        (11)

Indeed, with v_n=v.n and v_t=v-v_n n, the denominator is a_v u^2+2c_vu+d_v, where

    a_v=1+tau v_n^2,
    c_v=tau v_n(m.v_t),
    d_v=delta+1+tau(m.v_t)^2,
    Delta_v=a_v d_v-c_v^2=a_v(delta+1)+tau(m.v_t)^2.

The inverse transform is

    exp[-sqrt(Delta_v)|T|/a_v] exp[-ic_vT/a_v]/(2sqrt(Delta_v)).

The two displayed bounds follow from a_v<=1+tau and Delta_v>=a_v(delta+1). Reflection invariance makes the average real.

Suppose every smooth compact positive-time h had nonnegative Hankel form

    Q_delta(h)=integral_0^infinity integral_0^infinity
                 conjugate(h(t))H_delta(t+s)h(s) dt ds.

Approximation of finite point masses gives positivity of every finite matrix [H_delta(t_i+t_j)], t_i>0. Form the Hilbert space generated by vectors e_t with these inner products. The shifts T_a e_t=e_(t+a) are symmetric contractions. For completeness, if b_j=||T_a^j xi||^2, kernel boundedness bounds b_j uniformly, while Cauchy-Schwarz gives b_j^2<=b_0 b_(2j). Iterating proves b_1<=b_0; when b_0=0 it also proves that shifts preserve null vectors. Hence the shifts descend to bounded self-adjoint contractions. The identity T_a=T_(a/2)^2 makes them positive, and kernel continuity makes the semigroup strongly continuous.

The semigroup spectral theorem gives T_a=exp(-aE) for a nonnegative self-adjoint generator E. Continuity at zero lets e_t tend to a vector e_0, so

    H_delta(T)=integral_[0,infinity) exp(-ET) sigma_delta(dE)

for a finite positive measure sigma_delta. The exponential bound (11) forces its support into E>=sqrt((delta+1)/(1+tau)): any positive mass below this bound would violate (11) for sufficiently large T. Fourier inversion is now absolutely justified and gives

    G_delta(z)=integral 2E/(E^2+z) sigma_delta(dE).                      (12)

Thus it is Stieltjes. The actual kernel is continuous on the whole real T-axis and decays exponentially, so there is no contact or constant remainder. Also zG_delta(z)<=1 for z>0 implies that the pushed Stieltjes measure has total mass at most one by monotone convergence.

Apply the contrapositive to delta=0 and Section 3. There exists h in C_c^infinity((0,infinity)) and gamma>0 such that

    Q_0(h)=-gamma<0.                                                 (13)

The test can be real: for a real symmetric kernel the complex form splits as the sum of the forms of its real and imaginary parts. Equivalently, a finite strictly negative Hankel matrix can be smoothed at its strictly positive times. This is an existence proof of h; no explicit time coefficients are claimed.

## 5. Return to every fixed positive b, at finite tangential frequency

The scaling identity on real momenta is exact:

    kappa^2 F_b(kappa u n+kappa m)=F_(b/kappa^2)(u n+m).               (14)

No interchange of complex analytic continuation and the kappa limit is needed. More strongly, for delta>=0 the angular denominators give the pointwise bound

    0<=G_0(u^2)-G_delta(u^2)<=delta/(1+u^2)^2.

Since integral_R (1+u^2)^(-2)du=pi/2,

    ||H_delta-H_0||_infinity <=delta/4,
    |Q_delta(h)-Q_0(h)|<=delta ||h||_1^2/4.                           (15)

Fix the h,gamma from (13). Every delta<4gamma/||h||_1^2 has Q_delta(h)<0. Thus every

    kappa^2>b ||h||_1^2/(4gamma)                                    (16)

gives a strictly negative scaled fiber. If H_(b,kappa m) is the original normal kernel, (14) implies

    H_(b,kappa m)(T)=kappa^(-1) H_(b/kappa^2)(kappa T).

Use h_kappa(t)=kappa h(kappa t). It is still smooth and compactly supported strictly above zero, and

    Q_(b,kappa m)(h_kappa)=kappa^(-1)Q_(b/kappa^2)(h)<0.               (17)

This proves the stated all-sufficiently-large-frequency quantifier. Formula (16) is an exact bound in terms of an existing negative witness; it is not a computed numerical threshold.

There is also a short closure proof of existence of some finite violating frequency. If all scaled slices in (14) were Stieltjes, their positive spectral measures would have masses at most one by (12). Weak compactness on the one-point compactification [0,infinity] produces a limiting measure. For x>0 the kernel (x+t)^(-1) extends continuously by zero at infinity, so escaped mass contributes nothing. Dominated convergence identifies the limit with G_0(x), making it Stieltjes and contradicting Section 3. The direct estimate (15) gives the stronger quantifier and the compact-time witness transfer.

## 6. Legal compact spacetime tests

For the original fixed b>0 and any fixed positive-time h_kappa, the fixed-k Hankel form depends continuously on real tangential k. This follows from the bound F_b(u n+k)<=1/(b+u^2+|k|^2), normal Fourier inversion, and dominated convergence locally in k. The form is also globally bounded in k by ||h_kappa||_1^2/(2sqrt(b)).

Take any nonzero chi in C_c^infinity(R^3) and define the compact tangential packet

    g_R(x)=R^(-3/2)chi(x/R)exp(i kappa m.x).

Its normalized squared Fourier transform is an approximate identity at kappa m. For f_R(t,x)=h_kappa(t)g_R(x), Fourier decomposition of the reflected form gives

    Q_b(f_R)=(2pi)^(-3) integral |g_R_hat(k)|^2 Q_(b,k)(h_kappa) dk.

Boundedness and continuity make this strictly negative for some finite R, by (17). Hence f_R is an actual C_c^infinity test supported strictly inside the positive half-space. If this test is complex, at least one of its real and imaginary parts has negative form, since the covariance and reflected kernel are real and symmetric. This proves existence of a legal real test.

The supports of f and its reflection are strictly separated. Consequently adding distributions supported only at the spacetime origin cannot repair this violation.

## 7. Optional strengthening of parameter scope

The proof only requires a nonzero positive analytic effective tail on some interval below the original parameter support. Therefore it extends to any positive probability Borel measure P on a compact subset [ell,L] of (0,1), including atoms. Replace the first term in (1) by the measure (1+eta)P(d eta)/2, and retain the absolutely continuous positive tail

    [1/(4sqrt(eta))] integral_[eta,L] (1-lambda)/sqrt(lambda) P(d lambda) d eta.

On (0,ell) this is still exactly C_*/sqrt(eta). Atomic or rough contributions at eta>=ell have poles on disjoint portions of the injective arc and cannot cancel the selected interior jump. The main theorem was kept at the accepted density scope to make its relation to the coordinate-repair result immediate.

## Dependencies and exact checks

Read and used:

- /workspace/shared/isotropic-rp-repair-20261019/RESULT.md
- /workspace/shared/isotropic-rp-repair-audit-20261019/AUDIT.md
- /workspace/shared/infinite-angular-candidates-20261019/RESULT.md
- /workspace/shared/w4-angular-symmetrization-20261019/RESULT.md, especially Section 6
- /workspace/shared/w4-rp-obstruction-audit-20261019/AUDIT.md

The proof above supplies the new homogeneous diagonal continuation, nonreal-arc noncancellation, all-large-frequency transfer, and compact-test conclusion. The parent and another independent worker derived the same massless pole mechanism concurrently; this note incorporates that shared exact reduction and independently supplies the jump and witness arguments.

check_exact_identities.py verifies the rational pair formula, roots, residues, derivative, and scaling algebra with exact symbolic arithmetic. verify_regression_modes.py checks identical ordinary/optimized outputs and requires a corrupted residue to fail in both modes. These are regression checks, not substitutes for Sections 3-6.


## Completed regression record

All 22 exact identities passed. Ordinary and optimized execution agree, and the deliberately corrupted residue fails in both modes. Successful algebra-output SHA256:

    84df0872ca136d62bae38dfbec64999405a239bb010ddf50dcf8fb4d6f976e15

SOURCE_MANIFEST.json pins the byte lengths and SHA256 hashes of every mathematical dependency listed above.

Reproduce with:

    python check_exact_identities.py
    python verify_regression_modes.py
    python -O verify_regression_modes.py

The existence proof of the compact witness is analytic. These regression results do not provide or claim numerical witness times, coefficients, or a numerical tangential-frequency threshold.

FINITE_B_LEMMA.md separately records exact physical-sheet noncollision of oblique poles across all eta in (0,1), plus their local persistence at sufficiently large finite frequency. It is supplementary; the accepted theorem does not depend on a global finite-b pole-arc analysis.


## Independent audit

The complete proof passes the independent audit at /workspace/shared/oblique-pole-audit-20261019/AUDIT.md, including physical branches, the connected-domain/nonzero-jump argument, the bounded-Hankel necessity lemma, absence of contact remainders, all-large-frequency transfer, and real compact spacetime tests. The optional compact-supported Borel-parameter extension also passes.

That audit independently passed 22 exact identities and both ordinary/optimized corruption harnesses. Its successful-output SHA256 is 0cd16efdb781932cfaa402025c6259fecad0279dcbd5242a6094ef3d8f08e46d. Its report is hash-pinned in SOURCE_MANIFEST.json.
