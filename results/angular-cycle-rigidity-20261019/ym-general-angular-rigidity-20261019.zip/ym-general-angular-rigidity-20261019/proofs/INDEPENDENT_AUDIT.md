# Independent audit: two-mirror rigidity and full four-dimensional propagation

19 October 2026. Local mathematical work only; no external writes, merges, releases, or publication.

## Conclusion

For the scalar homogeneous covariance

    F(p) = integral_(S^3) rho(v) / (|p|^2 + tau (p.v)^2) d sigma(v),

where tau > 0 and rho is a nonnegative integrable probability density, the following statement is valid:

**If F is reflection invariant and reflection positive at every coordinate normal e_i and every diagonal normal (e_i +/- e_j)/sqrt(2), then F(p) = c/|p|^2 for all real p != 0.**

Here reflection positivity is used through its ordinary fixed-tangential-momentum positive Stieltjes representation. Only F's even part of rho is visible, so constant F alone cannot imply that an arbitrary, not necessarily antipodally even rho is constant. Under evenness of rho, nonvanishing even harmonic multipliers imply constant rho; that last injectivity calculation is separate from the rigidity proof below.

The proof does NOT infer isotropy from the finite reflection group. It first proves a two-dimensional homogeneous lemma and then propagates equality using first spectral moments and the equality case of Jensen's inequality. No general nonhomogeneous two-mirror lemma is needed or claimed.

## 1. Exact analytic support bound

Fix orthonormal n,m and put p = x n + m. For a=v.n and b=v.m, the denominator is

    A x^2 + 2B x + C,
    A=1+tau a^2, B=tau ab, C=1+tau b^2,
    AC-B^2=1+tau(a^2+b^2)>0.

Its two complex roots have squared modulus

    C/A = (1+tau b^2)/(1+tau a^2)
        in [1/(1+tau), 1+tau].

Consequently the original integral is holomorphic in x for |x|<1/sqrt(1+tau) and for |x|>sqrt(1+tau). On compact subsets of either region, its denominator is uniformly bounded away from zero over v, so this holds for any integrable rho. Reflection invariance at n makes this holomorphic function even in x. It descends to a holomorphic function of z=x^2 on

    |z|<1/(1+tau), and |z|>1+tau.

All coefficients are real, so it is real on the real portions of these domains.

If the slice is Stieltjes,

    F(x n+m) = integral_[0,infinity) nu(dt)/(x^2+t),

then nu is finite: by monotone convergence,

    nu([0,infinity)) = lim_(x->infinity) x^2 F(x n+m) = F(n).

A possible constant Stieltjes term vanishes by the same decay. The analytic continuation and Stieltjes inversion give

    supp nu subset [1/(1+tau), 1+tau].

More explicitly, analytic continuation real across each open negative interval outside this compact interval makes its inversion measure zero; analyticity at zero excludes an atom at zero. Thus neither an unbounded spectral tail nor spectral accumulation at zero causes a disconnected-cut loophole in this class.

For arbitrary nonzero tangent k, the same statement follows by homogeneity, with support bounds multiplied by |k|^2.

## 2. Two-dimensional homogeneous lemma

Let a homogeneous degree -2 function on R^2 minus the origin have a positive representation

    F(x,y) = integral mu(dt)/(x^2+t y^2),

with finite mu supported in a compact subset of (0,infinity). Suppose it is also Stieltjes in the squared normal variable after rotation through theta, where 0<theta<pi/2. Then mu is concentrated at t=1, and F(x,y)=mu((0,infinity))/(x^2+y^2).

Write c=cos(theta), s=sin(theta), and rotate x=c u-s, y=s u+c. The denominator is

    A_t u^2 + 2 B_t u + C_t,
    A_t=c^2+t s^2,
    B_t=sc(t-1),
    C_t=s^2+t c^2,
    A_t C_t-B_t^2=t.

The upper root and upper residue are

    w_t = sc(1-t)/A_t + i sqrt(t)/A_t,
    Res_(u=w_t) 1/(A_t u^2+2B_t u+C_t) = -i/(2 sqrt(t)).

Every upper residue has the same phase and a strictly positive magnitude. The root locus satisfies

    |w_t|^2 = 1 - 2 cot(2theta) Re(w_t).

The t<1 upper poles lie in the right half-plane, the t>1 upper poles in the left half-plane, and t=1 gives i. Enlarge each actual support to the complete compact initial arc from i on its side; do the same for conjugate lower arcs. Compact support away from t=0 and infinity keeps their other endpoints strictly off the real axis.

In either open half-plane, the complement of these upper/lower arcs is connected. For the right half-plane, the Cayley map W(u)=(u-i)/(u+i) sends its upper arc to an initial ray segment of radius R<1 and its lower arc to the terminal segment with radius at least 1/R. The unit lower semicircle joins the remaining region; every point can first move radially to it. The left-half-plane argument is obtained by u -> -u.

The rotated Stieltjes function S(u^2) is holomorphic in both open half-planes. The integral above is holomorphic off the enlarged arcs and agrees with S(u^2) on each real half-axis. Connectedness and the identity theorem therefore identify them throughout each slit half-plane.

The integral's partial fractions are Cauchy transforms of finite measures. Such transforms are locally integrable in the complex plane. The enlarged arcs have planar area zero, so the preceding equality holds almost everywhere in each whole half-plane. Distributionally,

    dbar [1/(u-w)] = pi delta_w.

In the upper-right quadrant this gives -i pi times the pushforward of mu|_(t<1) with positive weight 1/(2 sqrt(t)). Holomorphicity forces that measure to vanish. The upper-left quadrant similarly kills mu|_(t>1). Hence supp mu subset {1}.

This establishes continuation of the physical real-momentum germ. Merely spotting a formal pole would not have sufficed; compactness and connectedness are essential steps.

## 3. Pair-plane consequence

Restrict F to each coordinate two-plane span(e_i,e_j). Coordinate-normal RP and diagonal-normal RP within that plane meet the lemma's hypotheses, using Section 1. Therefore

    F(x e_i+y e_j) = c_ij/(x^2+y^2).

The planes share coordinate axes, so all constants are a single c>0. Hence F(p)=c/|p|^2 whenever p has at most two nonzero coordinates.

This is not yet full isotropy. A finite reflection group or analyticity alone does not propagate this equality to all of R^4.

## 4. Spectral mass and first moment

For any allowed mirror normal n and tangent k != 0, write

    F(u n+k) = integral nu_(n,k)(d lambda)/(u^2+lambda).

The mass and first moment are

    m0_(n,k) = F(n),
    m1_(n,k) = integral lambda nu_(n,k)(d lambda)
             = -1/2 D^2 F(n)[k,k].

The first identity follows from large u and monotone convergence. For the second, set z=u^2 and observe

    z^2 [m0/z - F(sqrt(z) n+k)]
       = integral z lambda/(z+lambda) nu_(n,k)(d lambda)
       -> integral lambda nu_(n,k)(d lambda).

On the other hand, homogeneity, smoothness, antipodal evenness and mirror invariance give

    F(u n+k) = F(n)/u^2 + D^2F(n)[k,k]/(2u^4) + O(u^-6).

Thus m1 is a finite quadratic form in k. This derivation also works without first invoking the compact support bound.

For coordinate n=e_i, reflection invariance under every coordinate sign flip makes this tangent quadratic form diagonal. Section 3 determines each diagonal entry to be c. Therefore

    m0_(e_i,k)=c,  m1_(e_i,k)=c |k|^2.

## 5. Global lower bound

Jensen's inequality for the probability measure nu/c and the convex function lambda -> 1/(u^2+lambda) yields

    F(u e_i+k) >= c/(u^2+|k|^2).

By continuity this includes u=0 whenever k != 0, and the coordinate-axis case is already known. Consequently

    H(p):=F(p)-c/|p|^2 >= 0  for every real p != 0.

This inequality alone is not the conclusion; its equality cases provide the propagation mechanism.

## 6. First moments at diagonal normals

Let n=(e_i+e_j)/sqrt(2), or n=(e_i-e_j)/sqrt(2). Section 3 gives F(n)=c, hence m0_(n,k)=c. Expanding the global lower bound along u n+k for large u gives

    m1_(n,k) <= c |k|^2.

Thus the tangent quadratic form D(k)=c|k|^2-m1_(n,k) is positive semidefinite.

Choose an orthonormal tangent basis consisting of the complementary diagonal in span(e_i,e_j) and the other two coordinate axes. Every basis vector b satisfies F(b)=c by Section 3. By continuity at u=0,

    integral lambda^-1 nu_(n,b)(d lambda)=F(b)=c.

Cauchy-Schwarz therefore gives

    m1_(n,b) F(b) >= m0_(n,b)^2,
    m1_(n,b)>=c.

Combined with m1_(n,b)<=c, this gives D(b)=0 for every basis vector. A positive semidefinite quadratic form vanishing on an orthonormal basis is identically zero. Therefore, for every diagonal normal,

    m0_(n,k)=c,  m1_(n,k)=c |k|^2.

No rotational invariance of the entire tangent space was assumed here.

## 7. Equality propagation and completion

For any coordinate or diagonal normal n, suppose a nonzero tangent vector k is already known to satisfy F(k)=c/|k|^2. Then

    integral nu=c,
    integral lambda nu=c|k|^2,
    integral lambda^-1 nu=c/|k|^2.

Equality holds in Cauchy-Schwarz. Since lambda>0 almost surely and the measure has positive mass, equality forces lambda to be constant almost surely, namely lambda=|k|^2. Hence

    nu_(n,k) = c delta_(|k|^2),
    F(u n+k)=c/(u^2+|k|^2)  for every real u.

Now set

    n=(e1+e2)/sqrt(2), m=(e1-e2)/sqrt(2), E=span(e3,e4).

Every k in E is radial by Section 3. Applying the equality statement with normal n proves radiality on span(n,E), which is precisely the entire three-dimensional hyperplane m-perp. The remaining line k=0 follows from Section 3 or continuity.

Apply the equality statement once more with normal m. Every tangent vector to m lies in this radial hyperplane, so every line u m+k is radial. These lines cover all of R^4. This proves F(p)=c/|p|^2 globally.

## 8. Scope and caution

- The argument works for arbitrary nonnegative normalized L1 angular densities. Smoothness of rho is unnecessary because the covariance is real analytic away from p=0.
- It concerns only scalar Gaussian two-point reflection positivity and covariance isotropy. It does not prove an interacting Yang-Mills or mass-gap claim.
- Both signs of diagonal normals were used in the final construction. If only the plus diagonals are explicitly listed, coordinate reflection invariance conjugates their RP to the minus diagonals, so the same conclusion follows.
- If rho is not required to be antipodally even, F cannot see its odd component: rho(v)=1+epsilon v1, |epsilon|<=1, is normalized and nonnegative and gives the same F as rho=1. Density isotropy therefore needs an evenness hypothesis or must be stated only for (rho(v)+rho(-v))/2.
- The two-dimensional lemma alone does not justify full-four-dimensional propagation. Sections 4-7 supply the missing argument.
- No claim that arbitrary nonhomogeneous two-mirror RP forces planar radiality is needed.

## 9. Constant and angular identifiability

Write s=sqrt(1+tau) and r=(1-s)/(1+s), so -1<r<0. The Chebyshev generating identity is

    sum_(j>=0) r^j U_(2j)(t)
       = (1+r)/[(1+r)^2-4r t^2].

Direct substitution gives the absolutely uniformly convergent expansion

    1/(1+tau t^2)
       = [2/(1+s)] sum_(j>=0) r^j U_(2j)(t).

Uniform convergence follows from |U_(2j)(t)|<=2j+1 for |t|<=1. The spherical convolution multiplier on degree 2j harmonics is therefore

    [2/(1+s)] r^j/(2j+1),

which is nonzero for every j because tau>0. Odd-degree multipliers are zero. The degree-zero multiplier is 2/(1+s).

Since integral rho d sigma=1, spherical averaging of F(e)=c gives

    c = 2/(1+sqrt(1+tau)).

Moreover, constant F forces every positive even-degree harmonic coefficient of rho to vanish. Completeness of spherical harmonics (or density of restrictions of polynomials in continuous functions on S^3) therefore gives

    (rho(v)+rho(-v))/2 = 1 almost everywhere.

If rho is continuous this identity holds everywhere; if rho is antipodally even it says rho=1. No assertion about the invisible odd part is warranted.

For an entirely self-contained normalization check, a coordinate of uniform S^3 has density (2/pi)sqrt(1-t^2) on [-1,1], and integration of 1/(1+tau t^2) against that density gives 2/(1+s).

## 10. Fixed positive-mass input corollary

For b>0 define

    F_b(p)=integral rho(v)/[b+|p|^2+tau(p.v)^2] d sigma(v).

If, for one fixed b>0, this covariance is mirror invariant and reflection positive at all coordinate and diagonal normals, with RP tested over all tangential momenta, then its homogeneous limit has all the hypotheses proved above. In particular,

    (rho(v)+rho(-v))/2 = 1 almost everywhere.

The phrase “all tangential momenta” is essential: positivity on isolated fibers is insufficient for the dilation and rigidity argument.

Indeed, for every kappa>0,

    kappa^2 F_b(kappa p) = F_(b/kappa^2)(p).

Reflection positivity and mirror invariance are preserved by this dilation. Fix any nonzero tangential vector k, write K=|k|^2, and let delta=b/kappa^2. The original nonnegative normalized angular integral gives

    0<F_delta(u n+k)<=1/(u^2+K),
    0<=F_0(u n+k)-F_delta(u n+k)<=delta/(u^2+K)^2.

Thus the normal-frequency slices converge in L1(du), and their inverse Fourier transforms H_delta converge uniformly, with the explicit estimate

    ||H_delta-H_0||_infinity <= delta/(4 |k|^3).

For each compactly supported smooth positive-time test h, the associated Hankel forms consequently satisfy

    |Q_delta(h)-Q_0(h)| <= delta ||h||_1^2/(4 |k|^3).

Their nonnegativity passes to delta=0. The usual bounded continuous Hankel-kernel characterization then supplies the homogeneous Stieltjes representation on every nonzero tangent fiber. If RP is initially stated as a full-spacetime quadratic form, Fourier localization first gives the fiber forms almost everywhere; continuity in nonzero k extends them to every such fiber. The needed continuity follows from the displayed integrable normal-frequency bound locally uniformly away from k=0.

This proves the necessity direction at every fixed positive b without taking a complex-momentum limit.

Conversely, if the even part of rho is 1, its odd part integrates to zero for every p and every b. Uniform sphere averaging then gives a radial positive Stieltjes function of q=|p|^2:

    F_b(q) = integral_[-1,1] [(2/pi)sqrt(1-t^2)/(1+tau t^2)]
                            /[q+b/(1+tau t^2)] dt.

Therefore F_b is reflection positive at every mirror. Consequently the complete scalar classification in this angular-integral class is: simultaneous coordinate-and-diagonal RP at one fixed b>=0 is equivalent to the even angular density being constant 1. For b=0 this representation is interpreted away from p=0, as in the theorem.
