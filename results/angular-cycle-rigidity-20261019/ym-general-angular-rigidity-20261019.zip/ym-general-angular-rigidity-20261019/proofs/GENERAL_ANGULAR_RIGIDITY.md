# Independent derivation: arbitrary even angular density rigidity from coordinate and diagonal RP

19 October 2026. Local scalar Gaussian covariance research only. No remote changes, publication, merge, release, interacting Yang–Mills conclusion, or mass-gap claim.

## Result and scope

Let sigma be probability surface measure on S^3. Let rho be a nonnegative, antipodally even L1 density with integral 1. Fix tau>0 and b>0, and define

    F_b(p) = integral rho(v) / [b + |p|^2 + tau (p.v)^2] d sigma(v).

Assume rho is invariant under the coordinate sign changes and coordinate permutations (the hyperoctahedral group W4). If F_b is reflection positive for the coordinate mirror normal e1 and the diagonal mirror normal (e1+e2)/sqrt(2), then

    rho = 1 almost everywhere.

By W4 covariance, the two stated RP assumptions imply RP at every coordinate and diagonal mirror. Alternatively one may assume all these mirror invariances and RP properties directly. Conversely rho=1 is RP at every mirror.

More generally, for arbitrary nonnegative normalized rho in L1, only rho_even(v)=[rho(v)+rho(-v)]/2 is visible to F_b. If rho_even is W4 invariant, the same assumptions force rho_even=1 almost everywhere. Equivalently one may require the covariance itself to have the stated mirror invariances; injectivity on even harmonics then supplies the corresponding invariance of rho_even. Odd density components cannot be identified by this covariance and are not ruled out.

This statement does not assume a finite harmonic expansion, finitely many ACG axes, analytic rho, or a particular positive-axis representation. It therefore answers the continuous positive-axis question at the level of the resulting density: no nonconstant continuous positive-axis angular density can have all the specified RP properties.

The new propagation argument was proposed independently by the coordinating audit worker. The present document checks it from the moment identities below and supplies an independent full derivation. The two-dimensional slit proof and its compact-support bound were also independently derived and compared. This file is a research proof, not a claim that repository integration or final coordinated audit has already occurred.

## 1. Homogeneous limit and spectral representation

Define F=F_0 away from p=0. For each delta>=0 and nonzero tangent k at a chosen mirror normal n,

    0 < F_delta(un+k) <= 1/(u^2+|k|^2),
    0 <= F_0(un+k)-F_delta(un+k) <= delta/(u^2+|k|^2)^2.

The real scaling identity is

    kappa^2 F_b(kappa p) = F_(b/kappa^2)(p).

If F_b is RP, every scaled covariance is RP. The displayed integrable bound gives uniform convergence of fixed-k inverse normal Fourier kernels as delta tends to zero. Hence every compact positive-time Hankel form for F is nonnegative.

Use the bounded-Hankel necessity lemma proved in the already accepted scalar-covariance work: for an even fixed-k slice with the present bounded continuous exponentially decaying normal kernel, nonnegative compact positive-time Hankel forms imply

    F(un+k) = integral_[0,infinity) mu_(n,k)(dt)/(u^2+t),           (1)

with a positive measure. This is an ordinary Stieltjes representation, with no contact or constant remainder. The original angular formula yields the needed exponential decay for k!=0. Fixed-k positivity holds for every k!=0, rather than only almost everywhere, by continuity of the Hankel forms in k.

The mass is finite: multiplying (1) by u^2 and letting u tend to infinity gives

    mass(mu_(n,k)) = F(n).                                      (2)

The finite value F(k) implies no atom at t=0 and integral t^(-1) dmu < infinity.

Only this accepted RP-to-Stieltjes lemma is imported; the rigidity steps below are new. All real derivatives used below exist even for rho merely L1: on compact real sets away from p=0 the angular denominators are uniformly bounded away from zero, and differentiation under the angular integral is legitimate to every order.

## 2. Compact spectral support on a unit tangent slice

Put |k|=1 and s=sqrt(1+tau). For a fixed angular v, the denominator of F(un+k) is

    A_v u^2 + 2 B_v u + C_v,
    A_v=1+tau(v.n)^2, B_v=tau(v.n)(v.k), C_v=1+tau(v.k)^2.

Its two nonreal conjugate roots have modulus sqrt(C_v/A_v), which lies in [1/s,s]. Consequently the angular integral is holomorphic on |u|<1/s and on |u|>s, uniformly on compact subsets of those sets. Reflection invariance makes it even in u there.

Writing z=u^2 gives analytic continuation of the Stieltjes germ to |z|<1/s^2 and |z|>s^2. Positive Stieltjes inversion then gives

    supp(mu_(n,k)) subset [1/(1+tau), 1+tau].                     (3)

For clarity, inversion is used only after identifying the germ on the connected slit disc or slit exterior from the positive real z-axis. Thus (3) is not an unjustified assertion about a different continuation sheet. Endpoint atoms are allowed.

## 3. Two nonorthogonal mirrors force isotropy on their plane

Let n,m be orthonormal, and suppose RP holds at n and at

    n_theta = c n + s_theta m,
    c=cos(theta)>0, s_theta=sin(theta)>0, 0<theta<pi/2.

The associated unit tangent in their plane is m_theta=-s_theta n+c m. By homogeneity and the n-slice representation with unit tangent m,

    F(x n+y m) = integral mu(dt)/(x^2+t y^2)                    (4)

for real (x,y)!=0. The compact measure mu obeys (3). This formula first follows for y!=0 and extends to y=0 by continuity.

On the rotated slice p=u n_theta+m_theta,

    f_theta(u) = integral mu(dt)/[A(t)u^2+2B(t)u+C(t)],
    A=c^2+t s_theta^2,
    B=c s_theta(t-1),
    C=s_theta^2+t c^2,
    AC-B^2=t.

The upper pole and its residue are

    w(t) = c s_theta(1-t)/A + i sqrt(t)/A,
    Res_upper = -i/[2 sqrt(t)].                                 (5)

Thus all upper residues have one strictly negative imaginary phase. The pole is in the right half-plane exactly when t<1, in the left half-plane exactly when t>1, and equals i only when t=1.

A complete continuation argument is needed here. The upper poles lie on

    |w|^2 = 1 - 2 cot(2theta) Re(w).

Under the Cayley map W(u)=(u-i)/(u+i), the upper pole has the exact image

    W(w(t)) = [(1-sqrt(t))/(1+sqrt(t))] exp(i(2theta-pi)).        (6)

For t<1 the enlarged upper-right support is an initial radial segment of one ray in the lower W-half-plane, of length R<1. The conjugate lower support is its terminal radial segment with radius at least 1/R. Their complement is connected: every point can move radially to the lower unit semicircle, and then along it. The same statement holds in the left u-half-plane for t>1. The compact support (3) keeps every nonboundary endpoint away from the real u-axis.

Because RP at n_theta gives a Stieltjes function of u^2, its physical germ is holomorphic on each open right/left u-half-plane. The rational-integral continuation (4) agrees with that germ on the real axis. The connected complements just proved identify the continuations throughout the slit half-planes.

The slit union has planar area zero. Cauchy transforms of finite compact measures are locally integrable. Hence the two identified functions agree almost everywhere, so their distributional d-bar derivatives agree. On the upper-right half-plane the rational-integral derivative is

    -i pi nu_+,

where nu_+ is the pushforward of mu restricted to t<1, with positive weight 1/(2sqrt(t)). Lower residues have disjoint lower-half-plane support; all other terms are holomorphic here. Holomorphicity therefore forces mu(t<1)=0. The left half-plane argument gives mu(t>1)=0.

Thus mu=c_plane delta_1, and

    F(x n+y m)=c_plane/(x^2+y^2).                               (7)

This proves plane rigidity without any finite-axis hypothesis and without transporting an inaccessible cut across another sheet.

Applying (7) to n=e_i and n_theta=(e_i+e_j)/sqrt(2) shows that every coordinate two-plane is radial. Their intersections on coordinate axes identify the constants. Write their common positive constant as c0:

    F(p)=c0/|p|^2 whenever p has at most two nonzero coordinates. (8)

## 4. Spectral mass and first moment are exact local derivatives

For any RP normal n, write m0(n)=F(n) and

    m1_n(k) = integral t mu_(n,k)(dt).

This first moment is finite and equals

    m1_n(k) = -1/2 D^2 F(n)[k,k],       k perpendicular to n.     (9)

Proof: reflection invariance plus antipodal evenness gives F(n+z k)=F(n-z k). Homogeneity gives u^2 F(un+k)=F(n+k/u). On the other hand,

    u^2 [m0(n)-u^2 F(un+k)]
      = integral [u^2 t/(u^2+t)] mu_(n,k)(dt).

The right side increases to the first moment; Taylor expansion of the left side gives the finite value in (9). Therefore m1_n is a nonnegative quadratic form on the whole tangent space. No extra regularity of the spectral measure in k is assumed, and no exchange of a k derivative with that measure is made.

## 5. Coordinate moments imply a global lower bound

Take n=e1. Every tangent coordinate sign change fixes e1 and leaves F invariant, so the Hessian quadratic (9) has no cross terms. From (8),

    m0(e1)=c0,
    m1_e1(e_j)=c0 for j=2,3,4.

Consequently m1_e1(k)=c0 |k|^2 for every k perpendicular to e1. Jensen's inequality for the probability measure mu/c0 gives

    F(u e1+k) >= c0/(u^2+|k|^2).

The k=0 case follows from homogeneity. We obtain the full-space bound

    F(p) >= c0/|p|^2 for every p!=0.                            (10)

## 6. Both diagonal first moments are exactly Euclidean

Put n+=(e1+e2)/sqrt(2) and n-=(e1-e2)/sqrt(2). Treat either as n. Its spectral mass is c0 by (8). Represent the quadratic (9) by a symmetric matrix M_n on n-perpendicular.

Expanding (10) at p=n+epsilon k gives

    m1_n(k) <= c0 |k|^2,

so c0 I-M_n is positive semidefinite.

An orthonormal tangent basis is (n_other,e3,e4). At each of these unit vectors a, (8) gives F(a)=c0. Jensen at u=0 gives

    c0 = integral t^(-1) mu_(n,a)(dt)
       >= c0^2/m1_n(a),

hence m1_n(a)>=c0. Combined with the previous upper bound, every diagonal entry of c0 I-M_n in this basis is zero. A positive semidefinite matrix with zero diagonal is zero (apply |A_ij|^2<=A_ii A_jj). Therefore

    m1_n+(k)=c0 |k|^2 and m1_n-(k)=c0 |k|^2.                   (11)

Notice that no radiality on the mixed planes span(n,e3) or span(n,e4) was assumed. Only the values at their tangent basis vectors were used. This is the essential propagation step.

## 7. Equality propagates from a plane to a hyperplane to all of R4

Whenever a positive measure mu has mass c0 and first moment c0 K, the exact identity is

    integral mu(dt)/t - c0/K
      = (1/K^2) integral [(t-K)^2/t] mu(dt),    K>0.             (12)

Thus if F(k)=c0/|k|^2, the diagonal moment identities (11) imply that the entire spectral measure at tangent k is c0 delta_(|k|^2). Its whole normal line is radial.

First use n=n+ and every nonzero k in span(e3,e4). Equation (8) supplies equality there. Hence F is radial on

    span(n+,e3,e4) = n--perpendicular.

The missing k=0 normal axis is already radial by homogeneity. Next use n=n- and every nonzero tangent k in this now-radial hyperplane. Equations (11)-(12) force its spectral measure to be c0 delta_(|k|^2). These normal lines cover R4 away from zero. Therefore

    F(p)=c0/|p|^2 for every p!=0.                               (13)

## 8. Harmonic inversion identifies rho, not its individual axes

Put s=sqrt(1+tau), y=(1-s)/(1+s), and C_tau=2/(1+s). On S^3,

    1/[1+tau(e.v)^2] = C_tau sum_(j>=0) y^j U_(2j)(e.v).

The series converges absolutely uniformly. The degree-2j spherical harmonic multiplier of rho -> |p|^2 F(p) is

    C_tau y^j/(2j+1),                                         (14)

which is nonzero for every j because tau>0. Equation (13) therefore kills every nonconstant even spherical harmonic coefficient of rho. Odd coefficients vanish by antipodal evenness. Spherical polynomials are dense in continuous functions, so rho=1 almost everywhere. Averaging (13) over e gives c0=C_tau.

For rho=1, rotational symmetry reduces F_b to a positive mixture of ordinary free propagators:

    F_b(p)=integral_[0,1] dnu(t) / [b+(1+tau t)|p|^2],

where nu is the distribution of (e.v)^2 under Haar v. Each summand is a positive multiple of 1/(|p|^2+b/(1+tau t)), so RP holds for every mirror.

## 9. Exact consequences for continuous positive ACG axes

For fixed lambda in (-1,1) excluding zero, let mu_axis be an even probability measure on S3 and let

    rho(v)=integral rho_(lambda,a)(v) mu_axis(da).

These densities are positive smooth, whether mu_axis is discrete, singular, or continuous. If their resulting rho is W4 invariant and the coordinate/diagonal RP assumptions hold, rho must be constant by the theorem above.

For fixed lambda, the ACG angular convolution has degree-2j multiplier

    [1+(1+lambda)j] lambda^j/(2j+1),                           (15)

which never vanishes. Therefore, for this fixed-parameter class, rho=1 if and only if the unoriented axis distribution is Haar. This is a statement about the full distribution, not about each individual axis: Haar axes are genuinely continuous and almost every axis is oblique.

For arbitrary positive joint mixtures of axes and anisotropy parameters, the theorem still forces the resulting rho to equal 1, but need not force a unique joint representation. Parameter-dependent harmonic cancellations can leave the same constant rho. No axis-by-axis exclusion is asserted in that class.

## 10. Boundaries and dependencies

- The conclusion is only for the scalar angular covariance family displayed at the start.
- tau=0 is excluded: then the covariance ignores rho, so no angular rigidity is possible.
- Antipodal evenness is necessary for identifying rho itself; without it, only its even part is visible to the covariance. Continuous ACG-axis mixtures are automatically even.
- The nonnegative normalized density assumption ensures the uniform real bounds and the accepted Fourier/Hankel hypotheses. The key rigidity proof after Stieltjes representation is more general.
- W4 symmetry is used to transport the two orbit-representative RP hypotheses and to eliminate coordinate Hessian cross terms. The alternative is to assume the full stated mirror invariance/RP family explicitly.
- No unresolved mathematical step was found in this independent propagation check. A separate coordinated review should reconcile final artifact hashes and the imported bounded-Hankel lemma before treating this as an accepted integrated research result.

Read sources:
- /workspace/shared/mixed-acg-axis-next-20261019/RESULT.md
- /workspace/shared/mixed-axis-root-20261019/DERIVATION.md
- /workspace/shared/infinite-angular-candidates-20261019/RESULT.md
- The bounded-Hankel lemma is quoted from the accepted source referenced by the mixed-axis result: /workspace/shared/diagonal-rp-next-20261019/RESULT.md.

The older finite-axis result is used only for its accepted RP-to-Stieltjes/high-frequency infrastructure and harmonic normalizations; its finite-axis obstruction is not used to prove the new theorem.

## 11. Negative witnesses and completed exact checks

For a nonconstant W4-invariant even rho, the proof by contradiction supplies at least one required mirror and one nonzero tangent fiber whose homogeneous slice is not Stieltjes. Normalize the tangent to unit length. The accepted bounded-Hankel contrapositive gives a real h in C_c^infinity((0,infinity)) with homogeneous form -epsilon_h<0. The real-momentum estimate implies

    ||H_delta-H_0||_infinity <= delta/4,
    |Q_delta(h)-Q_0(h)| <= delta ||h||_1^2/4.

Therefore every kappa with kappa^2>b||h||_1^2/(4epsilon_h) produces a negative fixed-b fiber at tangential frequency kappa k, with h_kappa(t)=kappa h(kappa t). A finite compact tangential wave packet, followed by taking a negative real or imaginary part if needed, supplies a real C_c^infinity spacetime witness strictly inside the positive half-space. This is an existence statement, not an explicit numerically located witness. It does not require making an improper zero-mass covariance into a standalone theory at p=0.

The saved check_exact.py passes 28 exact identity/basis/quadrant checks and rejects three deliberate corruptions (upper residue sign, Jensen-defect sign, and Hessian-moment sign). Ordinary and optimized Python outputs are byte-identical. These checks verify algebra only; the positivity, convergence, topology, continuation, and harmonic uniqueness arguments remain the analytic proof above.

Reproduce with:

    python check_exact.py
    python -O check_exact.py

The final MANIFEST.json records the reviewed local source hashes and hashes of this proof, checker, and both successful outputs. It contains no claim of external publication or execution of repository code.
