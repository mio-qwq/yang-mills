# Scalar general angular rigidity: local research checkpoint

Date: 19 October 2026. This is a small, locally verified research package.

## Exact result and its boundaries

For tau > 0, b > 0, and a nonnegative normalized L1 angular density rho on S3,
consider F_b(p) = integral rho(v) / [b + |p|² + tau(p·v)²] d sigma(v).
If rho is antipodally even and W4 invariant, reflection positivity at the
coordinate mirror normal e1 and diagonal mirror normal (e1+e2)/sqrt(2)
forces rho = 1 almost everywhere. Conversely rho = 1 is reflection positive
at every mirror. Equivalently, without evenness, the statement identifies only
the even part of rho; the odd part is invisible to this covariance.

The more general formulation assumes covariance reflection invariance and
reflection positivity at every coordinate and diagonal mirror. The homogeneous
limit is radial with constant 2/(1+sqrt(1+tau)). Reflection positivity is a
full-spacetime/all-tangential-momenta condition, not positivity at selected fibers.
The argument covers arbitrary L1 densities, with no finite-axis or finite-harmonic
assumption. For a nonconstant W4-invariant even rho in this class, at least one
required mirror fails reflection positivity. The proof gives existence, not
numerical coordinates, of a compact negative witness for such a mirror.

This concerns this scalar Gaussian covariance family. It is not an interacting
Yang-Mills construction, a mass-gap proof, formal Lean certification, or a claim
of mathematical novelty. The separate audit is a research review within the
same collaborative workflow, not a report of external peer review.

## Next-step boundary

The positive normalized angular-integral covariance class under these mirror
invariance and all-tangential-momenta hypotheses is now classified. Merely adding
axes or choosing smoother densities within the same class cannot evade the
result, so that is not a useful new research round. A substantive reopening
would change the kernel or covariance class, or prove applicability to a
genuinely interacting model. The general Yang-Mills mass-gap question remains
outside this scalar result. Isolated positive fiber tests do not supply the
reflection-positivity hypotheses used here.

## Reading order

1. proofs/GENERAL_ANGULAR_RIGIDITY.md: complete current derivation, including
   compact spectral support, two-mirror continuation, Jensen equality propagation,
   harmonic identifiability, and finite-positive-mass witness transfer.
2. proofs/INDEPENDENT_AUDIT.md: separate detailed audit and fixed-mass corollary.
3. proofs/BOUNDED_HANKEL_FULL_SOURCE.md: the full unabridged prior source.
   Section 4 contains the required bounded-Hankel-to-Stieltjes proof; Sections
   5–6 give real-frequency convergence and compact spacetime witness transfer.
   Its older finite-axis theorem is context, not the source of the new rigidity.
4. proofs/ROOT_DERIVATION.md: contemporaneous compact-support and propagation
   derivation. Its original provisional label is preserved, not silently edited.

The main analytic dependency is included in full. Standard results such as the
semigroup spectral theorem, positive Stieltjes inversion, Cauchy-transform
distribution identities, and harmonic completeness are used as ordinary
mathematics. Historical local paths in preserved proofs/manifests are provenance;
they do not need to exist to read the bundled core proof. The optional fixed-ACG
axis corollary cites prior harmonic normalization and is not separately formally
certified by this package.

## Reproduce the checks

Recorded environment: Python 3.12.14 and SymPy 1.14.0. SymPy must already be
available in the selected Python environment. No installation, network access,
repository checkout, or external-service action is performed by these scripts.
Commands below are run from the extracted package directory:

    python -I -B tools/verify_package.py
    python -I -B tools/replay_checks.py
    python -I -B -O tools/replay_checks.py
    python -I -B tools/rebuild_archive.py ../rebuilt.zip

The replay harness copies the two preserved research checkers to a fresh
temporary directory, then runs each with ordinary Python and Python -O using
isolated mode. Output must match the preserved reference bytes exactly.

- Primary checker: 28 exact identity/basis/quadrant checks and three deliberate
  corruption rejections in each mode (31 recorded entries).
- Audit checker: five exact algebra checks in each mode.
- Additional external mutation controls: three primary and five audit variants,
  each rejected in both modes, for 16 required failing processes. They mutate
  temporary copies only and verify the particular expected failure marker.

The exact replay result is in verification/REPLAY.json. It records all baseline
stdout, corruption outcomes, decisive error messages, versions, and output hashes.
The outer YM_COMPLETE.json records clean extraction, content corruption controls,
archive checksum, and two byte-identical rebuilds. Its own checksum is not
self-referential and it is intentionally outside this archive.

Successful checks verify specified algebra, corruption detection, file integrity,
and byte reproducibility. They do not prove the analytic theorem: positivity,
convergence, connectedness, analytic continuation, distributional arguments,
spectral representation, and harmonic uniqueness remain mathematical arguments
in the proof and audit. There is no formal proof-assistant build in this package.

## Integrity and provenance

Every copied proof and checker is unchanged byte-for-byte. PROVENANCE.json lists
original paths, byte counts, observed hashes, and source-manifest comparisons.
All 14 observed entries in the current primary and dependency source manifests
matched their pins. No current changed pin was silently rewritten. Original
manifests and exact reference outputs remain untouched.

The bounded-Hankel source has a previously documented append-only historical
update. Its original reconciliation JSON and exact suffix are preserved. Removing
that suffix from the bundled full source recovers the historical prefix with the
recorded earlier hash; no mathematical source was altered during packaging.

MANIFEST.json pins all other package files, including the verification scripts
and recorded replay. As usual, a manifest inside an archive is not an external
trust anchor; use the archive SHA-256 reported separately in YM_COMPLETE.json.
Archive generation uses sorted names, fixed timestamps/permissions, and
ZIP_STORED to avoid compression-library differences. The archive should rebuild
byte-for-byte from the unmodified extracted package.

No upload, pull-request merge, release, publication, or third-party repository
code execution was performed as part of this packaging task.
