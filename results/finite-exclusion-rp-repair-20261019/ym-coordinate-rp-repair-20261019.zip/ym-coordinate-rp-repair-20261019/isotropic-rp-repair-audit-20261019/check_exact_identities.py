#!/usr/bin/env python3
"""Exact algebra audit; no assert statements, valid under python -O."""
import sys
import sympy as s
checks=[]
def check(label, expr):
    if s.simplify(expr) != 0:
        raise RuntimeError(label + ': ' + str(s.factor(expr)))
    checks.append(label)

eta,a,d,H=s.symbols('eta a d H', positive=True)
A=1+eta; C=1-eta
x,y=s.symbols('x y',positive=True)
# Roots sqrt(a)=x and sqrt(d)=y; spectral quotient by h0.
D=(A*x+s.I*C*y)**2+H
T=2*(A+s.I*C*y/x)/D
h0=2/(x*(x+s.I*y))
computed=s.simplify(s.im(T)/s.im(h0))
N=A*A*x*x+C*C*y*y-H
if '--negative-control' in sys.argv:
    N=A*A*x*x+C*C*y*y+H
claimed=C*(x*x+y*y)*N/((A*A*x*x-C*C*y*y+H)**2+4*A*A*C*C*x*x*y*y)
check('complete tangent spectral ratio',computed-claimed)

alpha,v=s.symbols('alpha v',positive=True)
delta=1/alpha
m=(alpha-delta)**2/4
G=(1+v)/((1+v)**2+4*m*v)
partial=alpha/(alpha+delta)/(1+alpha**2*v)+delta/(alpha+delta)/(1+delta**2*v)
check('tangent partial fraction',G-partial)
check('partial weights sum to one',alpha/(alpha+delta)+delta/(alpha+delta)-1)
z,r=s.symbols('z r', nonzero=True)
check('even Cauchy transform', z*s.Rational(1,2)*(1/(z-r)+1/(z+r))-1/(1-r*r/z**2))

p=s.Function('p')
f_local=r*(1+r*r)*p(r*r)
f_derivative=s.diff(f_local,r)-(1-r*r)*p(r*r)
expected=4*r*r*p(r*r)+2*r*r*(1+r*r)*s.diff(p(r*r),r)/(2*r)
check('effective r weight derivative',f_derivative-expected)
v,a=s.symbols('v a',positive=True)
check('low-cut maximization square',(1/(8*A*A*a)-v/(v+2*A*A*a)**2)*8*A*A*a*(v+2*A*A*a)**2-(v-2*A*A*a)**2)

r0,Y,beta=s.symbols('r0 Y beta',positive=True)
L=1-r0+Y
u=(r0+Y)/L-2*r0*(1-r0)/L**2
vsq=4*r0*(1-r0)*Y*(1+Y)/L**4
c=2*r0*Y/L**2
N0=r0+beta*(1-r0)-(1-beta)*Y
D0=(r0-beta*(1-r0)+(1-beta)*Y)**2+4*beta*r0*(1-r0)
check('beta completed-square denominator',D0-L*L*((beta-u)**2+vsq))
check('beta completed-square numerator',N0-L*(beta-u+c))
check('beta resonance-distance identity',(1-u)**2+vsq-1/L**2)
etab=(1-s.sqrt(beta))/(1+s.sqrt(beta))
check('beta Jacobian',((1-etab)/(1+etab)**2)*(-s.diff(etab,beta))-1/(2*(1+s.sqrt(beta))))

b,tau,t=s.symbols('b tau t',positive=True)
xx=s.symbols('xx',positive=True)
Dx=1+(1+tau)*xx*xx
ss=b*(1+xx*xx)/Dx
aa=b-ss; dd=(1+tau)*ss-b
check('spectral x coordinate a',aa-b*tau*xx*xx/Dx)
check('spectral x coordinate d',dd-b*tau/Dx)
check('spectral x coordinate differential',s.diff(ss,xx)+2*b*tau*xx/Dx**2)
TT=s.symbols('TT',positive=True)
Dlt=C*C-4*eta*TT
E=A*A-4*eta*TT*(1+tau)
F=A*A+4*eta*TT*(1+tau)
check('cut mass numerator',A*A*xx*xx+C*C-4*eta*TT*Dx-(Dlt+E*xx*xx))
check('cut mass real denominator',A*A*xx*xx-C*C+4*eta*TT*Dx-(F*xx*xx-Dlt))
check('negative-region comparison',F+E-2*A*A)
ww=2*C*(A*A*xx*xx+C*C-4*eta*TT*Dx)/(s.pi*xx*(b*tau/Dx)*((A*A*xx*xx-C*C+4*eta*TT*Dx)**2+4*A*A*C*C*xx*xx))
claimed_mass=4*C*(Dlt+E*xx*xx)/(s.pi*Dx*((F*xx*xx-Dlt)**2+4*A*A*C*C*xx*xx))
check('signed density times spectral Jacobian',ww*(2*b*tau*xx/Dx**2)-claimed_mass)

rr,wwr=s.symbols('rr wwr',positive=True)
res=2*(A+C*wwr/rr)/((A*rr+C*wwr)*(A/rr+C*(1+tau)/wwr))
check('outer positive residue simplification',res-2/(A+C*(1+tau)*rr/wwr))
# Expansion at a=x^2, c=-b*tau+(1+tau)x^2, exact threshold H=C^2 b tau.
# Remove the common zero by rationalizing the denominator before the limit.
eta0=s.Rational(1,3); A0=1+eta0; C0=1-eta0
threshold_T=2*(A0+C0*s.I*s.sqrt(b*tau-(1+tau)*x*x)/x)/((A0*x+C0*s.I*s.sqrt(b*tau-(1+tau)*x*x))**2+C0*C0*b*tau)
check('threshold atom residue at eta=1/3',s.limit(x*x*threshold_T,x,0,dir='+')-1/A0)
check('anisotropy strict-difference factor',(beta**-2+3)/4-16/(beta+3)**2 - 3*(beta-1)**2*(beta**2+8*beta+3)/(4*beta**2*(beta+3)**2))
# Explicit repair constants; inequalities are exact and intentionally conservative.
def less(label, lhs, rhs):
    difference=s.simplify(rhs-lhs)
    if difference.is_positive is not True:
        raise RuntimeError(label+': comparison not proved: '+str(difference))
    checks.append(label)
g=6*(beta-s.Rational(1,9))*(s.Rational(1,4)-beta)/(s.Rational(5,36)**3)
check('taper probability mass',s.integrate(g,(beta,s.Rational(1,9),s.Rational(1,4)))-1)
check('taper maximum',g.subs(beta,s.Rational(13,72))-s.Rational(54,5))
check('taper derivative endpoint',s.diff(g,beta).subs(beta,s.Rational(1,9))-s.Rational(7776,25))
check('taper derivative first two bounds',s.Rational(7776,25)/4+s.Rational(54,5)*s.Rational(3,4)-s.Rational(4293,50))
check('taper J derivative bound',s.Rational(54,5)*s.Rational(1,2)/(4*s.Rational(3,4))-s.Rational(9,5))
less('B less than 1/6',1/(4*s.sqrt(3)),s.Rational(1,6))
less('R derivative final term',s.Rational(1,6)/(2*s.Rational(3,4)**s.Rational(3,2)),s.Rational(1,6))
less('R Lipschitz bound',s.Rational(4293,50)+s.Rational(9,5)+s.Rational(1,6),s.Integer(88))
less('R supremum interval bound',s.Rational(27,10)+1/(3*s.sqrt(3)),s.Integer(3))
check('R fourth-power tail bound',s.Rational(1,6)**4/(1-s.Rational(1,9))-s.Rational(1,1152))
check('R fourth-power interval bound',3**4*s.Rational(5,36)-s.Rational(45,4))
less('R L4 bound',s.Rational(1,1152)+s.Rational(45,4),s.Integer(16))
less('Holder factor bound',s.Integer(6)**s.Rational(3,4),s.Integer(4))
check('Cauchy M bound',2*88+4*2-184)
check('Y0 bound',s.Rational(1,9)/(1-s.Rational(1,9))-s.Rational(1,8))
less('halfline tail contribution bound',s.Rational(22,7)*s.Rational(1,6)*3,s.Integer(2))
check('uniform m comparison',2+8*184-1474)
less('uniform m rounded bound',s.Integer(1474),s.Integer(1500))
check('repaired strict spectral margin',1-(1+s.Rational(3,4)*1500)/1200-s.Rational(37,600))
print('PASS: '+str(len(checks))+' exact identities and comparisons')
for label in checks:
    print('  '+label)
