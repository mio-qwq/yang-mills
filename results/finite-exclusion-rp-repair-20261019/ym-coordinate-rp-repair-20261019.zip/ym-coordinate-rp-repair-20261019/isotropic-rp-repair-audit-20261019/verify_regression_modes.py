#!/usr/bin/env python3
import hashlib
import pathlib
import subprocess
import sys
here=pathlib.Path(__file__).resolve().parent
script=here/'check_exact_identities.py'
outputs=[]
for optimized in (False,True):
    cmd=[sys.executable]+(['-O'] if optimized else [])+[str(script)]
    result=subprocess.run(cmd,capture_output=True,text=True)
    if result.returncode:
        raise RuntimeError('Normal regression failed: '+result.stdout+result.stderr)
    outputs.append(result.stdout)
    negative=subprocess.run(cmd+['--negative-control'],capture_output=True,text=True)
    if negative.returncode==0 or 'complete tangent spectral ratio' not in negative.stderr:
        raise RuntimeError('Negative control did not fail as required.')
if outputs[0]!=outputs[1]:
    raise RuntimeError('Ordinary and optimized outputs differ.')
digest=hashlib.sha256(outputs[0].encode()).hexdigest()
print(outputs[0],end='')
print('PASS: normal and optimized outputs match; both negative controls fail.')
print('SHA256: '+digest)
