# Independent audit: isotropic dilution repairs the smoothed four-axis family

19 October 2026. Local scalar Gaussian two-point analysis only. No remote edits, merge, release, or publication.

## Verdict

The coordinate-mirror repair theorem in `/workspace/shared/isotropic-rp-repair-20261019/RESULT.md` passes this independent audit. Its parameter-Cauchy-transform bound, physical-sheet reconstruction, and genuine anisotropy are valid. The difficult eta-to-zero tail is integrable and causes no unbounded negative ratio after the parameter average.

The theorem extends to any nonnegative probability density p(lambda) whose zero extension is globally Lipschitz and whose support lies in [ell,Lambda] strictly inside (0,1). Smooth compact support is sufficient but unnecessary. In particular it repairs the previous polynomial beta taper after reparameterization and sufficiently small positive isotropic dilution. This does not assert diagonal-mirror positivity, rotational invariance, interacting Yang-Mills theory, or a mass gap.

Below is a separate, simpler proof of the required uniform bound, plus an independent global total-variation bound that justifies spectral Fubini. These avoid relying on unproved endpoint interchanges.

## 1. An effective parameter with no singular endpoint

Use the accepted axial decomposition

    F_(lambda,a)=(1+lambda)T_(lambda,a)/2
                  +(1-lambda)/2 integral_0^1 T_(lambda r^2,a) dr.

For a probability density p supported in [ell,Lambda], change eta=r^2 in the effective mixture. The resulting axial covariance is

    F_(mix,a)=integral_0^infinity f(r) T_(r^2,a) dr,
    f(r)=r(1+r^2)p(r^2)
         +(1/2) integral_(r^2)^infinity p(lambda)(1-lambda)/sqrt(lambda) d lambda.

The density f is nonnegative, has integral one, is constant on [0,sqrt(ell)], and vanishes on [sqrt(Lambda),infinity). Its even extension f_e is globally Lipschitz and compactly supported inside (-1,1). Almost everywhere,

    f'(r)=4r^2p(r^2)+2r^2(1+r^2)p'(r^2).

Thus, writing P=||p||_infinity and Lp=Lip(p), convenient bounds are

    Lf=Lip(f_e) <= 4 Lambda P+2 Lambda(1+Lambda)Lp,
    Pf=||f_e||_infinity
       <= sqrt(Lambda)(1+Lambda)P+(1-ell)/(2sqrt(ell)).

In particular the eta^(-1/2) tail becomes a genuinely constant neighborhood of r=0. It must not be discarded or treated as an arbitrary rough endpoint.

## 2. Uniform Cauchy-transform bound

For z outside the real axis define

    C_f(z)=integral_R f_e(t)/(z-t) dt,
    H(z)=z C_f(z)/2
        =integral_0^infinity f(r)/(1-r^2/z^2) dr.

Let z=u+iv. In the real part of C_f split |t-u|<=1 from its complement. Subtract f_e(u) on the symmetric near interval; its real-kernel contribution is zero. Lipschitz continuity gives

    |Re C_f(z)| <= 2 Lf+||f_e||_1=2 Lf+2.

The imaginary part is a Poisson integral, so

    |Im C_f(z)| <= pi Pf.

Consequently |C_f(z)|<=2Lf+2+pi Pf. If |z|<=2, the same bound applies to H. If |z|>2, the support |r|<1 gives |1-r^2/z^2|>=3/4 and therefore |H(z)|<=4/3. Define

    M=max{4/3, 2Lf+2+pi Pf}.

Then |H(z)|<=M everywhere off the real line. All constants depend only on the parameter density, not on b, tau, the cut position, or tangential frequency.

## 3. The full shared cut, including both endpoints and arbitrary tangential vectors

Fix the mirror e1 and any tangential vector k. For a tangent axis a let t=(a.k)^2; every t>=0 is covered. On q=-s+i0 in the common cut put

    a=b-s>0, d=(1+tau)s-b>0,
    h0=2/[sqrt(a)(sqrt(a)+i sqrt(d))],
    w0=2sqrt(d)/[pi sqrt(a)(a+d)]>0.

Write

    y=(sqrt(a)-i sqrt(d))/(sqrt(a)+i sqrt(d)),
    h=(sqrt(d)+i sqrt(a))/sqrt(a+d), so h^2=-y,
    alpha=sqrt(1+t/s)+sqrt(t/s), delta=1/alpha.

The exact tangent ratio factors as

    T_(eta,a)/h0
      =(1+eta y)/[(1+alpha^2 eta y)(1+delta^2 eta y)]
      =alpha/(alpha+delta) /(1-alpha^2 eta h^2)
         +delta/(alpha+delta) /(1-delta^2 eta h^2).

Both coefficients are positive and sum to one. Integrating eta=r^2 gives

    F_(mix,a)/h0
      =alpha/(alpha+delta) H(1/(alpha h))
         +delta/(alpha+delta) H(1/(delta h)).

The two H arguments lie strictly in the lower half plane, and therefore the absolute value of this ratio is at most M, uniformly in every s and t. If d>=a, writing the ratio as J gives

    w_(mix,a)/w0=Re J-sqrt(a/d) Im J >=-sqrt(2) M.

This estimate alone should not be used at the lower endpoint d=0, because its multiplier sqrt(a/d) diverges. That endpoint admits a separate pointwise bound. For every eta, set A=1+eta, C=1-eta and h_t=4eta tau t. Direct division gives

    w_eta/w0=C(a+d)(A^2 a+C^2 d-h_t)
       /[(A^2 a-C^2 d+h_t)^2+4A^2 C^2 a d].

If it is negative, let v=h_t-(A^2a+C^2d)>0. Then

    |w_eta/w0| <= C(a+d)v/(v+2A^2a)^2
                 <= C(a+d)/(8A^2a).

For d<=a this is at most C/(4A^2)<=1/4. The positive probability mixture retains that bound. Thus the global estimate is

    w_(mix,a) >=-m w0,    m=max{1/4,sqrt(2)M}=sqrt(2)M.

This covers the whole common cut and all tangential frequencies, including simultaneous frequency/endpoint limits. No order of such limits is needed.

## 4. Physical-sheet support and threshold atoms

The exact tangent block is

    T_eta(q;t)=2[A+C sqrt(b+(1+tau)q)/sqrt(b+q)]
       /{[A sqrt(b+q)+C sqrt(b+(1+tau)q)]^2+4eta tau t}.

Continue both roots individually from positive real q. Their positive linear combination lies in the first quadrant for Im(q)>0; its square has positive imaginary part. There are no nonreal physical-sheet poles.

There is no tangent support for q>-b/(1+tau). For q=-s, s>b, both roots are imaginary; changing both signs leaves the expression unchanged. Its only possible singularity is a unique real pole satisfying

    [A sqrt(s-b)+C sqrt((1+tau)s-b)]^2=4eta tau t.

It exists exactly when 4eta t>C^2 b. Its residue is

    R_eta=2/[A+C(1+tau)sqrt(s-b)/sqrt((1+tau)s-b)]>0,

and R_eta<=2/A<=2. Its position satisfies b<s<=b+eta tau t. At exact equality 4eta t=C^2b, the upper endpoint expansion is

    T_eta(q;t)=1/[A(q+b)]+O(|q+b|^(-1/2)).

Thus the endpoint atom has positive residue 1/A. The approaching outer pole has limiting residue 2/A; confusing these two values would invalidate reconstruction. This audit independently verifies the distinction.

For fixed t>0 the equality value eta is unique, since (1-eta)^2/(4eta) is strictly decreasing. An absolutely continuous parameter measure assigns it zero mass. The mixed off-cut measure is a positive pushforward of the outer-pole weights, with no endpoint atom surviving. When t=0 there is no such equality in the permitted eta interval.

The normal-axis mixture is the accepted positive one-mirror family. Its positive spectral measure remains positive under parameter integration.

## 5. A global total-variation bound legitimizes spectral mixing

For each fixed eta and t, the preceding analytic expression is O(1/q) at infinity. At the lower endpoint it is bounded; at the upper endpoint it is O(|q+b|^(-1/2)) after subtraction of the explicit threshold atom. A standard Cauchy contour around the finite cut and listed poles therefore gives exactly the signed Stieltjes representation. The endpoint arcs vanish after the stated atom subtraction. There is no contact or entire remainder.

Here is a uniform bound that makes the subsequent parameter Fubini entirely safe. Put

    x=sqrt((b-s)/((1+tau)s-b)), T=t/b,
    D0=1+(1+tau)x^2,
    delta=C^2-4eta T,
    E=A^2-4eta T(1+tau),
    F=A^2+4eta T(1+tau).

Changing s to x, with reversed orientation, gives exactly

    w_eta(s;t)|ds|
      =[4C/pi](delta+E x^2)
         /{D0[(F x^2-delta)^2+4A^2C^2x^2]} dx.

If delta<0, the negative part is bounded by the sum of the integrals

    (4C/pi) integral_0^infinity |delta|/(delta^2+4A^2C^2x^2) dx,
    (4C/pi) integral_0^infinity F/(F^2x^2+4A^2C^2) dx.

Each equals 1/A, so the negative mass is at most 2. The second term is needed only if E<0, in which case |E|<=F.

If delta>=0, negativity forces E<0 and x^2>delta/|E|. There

    F x^2-delta >=(F-|E|)x^2=2A^2x^2,
    |E|<=C^2(1+tau)<=1+tau.

Dropping D0 and enlarging the integration interval gives negative mass at most

    (4C/pi) integral_0^infinity |E|/[4A^2(A^2x^2+C^2)] dx
       =|E|/(2A^3)<=(1+tau)/2.

Therefore every block's negative spectral mass is at most

    N_tau=max{2,(1+tau)/2}.

All atoms are positive, and the total signed mass from infinity is

    lim_(q->+infinity) q T_eta(q;t)
       =2/[A+C sqrt(1+tau)]<=1.

Consequently every block has total variation at most 1+2N_tau, uniformly in eta, t and b. Because the effective parameter measure is a probability measure, signed Fubini follows directly. This also prevents hidden negative atoms from appearing through a parameter limit. The open-cut mixed density agrees with the averaged ordinary boundary value because for fixed interior s the denominators are uniformly separated from zero on the compact eta interval.

After q=z+K all tangent energies are K+s>0. Normal-axis energies are positive by the accepted theorem. Thus the representations are the required normal-frequency Stieltjes representations, not a formal representation in an unrelated variable.

## 6. Repair and anisotropy

One of the four axial terms is normal and positive. The other three each have common-cut density at least -m w0; all their extra support is positive. Hence the W4 average is bounded below by -(3m/4)w0 on the cut and is nonnegative elsewhere. Every

    0<epsilon<=1/[1+3m/4]

makes (1-epsilon)h0+epsilon F_W4 a positive Stieltjes function in z=u^2 for every tangential k. This implies fixed-k positive Hankel kernels; integrating tangential Fourier transforms gives genuine coordinate RP for compact smooth tests. The original normalized positive angular density supplies the usual real-momentum domination.

The density is strictly anisotropic: for every beta<1, strict convexity of x -> [1-(1-beta)x]^(-2) gives

    (1/4)[beta^(-2)+3] > [1-(1-beta)/4]^(-2).

Thus rho_mix(e1)>rho_mix((1,1,1,1)/2). Positive mixing and epsilon>0 preserve strictness. Every angular derivative is uniformly bounded on the compact beta interval, so even the Lipschitz parameter extension produces a C-infinity angular density.

## 7. Audit of the proposed beta-coordinate proof

The original proof's exact ratio, beta Jacobian, completed square, identity |1-(u+iv)|=1/L, and positive c-term are correct. The half-line Cauchy transform is -pi/sqrt(z-1) on the physical upper-half-plane branch. Subtracting B/sqrt(1-beta) on the entire half-line beta<1 is legitimate: it cancels the singularity identically near beta=1; the resulting remainder is globally Lipschitz and L4, with tail O(|beta|^(-1/2)). The near symmetric cancellation and far Holder estimate therefore apply.

For merely Lipschitz p, replace statements that the remainder is smooth by statements that it is globally Lipschitz, and interpret ||R'||_infinity as its weak derivative's essential supremum. No other argument changes. At the lower support endpoint, zero-extension Lipschitz continuity forces p=0, which is the necessary matching condition. A parameter density with a jump at that endpoint is not covered.

The original local double-integrability estimate near a threshold is also valid. The global bound in Section 5 provides a second, stronger justification and avoids keeping track of local neighborhoods when t varies.

## 8. Checked scope and limitations

- All tangential vectors, all common-cut points, both endpoint regimes, and eta approaching zero are covered uniformly.
- Positive off-cut poles and the special positive threshold atom are explicitly retained.
- The signed measure is reconstructed before positivity is concluded; there is no hidden contact term.
- The repair parameter can be chosen using p alone, independently of b and tau.
- Pure fixed-beta averaging remains excluded; it does not have the required Lipschitz effective r density.
- The previous failing tapered parameter mixture remains failing without isotropic dilution and is repaired after sufficiently small positive dilution.
- No diagonal-mirror claim is made.

`check_exact_identities.py` verifies the algebraic parts with exact SymPy expressions and explicit failures. Its negative control corrupts the tangent spectral numerator and must fail under ordinary and optimized Python. These checks supplement, rather than replace, the analytic proof above.

## 9. Independently checked explicit repair of the old taper

The proposed Section 7 explicit construction also passes. Let

    g(beta)=6(beta-1/9)(1/4-beta)/(5/36)^3

on [1/9,1/4], zero elsewhere. Its exact supremum is 54/5 and its Lipschitz constant is 7776/25. Under the parameter transform, lambda lies in [1/3,1/2]. The beta-Cauchy weight and its remainder satisfy

    h_mix(beta)=g(beta)sqrt(beta)/2+J(beta)/sqrt(1-beta),
    R(beta)=g(beta)sqrt(beta)/2+(J(beta)-B)/sqrt(1-beta),
    J'(beta)=g(beta)sqrt(beta)/[4sqrt(1-beta)],
    0<=J<=B<=1/(4sqrt(3))<1/6.

Almost everywhere in the interval, differentiating all terms gives

    |R'| <= |g'|sqrt(beta)/2+g/(4sqrt(beta))
             +g sqrt(beta)/[4(1-beta)]
             +B/[2(1-beta)^(3/2)]
           < 4293/50+9/5+1/6 <88.

Below 1/9, R=-B/sqrt(1-beta), whose derivative is smaller; above 1/4, R=0. Endpoint matching is continuous, so the piecewise almost-everywhere bound gives global Lipschitz continuity. On the compact interval,

    |R|<=27/10+1/(3sqrt(3))<3.

Therefore

    ||R||_4^4 <1/1152+45/4<16,
    M_beta=2Lip(R)+6^(3/4)||R||_4<184.

Here Y0=1/8, hence

    m_beta=pi B sqrt(8)+8M_beta<1474<1500.

Consequently the explicit angular density

    rho_repaired=1199/1200+(1/1200)rho_taper

has positive coordinate-mirror spectral measures for every b,tau>0, with the strict shared-cut bound

    w_repaired >= (37/600)w0.

This is the same previously negative tapered density with a constant background, not a newly substituted unknown example. Its genuine anisotropy and angular smoothness survive the dilution.

The final independent regression contains 39 exact identities and comparisons. Ordinary and optimized execution agree, and the intentionally corrupted spectral-numerator control fails in both. Successful-output SHA256:

    022aa2d36445f550a3283fcac8791a35a7907f2477d947836486361a82bf4678

Reproduce with:

    python check_exact_identities.py
    python verify_regression_modes.py
    python -O verify_regression_modes.py
