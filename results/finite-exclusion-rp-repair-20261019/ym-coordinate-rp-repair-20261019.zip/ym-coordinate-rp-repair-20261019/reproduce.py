#!/usr/bin/env python3
"""Portable, optimization-resistant integrity checks and exact local replay."""
import argparse
import hashlib
import io
import json
import os
from pathlib import Path, PurePosixPath
import re
import stat
import subprocess
import sys
import tempfile
from zipfile import ZipFile

ROOT = Path(__file__).resolve().parent
DEPENDENCY = 'dependencies/ym-w4-parameter-mixtures-20261019.zip'
DEPENDENCY_SHA = 'f255905f22eb287a30d8309f01af932b7798a17e14b52df0c40c16a8652d84bd'
PRIOR_ROOT = 'ym-w4-parameter-mixtures-20261019'
AXIAL_FILE = PRIOR_ROOT + '/dependencies/ym-positive-infinite-angular-20261019.zip'
AXIAL_SHA = '476a47359f8ff24bef53709d7e0cefa7dfa5e27001c9e4f5326f3d2e1ffe303b'
AXIAL_ROOT = 'ym-positive-infinite-angular-20261019'


def require(condition, message):
    if not condition:
        raise RuntimeError(message)


def sha(data):
    return hashlib.sha256(data).hexdigest()


def safe_name(name):
    path = PurePosixPath(name)
    require(name and not path.is_absolute() and '\\' not in name
            and name == path.as_posix() and '..' not in path.parts,
            'Unsafe payload path: ' + name)
    return name


def parse_manifest(data):
    entries = {}
    for line in data.decode('utf-8').splitlines():
        digest, name = line.split('  ', 1)
        safe_name(name)
        require(re.fullmatch('[0-9a-f]{64}', digest) is not None,
                'Invalid digest: ' + name)
        require(name not in entries and name != 'SHA256SUMS',
                'Duplicate or self-referential manifest entry: ' + name)
        entries[name] = digest
    require(entries, 'Empty manifest')
    return entries


def verify_tree(root=ROOT):
    entries = parse_manifest((root / 'SHA256SUMS').read_bytes())
    found = set()
    for path in root.rglob('*'):
        require(not path.is_symlink(), 'Symlink in payload: ' + str(path))
        if path.is_file():
            found.add(path.relative_to(root).as_posix())
    require(found == set(entries) | {'SHA256SUMS'},
            'Manifest file-set mismatch: ' + repr(sorted(found ^ (set(entries) | {'SHA256SUMS'}))))
    for name, digest in entries.items():
        path = root / name
        require(path.resolve().is_relative_to(root.resolve()), 'Path escaped payload: ' + name)
        require(sha(path.read_bytes()) == digest, 'Integrity mismatch: ' + name)
    return len(entries)


def verify_zip(data, prefix, digest):
    require(sha(data) == digest, 'Dependency archive identity mismatch: ' + prefix)
    contents = {}
    with ZipFile(io.BytesIO(data)) as archive:
        for entry in archive.infolist():
            name = safe_name(entry.filename)
            require(not entry.is_dir() and name.startswith(prefix + '/'),
                    'Unexpected dependency archive path: ' + name)
            require(name not in contents, 'Duplicate dependency ZIP entry: ' + name)
            require(not stat.S_ISLNK(entry.external_attr >> 16),
                    'Symlink in dependency ZIP: ' + name)
            contents[name] = archive.read(entry)
    manifest = parse_manifest(contents[prefix + '/SHA256SUMS'])
    expected = {prefix + '/' + name for name in manifest} | {prefix + '/SHA256SUMS'}
    require(set(contents) == expected, 'Dependency manifest file-set mismatch: ' + prefix)
    for name, digest in manifest.items():
        require(sha(contents[prefix + '/' + name]) == digest,
                'Dependency payload integrity mismatch: ' + prefix + '/' + name)
    return contents, len(manifest)


def dependencies():
    prior, prior_count = verify_zip((ROOT / DEPENDENCY).read_bytes(), PRIOR_ROOT, DEPENDENCY_SHA)
    axial, axial_count = verify_zip(prior[AXIAL_FILE], AXIAL_ROOT, AXIAL_SHA)
    proof_paths = [AXIAL_ROOT + '/RESULT.md', AXIAL_ROOT + '/AUDIT_POSITIVE.md']
    proof_files = []
    for name in proof_paths:
        require(bool(axial[name]), 'Missing accepted axial source proof: ' + name)
        proof_files.append({'path': name, 'bytes': len(axial[name]), 'sha256': sha(axial[name])})
    return prior, {'prior_archive_sha256': DEPENDENCY_SHA,
                   'prior_manifest_files': prior_count,
                   'axial_archive_sha256': AXIAL_SHA,
                   'axial_manifest_files': axial_count,
                   'accepted_axial_proof_files': proof_files,
                   'source_proof_integrity': 'PASS; hashes verified, not an automated proof check'}


def run(command, env, cwd=ROOT):
    return subprocess.run(command, capture_output=True, env=env, cwd=cwd)


def current_checks(env):
    tasks = [
        ('isotropic-rp-repair-20261019', 32,
         '4455920d6ac72bef4443dfceee450b4ba0fcfa5a53435e1715226c205287a75b',
         'FAIL Cauchy numerator and positive correction'),
        ('isotropic-rp-repair-audit-20261019', 39,
         '022aa2d36445f550a3283fcac8791a35a7907f2477d947836486361a82bf4678',
         'complete tangent spectral ratio'),
    ]
    results = []
    for directory, count, expected, negative_marker in tasks:
        good_outputs, runner_outputs = [], []
        script = ROOT / directory / 'check_exact_identities.py'
        runner = script.with_name('verify_regression_modes.py')
        for flags in ([], ['-O']):
            command = [sys.executable, *flags, str(script)]
            good = run(command, env)
            require(good.returncode == 0, 'Positive check failed: ' + directory + '\n' + good.stderr.decode())
            require(sha(good.stdout) == expected, 'Accepted output mismatch: ' + directory)
            good_outputs.append(good.stdout)
            bad = run(command + ['--negative-control'], env)
            require(bad.returncode != 0 and negative_marker in (bad.stdout + bad.stderr).decode(),
                    'Negative control failed to reject expected corruption: ' + directory)
            verification = run([sys.executable, *flags, str(runner)], env)
            require(verification.returncode == 0,
                    'Original regression runner failed: ' + directory + '\n' + verification.stderr.decode())
            runner_outputs.append(verification.stdout)
        require(good_outputs[0] == good_outputs[1], 'Checker mode mismatch: ' + directory)
        require(runner_outputs[0] == runner_outputs[1], 'Regression runner mode mismatch: ' + directory)
        results.append({'source': directory, 'exact_checks': count,
                        'positive_output_sha256': expected,
                        'positive_normal_and_optimized': 'PASS',
                        'negative_controls': 'EXPECTED_REJECTION_BOTH_MODES',
                        'original_regression_runners_normal_and_optimized': 'PASS',
                        'runner_output_sha256': sha(runner_outputs[0])})
    return results


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--integrity-only', action='store_true',
                        help='Verify the entire payload and both nested dependency manifests, without running algebra checks.')
    parser.add_argument('--with-dependency-replay', action='store_true',
                        help='Also run the pinned prior archive full replay, including its axial dependency.')
    args = parser.parse_args()
    require(not (args.integrity_only and args.with_dependency_replay), 'Choose integrity-only or dependency replay, not both')
    count = verify_tree()
    prior, dependency_report = dependencies()
    report = {'status': 'PASS', 'integrity_files': count, 'dependency_integrity': dependency_report}
    if args.integrity_only:
        print(json.dumps(report, indent=2, sort_keys=True))
        return
    import sympy
    require(sympy.__version__ == '1.14.0', 'SymPy 1.14.0 is required; found ' + sympy.__version__)
    env = dict(os.environ, PYTHONDONTWRITEBYTECODE='1', PYTHONHASHSEED='0')
    env.pop('PYTHONOPTIMIZE', None)
    report.update({'python': sys.version.split()[0], 'sympy': sympy.__version__,
                   'current_exact_check_total': 71, 'checks': current_checks(env),
                   'dependency_full_replay': 'NOT RUN; use --with-dependency-replay'})
    if args.with_dependency_replay:
        with tempfile.TemporaryDirectory(prefix='ym-coordinate-rp-dependency-') as directory:
            work = Path(directory)
            # Paths were validated and all bytes hash-checked before materializing.
            for name, data in prior.items():
                target = work / name
                target.parent.mkdir(parents=True, exist_ok=True)
                target.write_bytes(data)
            flags = ['-O'] if sys.flags.optimize else []
            result = run([sys.executable, *flags, str(work / PRIOR_ROOT / 'reproduce.py')], env, work)
            require(result.returncode == 0,
                    'Prior dependency replay failed:\n' + result.stderr.decode())
            details = json.loads(result.stdout)
            require(details.get('status') == 'PASS', 'Prior dependency did not report PASS')
            report['dependency_full_replay'] = details
            report['dependency_full_replay_output_sha256'] = sha(result.stdout)
    report['claim_boundary'] = ('Coordinate-mirror RP for this scalar Gaussian covariance family only. '
                                'Exact checks support the retained analytic proofs; no diagonal RP or Yang-Mills conclusion.')
    print(json.dumps(report, indent=2, sort_keys=True))


if __name__ == '__main__':
    main()
