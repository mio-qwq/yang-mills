#!/usr/bin/env python3
"""Exact algebra checks for the local isotropic RP repair theorem.

These checks are supporting regressions, not a substitute for the analysis.
No correctness check uses Python assert, so python -O preserves every check.
"""
import argparse
import hashlib
import json
import sys
import sympy as S

parser=argparse.ArgumentParser()
parser.add_argument('--negative-control', action='store_true')
args=parser.parse_args()
checks=[]

def equal(name, left, right):
    difference=S.factor(S.together(left-right))
    if difference != 0:
        print(f'FAIL {name}: {difference}', file=sys.stderr)
        raise SystemExit(1)
    checks.append(name)

eta,r,Y,beta=S.symbols('eta r Y beta', real=True)
A=1+eta; C=1-eta
L=1-r+Y
u=(r+Y)/L-2*r*(1-r)/L**2
v2=4*r*(1-r)*Y*(1+Y)/L**4
c=(3 if args.negative_control else 2)*r*Y/L**2
D=(r-beta*(1-r)+(1-beta)*Y)**2+4*beta*r*(1-r)
N=r+beta*(1-r)-(1-beta)*Y
equal('quadratic Cauchy denominator',D,L**2*((beta-u)**2+v2))
equal('Cauchy numerator and positive correction',N,L*((beta-u)+c))
equal('endpoint distance identity',(1-u)**2+v2,1/L**2)
equal('positive correction',c,2*r*Y/L**2)
equal('low-frequency numerator bound',N-(beta-(1-beta)*Y),r*(1-beta))
equal('normalization of axial mixture weights',A/2+C/2,1)
equal('beta relation',1-C**2/A**2,4*eta/A**2)

x,y,h=S.symbols('x y h',positive=True)
Z=(A*x+S.I*C*y)**2+h
T=2*(A+S.I*C*y/x)/Z
imag=S.simplify(S.im(S.expand_complex(T)))
expected=2*C*y/x*(h-A**2*x**2-C**2*y**2)/((A**2*x**2-C**2*y**2+h)**2+4*A**2*C**2*x**2*y**2)
equal('boundary imaginary part',imag,expected)
w0=2*y/(S.pi*x*(x*x+y*y))
equal('raw radial ratio',-imag/S.pi/w0,C*(x*x+y*y)*(A*A*x*x+C*C*y*y-h)/((A*A*x*x-C*C*y*y+h)**2+4*A*A*C*C*x*x*y*y))
ratio=C*(A*A*r+C*C*(1-r)-4*eta*Y)/((A*A*r-C*C*(1-r)+4*eta*Y)**2+4*A*A*C*C*r*(1-r))
betav=C*C/A**2
equal('dimensionless beta ratio',ratio,(C/A**2)*(N/D).subs(beta,betav))

t=S.symbols('t',positive=True)
et=(1-t)/(1+t)
equal('beta parameter Jacobian',S.diff(et,t)/(2*t),-1/(t*(1+t)**2))
equal('Cauchy weight Jacobian',((1-et)/(1+et)**2)/(t*(1+t)**2),1/(2*(1+t)))
equal('tail cancellation identity squared',et*(1+t)**2,1-t*t)
equal('direct beta density weight',t*(1+t)**2/(2*(1+t)**2),t/2)
equal('lambda to beta derivative',S.diff(((1-eta)/(1+eta))**2,eta),-4*(1-eta)/(1+eta)**3)

s,b,tau=S.symbols('s b tau',positive=True)
e=s-b; d=(1+tau)*s-b
squared=(A*S.sqrt(e)+C*S.sqrt(d))**2
equal('outer pole derivative',S.diff(squared,s),(A*S.sqrt(e)+C*S.sqrt(d))*(A/S.sqrt(e)+C*(1+tau)/S.sqrt(d)))
equal('threshold monotonicity',S.diff(C*C/(4*eta),eta),(eta*eta-1)/(4*eta*eta))

qroot=S.symbols('qroot',positive=True)
# At q+b=qroot^2, replace sqrt(c) by a symbol c0 at leading order.
c0=S.symbols('c0',nonzero=True)
threshold_T=2*(A+C*c0/qroot)/(2*A*C*c0*qroot+(A*A+C*C*(1+tau))*qroot**2)
equal('endpoint atom coefficient',S.limit(qroot*qroot*threshold_T,qroot,0),1/A)
outer_res=2*(A+C*y/x)/((A*x+C*y)*(A/x+C*(1+tau)/y))
equal('approaching outer residue',S.limit(outer_res,x,0),2/A)

# Axis-versus-diagonal density difference has a strictly positive factor
# for 0<beta<1, demonstrating nonconstancy after positive mixing.
v=S.symbols('v',positive=True)
diff=(1/v**4+3)/4-16/(3+v*v)**2
equal('nonconstant angular density difference',diff,3*(v*v-1)**2*(v**4+8*v*v+3)/(4*v**4*(v*v+3)**2))

# The smooth-r form reported independently has an especially simple derivative.
f0,p0,p1=S.symbols('f0 p0 p1')
z=S.symbols('z')
# d/dr of r(1+r^2)p(r^2) plus moving lower endpoint integral.
derivative=(1+3*z*z)*p0+2*z*z*(1+z*z)*p1-(1-z*z)*p0
equal('alternative smooth-r weight derivative',derivative,4*z*z*p0+2*z*z*(1+z*z)*p1)

def positive(name, value):
    value=S.factor(value)
    if value.is_positive is not True:
        print(f'FAIL {name}: expected positive, got {value}',file=sys.stderr)
        raise SystemExit(1)
    checks.append(name)

a0=S.Rational(1,9); c0=S.Rational(1,4); H=c0-a0
g=6*(beta-a0)*(c0-beta)/H**3
equal('taper normalization',S.integrate(g,(beta,a0,c0)),1)
equal('taper maximum',g.subs(beta,(a0+c0)/2),S.Rational(54,5))
equal('taper derivative extremum',S.diff(g,beta).subs(beta,a0),S.Rational(7776,25))
equal('taper Y0',a0/(1-a0),S.Rational(1,8))
equal('direct h derivative bound',S.Rational(7776,25)/4+S.Rational(54,5)*S.Rational(3,4),S.Rational(4293,50))
positive('R Lipschitz constant below 88',88-S.Rational(4293,50)-S.Rational(9,5)-S.Rational(1,6))
positive('R fourth-power norm below 16',16-S.Rational(1,1152)-S.Rational(45,4))
positive('six to three quarters below four, raised fourth powers',4**4-6**3)
positive('tail contribution below two',2-S.Rational(22,7)*S.Rational(1,6)*3)
positive('uniform m below 1500',1500-1474)
equal('explicit repaired cut margin',1-(1+S.Rational(3,4)*1500)/1200,S.Rational(37,600))

payload={'status':'PASS','count':len(checks),'checks':checks}
print(json.dumps(payload,sort_keys=True,indent=2))
