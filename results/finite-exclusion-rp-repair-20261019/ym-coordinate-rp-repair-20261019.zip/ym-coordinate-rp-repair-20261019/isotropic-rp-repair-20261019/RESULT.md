# Smooth parameter mixing plus a constant background repairs coordinate RP

19 October 2026. Local scalar Gaussian covariance research. No remote edits, merge, release, or publication.

## Result

Fix b>0 and tau>0. Let p(lambda) be any nonnegative C-infinity probability density compactly supported in an interval [lambda_-,lambda_+] strictly inside (0,1). Put

    beta(lambda)=((1-lambda)/(1+lambda))^2,
    rho_mix(v)=integral p(lambda) (1/4) sum_(j=1)^4
        sqrt(beta(lambda))/[1+(beta(lambda)-1)v_j^2]^2 d lambda.

The same conclusion holds when p is only globally Lipschitz, nonnegative, and compactly supported inside (0,1). In particular the earlier polynomial tapered counterexample is repaired by the explicit choice epsilon=1/1200 (Section 7).

There is an explicitly defined finite constant m=m(p)>0, independent of b, tau, and tangential frequency, such that every

    0<epsilon <= 1/(1+3m/4)

makes

    rho_epsilon(v)=(1-epsilon)+epsilon rho_mix(v),
    F_epsilon(p)=integral_(S^3) rho_epsilon(v)
             /[b+|p|^2+tau(p.v)^2] d sigma(v)

reflection positive at all four coordinate mirrors.

The density rho_epsilon is positive, normalized, C-infinity, W4-invariant, and nonconstant. The proof covers every tangential frequency, all of the shared spectral cut, and all extra spectral support. It does not assert RP at diagonal mirrors or arbitrary rotated mirrors, and is not an interacting Yang-Mills construction.

This is a genuine repair mechanism. It does not contradict the earlier fixed-beta obstruction: an atom in the mixing measure fails the smooth Cauchy-transform bound below. Nor does it contradict the tapered mixture's failure before adding a constant background.

## 1. Accepted axial decomposition and the effective mixing measure

For an axis a, write the accepted axial covariance as

    F_(lambda,a)=(1+lambda)/2 T_(lambda,a)
           +(1-lambda)/2 integral_0^1 T_(lambda r^2,a) dr.

Mixing p(lambda) gives

    F_(mix,a)=integral_0^(lambda_+) mu(eta) T_(eta,a) d eta,
    mu(eta)=p(eta)(1+eta)/2
        +[1/(4sqrt(eta))] integral_eta^(lambda_+)
                 p(lambda)(1-lambda)/sqrt(lambda) d lambda.       (1)

Here p is extended by zero. The measure mu(eta)d eta is positive and has total mass one. Its only endpoint singularity is an integrable eta^(-1/2) tail at zero. Formula (1) follows by eta=lambda r^2 and ordinary positive Fubini on real momenta.

For the mirror e1 set p=u e1+k, K=|k|^2, z=u^2, and q=z+K. The normal-axis mixture a=e1 is already reflection positive by the accepted one-mirror axial theorem. For each tangential axis a=e_j, j=2,3,4, only t=k_j^2 enters the remaining calculation. Thus considering all t>=0 treats every tangential vector k, with no restriction to an axial k.

For A=1+eta, C=1-eta the exact tangential building block is

    T_eta(q;t)=2[A+C sqrt(b+(1+tau)q)/sqrt(b+q)]
       /{[A sqrt(b+q)+C sqrt(b+(1+tau)q)]^2+4eta tau t}.  (2)

Each root is the principal root continued from q>0. In the upper half plane the positive root combination lies in the first quadrant, so the denominator does not vanish there. Lower-half-plane values follow by conjugation.

## 2. Exact ratio on the entire common cut

The radial covariance and its density are

    h0(q)=2/[sqrt(b+q)(sqrt(b+q)+sqrt(b+(1+tau)q))],
    w0(s)=2sqrt(d)/[pi sqrt(a)(a+d)],
    a=b-s, d=(1+tau)s-b,
    b/(1+tau)<s<b.                                          (3)

With h=4eta tau t and P=A^2 a+C^2 d, direct complex division of (2) gives

    w_eta(s;t)/w0(s)
      =C(a+d)(P-h)
        /[(A^2 a-C^2 d+h)^2+4A^2 C^2 a d],                  (4)

where w_eta=-(1/pi) Im T_eta(-s+i0).

Put

    r=a/(a+d) in (0,1), Y=t/s>=0, L=1-r+Y>0,
    beta=((1-eta)/(1+eta))^2,
    beta_min=((1-lambda_+)/(1+lambda_+))^2>0.

The factor in (4), after removing C/A^2, is

    [r+beta(1-r)-(1-beta)Y]
      /{[r-beta(1-r)+(1-beta)Y]^2+4beta r(1-r)}.             (5)

Changing the mixing variable eta to beta absorbs the removed factor:

    h_mix(beta)=mu(eta)/[2(1+sqrt(beta))],
    mu(eta)(C/A^2)|d eta/d beta|=h_mix(beta).                (6)

Extend h_mix by zero outside [beta_min,1). Define

    u=(r+Y)/L-2r(1-r)/L^2,
    v=2sqrt(r(1-r)Y(1+Y))/L^2,
    c=2rY/L^2 >=0.                                         (7)

For Y>0, v>0. Exact expansion gives

    [r-beta(1-r)+(1-beta)Y]^2+4beta r(1-r)
       =L^2[(beta-u)^2+v^2],
    r+beta(1-r)-(1-beta)Y=L[(beta-u)+c],
    |1-(u+i v)|=1/L.                                      (8)

Consequently the complete tangential-axis mixture obeys

    w_mix,tan/w0
      =(1/L) integral h_mix(beta)
             [(beta-u)+c]/[(beta-u)^2+v^2] d beta.          (9)

The c term is nonnegative. This expression is an ordinary absolutely convergent integral at every open-cut point. No endpoint PV substitution has been made.

## 3. The endpoint singularity has an exactly controlled Cauchy transform

Define

    B=(1/8) integral p(lambda)(1-lambda)/sqrt(lambda) d lambda >0.

For eta<lambda_-, the integral in (1) is constant. Using

    sqrt(eta)(1+sqrt(beta))=sqrt(1-beta)

shows that, on a whole left-neighborhood of beta=1,

    h_mix(beta)=B/sqrt(1-beta).                            (10)

Define on the whole real line

    R(beta)=h_mix(beta)-B 1_(beta<1)/sqrt(1-beta).            (11)

The two terms cancel identically near beta=1. At beta_min the smooth compact support of p makes h_mix smoothly zero. Thus R is C-infinity on the real line, R' is bounded, and R belongs to L^4(R). Under the weaker globally Lipschitz assumption on p, R is globally Lipschitz instead, and ||R'||_infinity means its essential derivative bound; every subsequent estimate is unchanged. At negative infinity R=-B/sqrt(1-beta), which proves the last claim; R vanishes near and above 1.

For every z=u+i v with v>0, symmetric cancellation and Holder's inequality give

    |Re integral R(beta)/(beta-z) d beta| <= M,
    M=2||R'||_infinity+6^(3/4)||R||_4.                      (12)

Indeed, on |beta-u|<=1 subtract R(u), whose contribution to the real part is zero by oddness. The remainder is bounded by 2||R'||_infinity. On |beta-u|>=1, use |beta-u|/[(beta-u)^2+v^2]<=1/|beta-u| and

    integral_(|x|>=1) |x|^(-4/3) dx=6.

The elementary half-line Cauchy transform, with the principal square root, is

    integral_(-infinity)^1 [d beta/(sqrt(1-beta)(beta-z))]
       =-pi/sqrt(z-1).                                   (13)

It follows from (8), (11)-(13) that

    Re integral h_mix(beta)/(beta-(u+i v)) d beta
       >=-pi B sqrt(L)-M.                                (14)

Dropping the nonnegative c term in (9) therefore proves

    w_mix,tan/w0 >=-pi B/sqrt(L)-M/L.                       (15)

The apparent issue L->0 is harmless. If

    Y <= Y0=beta_min/(1-beta_min),

then the numerator in (5) is nonnegative for every beta in the support, because

    r+beta(1-r) >= beta >= beta_min,
    (1-beta)Y <= (1-beta_min)Y <= beta_min.

Thus the complete ratio is nonnegative in this region, including Y=0. In the remaining region L>=Y>=Y0. The explicit uniform constant

    m=pi B/sqrt(Y0)+M/Y0                                 (16)

is finite and satisfies

    w_mix,tan(s;t) >= -m w0(s)

for every t>=0 and every b/(1+tau)<s<b. This bound is independent of b and tau.

## 4. Extra spectral support is positive

For q real and q>-b/(1+tau), the two roots in (2) are nonnegative real and the denominator is strictly positive. There are no tangential poles or cuts there.

For q=-s with s>b, set e=s-b>0 and d=(1+tau)s-b>0. The denominator is real:

    D_eta(s)=4eta tau t-(A sqrt(e)+C sqrt(d))^2.

The squared expression is strictly increasing in s. Thus an outer pole exists exactly when

    4eta tau t > C^2 b tau,

and then it is unique, simple, and has s_eta>b. Its residue in q is

    R_eta(t)=2[A+C sqrt(d)/sqrt(e)]
       /{(A sqrt(e)+C sqrt(d))
                   [A/sqrt(e)+C(1+tau)/sqrt(d)]}>0.         (17)

Outside the common cut and these poles, upper and lower boundary values agree, since changing the sign of both imaginary roots leaves (2) unchanged.

At equality 4eta tau t=C^2 b tau, expansion at q=-b gives

    T_eta(q;t)=1/[A(q+b)]+O(|q+b|^(-1/2)),                  (18)

so the endpoint atom also has positive weight 1/A. The residue of a pole approaching b from above tends instead to 2/A; the two facts are compatible because the nearby signed cut density also changes. One must not substitute the limiting outer-pole residue for the endpoint residue.

After mixing against the absolutely continuous measure mu, the isolated equality value of eta has zero measure. All outer poles yield a positive pushforward measure on s>b. Hence the mixture has no negative extra spectral support outside the radial cut.

## 5. Signed spectral reconstruction is justified before the positivity conclusion

For each fixed eta in (0,lambda_+), t>=0, (2) is holomorphic away from the common cut and the just-listed real poles; it is O(1/q) at infinity. At the lower cut endpoint it is bounded. At the upper endpoint it is O((q+b)^(-1/2)), except for the explicitly removed positive atom (18), after whose removal the same bound holds. Its simple outer poles have residues (17). Cauchy's formula therefore gives the signed Stieltjes representation consisting exactly of the density (4), the outer pole, and the possible endpoint atom. There is no entire or contact remainder.

For clarity, mixing this representation does not require an unproved interchange of a singular spectral limit. For fixed finite t, eta near zero is uniformly away from the resonance at s=b; the eta^(-1/2) mixing tail is integrable there. If a resonance eta_c lies in (0,lambda_+], it is unique because C^2/(4eta) is strictly decreasing. The density mu is bounded and smooth near eta_c. In local coordinates a=b-s and delta=eta-eta_c, (4) implies, for constants depending only on this fixed t and a compact eta neighborhood,

    |w_eta(s;t)| <= C a^(-1/2)
                    (|delta|+a)/(delta^2+a).              (19)

This follows because the real denominator term has a simple eta zero and its imaginary-square term is comparable to a; the O(a) shift of the simple zero preserves comparability to delta^2+a. Integrating (19) in eta gives at most

    C a^(-1/2)(1+|log a|),

which is integrable at a=0. All other cut regions are uniformly integrable. The outer-pole residues are bounded on the compact parameter region where poles exist, including their finite threshold limit. Therefore absolute Fubini applies to the signed cut integral and to the positive pole integral. The mixed function has an actual finite signed Stieltjes measure with cut density (9) and the positive outer pushforward measure described above.

Shifting q=z+K places every tangential spectral parameter at z=-(K+s), with K+s>0. The accepted normal-axis mixture also has a positive Stieltjes measure in z. Thus all spectral measures invoked here are normal-frequency spectral measures on positive squared energies.

## 6. Constant dilution and full coordinate RP

At any fixed tangential k, the normal-axis contribution is positive and each of the three tangential-axis contributions has common-cut density >=-m w0. Their equal four-axis average consequently has

    w_W4 >= -(3m/4) w0

on the common cut. Its spectral measure away from that cut is positive. Therefore

    F_epsilon=(1-epsilon)h0+epsilon F_W4

has a nonnegative Stieltjes measure at every k whenever

    1-epsilon-(3m/4)epsilon >=0.

A positive Stieltjes representation in z=u^2 gives a positive Laplace mixture in positive normal time, and therefore fixed-k Hankel positivity. Integrating against tangential Fourier transforms gives reflection positivity for smooth compact tests. Positivity/normalization of the original angular density also gives the common real-momentum bound F_epsilon(p)<=1/(b+|p|^2), so all Fourier manipulations and the Gaussian two-point form have the usual domination. W4 symmetry transports the conclusion from e1 to every coordinate mirror.

Finally rho_mix is nonconstant. For each beta<1, the function x -> [1-(1-beta)x]^(-2) is strictly convex. Comparing the four coordinate squares (1,0,0,0) with (1/4,1/4,1/4,1/4) shows rho_mix(e1)>rho_mix((1,1,1,1)/2). Positive mixing and epsilon>0 preserve the strict inequality.

## 7. Explicit repair of the previously negative tapered example

Use exactly the earlier parameter density

    a0=1/9, c0=1/4, H=c0-a0=5/36,
    g(beta)=6(beta-a0)(c0-beta)/H^3 on [a0,c0], zero elsewhere.

It is globally Lipschitz, so the theorem applies. Its transformed p is supported in lambda in [1/3,1/2]. In the notation above, write

    J(beta)=(1/8) integral_(eta(beta))^(lambda_+)
                         p(lambda)(1-lambda)/sqrt(lambda) d lambda.

Then throughout [a0,c0],

    h_mix(beta)=g(beta)sqrt(beta)/2+J(beta)/sqrt(1-beta),
    J'(beta)=g(beta)sqrt(beta)/[4sqrt(1-beta)],
    0<=J(beta)<=B<1/6.

The bound on B follows from

    B <= (1/8) max_(1/3<=lambda<=1/2)(1-lambda)/sqrt(lambda)
       =1/(4sqrt(3))<1/6.

Outside [a0,c0], R=-B/sqrt(1-beta) for beta<a0 and R=0 for beta>c0. The exact elementary bounds

    ||g||_infinity=54/5,
    ||g'||_infinity=7776/25

give, almost everywhere on [a0,c0],

    |R'| <= (7776/25)(1/4)+(54/5)(3/4)
            +(54/5)(1/2)/[4(3/4)]
            +B/[2(3/4)^(3/2)]
         < 4293/50+9/5+1/6 <88.

On beta<a0 its derivative is smaller still. Thus Lip(R)<88. Also, on [a0,c0],

    |R| <= 27/10+1/(3sqrt(3)) <3.

Consequently

    ||R||_4^4
      <= B^4/(1-a0)+3^4(c0-a0)
      < 1/1152+45/4 <16,

and ||R||_4<2. Since 6^(3/4)<4, (12) gives M<184. Finally Y0=1/8, pi<22/7, sqrt(8)<3, and B<1/6 show

    m=pi B sqrt(8)+8M <2+1472=1474<1500.

Therefore the completely explicit positive, nonconstant angular density

    rho_repaired=(1199/1200)+(1/1200)rho_taper

is coordinate-reflection-positive for every b,tau>0. Its common-cut spectral density even satisfies the uniform strict lower bound

    w_repaired >= [1-(1+3*1500/4)/1200]w0
               =(37/600)w0 >0.

The angular density is C-infinity even though g is only Lipschitz, because beta lies in a compact subinterval of (0,1). If an explicitly C-infinity parameter density is required, choose any smooth compact bump and use (16); no limiting transfer of the explicit 1/1200 bound is needed or claimed.

## Scope and remaining bottleneck

The repair mechanism is proved for coordinate mirrors. The immediate unsolved question for a stronger W4 reflection claim is positivity at diagonal mirrors, whose axes are neither purely normal nor purely tangential to all four summands. The above proof does not cover those mixed orientations. No claim of Euclidean rotational invariance, interacting Yang-Mills reconstruction, or a Yang-Mills mass gap follows from this scalar two-point construction.

The independent audit in /workspace/shared/isotropic-rp-repair-audit-20261019/AUDIT.md passes the theorem, physical-sheet reconstruction, and every explicit-repair constant in Section 7. It additionally supplies a different uniform-bound proof using the nonsingular r=sqrt(eta) density and a uniform total-variation bound for the signed building-block measures. Exact symbolic regression checks accompany this note; they support the algebra but do not replace the analytic Cauchy-transform and reconstruction arguments.

## Exact regression record

The script check_exact_identities.py verifies 32 exact algebraic identities and rational inequalities. The script verify_regression_modes.py checks that ordinary and optimized execution give identical output and that a deliberately corrupted positive-correction coefficient fails in both modes. Both regression-runner modes passed. The successful algebra-output SHA256 is 4455920d6ac72bef4443dfceee450b4ba0fcfa5a53435e1715226c205287a75b.

Reproduce with:

    python check_exact_identities.py
    python verify_regression_modes.py
    python -O verify_regression_modes.py
