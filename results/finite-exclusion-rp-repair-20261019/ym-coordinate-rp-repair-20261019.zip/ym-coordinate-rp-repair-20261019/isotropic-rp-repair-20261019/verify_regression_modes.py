#!/usr/bin/env python3
import hashlib
import json
from pathlib import Path
import subprocess
import sys

script=Path(__file__).with_name('check_exact_identities.py')
outputs=[]
for optimized in (False,True):
    command=[sys.executable]+(['-O'] if optimized else [])+[str(script)]
    good=subprocess.run(command,capture_output=True,text=True)
    if good.returncode:
        raise SystemExit(f'Valid mode failed: {command}\n{good.stderr}')
    outputs.append(good.stdout)
    bad=subprocess.run(command+['--negative-control'],capture_output=True,text=True)
    if bad.returncode == 0 or 'FAIL Cauchy numerator and positive correction' not in bad.stderr:
        raise SystemExit(f'Negative control did not fail as required: {command}\n{bad.stderr}')
if outputs[0]!=outputs[1]:
    raise SystemExit('Ordinary and optimized outputs differ')
print(json.dumps({'status':'PASS','identities':32,'ordinary_optimized_identical':True,
                  'negative_controls_rejected':2,
                  'successful_output_sha256':hashlib.sha256(outputs[0].encode()).hexdigest()},sort_keys=True,indent=2))
