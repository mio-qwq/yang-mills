# Coordinate reflection positivity repaired by constant dilution

Local reproducible source checkpoint, 19 October 2026. No remote action was performed.

## Accepted result and limits

The previously negative tapered four-axis density is repaired by

    rho_repaired = 1199/1200 + (1/1200) rho_taper.

For every b > 0 and tau > 0, the resulting positive, smooth, normalized, nonconstant W4-invariant angular density is reflection-positive at all four coordinate mirrors. The shared-cut spectral density has the uniform strict lower bound (37/600) w0. The independent audit supplies a second uniform-bound proof and verifies signed spectral reconstruction.

This is a scalar Gaussian covariance result. Coordinate mirrors do not establish diagonal or arbitrary rotated-mirror positivity, Euclidean rotational invariance, an interacting Yang-Mills construction, or a mass gap. Symbolic checks support the analytic proofs; they are not formal verification or human peer review.

## Reading order

1. isotropic-rp-repair-20261019/RESULT.md: proof and explicit constants, especially Section 7.
2. isotropic-rp-repair-audit-20261019/AUDIT.md: independent argument and audit.
3. dependencies/ym-w4-parameter-mixtures-20261019.zip: unchanged accepted prior source archive. Its nested ym-positive-infinite-angular-20261019.zip contains the accepted axial theorem in RESULT.md and AUDIT_POSITIVE.md.
4. PROVENANCE.json: exact input hashes and the pinned prior repository commit/path. Prior obstructions remain valid for their undiluted families.

All seven current original files and the exact prior archive are byte-for-byte copies. Historical absolute paths in retained documents map to their matching directory names here. The remote pin comes from the previously recorded exact-commit byte-readback receipt; this packaging operation does not claim a fresh remote fetch.

## Portable reproduction

Use Python 3.10+ with SymPy 1.14.0 (requirements.txt). Install dependencies only in an environment you choose. No network connection or original workspace path is needed after extraction.

    python reproduce.py
    python -O reproduce.py
    python reproduce.py --with-dependency-replay
    python -O reproduce.py --with-dependency-replay
    python -O reproduce.py --integrity-only

The default run checks every payload hash, both nested dependency manifests, and the preserved axial proof-file hashes. It reruns the 32 main and 39 independent exact checks normally and with -O, verifies their accepted output hashes, rejects the deliberate corruptions in both modes, and runs both original regression runners normally and with -O. --with-dependency-replay additionally runs the prior full replay, including its axial dependency. --integrity-only performs the complete nested byte-integrity checks without importing SymPy. No option automatically proves the analytic arguments.

Replay writes only to temporary directories; bytecode writes are disabled in subprocesses. Keep this extraction clean: unexpected extra files cause an integrity failure. SHA256SUMS covers every payload file except itself; first verify the externally recorded ZIP SHA-256 to authenticate that manifest.

## Deterministic rebuild and recovery

From a clean, verified extraction:

    python build_archive.py ../ym-coordinate-rp-repair-20261019-rebuilt.zip

The builder refuses to overwrite an existing target. Entries are lexicographically sorted, use fixed 1980-01-01 timestamps and regular-file mode 0644, and use DEFLATE level 9. Byte-identical rebuilding requires the same zlib implementation. A hash mismatch is a blocker; preserve the reference and investigate a copy. This archive does not authorize publication, merges, releases, or further numerical searches.
