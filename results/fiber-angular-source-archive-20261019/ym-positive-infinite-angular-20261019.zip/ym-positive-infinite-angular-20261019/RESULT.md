# Smooth infinite-angular densities can have one-mirror reflection positivity

19 October 2026. Local scalar-covariance research. No repository, PR, release, or external object was changed.

## Executive result

Fix b>0, tau>0, and a unit vector n in R^4. For every 0<beta<1, the normalized density

    rho_beta(v)=sqrt(beta)/[1+(beta-1)(n.v)^2]^2,   v in S^3,

is positive, smooth, antipodally even, invariant under reflection in n, and nonconstant, with infinitely many nonzero spherical-harmonic degrees. Its covariance

    F_beta(p)=integral_{S^3} rho_beta(v)/[b+|p|^2+tau(p.v)^2] d sigma(v)

is reflection positive at the mirror normal to n.

This is an exact analytic counterexample to extending the finite-harmonic **one-invariant-mirror** rigidity theorem to arbitrary smooth even angular densities. The finite-degree assumption is therefore essential for that one-mirror conclusion, not merely for its existing proof.

The density singles out n. It is not W_4-invariant for beta != 1, so this does not settle the arbitrary-density W_4 coordinate/diagonal-mirror problem. It also makes no interacting Yang-Mills, mass-gap, or four-dimensional reconstruction claim.

A particularly simple example, valid for every b,tau>0, is

    beta=1/4,
    rho(v)=(1/2)/[1-3(n.v)^2/4]^2.

The proof gives the complete positive normal spectral measure. It is a positive mixture of elementary measures, each consisting of an explicit positive density on a compact interval plus at most one positive atom. No numerical positivity test is used.

## 1. Exact infinite harmonic expansion

Write

    lambda=(1-sqrt(beta))/(1+sqrt(beta)),
    A=1+lambda, C=1-lambda,
    beta=(C/A)^2.

For 0<beta<=1 we have 0<=lambda<1. Let U_l be the Chebyshev polynomial of the second kind, normalized by U_l(1)=l+1. Its even generating function and its differentiated version are

    G_lambda(t)=sum_{j>=0} lambda^j U_{2j}(t)
              =(1+lambda)/[(1+lambda)^2-4lambda t^2],

    P_lambda(t)=sum_{j>=0}(2j+1)lambda^j U_{2j}(t)
              =(1-lambda)[(1+lambda)^2+4lambda t^2]
                 /[(1+lambda)^2-4lambda t^2]^2.

Direct differentiation gives

    rho_beta(t)=(A/2)P_lambda(t)+(C/2)G_lambda(t)
               =sum_{j>=0}[1+(1+lambda)j]lambda^j U_{2j}(t).       (1)

All these series converge absolutely and uniformly on [-1,1] because |U_{2j}(t)|<=2j+1 and lambda<1. Under probability surface measure on S^3, the polynomials U_l(n.v) are zonal harmonics; every positive-degree term has mean zero. Equation (1) therefore proves normalization, integral rho_beta d sigma=1. It agrees with the angular-central-Gaussian formula sqrt(det B)/(v^T Bv)^2 for B=I+(beta-1)nn^T.

For lambda>0 every coefficient in (1) is nonzero. Thus no finite harmonic expansion represents rho_beta. Positivity and smoothness follow directly from 1+(beta-1)t^2>=beta>0.

## 2. Exact reduction to elementary covariances

Write p=un+k with k perpendicular to n, and put

    K=|k|^2, q=u^2+K, a=b+q, c=b+(1+tau)q,
    y=(sqrt(a)-sqrt(c))/(sqrt(a)+sqrt(c)),
    h0=(1+y)/a=2/[a+sqrt(a)sqrt(c)].

For real p, the square roots are positive and |y|<1. The generating function gives

    1/[a+tau*q*t^2]=h0 sum_{j>=0} y^j U_{2j}(t).

The S^3 harmonic convolution identity is

    integral U_l(n.v)U_m(e.v) d sigma(v)
      =1_(l=m) U_l(n.e)/(l+1).

This follows from orthogonality of distinct harmonic degrees and the zonal projection formula; it has the same normalization as the finite-harmonic companion result. Absolute uniform convergence justifies its use term by term. Therefore

    F_beta(p)=h0 sum_{j>=0}
        [1+(1+lambda)j](lambda*y)^j U_{2j}(u/sqrt(q))/(2j+1).

For any 0<=eta<1 define

    T_eta(p)=h0 G_{eta*y}(u/sqrt(q)).

The formulas extend continuously to p=0. Since

    [1+(1+lambda)j]/(2j+1)=A/2+C/[2(2j+1)],
    1/(2j+1)=integral_0^1 r^(2j) dr,

we obtain the exact positive mixture

    F_beta(p)=(A/2)T_lambda(p)
                +(C/2) integral_0^1 T_{lambda*r^2}(p) dr.           (2)

The parameters inside T_{lambda*r^2} are always recomputed for that subscript. The outer A,C in (2) depend on lambda. Their coefficients are positive and sum to one.

## 3. Closed form for the elementary covariance

For the rest of the proof fix 0<=eta<1 and abbreviate

    A_eta=1+eta, C_eta=1-eta,
    D_eta(q,K)=[A_eta sqrt(c)+C_eta sqrt(a)]^2-4eta*tau*K.

Elementary algebra in the generating function gives

    T_eta(p)=2[A_eta+C_eta sqrt(c)/sqrt(a)]/D_eta(q,K).               (3)

Equivalently,

    D_eta=A_eta^2 c+C_eta^2 a-4eta*tau*K
             +2A_eta C_eta sqrt(a)sqrt(c).

When continued in q, each square root is its principal square root. In particular sqrt(a)sqrt(c) must not be replaced globally by the principal square root of the product ac.

Let

    a0=b/(1+tau).

We next prove the exact normal-frequency representation

    T_eta(un+k)
      =integral_{a0}^b w_eta(K,s) ds/[u^2+K+s]
         +1_(atom exists) R_eta(K)/[u^2+K-q_eta(K)],                (4)

with all coefficients nonnegative. The atom and density are specified below.

## 4. No missing off-axis singularities

Use z=u^2 and q=z+K. If Im z>0, both sqrt(a) and sqrt(c) have strictly positive real and imaginary parts. Thus their positive linear combination

    S=A_eta sqrt(c)+C_eta sqrt(a)

lies in the first quadrant. Its square has strictly positive imaginary part, so D_eta=S^2-4eta*tau*K cannot vanish. The lower half-plane follows by conjugation.

For real q<-b, both roots are purely imaginary on each rim. Their ratio is positive real and the value of their squared sum is the same on both rims. Moreover D_eta<0 there. Thus the apparent individual-root cut below -b is removable: the boundary values of T_eta agree and analytically extend across every point of that interval. The only continuous cut is [-b,-a0].

For q>-a0, both roots are positive and D_eta is strictly increasing, with limit +infinity as q tends to +infinity. At the right endpoint of the cut,

    D_eta(-a0,K)=C_eta^2*b*tau/(1+tau)-4eta*tau*K.                    (5)

Hence eta=0 has no pole. When eta>0 there is exactly one pole q_eta(K)>-a0 if and only if

    K>Kcrit(eta):=b*C_eta^2/[4eta*(1+tau)].                          (6)

It is a simple pole and its residue is

    R_eta(K)=2[A_eta+C_eta sqrt(c)/sqrt(a)]
                 /(partial_q D_eta(q,K)) evaluated at q=q_eta(K),  (7)

which is strictly positive. The derivative in (7) is positive and finite at this root.

The pole has strictly positive normal squared energy. In fact it has the uniform lower bound

    K-q_eta(K)>a0.                                                 (8)

To see this, evaluate at q=K-a0. Here c=(1+tau)K and a=K+b*tau/(1+tau), and

    A_eta^2 c+C_eta^2 a-4eta*tau*K
      =K[A_eta^2+(1+tau)C_eta^2]+C_eta^2*b*tau/(1+tau)>0.

The cross term is nonnegative, so D_eta(K-a0,K)>0. Strict monotonicity places its zero below K-a0.

## 5. Explicit positive cut density

For a0<s<b let

    a_s=b-s>0,
    d_s=(1+tau)s-b>0,
    h_s=sqrt(d_s/a_s),
    V=C_eta^2 a_s-A_eta^2 d_s-4eta*tau*K,
    W=2A_eta C_eta sqrt(a_s*d_s)>0.

At q=-s+i0, the numerator in (3) is 2(A_eta+i C_eta h_s), while its denominator is V+iW. Therefore

    w_eta(K,s)=-(1/pi) Im T_eta(q=-s+i0)
       =2 C_eta h_s
          [A_eta^2 d_s+(2A_eta^2-C_eta^2)a_s+4eta*tau*K]
            /[pi(V^2+W^2)].                                      (9)

Every factor has the required sign. In particular

    2A_eta^2-C_eta^2=1+6eta+eta^2>0.

Thus w_eta(K,s)>0 throughout the open cut.

At eta=0, (9) reduces exactly to the uniform-orbit density

    w_0(K,s)=2/[pi*tau*s] sqrt{[(1+tau)s-b]/(b-s)},

which is independent of K, as it should be.

## 6. Endpoint audit and exact Cauchy recovery

The endpoint behavior must be checked separately when a pole reaches the cut.

- At s=b, the limiting denominator is -tau[A_eta^2*b+4eta*K], which is nonzero. Formula (3) is at worst O((q+b)^(-1/2)), and (9) is O((b-s)^(-1/2)).
- At s=a0, if K differs from Kcrit, the denominator is nonzero and the density is O((s-a0)^(1/2)).
- At K=Kcrit, the constant part of the denominator vanishes, but its leading nonzero term is 2A_eta C_eta sqrt(b*tau/(1+tau)) sqrt(c). The covariance is O((q+a0)^(-1/2)) and the density is O((s-a0)^(-1/2)). This is integrable and is not an endpoint atom.

All cut densities are integrable for each fixed K and eta. The small circles in a keyhole Cauchy contour consequently vanish, including at the critical threshold. The only additional contour residues are the simple positive poles (7).

At infinity,

    T_eta(z,K)=M_eta/z+O(z^(-2)),
    M_eta=2[A_eta+C_eta sqrt(1+tau)]
               /[A_eta sqrt(1+tau)+C_eta]^2>0.

The large-circle contribution for the Cauchy representation vanishes. Conjugate boundary values on the compact cut, (9), and the pole residue theorem therefore give exactly (4). There is no polynomial addition, hidden endpoint mass, or contact term.

Equivalently, the positive measure in normal squared energy x is

    nu_eta,K(dx)=1_(K+a0,K+b)(x) w_eta(K,x-K) dx
       +1_(K>Kcrit) R_eta(K) delta_(K-q_eta(K))(dx).

It is finite, supported in x>=a0, and has total mass M_eta.

## 7. Reflection positivity and justified mixture

Equation (4) is a positive Stieltjes representation in u^2 at every real tangential frequency k. Its inverse normal Fourier transform is

    K_eta,k(T)=integral exp(-sqrt(x)|T|)/(2sqrt(x)) nu_eta,K(dx).

Consequently the reflected form of a positive-time test is an integral of

    |integral_0^infinity exp(-sqrt(x)t) fhat(t,k) dt|^2
       nu_eta,K(dx)/(2sqrt(x)),

and is nonnegative. Here fhat is the tangential Fourier transform. The measure's lower mass bound, finite total mass, and rapid tangential decay of smooth compact tests justify the Fourier integrations. Thus T_eta is reflection positive at n.

There is also an ordinary positive angular realization: T_eta is the original orbit covariance with density P_eta(n.v). The explicit expression in Section 1 shows P_eta>=0 and its mean is 1. It follows that, for real p,

    0<=T_eta(p)<=1/(b+|p|^2),
    0<=F_beta(p)<=1/(b+|p|^2).                                    (10)

These uniform estimates justify averaging reflected forms in (2) by absolute integrability against test Fourier transforms. Positive averages preserve reflection positivity. This proves the theorem for every 0<beta<=1.

The same bound also gives the earlier ultraviolet O(d^6) estimate in dimension four. Thus the new examples do not evade finite-degree rigidity by violating that ultraviolet estimate; their infinite angular degree is the relevant distinction.

## 8. Exact scope and relation to previous results

1. For beta=1 the density is constant, recovering the known radial all-mirror example. For 0<beta<1 it is nonconstant, normalized, smooth and infinite harmonic, yet RP at its invariant mirror n.
2. This disproves the proposed one-invariant-mirror extension from finite harmonic degree to arbitrary smooth even densities. It does not contradict the finite theorem: no highest nonzero harmonic exists, and summing all degrees creates positive dispersive spectral atoms that finite truncations cannot capture.
3. It does not contradict the all-mirror arbitrary-density theorem. These nonconstant examples cannot satisfy RP at every mirror. The selected density is also not W_4-invariant, so the fixed coordinate/diagonal-mirror W_4 question is unchanged.
4. The proof is for b>0, tau>0, and 0<beta<=1. Results about beta>1, if separately supplied, are not needed for this theorem and are excluded from its accepted claim set here.
5. This is a scalar Gaussian two-point result. It is not an interacting gauge-theory construction or a Yang-Mills mass-gap proof.

## 9. Verification files

- RESULT.md: the self-contained accepted positive-family proof; the earlier exploratory derivation is not an input to this archive.
- AUDIT_POSITIVE.md: independent harmonic/physical-sheet audit of the accepted positive family only.
- ROOT_REVIEW.md: review of the accepted positive family. References there to earlier broader investigations are historical; those documents and their beta>1 classification claims are deliberately excluded from this archive.
- check_exact_identities.py: 25 exact SymPy identities, including the generating functions, all coefficient relations through degree 24, the closed form, spectral sign numerator, and threshold-energy algebra. It also contains exact auxiliary identities for a separately scoped beta>1 investigation.
- exact-checks.json: saved PASS report.
- verify_regression_modes.py: verifies identical good output under ordinary Python and python -O, then perturbs the degree-four coefficient and requires both modes to fail with the intended exact mismatch.
- regression-validation.json and regression-validation-optimized.json: identical successful harness reports.

The scripts use explicit failures rather than assert statements. The finite exact checks are regression tests; the all-degree and analytic results are proved in the text.

Reproduce from this directory:

    python check_exact_identities.py
    python verify_regression_modes.py
    python -O verify_regression_modes.py

Both negative controls must fail:

    python check_exact_identities.py --negative-control
    python -O check_exact_identities.py --negative-control
