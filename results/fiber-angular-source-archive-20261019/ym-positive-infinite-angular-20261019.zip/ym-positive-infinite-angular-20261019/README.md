# Positive infinite-angular one-mirror example

Source research checkpoint, 19 October 2026. For b,tau>0 and 0<beta<1,
the displayed axial angular-central-Gaussian density is normalized, smooth,
positive, nonconstant and infinite-harmonic, and its scalar covariance has
reflection positivity at the selected invariant mirror. beta=1 is radial.
This is a counterexample to dropping finite harmonic degree from the
one-invariant-mirror theorem. It is neither W4-invariant nor a counterexample
to all-mirror rigidity, and supplies no interacting Yang-Mills construction
or mass gap. No originality, human peer review, or proof-assistant verification
claim is made. Reviews were AI-assisted; universal claims rest on written proofs.

Read RESULT.md and the positive-only AUDIT_POSITIVE.md. ROOT_REVIEW.md records
the additional review; references there to earlier local investigations are
historical. COPY_EDITS.json records two documentation-only copy edits.
ORIGINAL_ACCEPTED_FILES.json preserves the original accepted-input hashes.
No beta>1 classification manuscript or exploratory numerical cache is included.

Requires Python 3.10+ and SymPy (verified with version 1.14.0). Run:

    python check_exact_identities.py
    python verify_regression_modes.py
    python -O verify_regression_modes.py

The harness also requires both deliberate coefficient perturbations to fail.
All tests use explicit failures that remain active with -O. The checker contains
25 identities: 20 support the accepted positive-family algebra and five are
auxiliary regression identities from a separately scoped investigation.
Those five identities are retained byte-for-byte for exact receipt compatibility;
they do not certify or incorporate any beta>1 classification. The checked finite
identities do not replace the infinite-series convergence and spectral proof.
SHA256SUMS covers every other file. All programs print receipts without changing
source files. No file outside this archive is needed.
