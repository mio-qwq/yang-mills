#!/usr/bin/env python3
"""Check exact regression output and deliberate failure under both Python modes."""
import json
from pathlib import Path
import subprocess
import sys

root=Path(__file__).resolve().parent
script=root/'check_exact_identities.py'
outputs=[]
results=[]
for optimized in (False, True):
    prefix=[sys.executable]+(['-O'] if optimized else [])
    good=subprocess.run(prefix+[str(script)],text=True,capture_output=True)
    if good.returncode != 0:
        raise RuntimeError(f'good run failed: {good.stderr}')
    data=json.loads(good.stdout)
    if data.get('status') != 'PASS' or data.get('exact_checks') != 25:
        raise RuntimeError('wrong successful regression report')
    outputs.append(good.stdout)
    bad=subprocess.run(prefix+[str(script),'--negative-control'],text=True,capture_output=True)
    if bad.returncode == 0 or 'harmonic-mixture-coefficient-2: exact residual 1/5' not in bad.stderr or 'PASS' in bad.stdout:
        raise RuntimeError(f'negative control did not fail as required: {bad.stdout} {bad.stderr}')
    results.append({'optimized':optimized,'positive_exit':good.returncode,'negative_exit':bad.returncode,'negative_control':'intended exact coefficient mismatch'})
if outputs[0] != outputs[1]:
    raise RuntimeError('ordinary and optimized outputs differ')
print(json.dumps({'status':'PASS','identical_positive_output':True,'modes':results},indent=2))
