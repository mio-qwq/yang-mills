# Independent audit: nonconstant axial density with one-mirror RP

19 October 2026. Local mathematical audit. No external object was changed.

## Accepted positive-family result

For b,τ>0, n=e₀, 0<β≤1, B=diag(β,1,1,1), and probability surface measure dσ on S³,

    Fβ(p)=∫ [√β/(vᵀBv)²] / [b+|p|²+τ(p·v)²] dσ(v)

has reflection positivity at n. For 0<β<1 the angular density is nonconstant and has an infinite harmonic expansion. The proof gives the entire positive normal spectral measure, including extra atoms. This file proves only that positive-family theorem and makes no classification assertion outside 0<β≤1.

## 1. Exact harmonic-sum covariance

Set

    λ = (1−√β)/(1+√β),       −1 < λ < 1,
    q = z+κ,   z=p₀²,   κ=|k|²,
    a = b+q,   c=b+(1+τ)q,
    y = (√a−√c)/(√a+√c),
    h₀(q) = 2/(a+√(ac)) = (1+y)/a.

The square-root ratio is chosen by continuation from q≥0. Define

    Gα(t) = (1+α)/[(1+α)²−4αt²],
    Hα(z;κ) = h₀(q) G_{αy}(p₀/√q).

The apparent q=0 singularity in the latter expression is removable. The exact covariance is

    Fβ(z;κ) = (1+λ)/2 Hλ(z;κ)
               + (1−λ)/2 ∫₀¹ H_{λr²}(z;κ) dr.              (1)

In particular, when λ≥0, this is a positive combination of the functions Hα with α≥0.

### Verification of (1)

For the Chebyshev polynomials Uj,

    Gλ(t) = Σ_{r≥0} λʳ U₂ᵣ(t).

Because √β=(1−λ)/(1+λ), direct differentiation gives

    ρβ(t) = Gλ(t)+(1+λ)λ∂λGλ(t)
           = Σ_{r≥0} [1+(1+λ)r] λʳ U₂ᵣ(t).               (2)

For |λ|<1 this converges absolutely and uniformly on −1≤t≤1, even after the displayed first derivative. The S³ Funk–Hecke normalization is

    ∫ U₂ᵣ(n·v)/[a+τq(e·v)²] dσ(v)
       = U₂ᵣ(n·e)/(2r+1) · h₀(q)yʳ,    e=p/√q.          (3)

For example, the scalar integral entering (3) follows by expanding

    1/[a+τqt²] = h₀(q) Σ_{j≥0} yʲ U₂ⱼ(t)

and using the normalized semicircle orthogonality of Uj. This expansion follows algebraically from

    τq/a = −4y/(1+y)².

Substituting (2) in (3), and using

    [1+(1+λ)r]/(2r+1) = (1+λ)/2 + (1−λ)/[2(2r+1)],
    1/(2r+1) = ∫₀¹ t²ʳ dt,

proves (1) on real momenta. All interchanges there are uniformly absolutely convergent. Subsequent continuation is through the displayed explicit functions.

An equivalent useful closed form for Hα is obtained by writing A=1+α, C=1−α:

    Hα = 2[A+C√(c/a)] /
          [A²c+C²a−4ατκ+2AC√(ac)].                     (4)

This also directly checks the generating-function expression.

## 2. Conformal variable and all possible poles

Put

    Dτ(y) = τ(1+y)²+4y,
    h = (√(1+τ)−1)/(√(1+τ)+1),       0<h<1.

Then

    q = −4by/Dτ(y),
    a = bτ(1+y)²/Dτ(y),
    dq/dy = −4bτ(1−y²)/Dτ(y)².                         (5)

The branch y selected above maps the slit q-plane

    C \ [−b,−b/(1+τ)]

onto the open unit disk with y=−h removed. After adjoining q=∞ to the slit plane, the map is onto the full open unit disk; q=∞ corresponds to y=−h. One way to check this is that the quadratic inverse equation has reciprocal roots; its boundary |y|=1 maps to the slit, and y=0 corresponds to q=0. The critical points are y=±1. This is the usual elementary Joukowski-type conformal parametrization, with a pole inside the disk representing infinity.

The exact expression is

    Hα = Dτ(y)(1+αy) / [τ(1+y)Pα(y)],
    Pα(y) = b(1−αy)²−ακDτ(y).                          (6)

Consequently all off-cut poles are roots of Pα in |y|<1. No singularity occurs at q=∞, where Hα=O(q⁻¹).

For later use, the discriminant of Pα is

    disc Pα = 4κα [bτ(1+α)²+4bα+4κα(1+τ)].             (7)

For α>0 this is positive, so all roots are real. Only 0≤α<1 is needed in this audit.

## 3. Exact continuous normal spectral density

Use s for the radial mass coordinate, so the normal spectral variable is x=κ+s. Let

    a₀ = b/(1+τ),       a₀ < s < b,
    t(s)² = (b−s)/(τs),
    w(s) = 2/(πτs) √{[(1+τ)s−b]/(b−s)}.

The uniform covariance h₀ has positive measure w(s) ds in the denominator z+κ+s. On the upper lip of this cut,

    y = e^(−iφ),     cos φ = 2t(s)²−1,
    (p₀/√q)² = 1+κ/s = T².

For any −1<α<1, the ordinary cut density of Hα is

    w(s) Mα(s,κ),

where

    Mα(s,κ) =
       (1−α)[(1+α)²+4α(t(s)²+κ/s)]
       / |(1+αy)²−4αy(1+κ/s)|².                       (9)

This is an exact signed density, not a positivity inference from a truncated angular series.

For verification, let

    N(y)=(1+y)(1+αy),
    Q(y)=(1+αy)²−4αyT².

When |y|=1, elementary multiplication gives

    Im[N(y) conjugate(Q(y))]/Im y
       = (1−α)[1+α²+2α cosφ+4αT²].                    (10)

Because Hα=N/(aQ), while h₀=(1+y)/a, their imaginary-part ratio is exactly (9). The density is −Im Hα/π.

For α≥0, every factor in the numerator of (9) is strictly positive. Thus this entire cut has positive density.



## 4. Positive atoms and Stieltjes representation for α≥0

When α=0, H₀=h₀ is already a positive Stieltjes function. Let 0<α<1.

On −1<y<−h, Dτ(y)<0 and hence Pα(y)>0. On −h<y<1, consider

    Rα(y) = b(1−αy)²/Dτ(y).

Its derivative is

    Rα′(y) = −b(1−αy)Jα(y)/Dτ(y)²,
    Jα(y) = 2[τ(1+α)(1+y)+2(1+αy)] > 0.              (11)

It decreases strictly from +∞ to b(1−α)²/[4(1+τ)]. Together with (7), this proves that there is precisely one physical-sheet pole if

    κ > κc(α) := b(1−α)²/[4α(1+τ)],                  (12)

and none if κ<κc(α). At equality the endpoint singularity is integrable and has no atom.

For κ>κc(α), let yα∈(−h,1) be the unique solution of

    κ = b(1−αyα)²/[αDτ(yα)].

The pole is at z=−xα, with

    xα = b(1+αyα)²/[αDτ(yα)] > 0.                    (13)

It lies to the right of the normal cut in the z-plane, equivalently 0<xα<κ+a₀. Its residue is

    rα = 2(1−yα)(1+αyα)
          /{(1−αyα)[τ(1+α)(1+yα)+2(1+αyα)]} > 0.    (14)

To obtain (14), use (6), multiply by q−q(yα), and apply (5) and (11). Every denominator is nonzero at this simple pole.

The resulting exact representation is

    Hα(z;κ) = ∫_{a₀}^b w(s)Mα(s,κ)/(z+κ+s) ds
               + 1_{κ>κc(α)} rα/(z+xα).             (15)

There is no contact term or omitted subtraction. For completeness, (15) follows by the elementary Cauchy contour around the finite slit and the enumerated simple pole: Hα=O(1/z), the generic endpoints are at worst inverse square roots, and at κ=κc(α) the y=1 singularity is still an inverse square root. Both sides therefore have the same jumps, poles, and infinity behavior, and their difference is zero.

All measures in (15) are positive. The α-integral in (1) therefore produces a positive measure by ordinary nonnegative Fubini. Its total weighted mass is finite, since the original expression (1) is finite at z=0. This proves reflection positivity for λ≥0, equivalently 0<β≤1. For each k the inverse normal transform is a positive mixture of exp(−√x |t|)/(2√x), so integration over k gives the full reflected positivity form.

No finite angular truncation is asserted to preserve this property. It is the exact infinite sum that produces (15).

## Scope and normalization

- The endpoint y=−1 corresponds quadratically to q=−b. For α≥0, Pα(−1)>0, so Hα has only an integrable inverse-square-root singularity there.
- The endpoint y=1 corresponds quadratically to q=−b/(1+τ). At the atom-emergence threshold, Pα has a simple zero in y there, giving an integrable inverse-square-root singularity. The atom residue tends to zero. No endpoint atom is omitted.
- The scalar normalization is ∫ρβdσ=1 and Fβ(0)=1/b; it also follows directly from ∫(vᵀBv)⁻²dσ=det(B)⁻¹/².
- For β<1 the top Hλ term develops a positive atom when κ>bβ/[(1−β)(1+τ)]. The integral in (1) also includes the positive poles of Hα across α∈[0,λ]. Restricting attention to the original radial cut would omit part of the measure.
- The covariance is invariant under the chosen mirror and tangential rotations. A nonconstant axial density is generally not invariant under axis permutations. No all-mirror or W₄-invariant nonradial counterexample is claimed.
- The result assumes b,τ>0 and a scalar covariance. It does not address a massless limit, tensor covariance, interacting reconstruction, or a Yang–Mills mass-gap construction.

### Final algebra audit

A direct symbolic simplification, without floating-point substitution, verified:

- the generating-density identity in (2);
- the derivative identity (11);
- the residue identity (14);
- q+b=bτ(1+y)²/Dτ(y), showing the y=−1 quadratic endpoint;
- q+b/(1+τ)=bτ(1−y)²/[(1+τ)Dτ(y)], showing the y=1 quadratic endpoint.

Every symbolic difference was identically zero. The sign proofs use the explicit inequalities above, not the symbolic checker.
