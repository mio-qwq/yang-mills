#!/usr/bin/env python3
"""Exact algebra regression checks. These do not replace the analytic proof."""
import argparse
import json
import sympy as s

p = argparse.ArgumentParser()
p.add_argument('--negative-control', action='store_true')
args = p.parse_args()
checks = []

def zero(name, expr):
    residual = s.factor(expr)
    if residual != 0:
        raise RuntimeError(f'{name}: exact residual {residual}')
    checks.append(name)

l, t, y, q, a, K, h, V, W = s.symbols('l t y q a K h V W', nonzero=True)
A, C = 1+l, 1-l
D = A*A-4*l*t*t
G = A/D
P = s.factor(G+2*l*s.diff(G,l))
rho = C*A**3/D**2
zero('poisson-generating-function', P-C*(A*A+4*l*t*t)/D**2)
zero('acg-generating-function', rho-(G+A*l*s.diff(G,l)))
zero('acg-positive-mixture-identity', rho-(A*P+C*G)/2)
for j in range(13):
    expected = 1+A*j
    if args.negative_control and j == 2:
        expected += 1
    zero(f'harmonic-mixture-coefficient-{j}', expected/s.Integer(2*j+1)-(A/s.Integer(2)+C/(2*s.Integer(2*j+1))))

R=(1-y)/(1+y)
tau=a*(R**2-1)/q
original=(1+y)/a*(1+l*y)/((1+l*y)**2-4*l*y*(q-K)/q)
closed=2*(A+C*R)/(A*A*a*R*R+C*C*a-4*l*tau*K+2*A*C*a*R)
zero('closed-T-formula', original-closed)

# Imaginary part of 2(A+i C h)/(V+i W), with d=a*h^2.
v=C*C*a-A*A*a*h*h-4*l*K
w=2*A*C*a*h
neg_im_numerator=2*(A*w-C*h*v)
positive_form=2*C*h*(A*A*a*h*h+(2*A*A-C*C)*a+4*l*K)
zero('signed-cut-density-numerator', neg_im_numerator-positive_form)
zero('cut-positive-coefficient', 2*A*A-C*C-(1+6*l+l*l))
zero('pole-positive-energy-coefficient', (1+s.Symbol('tau'))*A*A+C*C-4*l*s.Symbol('tau')-(A*A+(1+s.Symbol('tau'))*C*C))

L,wvar=s.symbols('L wvar', nonzero=True)
T2=(L+1)**2/(4*L)
zero('large-tangent-partial-fraction', (1+wvar)/((1+wvar)**2-4*wvar*T2)-(L/(1-wvar*L)-1/(1-wvar/L))/(L-1))
zero('negative-lambda-asymptotic-sign-factor', l**3*(2+l)-(1+2*l)+A**3*C)
zero('large-w-coefficient-one', (C-A)/2+l)
zero('large-w-coefficient-two', (C/s.Integer(3)-A)/2+(1+2*l)/3)
zero('small-w-coefficient-one', (A+C/s.Integer(3))/2-(2+l)/3)

print(json.dumps({'status':'PASS','exact_checks':len(checks),'checks':checks},indent=2))
