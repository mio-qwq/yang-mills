# Independent audit: finite harmonic angular densities

19 October 2026. Local mathematical audit; no remote writes.

## Verdict

The proposed harmonic-to-Stieltjes reduction is correct. The original two-mirror plus ultraviolet argument is valid, but a stronger result follows directly from single-mirror spectral positivity:

> Let `b>0`, `tau>0`, and let `rho` be a real finite spherical-harmonic sum on `S^3`, antipodally even and invariant under one Euclidean reflection `theta_n`. If the stationary multiplier
>
> `F(p)= integral rho(v)/(b+|p|^2+tau(p.v)^2) d sigma(v)`
>
> is covariance-reflection-positive at that mirror, then `rho` is a nonnegative constant.

Here `sigma` is normalized surface measure. Nonnegativity of `rho` may be retained as a natural density hypothesis, but it is not needed for this implication. No ultraviolet bound and no `W_4` symmetry are needed in the stronger proof. Finite harmonic degree is essential to the supplied argument.

The only correction to the proposed formulas is that the one-sided transformed formula for `lambda_l` is valid for **even** `l`. For odd `l`, `lambda_l=0`, while the displayed one-sided integral generally does not vanish.

## 1. Normalization and the change of variables

Write `rho(v)=sum_(r=0)^R H_(2r)(v)`, with real homogeneous harmonic polynomials. For `q=|p|^2>0`, Funk--Hecke with normalized `S^3` measure gives

`F(p)=sum_r H_(2r)(p) q^(-r) lambda_(2r)(q)`,

where

`lambda_l(q)=2/[pi(l+1)] integral_(-1)^1 sqrt(1-t^2) U_l(t)/[b+q(1+tau t^2)] dt`.

The factor `l+1` is `U_l(1)`, and the marginal density is `2 sqrt(1-t^2)/pi`. Thus the stated normalization is correct.

For even `l`, fold the integral to `0<t<1`, put

`s=b/(1+tau t^2)`, `a=b/(1+tau)`,

and note

`|dt/ds|=b/(2 tau t s^2)` and `b+q(1+tau t^2)=(b/s)(q+s)`.

This gives exactly

`lambda_l(q)=integral_a^b w(s) U_l(t(s))/(l+1)/(q+s) ds`,

`t(s)=sqrt((b-s)/(tau s))`,

`w(s)=2/(pi tau s) sqrt(((1+tau)s-b)/(b-s))`.

The weight is strictly positive on `(a,b)`. It is of order `(s-a)^(1/2)` at `a`, and of order `(b-s)^(-1/2)` at `b`. Multiplication by any fixed `s^(-r) U_(2r)(t(s))` preserves integrability, since `a>0` and the Chebyshev polynomial is bounded on `[0,1]`.

One normalization check is `integral w(s)/s ds=1/b`. The unweighted mass is `integral w(s) ds=2/(1+sqrt(1+tau))`; `w(s) ds` is positive but need not be a probability measure.

## 2. Moment cancellation and exact removal of zero poles

For `|q|<a`, expand the original angular denominator. The coefficient of `q^j` is a constant times the inner product of `U_(2r)(t)` with `(1+tau t^2)^j`. For `j<r`, this is zero by orthogonality, because the latter polynomial has degree `2j<2r`. Therefore

`lambda_(2r)(q)=O(q^r)`.

The mass interval has a positive gap, so differentiation under its Stieltjes integral is justified and yields

`integral_a^b w(s) U_(2r)(t(s))/(2r+1) s^(-j-1) ds=0`, for `0<=j<r`.

The exact finite identity

`1/(q+s)=sum_(j=0)^(r-1) (-q)^j/s^(j+1) + (-q)^r/[s^r(q+s)]`

then proves

`q^(-r)lambda_(2r)(q)=integral_a^b (-1)^r s^(-r) w(s) U_(2r)(t(s))/(2r+1)/(q+s) ds`.

Thus the sign and inverse-mass power are correct. This is an equality of ordinary functions for `q>0`, with continuous/analytic extension at `q=0`; no zero-mass pole, polynomial subtraction, or contact term is introduced.

Consequently

`P_s(p)=w(s)sum_(r=0)^R (-1)^r s^(-r) U_(2r)(t(s))/(2r+1) H_(2r)(p)`

gives `F(p)=integral_a^b P_s(p)/(q+s) ds`. Each `P_s` is harmonic, has degree at most `2R`, and inherits the relevant reflection symmetry. Its coefficient norm is integrable over the compact, gapped mass interval. Equality also holds in tempered distributions.

## 3. Independent low-degree and closed-form checks

For `q>0`, set

`A=b+q`, `C=b+(1+tau)q`,

`z=(sqrt(C)-sqrt(A))/(sqrt(C)+sqrt(A))`.

Direct Chebyshev/Fourier integration gives

`lambda_(2r)(q)= [2/(sqrt(A)(sqrt(A)+sqrt(C)))] (-z)^r/(2r+1)`.

In particular, every even harmonic eigenvalue is nonzero for `q>0`, and

`lambda_(2r)(q)=(-1)^r tau^r q^r/[4^r(2r+1)b^(r+1)] + O(q^(r+1))`.

Specific checks are

- `lambda_0(0)=1/b`;
- `lambda_2(q)=-tau q/(12b^2)+O(q^2)`;
- `lambda_4(q)=tau^2 q^2/(80b^3)+O(q^3)`.

These agree with `U_2=4t^2-1`, `U_4=16t^4-12t^2+1`, and the normalized semicircle moments. They confirm the denominator `2r+1`, the powers of `b`, and the alternating sign.

## 4. Applicability of the audited spectral positivity theorem

Use positive Lebesgue measure restricted to `(a,b)` as the base measure. There is a common finite degree bound and an integrable coefficient norm. A single finite stage already represents the whole multiplier, with zero contact subtraction. The residue integrability hypothesis is immediate on every compact tangential frequency set: the masses are bounded above and bounded away from zero, and residue evaluation only multiplies coefficients by bounded functions there.

The signed-residue extraction in Section 3 of the audited spectral theorem is mirrorwise and does not need invariant-ring arguments or `W_4`. At a mirror of `P_s`, polynomial dependence on normal momentum is even. Thus

`R_n(k,s)=P_s(i sqrt(|k|^2+s)n+k)`

is a real polynomial in tangential `k`. Reflection positivity implies that, outside one mass-null set,

`R_n(k,s)>=0` for every real tangential `k`.

All the representation and signed-measure integrability hypotheses used for this implication are satisfied here. In particular there is no conditional spectral sum or unproved interchange.

## 5. Stronger one-mirror rigidity

Suppose the highest nonzero positive harmonic degree is `L=2R>0`. Its spectral scalar is

`beta_L(s)=(-1)^R s^(-R) w(s) U_L(t(s))/(L+1)`.

For every fixed tangential `k`, homogeneity and the finite degree bound give

`T^(-L) R_n(Tk,s) -> beta_L(s) h_L(k)` as `T->infinity`,

where `h_L(k)=H_L(i|k|n+k)`.

Reflection invariance of `H_L` makes it even in its normal coordinate. Therefore `h_L` is a real homogeneous polynomial in `k`: every occurrence of the square root is raised to an even power.

This polynomial is nonzero. Indeed, write `H_L(un+k)=h(u^2,k)`. If its null-slice evaluation vanished for all real `k`, polynomial division in `u^2` would show that `u^2+|k|^2=q` divides `H_L`. A nonzero homogeneous harmonic polynomial cannot be divisible by `q`; a proof is given below.

Choose one fixed real `k_0` with `h_L(k_0) != 0`. The polynomial `U_(2R)` has `R` simple roots in `(0,1)` and takes both signs there. The map `s -> t(s)` is a continuous decreasing bijection from `(a,b)` to `(1,0)`. Hence `beta_L` takes both signs on open mass intervals, each of positive Lebesgue measure. Choose an interval on which `beta_L(s) h_L(k_0)<0`.

For almost every mass in that interval, masswise residue positivity gives `R_n(Tk_0,s)>=0` for every `T>0`, whereas its scaled limit is strictly negative. This is a contradiction. Thus no positive harmonic degree exists. Finally `P_s=w(s)H_0`, so residue positivity forces `H_0>=0`.

There is no exception at a zero of `U_L`: these are finitely many masses and are irrelevant. The case `L=0` is exactly the allowed constant case.

## 6. The harmonic-divisibility and quotient arguments

For homogeneous polynomials use the positive Fischer inner product, in which multiplication by `q=sum p_i^2` is adjoint to `Delta`. If a harmonic homogeneous polynomial is `Q=qG`, then

`||Q||_F^2 = <qG,Q>_F = <G,Delta Q>_F = 0`.

Thus `Q=0`. This proves the needed nondivisibility without any assumption about signs on the real null cone.

For the original two-mirror argument, suppose the audited ultraviolet theorem yields

`P_s=c_s+(q+s)G_s`.

Both `P_s` and `P_s-c_s` are harmonic. If `G_s` were nonzero and had highest homogeneous part `G_d`, the highest homogeneous part of `P_s-c_s` would be `qG_d`, and it would itself be harmonic. The preceding fact rules this out. Hence `G_s=0`, so `P_s` is constant. Comparing homogeneous degrees then annihilates every positive-degree `H_(2r)`, because its scalar factor is nonzero for almost every mass.

This quotient-to-harmonic step is valid even though `P_s` is not homogeneous.

## 7. Ultraviolet check for the original route

If `rho>=0`, then `0<=F(p)<=M/(b+|p|^2)`, with `M=integral rho d sigma`. The same absolute bound with `M=integral |rho| d sigma` holds for real signed densities. For a fixed compact smooth test and `f_d(x)=f(x/d)`, Fourier scaling and Cauchy--Schwarz give

`|B_C(theta_n f_d,f_d)| <= const d^6 integral |f_hat(k)|^2/|k|^2 dk = O(d^6)`.

The integral is finite in four dimensions. This is stronger than the audited theorem's `o(d^(-2))` condition. Thus the original two-mirror proof is also sound, although unnecessary once Section 5 is used.

## 8. Scope and invisible odd harmonics

The kernel is even under `v -> -v`. Therefore only `rho_even(v)=[rho(v)+rho(-v)]/2` is visible. Without antipodal symmetry, the conclusion can only be that this even part is constant. For example, with `n=e_0`, `rho(v)=1+epsilon v_1`, `|epsilon|<=1`, is nonnegative and invariant under that reflection, but is nonconstant and has exactly the same multiplier as the uniform density.

For `W_4`-invariant densities this caveat disappears, because antipodal symmetry is automatic. Nothing here establishes rigidity for arbitrary infinite harmonic series or singular angular measures; the highest-degree argument applies to finite harmonic sums.
