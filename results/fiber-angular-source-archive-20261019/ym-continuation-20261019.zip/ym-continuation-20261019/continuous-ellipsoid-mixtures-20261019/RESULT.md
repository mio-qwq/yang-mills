# Continuous rank-one ellipsoid mixtures with finite angular spectrum are rigid

19 October 2026. Local scalar-covariance research only. No repository, PR, release, or other external object was changed.

## Executive result

Let dσ be probability surface measure on S³. Fix m>0 and τ>0, and let ρ≥0 be a real W₄-invariant finite sum of spherical harmonics. Define

    q(p)=|p|²,
    F(p)=∫_{S³} ρ(v)/[q(p)+m²+τ(p·v)²] dσ(v).

Then:

1. F has an exact compact-mass spectral representation with a polynomial numerator at each mass, a common finite degree, bounded coefficient functions relative to an explicit finite positive measure, and no contact subtraction. The mass interval is [m²/(1+τ),m²].
2. The apparent powers of q⁻¹ in the harmonic separation cancel exactly by finitely many vanishing inverse-mass moments. There is no pole at q=0 and no missing massless or contact term.
3. All the hypotheses of the already audited finite-polynomial-per-mass theorem hold whenever the corresponding RP assumptions hold. The ultraviolet estimate is automatically O(d⁶), so that theorem forces rotational invariance.
4. In fact there is a stronger conclusion: RP at **any one** W₄ mirror already forces ρ to be constant. No ultraviolet assumption is needed for this stronger argument. The highest angular harmonic creates a mass-density coefficient with both signs; masswise RP positivity cannot accommodate it.
5. Conversely, a constant nonnegative ρ gives a positive radial Stieltjes covariance and RP at every reflection mirror. Thus, in this class, one-mirror RP, all-mirror RP, and constant angular density are equivalent.

This closes the specified finite-spherical-harmonic continuous-orbit boundary. It does not classify arbitrary angular densities, general continuous ellipsoid mixtures, tensor covariances, or interacting Yang–Mills limits.

## 1. Harmonic notation and normalization

Write the finite harmonic expansion as

    ρ(v)=Σ_{r=0}^R H_{2r}(v),       v∈S³,

where H_{2r} is a real homogeneous harmonic polynomial of degree 2r on R⁴. W₄ contains v↦−v, so all odd degrees vanish. Each harmonic component is W₄-invariant: orthogonal transformations preserve harmonic degree, and the unique harmonic projections commute with W₄. The constant H₀ equals ∫ρ dσ.

Let U_l be the Chebyshev polynomial of the second kind:

    U_l(cos θ)=sin((l+1)θ)/sin θ,
    U_l(1)=l+1.

Its weighted orthogonality is

    ∫_{−1}^1 U_l(t)U_j(t)√(1−t²) dt=(π/2)δ_lj.

This follows directly by t=cos θ and ordinary sine orthogonality. In particular U_{2r} is orthogonal, with this weight, to every polynomial of degree less than 2r.

For a unit vector e, the conditional spherical average of a harmonic polynomial is

    average[H_l(v) | e·v=t]=H_l(e) U_l(t)/(l+1).             (1)

For completeness, the average is a zonal spherical harmonic of degree l. The spherical Laplacian equation for its profile Y(t) is

    (1−t²)Y''−3tY'+l(l+2)Y=0.

There is a unique polynomial solution of degree at most l up to scale, namely U_l. Evaluating at t=1 fixes the normalization. The conditional distribution of t=e·v under probability surface measure on S³ has density (2/π)√(1−t²). This proves the needed Funk–Hecke identity rather than assuming its normalization.

Set b=m². For real q>0, (1) gives

    F(p)=Σ_{r=0}^R H_{2r}(p) q^(−r) M_r(q),               (2)

where

    M_r(q)=2/[π(2r+1)] ∫_{−1}^1
        U_{2r}(t)√(1−t²)/[b+q(1+τt²)] dt.                (3)

Only even degrees are being used in all subsequent one-sided change-of-variable formulas. The corresponding odd-degree integral in (3) would be zero.

## 2. Exact compact spectral measure

Put

    a=b/(1+τ),
    t(s)=√[(b−s)/(τs)],                 a<s<b,
    w(s)=2/(πτs) √[((1+τ)s−b)/(b−s)],
    μ(ds)=1_(a,b)(s) w(s) ds.

The measure μ is strictly positive on the open interval and finite. More precisely,

    w(s)=O((s−a)^(1/2)) as s↓a,
    w(s)=O((b−s)^(−1/2)) as s↑b.

There are no endpoint atoms. These statements follow directly from the displayed formula, since 0<a<b.

In (3), fold the even t-integral onto [0,1], then set

    s=b/(1+τt²),
    |dt/ds|=b/(2τt s²),
    1/[b+q(1+τt²)]=(s/b)/(q+s).

The result is the exact signed Stieltjes formula

    M_r(q)=∫_a^b [U_{2r}(t(s))/(2r+1)] μ(ds)/(q+s).       (4)

The numerator in square brackets is bounded on [a,b]. In fact U_{2r}(t(s)) is a polynomial in (b−s)/(τs), so it has a smooth extension to both endpoints.

## 3. All apparent zero-momentum poles cancel

The geometric expansion in q in (3) converges uniformly in t near q=0. Its jth Taylor coefficient is proportional to

    ∫_{−1}^1 U_{2r}(t)(1+τt²)^j√(1−t²) dt.

This vanishes whenever j<r, because (1+τt²)^j has degree 2j<2r. Therefore M_r has a zero of order at least r at zero. Equivalently, expanding (4),

    ∫_a^b [U_{2r}(t(s))/(2r+1)] s^(−j−1) μ(ds)=0,
                     j=0,…,r−1.                         (5)

All these are ordinary absolutely convergent integrals. The positive lower mass bound a is essential here.

For any integer r≥1, the finite algebraic identity

    q^(−r)/(q+s)
      =Σ_{j=0}^{r−1} (−1)^j s^(−j−1)q^(j−r)
        +(−1)^r s^(−r)/(q+s)                             (6)

holds when q≠0 and s≠0. Multiply (6) by the signed measure in (4) and use (5). Every negative power of q vanishes exactly. Thus

    A_r(q):=q^(−r)M_r(q)
      =∫_a^b α_r(s) μ(ds)/(q+s),
    α_r(s)=(−1)^r U_{2r}(t(s))/[(2r+1)s^r].               (7)

For r=0 the same formula holds with α₀=1. Each α_r is real, bounded, and smooth on the closed mass interval. Formula (7) is an ordinary finite signed Stieltjes transform.

In particular A_r is analytic on C\[−b,−a], including at q=0. There are no hidden poles, endpoint atoms, or polynomial additions. As a normalization check, the first surviving Taylor coefficient is

    A_r(0)=(−1)^r τ^r/[(2r+1)4^r b^(r+1)].                (8)

To verify (8), only the leading τ^r t^(2r) term survives at Taylor order r; the coefficient of U_{2r} in t^(2r) is 4^(−r), and its weighted squared norm is π/2. In particular the separated harmonic multiplier is not identically zero at any degree.

### Boundary jumps, with no contour assumption

The density γ_r(s)=α_r(s)w(s) is smooth in the interior and integrable at both endpoints. For a<s<b,

    Im A_r(−s+iε)
      =−∫_a^b ε γ_r(t)/[(t−s)²+ε²] dt
      →−π γ_r(s).

This is the ordinary approximate-identity limit. The corresponding difference between upper and lower boundary values is −2πiγ_r(s); the real boundary value is the usual principal-value integral. Hence the claimed signed jumps are precisely the integrable densities already constructed algebraically. No contour at q=0, an endpoint, or infinity was discarded.

## 4. Exact finite-polynomial-per-mass representation

Define

    P_s(p)=Σ_{r=0}^R α_r(s) H_{2r}(p).                   (9)

Combining (2) and (7) gives, first for q>0 and then by continuity at p=0,

    F(p)=∫_a^b P_s(p)/(q(p)+s) μ(ds).                    (10)

Every P_s is a real W₄-invariant harmonic polynomial, with degree at most 2R. Its coefficient norm is uniformly bounded in s. Thus (10) is absolutely convergent for every real p and defines a tempered multiplier. The equality is exact as functions and consequently as tempered distributions.

This verifies the spectral theorem's hypotheses E and R concretely:

- μ is a finite positive measure on the compact positive mass interval [a,b].
- The degree has one finite bound and the coefficient norm is μ-integrable.
- The exhaustion can be constant, E_j=[a,b], with K_j=0. No finite or infinite contact subtraction occurs.
- At any W₄ mirror n, write p=un+k with k⊥n. Since P_s is invariant under u↦−u, the residue

      R_n(k,s)=P_s(i√(|k|²+s)n+k)

  is a real polynomial in k. On every compact k-set it is uniformly bounded in s. The gap a>0 bounds 1/√(|k|²+s), and μ is finite. Therefore all local exponential total-variation estimates required by R hold, including at k=0.

The original integral also directly supplies ordinary covariance positivity and temperedness:

    0≤F(p)≤(∫ρ dσ)/(q(p)+b)≤(∫ρ dσ)/q(p),     p≠0.     (11)

It is W₄-invariant by a change of variable on S³. Its inverse Fourier transform is a stationary real tempered covariance.

## 5. The requested RP-plus-ultraviolet reduction

Let f_d(x)=f(x/d), where f is a fixed compact smooth test. By ordinary covariance Cauchy–Schwarz and (11),

    |B_C(θ_n f_d,f_d)|≤const_f d⁶.                       (12)

Indeed, its ordinary covariance norm is bounded by a constant times

    ∫ |p|^(−2)|d⁴ f̂(dp)|² dp
      =d⁶ ∫ |ξ|^(−2)|f̂(ξ)|² dξ,

which is finite in dimension four. The reflected test has the same estimate. Therefore the required o(d^(−2)) hypothesis is automatic.

If RP holds at the coordinate and diagonal representative mirrors, the audited theorem in the companion input `spectral-degree-boundary-20261019/RESULT.md` applies. It yields, for μ-almost every s,

    P_s(p)=c_s+(q(p)+s)G_s(p),         c_s≥0.             (13)

In the present class (13) actually forces P_s to be constant. If its highest nonconstant homogeneous part has degree L, that part is harmonic by (9). Equation (13) makes it divisible by q. A nonzero homogeneous harmonic polynomial cannot be divisible by q. This standard fact also follows from orthogonality on the sphere: a degree-L harmonic is orthogonal to every restriction of a polynomial of degree less than L, whereas H=qG would restrict to the degree-(L−2) polynomial G on S³. Its squared norm would then vanish.

Thus α_r(s)H_{2r}=0 at every positive degree for almost every s. But U_{2r}(t(s)) has only finitely many zeros in (a,b), and α_r is otherwise nonzero. Since μ is strictly positive there, every H_{2r} with r≥1 vanishes. Hence ρ=H₀ is constant.

This establishes the requested reduction without relying on the stronger result below.

## 6. A self-contained one-mirror strengthening

The same representation proves that RP at a single W₄ mirror already forces the conclusion. This needs only the masswise signed-residue extraction, not the ultraviolet part of the companion theorem. A proof of that extraction in this compact-mass setting follows, to make the strengthening independently checkable.

### 6.1 RP forces masswise residue positivity

Fix a mirror n. Polynomial division in u² gives

    P_s(un+k)=[u²+|k|²+s]B_s(u,k)+R_n(k,s).               (14)

The integrated polynomial B_s contributes a distribution supported at the origin, and hence contributes zero to any pairing of strictly separated reflected tests. Degree and coefficient bounds justify this division and integration as ordinary finite polynomial operations.

For positive times T the inverse normal transform is therefore

    K_k(T)=∫_a^b e^(−ωT) R_n(k,s)/(2ω) μ(ds),
    ω=√(|k|²+s).                                        (15)

For each k this is a continuous function of T, and it depends continuously on k. The same holds for scalar reflected forms of compact smooth time tests h. All assertions follow from compact mass support, a>0, finite degree, and finite μ.

If one such scalar reflected form were negative at some k, continuity would make it negative on an open tangential neighborhood. A smooth Fourier cutoff in that neighborhood would give a negative four-dimensional reflected form. Its inverse tangential transform is Schwartz; smooth spatial cutoffs converge in Schwartz topology to a compact smooth half-space test with the same strict negative sign. Therefore full RP implies, at every fixed real k,

    ∫ |∫_0^∞ h(t)e^(−ωt)dt|² ν_k(dω)≥0,                (16)

where ν_k is the finite signed measure obtained from

    R_n(k,s) μ(ds)/(2√(|k|²+s))

by the injective change s↦ω. Point-time masses at t₀,t₀+1,…,t₀+N, t₀>0, are limits of admissible smooth bumps. Thus (16) implies

    ∫ e^(−2t₀ω)|P(e^(−ω))|² ν_k(dω)≥0                   (17)

for every polynomial P. Push the finite signed measure e^(−2t₀ω)ν_k forward under x=e^(−ω). It is supported on a compact interval with positive endpoints. Uniform polynomial approximation of the square root of any nonnegative continuous function shows from (17) that the pushed measure is positive. Both the change of variable and damping are invertible and strictly positive on this support. Consequently ν_k is positive, and

    R_n(k,s)≥0 for μ-almost every s, for each k.          (18)

For use simultaneously in k, intersect the full-measure sets in (18) for a countable dense set of k's. Polynomial continuity in k then upgrades (18) to every k outside a single mass-null set. This avoids any uncountable intersection.

### 6.2 The highest angular degree has an unavoidable changing sign

Suppose R≥1 is the largest index with H_{2R} nonzero. Define

    L_n(k)=H_{2R}(i|k|n+k).

This is a real homogeneous polynomial in k: reflection invariance makes H_{2R}(un+k) even in u, so evaluating u²=−|k|² introduces no square root.

The polynomial L_n is not identically zero. If it were zero, division of H_{2R}(un+k) by u²+|k|² would have zero remainder, so q would divide H_{2R}. The harmonic nondivisibility fact used in Section 5 rules this out. Hence choose k₀ with L_n(k₀)≠0.

The leading tangential scaling term of the mass residue is

    lim_{T→∞} T^(−2R)R_n(Tk₀,s)=α_R(s)L_n(k₀).           (19)

This follows by homogeneity and finite polynomial expansion; the terms involving s or lower harmonic degrees carry lower powers of T. Masswise positivity (18), applied along positive integer T, implies

    α_R(s)L_n(k₀)≥0 for μ-almost every s.                 (20)

But α_R takes both signs on open mass intervals. Indeed U_{2R} has R simple roots in (0,1), namely

    cos(jπ/(2R+1)),        j=1,…,R,

and changes sign across each one. The map s↦t(s) is a continuous bijection from (a,b) onto (1,0), while the other factors in α_R have a fixed nonzero sign. Every one of the resulting open sign intervals has strictly positive μ-measure.

Since L_n(k₀) is a fixed nonzero real number, (20) is impossible. Thus there is no positive-degree harmonic and ρ is constant.

### 6.3 What a negative test looks like

This proof identifies the obstruction rather than merely invoking an abstract theorem. Choose a compact interior mass interval J on which α_R(s)L_n(k₀)≤−η<0. The lower powers in (19) are uniformly bounded on J, so for sufficiently large finite T,

    R_n(Tk₀,s)<0 on J.

The signed measure ν_{Tk₀} therefore has a negative part on the corresponding energy interval. Choose a nonnegative continuous function supported in that interval with strictly negative integral, and approximate its square root after the positive damping in (17) by a polynomial in e^(−ω). The resulting finite real time coefficients give a strictly negative Hankel form. Smooth time bumps, tangential frequency localization, and tangential spatial cutoffs produce a legal compact smooth reflected test with strictly negative form. No numerical eigenvalue inference or distribution at a coincident point is used.

## 7. Constant density: exact radial covariance and converse

If ρ=c≥0, equations (7) and (10) reduce to

    F(p)=c∫_a^b μ(ds)/(q(p)+s).                          (21)

This is a positive mixture of ordinary radial massive resolvents, so it has RP at every Euclidean reflection mirror. Its explicit multiplier is

    F(p)=2c/[b+q+√((b+q)(b+(1+τ)q))].                   (22)

The square root is positive for real q≥0. One elementary evaluation is to set t=cos θ in (3) at r=0, write sin²θ=1−cos²θ, and use the substitution x=tan θ to evaluate the resulting integrals of 1/(A+B cos²θ). Formula (22) has value c/b at q=0 and asymptotic coefficient 2c/(1+√(1+τ)) times q⁻¹.

Every individual ellipsoid I+τvvᵀ is anisotropic when τ>0. Thus continuous uniform averaging really does yield an all-mirror RP radial covariance although the corresponding finite-mixture theorem forbids anisotropic components in any finite positive mixture. There is no contradiction: shifted poles can reorganize into a radial cut under continuous averaging, and the finite-pole no-cancellation proof does not extend term by term to this orbit integral.

For nonconstant finite-harmonic W₄ density, the same continuous averaging produces a perfectly valid ordinary positive covariance obeying O(d⁶), but it fails RP at every W₄ mirror individually.

## 8. Contacts and exact limits of scope

- No contact term was needed to obtain (10). The signed cancellations occur between finitely many inverse-mass moments inside each radial coefficient, before the Fourier/distributional step.
- Adding any origin-supported contact distribution cannot repair a failed RP test. Every strictly separated reflection pairing with such a distribution is zero. Consequently the rigidity conclusion for the displayed mixture survives arbitrary contact additions whenever the relevant covariance/reflection assumptions are imposed; an added anisotropic contact itself need not be radial.
- Finite angular degree is essential to the present proof. It provides a polynomial numerator family and a highest nonzero harmonic. This result does not claim that the highest-degree argument survives an infinite harmonic expansion, or that its coefficient and distributional interchanges would converge.
- The lower mass gap m>0 and τ>0 are part of the theorem. The factors s^(−r), moment identities, and spectral interval used here do not automatically extend to m=0. At τ=0 the denominator is independent of v, and no conclusion identifying ρ itself can hold.
- For a density not assumed antipodally even, the odd part is invisible to F. The argument could identify only its even part. W₄ invariance removes that ambiguity here.
- The stronger one-mirror proof uses antipodal evenness and invariance under that mirror; the rest of W₄ is unnecessary for that argument. It does not claim RP without reflection invariance, nor classify arbitrary continuous orbit measures or general nonpolynomial scalar covariances.
- This is a scalar Gaussian two-point obstruction. It does not establish a spectral representation for an interacting Yang–Mills limit, prove a mass gap, or prove full Euclidean reconstruction for a gauge theory.

## Companion input

The requested spectral-class application uses the already audited finite-polynomial-per-mass result in `spectral-degree-boundary-20261019/RESULT.md`. The compact-mass reduction, moment cancellation, exact density, and one-mirror strengthening above are proved directly here. No niche literature assertion or unverified external source is required for these calculations; the only general ingredients are elementary spherical harmonics, Fourier transforms, polynomial approximation, and standard finite signed-measure facts.

## Local audit and exact regression checks

An independent mathematical check is recorded in `AUDIT.md`. It verifies the Jacobian, moment cancellations, endpoint integrability, quotient-to-harmonic argument, and stronger one-mirror theorem. Its even-degree qualification is already incorporated throughout this report.

The standard-library script `check_exact_identities.py` uses only integer arithmetic and `fractions.Fraction`. It checks the formal two-variable partial-fraction polynomial identity for r=0,…,12, the vanishing moments using normalized semicircle moments Catalan(j)/4^j, the first surviving coefficient A_r(0), and Chebyshev normalization. The saved run `exact-checks.json` reports PASS: 13 formal identities, 312 vanishing-moment checks, 39 coefficient checks, and 13 norm checks, through harmonic degree 24. These are regression tests, not substitutes for the all-r proofs above.

All executable checks use explicit `require` calls that raise `RuntimeError`; Python optimization cannot remove them. The companion `verify_regression_modes.py` verifies byte-identical successful arithmetic reports under ordinary Python and `python -O`. It also deliberately changes the expected r=2 coefficient from 1/80 to 81/80 and verifies that both modes fail with the intended coefficient-mismatch error and never print PASS. The harness itself was also run under `-O` with identical output. `regression-validation.json` records these checks.

Reproduce the arithmetic and harness checks from this directory:

    python check_exact_identities.py
    python verify_regression_modes.py
    python -O verify_regression_modes.py

For manual negative controls, both commands below must exit nonzero:

    python check_exact_identities.py --negative-control
    python -O check_exact_identities.py --negative-control
