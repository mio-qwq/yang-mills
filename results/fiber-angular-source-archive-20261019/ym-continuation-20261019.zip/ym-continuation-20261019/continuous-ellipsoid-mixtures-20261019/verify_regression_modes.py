#!/usr/bin/env python3
"""Exercise exact checks normally, under -O, and with a deliberate bad expectation.

Uses only the standard library and the adjacent, locally authored checker.
Writes no files; print the validation report to stdout.
"""
import json
from pathlib import Path
import subprocess
import sys


def require(condition, message):
    if not condition:
        raise RuntimeError(message)


def run(optimized=False, negative=False):
    checker = Path(__file__).with_name("check_exact_identities.py")
    command = [sys.executable]
    if optimized:
        command.append("-O")
    command.append(str(checker))
    if negative:
        command.append("--negative-control")
    return subprocess.run(command, capture_output=True, text=True, check=False)


def main():
    normal = run()
    optimized = run(optimized=True)
    for label, result in [("normal", normal), ("optimized", optimized)]:
        require(result.returncode == 0, f"{label} arithmetic run failed: {result.stderr}")
        require(not result.stderr, f"{label} arithmetic run wrote unexpected stderr")
        report = json.loads(result.stdout)
        require(report.get("status") == "PASS", f"{label} arithmetic run did not report PASS")
    require(normal.stdout == optimized.stdout, "Normal and optimized arithmetic reports differ")
    negative_results = {}
    for optimized_mode, label in [(False, "normal"), (True, "optimized")]:
        result = run(optimized=optimized_mode, negative=True)
        require(result.returncode != 0, f"{label} deliberate tamper was not rejected")
        require("A_r(0) coefficient mismatch: r=2, b=1, tau=1, actual=1/80, expected=81/80"
                in result.stderr, f"{label} tamper failed for an unexpected reason")
        require('"status": "PASS"' not in result.stdout,
                f"{label} tamper incorrectly printed PASS")
        negative_results[label] = {
            "returncode": result.returncode,
            "expected_failure": "A_r(0) coefficient mismatch: actual=1/80, expected=81/80",
            "printed_PASS": False,
        }
    print(json.dumps({
        "status": "PASS",
        "normal_and_optimized_output_identical": True,
        "arithmetic_report": json.loads(normal.stdout),
        "deliberate_expected_coefficient_tamper": negative_results,
        "checks_use_explicit_RuntimeError": True,
        "scope": "Regression harness validation only; the all-degree proof remains primary."
    }, indent=2))


if __name__ == "__main__":
    main()
