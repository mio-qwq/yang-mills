#!/usr/bin/env python3
"""Exact finite regression checks, using only the Python standard library.

These checks complement, and do not replace, the all-degree proof in RESULT.md.
No network, files outside this directory, or external executable is required.
"""
from fractions import Fraction
from math import comb
import json
import argparse


def require(condition, message):
    """Never elided by python -O: a failed check always stops the run."""
    if not condition:
        raise RuntimeError(message)


def add(p, q):
    r = [Fraction(0)] * max(len(p), len(q))
    for i, a in enumerate(p):
        r[i] += a
    for i, a in enumerate(q):
        r[i] += a
    return r


def scale(p, a):
    return [a * x for x in p]


def mul(p, q):
    r = [Fraction(0)] * (len(p) + len(q) - 1)
    for i, a in enumerate(p):
        for j, b in enumerate(q):
            r[i + j] += a * b
    return r


def power(p, n):
    r = [Fraction(1)]
    for _ in range(n):
        r = mul(r, p)
    return r


def chebyshev_u(n):
    if n == 0:
        return [Fraction(1)]
    prev, curr = [Fraction(1)], [Fraction(0), Fraction(2)]
    for _ in range(1, n):
        prev, curr = curr, add(mul([0, 2], curr), scale(prev, -1))
    return curr


def semicircle_moment(n):
    """Integral t^n (2/pi)sqrt(1-t^2) dt over [-1,1]."""
    if n % 2:
        return Fraction(0)
    k = n // 2
    catalan = comb(2 * k, k) // (k + 1)
    return Fraction(catalan, 4 ** k)


def semicircle_average(p):
    return sum((a * semicircle_moment(i) for i, a in enumerate(p)), Fraction(0))


def monomial_shift(p, n):
    return [Fraction(0)] * n + p


def check_partial_fraction_polynomial_identity(r):
    # Identity (6), multiplied by q^r(q+s)s^r, reads:
    # s^r = sum_{j<r}(-1)^j s^(r-j-1)q^j(q+s) + (-1)^r q^r.
    # Store the exact polynomial in independent formal variables q and s.
    rhs = {}
    def put(q_degree, s_degree, coefficient):
        key = (q_degree, s_degree)
        rhs[key] = rhs.get(key, 0) + coefficient
    for j in range(r):
        put(j + 1, r - j - 1, (-1) ** j)
        put(j, r - j, (-1) ** j)
    put(r, 0, (-1) ** r)
    rhs = {key: value for key, value in rhs.items() if value}
    require(rhs == {(0, r): 1}, f"Partial-fraction identity mismatch: r={r}, rhs={rhs}")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--negative-control", action="store_true",
                        help="Deliberately corrupt one expected coefficient; this run must fail.")
    args = parser.parse_args()
    max_r = 12
    moment_checks = 0
    coefficient_checks = 0
    parameter_pairs = [
        (Fraction(1), Fraction(1)),
        (Fraction(3, 2), Fraction(2, 3)),
        (Fraction(7, 5), Fraction(11, 4)),
    ]
    for r in range(max_r + 1):
        check_partial_fraction_polynomial_identity(r)
        u = chebyshev_u(2 * r)
        # Orthogonality against all even powers below degree 2r. These
        # exactly imply every inverse-mass cancellation for arbitrary tau.
        for k in range(r):
            require(semicircle_average(monomial_shift(u, 2 * k)) == 0,
                    f"Semicircle orthogonality mismatch: r={r}, k={k}")
            moment_checks += 1
        require(semicircle_average(monomial_shift(u, 2 * r)) == Fraction(1, 4 ** r),
                f"Leading semicircle moment mismatch: r={r}")
        require(semicircle_average(mul(u, u)) == 1,
                f"Chebyshev norm mismatch: r={r}")
        for b, tau in parameter_pairs:
            c = [Fraction(1), Fraction(0), tau]
            for j in range(r):
                # Integral [U_2r/(2r+1)] s^(-j-1) mu(ds), after the
                # proven change of variables, is this exact expectation.
                inverse_mass_moment = semicircle_average(mul(u, power(c, j)))
                inverse_mass_moment /= (2 * r + 1) * b ** (j + 1)
                require(inverse_mass_moment == 0,
                        f"Inverse-mass moment mismatch: r={r}, j={j}, b={b}, tau={tau}")
                moment_checks += 1
            # The first nonzero Taylor coefficient of M_r is A_r(0).
            actual = ((-1) ** r) * semicircle_average(mul(u, power(c, r)))
            actual /= (2 * r + 1) * b ** (r + 1)
            expected = Fraction((-1) ** r, (2 * r + 1) * 4 ** r)
            expected *= tau ** r / b ** (r + 1)
            if args.negative_control and r == 2 and (b, tau) == parameter_pairs[0]:
                expected += 1  # Intentional tamper to prove failure detection.
            require(actual == expected,
                    f"A_r(0) coefficient mismatch: r={r}, b={b}, tau={tau}, "
                    f"actual={actual}, expected={expected}")
            coefficient_checks += 1
    print(json.dumps({
        "status": "PASS",
        "maximum_r": max_r,
        "maximum_harmonic_degree": 2 * max_r,
        "formal_partial_fraction_identities": max_r + 1,
        "exact_vanishing_moment_checks": moment_checks,
        "exact_A_r_zero_checks": coefficient_checks,
        "normalized_Chebyshev_norm_checks": max_r + 1,
        "arithmetic": "fractions.Fraction and exact integer coefficients",
        "scope": "Finite regression checks; the general theorem is proved in RESULT.md."
    }, indent=2))


if __name__ == "__main__":
    main()
