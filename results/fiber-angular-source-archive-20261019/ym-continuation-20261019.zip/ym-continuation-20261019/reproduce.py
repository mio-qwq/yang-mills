#!/usr/bin/env python3
"""Verify the finite-harmonic local checkpoint; only adjacent local checks run."""
from pathlib import Path
import hashlib
import json
import os
import subprocess
import sys

ROOT = Path(__file__).resolve().parent
MODULE = ROOT/'continuous-ellipsoid-mixtures-20261019'


def require(ok, message):
    if not ok:
        raise RuntimeError(message)


def main():
    count = 0
    for line in (ROOT/'SHA256SUMS').read_text().splitlines():
        expected, name = line.split('  ',1)
        path = ROOT/name
        require(path.resolve().is_relative_to(ROOT), 'Unsafe manifest path')
        require(path.is_file() and hashlib.sha256(path.read_bytes()).hexdigest() == expected,
                'Integrity mismatch: '+name)
        count += 1
    env = dict(os.environ, PYTHONDONTWRITEBYTECODE='1', PYTHONHASHSEED='0')
    env.pop('PYTHONOPTIMIZE',None)
    reports = {}
    for filename, receipt in [('check_exact_identities.py','exact-checks.json'),
                              ('verify_regression_modes.py','regression-validation.json')]:
        outputs = []
        for mode in ([],['-O']):
            r = subprocess.run([sys.executable]+mode+[filename],cwd=MODULE,env=env,
                               capture_output=True,text=True)
            require(r.returncode == 0 and not r.stderr, filename+' failed: '+r.stderr)
            require(json.loads(r.stdout) == json.loads((MODULE/receipt).read_text()),
                    filename+' differs from saved receipt')
            outputs.append(r.stdout)
        require(outputs[0] == outputs[1], filename+' differs under optimization')
        reports[filename] = {'normal_and_optimized_output_identical':True,
                             'stdout_sha256':hashlib.sha256(outputs[0].encode()).hexdigest()}
    print(json.dumps({'status':'PASS','integrity_files_checked':count,'checks':reports,
        'deliberate_tamper_rejected_in_normal_and_optimized_python':True,
        'runtime_dependencies':'Python standard library only',
        'scope':'Finite regression checks support the written all-degree one-mirror theorem; no infinite angular or interacting Yang-Mills result.'},indent=2))

if __name__ == '__main__':
    main()
