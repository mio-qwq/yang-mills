# Local finite-harmonic ellipsoid recovery checkpoint

This local-only snapshot preserves the finalized proof, independent and root
reviews, and hardened exact regressions for continuous rank-one ellipsoid
mixtures on S^3 with positive m and tau and a finite even angular harmonic sum.
Reflection positivity at one invariant mirror forces the density to be a
nonnegative constant; constant nonnegative density gives the radial positive
Stieltjes converse. In particular this applies to finite-harmonic W4-invariant
nonnegative densities. The theorem is a scalar covariance result.

## Reproduction

Requires Python 3.10 or later, standard library only. From this extracted folder:

    python reproduce.py
    python -O reproduce.py

Each command checks all file hashes, runs the exact arithmetic and regression
harness under ordinary and optimized Python, and compares the saved receipts.
The harness deliberately changes the r=2 expected coefficient from 1/80 to 81/80;
both modes must reject that tamper and must not print PASS for the bad run.
All executable validations use explicit exceptions, so optimization cannot
remove them. These checks write no files and need no network or external tools.

The underlying direct commands, from continuous-ellipsoid-mixtures-20261019, are:

    python check_exact_identities.py
    python verify_regression_modes.py
    python -O verify_regression_modes.py

The general all-degree proof is in RESULT.md. The finite exact regressions cover
harmonic degree at most 24 and complement, rather than replace, the proof.
AUDIT.md and ROOT_REVIEW.md record the independent and root mathematical reviews.

## Dependency and scope boundaries

The stronger one-mirror argument in RESULT.md Section 6 is self-contained. The
optional two-mirror plus ultraviolet route in Section 5 cites the earlier
neighboring spectral-degree-boundary-20261019/RESULT.md. That earlier theorem is
not included and is unnecessary for the stronger conclusion preserved here.

All seven author/root-approved input files are byte-for-byte copies; hashes and
original locations are recorded in CHECKPOINT_MANIFEST.json. No binaries or
caches are included. No infinite angular expansion, general continuous ellipsoid
classification, interacting Yang-Mills construction, or mass gap is claimed.
Other ongoing structural work is excluded.
